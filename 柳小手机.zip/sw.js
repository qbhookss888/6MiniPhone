/* 清柳 小手机 Service Worker —— 仅缓存壳层文件以支持 PWA 安装，不接管运行时资源。 */
const CACHE_NAME = "qwq-phone-shell-v1";
const SHELL = [
  "./index.html",
  "./manifest.json"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL)).catch(() => undefined)
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))).catch(() => undefined)
  );
  self.clients.claim();
});

// 不做离线接管：所有 App 模块始终走网络，避免陈旧缓存。
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  if (event.request.mode === "navigate") {
    event.respondWith(fetch(event.request).catch(() => caches.match("./index.html")));
  }
});
