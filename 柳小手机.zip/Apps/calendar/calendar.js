(() => {
  "use strict";

  const db = window.ThemeCustomization?.db;
  if (!db) throw new Error("清柳 Calendar requires ThemeCustomization.db");

  const WEEKDAYS = Object.freeze(['日', '一', '二', '三', '四', '五', '六']);
  const WEEKDAYS_EN = Object.freeze(['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']);

  function pad2(value) { return String(value).padStart(2, '0'); }
  function dateKey(date) {
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
  }
  function parseDateKey(key) {
    const [year, month, day] = key.split('-').map(Number);
    return new Date(year, month - 1, day);
  }
  function shiftDate(date, amount) {
    const next = new Date(date);
    next.setDate(next.getDate() + amount);
    return next;
  }
  function startOfWeek(date) {
    const dayOffset = (date.getDay() + 6) % 7;
    return shiftDate(date, -dayOffset);
  }
  function lunarDayLabel(date) {
    try {
      return new Intl.DateTimeFormat('zh-CN-u-ca-chinese', { day: 'numeric' }).format(date);
    } catch (_) {
      return '农历';
    }
  }
  function escapeHTML(value) {
    return String(value).replace(/[&<>'"]/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    })[char]);
  }

  const CalendarController = (() => {
    const state = {
      tab: 'calendar',
      cursor: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
      selectedDate: dateKey(new Date()),
      items: [],
      close: null,
      host: null,
      toastTimer: 0,
      swipeStart: null,
      ignoreDateClickUntil: 0,
      monthMotion: '',
      yearPickerOpen: false
    };

    function demoItems() {
      const today = new Date();
      return [
        { id: 'demo-1', date: dateKey(today), time: '09:30', end: '10:10', title: '晨间计划', meta: '专注 · 今日优先', type: 'plan' },
        { id: 'demo-2', date: dateKey(today), time: '14:00', end: '15:00', title: '项目整理', meta: '工作 · 线上', type: 'work' },
        { id: 'demo-3', date: dateKey(shiftDate(today, 1)), time: '18:30', end: '19:10', title: '轻运动', meta: '健康 · 40 分钟', type: 'health' },
        { id: 'demo-4', date: dateKey(shiftDate(today, 3)), time: '11:00', end: '11:30', title: '本周复盘', meta: '个人 · 清单', type: 'review' }
      ];
    }

    function allItems() {
      return [...demoItems(), ...state.items].sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
    }

    function selectedItems() {
      return allItems().filter(item => item.date === state.selectedDate);
    }

    function frameTemplate() {
      return `
        <article class="calendar-app" aria-label="日历应用">
          <header class="calendar-nav">
            <div class="calendar-nav-left">
                    <div class="calendar-brand">
                <button class="calendar-brand-name global-page-title" type="button" data-calendar-brand-name data-calendar-action="close" aria-label="返回主屏幕">Calendar.</button>
              </div>
            </div>
            <div class="calendar-nav-actions">
              <button class="calendar-icon-button" type="button" data-calendar-action="search" aria-label="搜索行程"><i data-lucide="search"></i></button>
              <button class="calendar-icon-button" type="button" data-calendar-action="add" aria-label="添加行程"><i data-lucide="plus"></i></button>
              <button class="calendar-icon-button" type="button" data-calendar-action="settings" aria-label="日历设置"><i data-lucide="settings"></i></button>
            </div>
          </header>

          <main class="calendar-body">
            <section class="calendar-view" data-calendar-view="calendar" aria-label="日历"></section>
            <section class="calendar-view" data-calendar-view="schedule" aria-label="行程"></section>
            <section class="calendar-view" data-calendar-view="health" aria-label="健康"></section>
          </main>

          <nav class="calendar-dock" aria-label="日历应用导航">
            <button class="calendar-dock-button" type="button" data-calendar-tab="calendar" aria-label="日历">
              <i data-lucide="calendar-days"></i><span class="calendar-dock-label">CALENDAR</span>
            </button>
            <button class="calendar-dock-button" type="button" data-calendar-tab="schedule" aria-label="行程">
              <i data-lucide="list-checks"></i><span class="calendar-dock-label">SCHEDULE</span>
            </button>
            <button class="calendar-dock-button" type="button" data-calendar-tab="health" aria-label="健康">
              <i data-lucide="heart-pulse"></i><span class="calendar-dock-label">HEALTH</span>
            </button>
          </nav>
          <div class="calendar-toast" role="status" aria-live="polite" data-calendar-toast></div>
        </article>`;
    }

    function calendarTemplate() {
      const year = state.cursor.getFullYear();
      const month = state.cursor.getMonth();
      const first = new Date(year, month, 1);
      const start = new Date(year, month, 1 - first.getDay());
      const todayKey = dateKey(new Date());
      const eventDates = new Set(allItems().map(item => item.date));
      const cells = Array.from({ length: 42 }, (_, index) => {
        const day = shiftDate(start, index);
        const key = dateKey(day);
        const classes = [
          'calendar-day',
          day.getMonth() !== month ? 'is-outside' : '',
          key === todayKey ? 'is-today' : '',
          key === state.selectedDate ? 'is-selected' : '',
          eventDates.has(key) ? 'has-event' : ''
        ].filter(Boolean).join(' ');
        return `<button class="${classes}" type="button" data-calendar-date="${key}" aria-label="${year}年${day.getMonth() + 1}月${day.getDate()}日">${day.getDate()}</button>`;
      }).join('');
      const chosen = parseDateKey(state.selectedDate);
      const chosenKey = dateKey(chosen);
      const dayOrder = Math.floor((Date.UTC(chosen.getFullYear(), chosen.getMonth(), chosen.getDate()) - Date.UTC(chosen.getFullYear(), 0, 0)) / 86400000);
      const monthEN = new Intl.DateTimeFormat('en-US', { month: 'short' }).format(chosen).toUpperCase();
      const dayName = `星期${WEEKDAYS[chosen.getDay()]}`;
      const motionClass = state.monthMotion ? ` is-${state.monthMotion}` : '';
      return `
        <div class="month-surface${motionClass}" data-month-swipe aria-label="左右滑动切换月份">
          <div class="month-toolbar">
            <div class="month-label">${month + 1}月</div>
            <button class="month-year" type="button" data-calendar-action="year" aria-expanded="${state.yearPickerOpen}">${year}</button>
          </div>
          ${state.yearPickerOpen ? yearPickerTemplate(year) : ''}
          <div class="weekday-row" aria-hidden="true">${WEEKDAYS.map(day => `<span class="weekday">${day}</span>`).join('')}</div>
          <div class="month-grid">${cells}</div>
        </div>
        <div class="section-heading"><h2>${chosenKey === todayKey ? '今天' : '当天'}</h2><span>${chosen.getFullYear()} · ${pad2(chosen.getMonth() + 1)} · ${pad2(chosen.getDate())}</span></div>
        <section class="day-summary" aria-label="当天日期摘要">
          <span class="day-summary-date"><strong>${pad2(chosen.getDate())}</strong><span>${monthEN}</span></span>
          <span class="day-summary-copy"><span class="day-summary-title">${dayName}</span><span class="day-summary-meta">${escapeHTML(lunarDayLabel(chosen))}</span></span>
          <span class="day-summary-order">全年<br>第 ${dayOrder} 天</span>
        </section>`;
    }

    function yearPickerTemplate(selectedYear) {
      const start = selectedYear - 7;
      const years = Array.from({ length: 16 }, (_, index) => start + index);
      return `<div class="year-picker" role="dialog" aria-label="选择年份">
        <div class="year-picker-head"><span>选择年份</span><button class="year-picker-close" type="button" data-calendar-action="year-close" aria-label="关闭年份选择"><i data-lucide="x"></i></button></div>
        <div class="year-picker-grid">${years.map(year => `<button class="year-option${year === selectedYear ? ' is-selected' : ''}" type="button" data-calendar-year="${year}">${year}</button>`).join('')}</div>
      </div>`;
    }

    function timelineTemplate(items) {
      const durationOf = item => {
        const [startHour, startMinute] = item.time.split(':').map(Number);
        const [endHour, endMinute] = (item.end || item.time).split(':').map(Number);
        return Math.max(0, endHour * 60 + endMinute - startHour * 60 - startMinute);
      };
      const total = items.reduce((sum, item) => sum + durationOf(item), 0);
      const content = items.length ? `<div class="timeline-list">${items.map((item, index) => `
        <article class="timeline-item" data-timeline-id="${escapeHTML(item.id)}">
          <span class="timeline-time">${escapeHTML(item.time)}</span>
          <span class="timeline-track" aria-hidden="true"><span class="timeline-node">${pad2(index + 1)}</span></span>
          <span class="timeline-card">
            <span class="timeline-card-head"><span class="timeline-title">${escapeHTML(item.title)}</span><span class="timeline-duration">${durationOf(item)} MIN</span></span>
            <span class="timeline-meta">${escapeHTML(item.meta || '个人行程')}</span>
            <span class="timeline-window">${escapeHTML(item.time)} — ${escapeHTML(item.end || item.time)}</span>
          </span>
        </article>`).join('')}</div>` : '<div class="timeline-empty">这一天还没有安排。</div>';
      return `<section class="schedule-agenda"><div class="schedule-agenda-head"><span class="schedule-agenda-count"><strong>${items.length}</strong><span>项安排</span></span><span class="schedule-agenda-total">共 ${total} 分钟</span></div>${content}</section>`;
    }

    function scheduleTemplate() {
      const selected = parseDateKey(state.selectedDate);
      const weekStart = startOfWeek(selected);
      const days = Array.from({ length: 7 }, (_, index) => {
        const date = shiftDate(weekStart, index);
        const key = dateKey(date);
        const active = key === state.selectedDate ? ' is-selected' : '';
        return `<button class="schedule-week-day${active}" type="button" data-calendar-date="${key}" aria-label="${date.getMonth() + 1}月${date.getDate()}日">
          <span class="schedule-week-name">${WEEKDAYS_EN[date.getDay()]}</span>
          <span class="schedule-week-date">${pad2(date.getDate())}</span>
          <span class="schedule-week-lunar">${escapeHTML(lunarDayLabel(date))}</span>
        </button>`;
      }).join('');
      const items = selectedItems();
      return `
        <div class="schedule-week-shell" aria-label="周视图">${days}</div>
        <div class="section-heading"><h2>行程安排</h2><span>${selected.getMonth() + 1}月${selected.getDate()}日 · ${WEEKDAYS_EN[selected.getDay()]}</span></div>
        ${timelineTemplate(items)}`;
    }

    function healthTemplate() {
      const today = new Date();
      const daySeed = today.getDate();
      const steps = 6200 + (daySeed * 137) % 2800;
      const sleep = (6.8 + (daySeed % 5) * .2).toFixed(1);
      const water = 5 + daySeed % 3;
      const focus = 46 + daySeed % 22;
      return `
        <section class="health-profile" aria-label="个人健康资料">
          <div class="health-profile-main">
            <span class="health-profile-avatar" aria-hidden="true"><i data-lucide="image-plus"></i></span>
            <span class="health-profile-copy">
              <span class="health-profile-name"><strong>清柳</strong><i data-lucide="chevron-down" aria-hidden="true"></i></span>
              <span class="health-profile-signature">保持自己的节奏</span>
            </span>
          </div>
          <div class="health-profile-stats">
            <span class="health-profile-stat"><strong>165<small>cm</small></strong><small>身高</small></span>
            <span class="health-profile-stat"><strong>48<small>kg</small></strong><small>体重</small></span>
            <span class="health-profile-stat"><strong>19.6<small>%</small></strong><small>体脂率</small></span>
            <span class="health-profile-stat"><strong>LV.08</strong><small>等级</small></span>
          </div>
        </section>
        <section class="health-summary">
          <div class="health-summary-label">今日活动</div>
          <div class="health-summary-value">${steps.toLocaleString()}<span class="health-summary-unit">步</span></div>
          <div class="health-summary-note">相比过去 7 日平均值保持稳定，建议在晚间补充一次轻量步行。</div>
        </section>
        <div class="health-grid">
          <div class="health-row is-first">
            <article class="health-card"><div class="health-card-top"><i data-lucide="moon-star"></i><span class="health-card-code">01</span></div><div class="health-card-data"><div class="health-card-value">${sleep}<small>H</small></div><div class="health-card-foot"><span class="health-card-label">睡眠</span><span class="health-card-note">较昨夜 +0.4</span></div></div></article>
            <article class="health-card is-compact"><div class="health-card-top"><i data-lucide="glass-water"></i><span class="health-card-code">02</span></div><div class="health-card-data"><div class="health-card-value">${water}<small>杯</small></div><div class="health-card-foot"><span class="health-card-label">饮水</span><span class="health-card-note">目标 8</span></div></div></article>
            <article class="health-card"><div class="health-card-top"><i data-lucide="timer"></i><span class="health-card-code">03</span></div><div class="health-card-data"><div class="health-card-value">${focus}<small>MIN</small></div><div class="health-card-foot"><span class="health-card-label">专注</span><span class="health-card-note">3 段</span></div></div></article>
          </div>
          <div class="health-row is-second">
            <article class="health-card"><div class="health-card-top"><i data-lucide="activity"></i><span class="health-card-code">04</span></div><div class="health-card-data"><div class="health-card-value">72<small>BPM</small></div><div class="health-card-foot"><span class="health-card-label">静息心率</span></div></div></article>
            <article class="health-card is-dark"><div class="health-card-top"><i data-lucide="flame"></i><span class="health-card-code">05</span></div><div class="health-card-data"><div class="health-card-value">28<small>MIN</small></div><div class="health-card-foot"><span class="health-card-label">运动</span><span class="health-card-note">轻燃脂</span></div></div></article>
            <article class="health-card"><div class="health-card-top"><i data-lucide="heart"></i><span class="health-card-code">06</span></div><div class="health-card-data"><div class="health-card-foot"><span class="health-card-label">女性记录</span></div><div class="women-records"><span>爱爱</span><span>经期</span></div></div></article>
          </div>
        </div>`;
    }

    function updateBrand() {
      const labels = {
        calendar: 'Calendar.',
        schedule: 'Schedule.',
        health: 'Health.'
      };
      state.host.querySelector('[data-calendar-brand-name]').textContent = labels[state.tab];
      const addButton = state.host.querySelector('[data-calendar-action="add"]');
      const searchButton = state.host.querySelector('[data-calendar-action="search"]');
      addButton.hidden = state.tab !== 'schedule';
      addButton.setAttribute('aria-label', '添加行程');
      searchButton.setAttribute('aria-label', state.tab === 'calendar' ? '搜索日期' : state.tab === 'schedule' ? '搜索行程' : '搜索健康记录');
    }

    function render() {
      if (!state.host) return;
      const templates = { calendar: calendarTemplate, schedule: scheduleTemplate, health: healthTemplate };
      state.host.querySelectorAll('[data-calendar-view]').forEach(view => {
        const key = view.dataset.calendarView;
        view.classList.toggle('is-active', key === state.tab);
        if (key === state.tab) view.innerHTML = templates[key]();
      });
      state.host.querySelectorAll('[data-calendar-tab]').forEach(button => {
        const active = button.dataset.calendarTab === state.tab;
        button.classList.toggle('is-active', active);
        button.setAttribute('aria-current', active ? 'page' : 'false');
      });
      updateBrand();
      window.QWQIcons?.hydrate?.(state.host);
      state.monthMotion = '';
    }

    function showToast(message) {
      const toast = state.host.querySelector('[data-calendar-toast]');
      toast.textContent = message;
      toast.classList.add('is-visible');
      clearTimeout(state.toastTimer);
      state.toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 1500);
    }

    async function addQuickItem() {
      const row = {
        date: state.selectedDate,
        time: '09:00',
        end: '09:30',
        title: '新行程',
        meta: '个人 · 待编辑',
        type: 'plan',
        createdAt: Date.now()
      };
      try {
        row.id = await db.calendarItems.add(row);
        state.items.push(row);
        render();
        showToast('已加入所选日期');
      } catch (_) {
        showToast('暂时无法保存');
      }
    }

    function changeMonth(amount) {
      const selected = parseDateKey(state.selectedDate);
      const target = new Date(state.cursor.getFullYear(), state.cursor.getMonth() + amount, 1);
      const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
      state.cursor = target;
      state.selectedDate = dateKey(new Date(target.getFullYear(), target.getMonth(), Math.min(selected.getDate(), lastDay)));
      state.yearPickerOpen = false;
      state.monthMotion = amount > 0 ? 'next' : 'prev';
      render();
    }

    function onPointerDown(event) {
      if (!event.target.closest('[data-month-swipe]')) return;
      state.swipeStart = { x: event.clientX, y: event.clientY, pointerId: event.pointerId };
    }

    function onPointerUp(event) {
      const start = state.swipeStart;
      state.swipeStart = null;
      if (!start || start.pointerId !== event.pointerId) return;
      const deltaX = event.clientX - start.x;
      const deltaY = event.clientY - start.y;
      if (Math.abs(deltaX) < 44 || Math.abs(deltaX) <= Math.abs(deltaY) * 1.15) return;
      state.ignoreDateClickUntil = Date.now() + 360;
      changeMonth(deltaX < 0 ? 1 : -1);
    }

    function onClick(event) {
      const tab = event.target.closest('[data-calendar-tab]');
      if (tab) {
        state.tab = tab.dataset.calendarTab;
        state.yearPickerOpen = false;
        render();
        return;
      }
      const yearOption = event.target.closest('[data-calendar-year]');
      if (yearOption) {
        const year = Number(yearOption.dataset.calendarYear);
        const selected = parseDateKey(state.selectedDate);
        const month = state.cursor.getMonth();
        const lastDay = new Date(year, month + 1, 0).getDate();
        state.cursor = new Date(year, month, 1);
        state.selectedDate = dateKey(new Date(year, month, Math.min(selected.getDate(), lastDay)));
        state.yearPickerOpen = false;
        render();
        return;
      }
      const day = event.target.closest('[data-calendar-date]');
      if (day) {
        if (Date.now() < state.ignoreDateClickUntil) return;
        state.selectedDate = day.dataset.calendarDate;
        const selected = parseDateKey(state.selectedDate);
        state.cursor = new Date(selected.getFullYear(), selected.getMonth(), 1);
        state.yearPickerOpen = false;
        render();
        return;
      }
      const action = event.target.closest('[data-calendar-action]')?.dataset.calendarAction;
      if (!action) return;
      if (action === 'close') state.close();
      if (action === 'search') showToast('事件搜索已就绪');
      if (action === 'add' && state.tab === 'schedule') addQuickItem();
      if (action === 'settings') showToast('日历设置');
      if (action === 'year') {
        state.yearPickerOpen = !state.yearPickerOpen;
        render();
      }
      if (action === 'year-close') {
        state.yearPickerOpen = false;
        render();
      }
    }

    return Object.freeze({
      async mount(host, context) {
        state.host = host;
        state.close = context.close;
        state.tab = 'calendar';
        state.cursor = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
        state.selectedDate = dateKey(new Date());
        state.items = [];
        state.yearPickerOpen = false;
        state.monthMotion = '';
        host.innerHTML = frameTemplate();
        host.addEventListener('click', onClick);
        host.addEventListener('pointerdown', onPointerDown);
        host.addEventListener('pointerup', onPointerUp);
        render();
        state.items = await db.calendarItems.toArray();
        render();
      },
      unmount(host) {
        clearTimeout(state.toastTimer);
        host.removeEventListener('click', onClick);
        host.removeEventListener('pointerdown', onPointerDown);
        host.removeEventListener('pointerup', onPointerUp);
        state.host = null;
        state.close = null;
      }
    });
  })();

  const root = document.getElementById("qwq-calendar-root");
  let mounted = false;

  async function open() {
    if (!root) return false;
    await window.ThemeCustomization.ready;
    if (!mounted) {
      await CalendarController.mount(root, {
        close: () => window.MyPhoneManager?.closeApp?.("calendar")
      });
      mounted = true;
    }
    return true;
  }

  function close() {
    // 参考轻量页面生命周期：路由隐藏已经把日历移出渲染树，不再为普通返回主屏
    // 销毁整页 DOM / 事件 / 已读取日历数据。再次进入复用同一挂载实例，避免重复建树与全表读取。
    return true;
  }

  window.CalendarApp = Object.freeze({ open, close });
})();