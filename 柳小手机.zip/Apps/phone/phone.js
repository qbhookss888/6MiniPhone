/* Phone App —— 电话（经典脚本，全局 PhoneApp）。 */
(function () {
  "use strict";
  if (window.PhoneApp) return;

  const page = document.getElementById("page-phone-app");
  const root = page && page.querySelector(".o3o-phone-root");
  const RECENTS_KEY = "phone.recents.v1";

  const state = {
    activeCall: null,      // {id, kind:'outgoing'|'incoming'|'video', contactId, name, number, timer, startedAt}
    timerInterval: 0,
    recents: [],
    hydrated: false,
    rendering: false
  };

  function uid(prefix) {
    return `${prefix}-${globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`}`;
  }

  async function dbReady() {
    try { await window.ThemeCustomization?.ready; } catch (_) { }
    return window.ThemeCustomization?.db || null;
  }

  // ---------- 号码与联系人 ----------
  function pseudoNumber(seedText) {
    const text = String(seedText || "");
    let hash = 0;
    for (let i = 0; i < text.length; i += 1) hash = (hash * 31 + text.charCodeAt(i)) >>> 0;
    const body = String(10000000 + (hash % 90000000));
    return `1${body.slice(0, 3)}${body.slice(3, 7)}${body.slice(7, 11)}`;
  }

  async function loadContacts() {
    const db = await dbReady();
    if (!db?.contacts) return [];
    try {
      const all = await db.contacts.toArray();
      const seen = new Set();
      const rows = [];
      all.forEach((c) => {
        const name = String(c.displayName || c.name || c.nickname || "").trim();
        const key = name || c.contactId;
        if (seen.has(key)) return;
        seen.add(key);
        rows.push({ contactId: c.contactId, name: name || "未命名联系人", avatarAssetId: c.avatarAssetId || null });
      });
      return rows.sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));
    } catch (_) { return []; }
  }

  async function loadRecents() {
    if (state.hydrated) return state.recents;
    const db = await dbReady();
    if (db?.persistenceMeta) {
      try {
        const row = await db.persistenceMeta.get(RECENTS_KEY);
        if (Array.isArray(row?.value)) state.recents = row.value;
      } catch (_) { }
    }
    state.hydrated = true;
    return state.recents;
  }

  async function persistRecents() {
    const db = await dbReady();
    if (!db?.persistenceMeta) return;
    try {
      await db.persistenceMeta.put({ key: RECENTS_KEY, value: state.recents.slice(0, 60), updatedAt: Date.now() });
    } catch (_) { }
  }

  function addRecent(item) {
    state.recents = [item, ...state.recents.filter((r) => !(r.contactId && r.contactId === item.contactId && r.kind === item.kind))].slice(0, 60);
    void persistRecents();
    renderRecents();
  }

  // ---------- 视图切换 ----------
  function views() {
    return page ? Array.from(page.querySelectorAll("[data-phone-view]")) : [];
  }

  function showView(name, { silent = false } = {}) {
    if (!page) return false;
    let found = false;
    views().forEach((view) => {
      const active = view.dataset.phoneView === name;
      view.classList.toggle("is-active", active);
      if (active) found = true;
    });
    page.querySelectorAll("[data-phone-tab]").forEach((tab) => {
      const active = tab.dataset.phoneTab === name;
      tab.classList.toggle("is-active", active);
      if (active) tab.setAttribute("aria-current", "page");
      else tab.removeAttribute("aria-current");
    });
    if (found && !silent) {
      if (name === "calls") void renderRecents();
      if (name === "contacts") void renderContacts();
      if (name === "search") renderSearchResults();
    }
    return found;
  }

  function setNumber(digits) {
    const numberEl = page?.querySelector("#phoneKeypadNumber");
    const matchEl = page?.querySelector("#phoneKeypadMatch");
    if (!numberEl) return;
    numberEl.textContent = digits || "";
    numberEl.classList.toggle("is-empty", !digits);
    if (matchEl) {
      matchEl.replaceChildren();
      if (digits) {
        void loadContacts().then((contacts) => {
          const matched = contacts.filter((c) => pseudoNumber(c.name + c.contactId).includes(digits)).slice(0, 2);
          if (matchEl) {
            matched.forEach((c) => {
              const btn = document.createElement("button");
              btn.type = "button";
              btn.className = "phone-keypad-match-row";
              btn.textContent = `${c.name} · ${pseudoNumber(c.name + c.contactId)}`;
              btn.addEventListener("click", () => startOutgoing(c.name, pseudoNumber(c.name + c.contactId), c.contactId));
              matchEl.appendChild(btn);
            });
          }
        });
      }
    }
  }

  function renderRecents() {
    const host = page?.querySelector("#phoneRecents");
    if (!host) return;
    const list = state.recents.slice(0, 30);
    host.replaceChildren();
    if (!list.length) {
      const empty = document.createElement("div");
      empty.className = "phone-empty-state";
      empty.textContent = "暂无最近通话";
      host.appendChild(empty);
      return;
    }
    list.forEach((item) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "phone-recent-row";
      const left = document.createElement("span");
      left.className = "phone-recent-badge";
      left.textContent = item.kind === "incoming" ? "↓" : item.kind === "missed" ? "!" : "↑";
      left.classList.add(item.kind === "missed" ? "is-missed" : "");
      const copy = document.createElement("span");
      copy.className = "phone-recent-copy";
      const name = document.createElement("strong");
      name.textContent = item.name || item.number || "未知";
      const sub = document.createElement("small");
      sub.textContent = formatRecentTime(item.at);
      copy.append(name, sub);
      row.append(left, copy);
      row.addEventListener("click", () => openDetail(item));
      host.appendChild(row);
    });
  }

  function formatRecentTime(at) {
    const time = Number(at) || Date.now();
    const date = new Date(time);
    const now = new Date();
    const sameDay = date.toDateString() === now.toDateString();
    if (sameDay) return new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit", hour12: false }).format(date);
    return new Intl.DateTimeFormat("zh-CN", { month: "numeric", day: "numeric" }).format(date);
  }

  async function renderContacts() {
    const host = page?.querySelector("#phoneContactsList");
    if (!host) return;
    const contacts = await loadContacts();
    host.replaceChildren();
    if (!contacts.length) {
      const empty = document.createElement("div");
      empty.className = "phone-empty-state";
      empty.textContent = "还没有联系人，先在 QQ 中添加好友吧";
      host.appendChild(empty);
      return;
    }
    const byLetter = new Map();
    contacts.forEach((c) => {
      const letter = (/[a-zA-Z]/.test(c.name[0]) ? c.name[0] : "#").toUpperCase();
      if (!byLetter.has(letter)) byLetter.set(letter, []);
      byLetter.get(letter).push(c);
    });
    byLetter.forEach((group, letter) => {
      const section = document.createElement("section");
      section.className = "phone-contact-group";
      const heading = document.createElement("h3");
      heading.textContent = letter;
      section.appendChild(heading);
      group.forEach((c) => {
        const row = document.createElement("button");
        row.type = "button";
        row.className = "phone-contact-row";
        const avatar = document.createElement("span");
        avatar.className = "phone-contact-avatar";
        avatar.textContent = (c.name[0] || "?").toUpperCase();
        const name = document.createElement("span");
        name.className = "phone-contact-name";
        name.textContent = c.name;
        row.append(avatar, name);
        row.addEventListener("click", () => openDetail(c));
        section.appendChild(row);
      });
      host.appendChild(section);
    });
  }

  // ---------- 详情 ----------
  async function openDetail(contact) {
    const detail = page?.querySelector('[data-phone-view="detail"]');
    if (!detail) return;
    const nameEl = page.querySelector("#phoneDetailName");
    const numberEl = page.querySelector("#phoneDetailNumber");
    const phoneValue = page.querySelector("#phoneDetailPhone");
    const avatarEl = page.querySelector("#phoneDetailAvatarImage");
    const contactId = contact.contactId || contact.id || "";
    const number = contact.number || pseudoNumber(contact.name + contactId);
    if (nameEl) nameEl.textContent = contact.name || contact.displayName || "联系人";
    if (numberEl) numberEl.textContent = number;
    if (phoneValue) phoneValue.textContent = number;
    if (avatarEl) {
      avatarEl.style.display = "none";
      const fallback = page.querySelector("#phoneDetailAvatar .phone-avatar-placeholder");
      if (fallback) fallback.style.display = "";
    }
    detail.dataset.contactId = contactId;
    detail.dataset.contactName = contact.name || "";
    detail.dataset.contactNumber = number;
    showView("detail");
  }

  function currentDetail() {
    const detail = page?.querySelector('[data-phone-view="detail"]');
    if (!detail) return null;
    return {
      contactId: detail.dataset.contactId || "",
      name: detail.dataset.contactName || "联系人",
      number: detail.dataset.contactNumber || ""
    };
  }

  // ---------- 呼叫 ----------
  function fmtDuration(seconds) {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(Math.floor(seconds % 60)).padStart(2, "0");
    return `${m}:${s}`;
  }

  function tickCall() {
    if (!state.activeCall) return;
    state.activeCall.elapsed = (Date.now() - state.activeCall.startedAt) / 1000;
    const timer = page?.querySelector("#phoneCallTimer");
    if (timer) timer.textContent = fmtDuration(state.activeCall.elapsed);
    const videoTimer = page?.querySelector("#phoneVideoTimer");
    if (videoTimer) videoTimer.textContent = fmtDuration(state.activeCall.elapsed);
  }

  function setActiveCall(call) {
    if (state.activeCall) return false;
    state.activeCall = call;
    call.startedAt = Date.now();
    state.timerInterval = window.setInterval(tickCall, 1000);
    return true;
  }

  function clearActiveCall() {
    if (state.timerInterval) window.clearInterval(state.timerInterval);
    state.timerInterval = 0;
    state.activeCall = null;
  }

  function nameFor(contactId, fallback) {
    const name = String(fallback || "").trim();
    return name || (contactId ? String(contactId).slice(0, 12) : "电话");
  }

  function startOutgoing(name, number, contactId) {
    if (!page) return false;
    if (!setActiveCall({ id: uid("call"), kind: "outgoing", contactId: contactId || "", name: nameFor(contactId, name), number: number || pseudoNumber(name) })) return false;
    const nameEl = page.querySelector("#phoneCallingName");
    const numberEl = page.querySelector("#phoneCallingNumber");
    const statusEl = page.querySelector("#phoneCallingStatus");
    if (nameEl) nameEl.textContent = state.activeCall.name;
    if (numberEl) numberEl.textContent = state.activeCall.number;
    if (statusEl) statusEl.textContent = "正在呼叫…";
    showView("calling");
    window.setTimeout(() => {
      if (!state.activeCall || state.activeCall.kind !== "outgoing") return;
      state.activeCall.state = "connected";
      const nameEl2 = page.querySelector("#phoneCallName");
      const subEl = page.querySelector("#phoneCallSub");
      const timerEl = page.querySelector("#phoneCallTimer");
      if (nameEl2) nameEl2.textContent = state.activeCall.name;
      if (subEl) subEl.textContent = state.activeCall.number;
      if (timerEl) timerEl.textContent = "00:00";
      showView("call");
      appendTranscript("text", null, "已接通，模拟通话进行中（离线演示，无真实语音）。");
    }, 1600);
    return true;
  }

  function appendTranscript(role, text, fallback) {
    const host = page?.querySelector("#phoneCallTranscript");
    if (!host) return;
    const content = String(text || "").trim() || String(fallback || "");
    const bubble = document.createElement("div");
    bubble.className = role === "me" ? "phone-transcript-bubble is-me" : "phone-transcript-bubble";
    bubble.textContent = content;
    host.appendChild(bubble);
    host.scrollTop = host.scrollHeight;
  }

  function endCall() {
    if (!state.activeCall) { showView("calls"); return true; }
    const call = state.activeCall;
    const elapsed = Math.max(1, Math.round((Date.now() - call.startedAt) / 1000));
    addRecent({ contactId: call.contactId || "", name: call.name, number: call.number, kind: call.kind === "outgoing" ? "outgoing" : "incoming", at: Date.now(), duration: elapsed });
    clearActiveCall();
    showView("calls");
    return true;
  }

  // ---------- 呼入（QQ 调用） ----------
  function incoming(contactId, options) {
    const payload = options && typeof options === "object" ? options : {};
    if (state.activeCall) return Promise.resolve(false);
    return Promise.resolve().then(async () => {
      const contacts = await loadContacts();
      const contact = contacts.find((c) => c.contactId === contactId) || null;
      const name = contact?.name || nameFor(contactId, payload.opening || "");
      const number = contact ? pseudoNumber(contact.name + contactId) : pseudoNumber(contactId + name);
      if (!setActiveCall({ id: uid("call"), kind: "incoming", contactId: contactId || "", name, number, state: "ringing" })) return false;
      if (page) {
        const nameEl = page.querySelector("#phoneCallingName");
        const numberEl = page.querySelector("#phoneCallingNumber");
        const statusEl = page.querySelector("#phoneCallingStatus");
        if (nameEl) nameEl.textContent = name;
        if (numberEl) numberEl.textContent = number;
        if (statusEl) statusEl.textContent = "来电…";
        showView("calling");
        // 2 秒后自动接通（模拟接听）
        window.setTimeout(() => {
          if (!state.activeCall || state.activeCall.state !== "ringing") return;
          state.activeCall.state = "connected";
          const callName = page.querySelector("#phoneCallName");
          const callSub = page.querySelector("#phoneCallSub");
          const callTimer = page.querySelector("#phoneCallTimer");
          if (callName) callName.textContent = state.activeCall.name;
          if (callSub) callSub.textContent = state.activeCall.number;
          if (callTimer) callTimer.textContent = "00:00";
          showView("call");
        }, 2000);
      }
      console.log("[Phone] 来电", contactId, payload.opening || "");
      return true;
    });
  }

  // ---------- 拨号键盘 ----------
  function buildKeypad() {
    const grid = page?.querySelector("#phoneKeypadGrid");
    if (!grid || grid.childElementCount) return;
    const keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"];
    keys.forEach((key) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "phone-keypad-key";
      button.dataset.phoneKey = key;
      const letters = { "2": "ABC", "3": "DEF", "4": "GHI", "5": "JKL", "6": "MNO", "7": "PQRS", "8": "TUV", "9": "WXYZ", "0": "+" }[key] || "";
      button.innerHTML = `<strong>${key}</strong>${letters ? `<small>${letters}</small>` : ""}`;
      button.addEventListener("click", () => {
        const number = page.querySelector("#phoneKeypadNumber");
        const current = number?.textContent || "";
        setNumber(current.length < 20 ? current + key : current);
      });
      grid.appendChild(button);
    });
  }

  function dialKeypad() {
    const number = (page?.querySelector("#phoneKeypadNumber")?.textContent || "").trim();
    if (!number) return;
    void loadContacts().then((contacts) => {
      const contact = contacts.find((c) => pseudoNumber(c.name + c.contactId) === number) || null;
      startOutgoing(contact?.name || number, number, contact?.contactId || "");
    });
  }

  function searchAll(keyword) {
    const term = String(keyword || "").trim().toLowerCase();
    return Promise.resolve().then(async () => {
      const contacts = await loadContacts();
      const contactHits = term ? contacts.filter((c) => c.name.toLowerCase().includes(term) || pseudoNumber(c.name + c.contactId).includes(term)).slice(0, 6) : contacts.slice(0, 6);
      const recentHits = term ? state.recents.filter((r) => (r.name || "").toLowerCase().includes(term) || (r.number || "").includes(term)).slice(0, 6) : [];
      return { contactHits, recentHits };
    });
  }

  function renderSearchResults() {
    const input = page?.querySelector("#phoneGlobalSearch");
    const host = page?.querySelector("#phoneSearchResults");
    if (!input || !host) return;
    void searchAll(input.value).then(({ contactHits, recentHits }) => {
      host.replaceChildren();
      if (!contactHits.length && !recentHits.length) {
        const empty = document.createElement("div");
        empty.className = "phone-empty-state";
        empty.textContent = "没有匹配结果";
        host.appendChild(empty);
        return;
      }
      const section = document.createElement("section");
      section.className = "phone-search-section";
      recentHits.forEach((item) => {
        const row = document.createElement("button");
        row.type = "button";
        row.className = "phone-recent-row";
        row.innerHTML = `<span class="phone-recent-badge is-recent">回</span><span class="phone-recent-copy"><strong>${escapeHtml(item.name || item.number || "未知")}</strong><small>${escapeHtml(item.number || "")}</small></span>`;
        row.addEventListener("click", () => startOutgoing(item.name || item.number, item.number, item.contactId));
        section.appendChild(row);
      });
      contactHits.forEach((c) => {
        const row = document.createElement("button");
        row.type = "button";
        row.className = "phone-contact-row";
        row.innerHTML = `<span class="phone-contact-avatar">${escapeHtml((c.name[0] || "?").toUpperCase())}</span><span class="phone-contact-name">${escapeHtml(c.name)}</span>`;
        row.addEventListener("click", () => openDetail(c));
        section.appendChild(row);
      });
      host.appendChild(section);
    });
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
  }

  // ---------- 事件绑定 ----------
  function bindEvents() {
    if (!page || page.dataset.phoneBound === "1") return;
    page.dataset.phoneBound = "1";

    page.querySelectorAll("[data-phone-tab]").forEach((tab) => {
      tab.addEventListener("click", () => {
        const name = tab.dataset.phoneTab;
        if (name === "contacts") { void renderContacts().then(() => showView("contacts")); return; }
        showView(name);
      });
    });

    const searchTab = page.querySelector("#phoneSearchTab");
    if (searchTab) searchTab.addEventListener("click", () => { void renderSearchResults(); showView("search"); });

    const searchInput = page.querySelector("#phoneGlobalSearch");
    if (searchInput) searchInput.addEventListener("input", () => renderSearchResults());

    const deleteDigit = page.querySelector("#phoneDeleteDigit");
    if (deleteDigit) deleteDigit.addEventListener("click", () => {
      const number = page.querySelector("#phoneKeypadNumber");
      setNumber((number?.textContent || "").slice(0, -1));
    });

    const dialCall = page.querySelector("#phoneDialCall");
    if (dialCall) dialCall.addEventListener("click", dialKeypad);

    const callingEnd = page.querySelector("#phoneCallingEnd");
    if (callingEnd) callingEnd.addEventListener("click", endCall);

    const callEnd = page.querySelector('[data-phone-call-control="end"]');
    if (callEnd) callEnd.addEventListener("click", endCall);

    const minimize = page.querySelector("#phoneCallingMinimize");
    if (minimize) minimize.addEventListener("click", () => { if (state.activeCall) showView("calls"); });

    const callMinimize = page.querySelector("#phoneCallMinimize");
    if (callMinimize) callMinimize.addEventListener("click", () => { if (state.activeCall) showView("calls"); });

    const sendBtn = page.querySelector("#phoneCallSend");
    const heartBtn = page.querySelector("#phoneCallHeart");
    const inputEl = page.querySelector("#phoneCallInput");
    const composerClose = page.querySelector("#phoneCallComposerClose");
    const sendMessage = () => {
      const value = (inputEl?.value || "").trim();
      if (!value) return;
      appendTranscript("me", value);
      if (inputEl) inputEl.value = "";
      window.setTimeout(() => {
        if (!state.activeCall) return;
        appendTranscript("them", "收到啦～（离线演示回复）");
      }, 1200);
    };
    if (sendBtn) sendBtn.addEventListener("click", sendMessage);
    if (inputEl) inputEl.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); sendMessage(); }
    });
    if (heartBtn) heartBtn.addEventListener("click", () => {
      if (!state.activeCall) return;
      appendTranscript("them", "（对方主动发来消息）在忙什么呢？");
    });
    if (composerClose) composerClose.addEventListener("click", () => {
      if (state.activeCall) showView("call");
    });

    page.querySelectorAll("[data-phone-call-control]").forEach((control) => {
      control.addEventListener("click", () => {
        const action = control.dataset.phoneCallControl;
        if (action === "end") return endCall();
        if (action === "keypad") { const composer = page.querySelector("#phoneCallComposer"); if (composer) composer.hidden = !composer.hidden; }
        control.classList.toggle("is-active", action !== "more" && action !== "end");
      });
    });

    // 联系人详情操作
    page.querySelectorAll("[data-phone-contact-action]").forEach((action) => {
      action.addEventListener("click", () => {
        const detail = currentDetail();
        if (!detail) return;
        const type = action.dataset.phoneContactAction;
        if (type === "call") startOutgoing(detail.name, detail.number, detail.contactId);
        else if (type === "message") {
          document.dispatchEvent(new CustomEvent("qwq:contact-message", { detail: { contactId: detail.contactId || detail.number } }));
        } else if (type === "video") {
          const videoApp = window.PhoneVideoApp;
          if (videoApp?.outgoing) videoApp.outgoing(detail.name, detail.number, detail.contactId);
        }
      });
    });

    const detailBack = page.querySelector("#phoneDetailBack");
    if (detailBack) detailBack.addEventListener("click", () => showView("contacts"));

    // 返回主屏按钮
    const desktopReturn = page.querySelector("#phoneDesktopReturn");
    if (desktopReturn) desktopReturn.addEventListener("click", () => {
      try { window.MyPhoneManager?.open?.(); } catch (_) { }
    });

    buildKeypad();
  }

  // ---------- App 契约 ----------
  function open(view) {
    if (!page) return false;
    const target = String(view || "calls");
    bindEvents();
    void loadRecents();
    if (state.activeCall && ["calling", "call"].includes(state.activeCall.state === "connected" ? "call" : "calling")) {
      showView(state.activeCall.state === "connected" ? "call" : "calling");
    } else {
      showView(target in { calls: 1, contacts: 1, keypad: 1, search: 1 } ? target : "calls");
    }
    return true;
  }

  function close() {
    // 轻量生命周期：保留状态；挂断由用户操作触发。
    return true;
  }

  function stateInfo() {
    return {
      active: Boolean(state.activeCall),
      kind: state.activeCall?.kind || null,
      name: state.activeCall?.name || null,
      recents: state.recents.length
    };
  }

  window.PhoneApp = Object.freeze({
    open,
    close,
    incoming,
    startOutgoing,
    endCall,
    state: stateInfo
  });
})();
console.log("[Phone] 电话模块已加载");
