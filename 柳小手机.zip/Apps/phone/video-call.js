/* Phone Video Call —— 视频通话（经典脚本，全局 PhoneVideoApp）。 */
(function () {
  "use strict";
  if (window.PhoneVideoApp) return;

  const page = document.getElementById("page-phone-app");

  const state = {
    active: null,        // {contactId, name, timer, startedAt}
    timerInterval: 0
  };

  function uid(prefix) {
    return `${prefix}-${globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`}`;
  }

  function views() {
    return page ? Array.from(page.querySelectorAll("[data-phone-view]")) : [];
  }

  function showView(name) {
    if (!page) return false;
    views().forEach((view) => view.classList.toggle("is-active", view.dataset.phoneView === name));
    return true;
  }

  function fmt(seconds) {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(Math.floor(seconds % 60)).padStart(2, "0");
    return `${m}:${s}`;
  }

  function tick() {
    if (!state.active) return;
    const timer = page?.querySelector("#phoneVideoTimer");
    if (timer) timer.textContent = fmt((Date.now() - state.active.startedAt) / 1000);
  }

  function beginVideo(contactId, name, { incomingMode = false, events = null } = {}) {
    if (!page || state.active) return false;
    const displayName = String(name || "").trim() || (contactId ? String(contactId).slice(0, 12) : "视频通话");
    state.active = { id: uid("video"), contactId: contactId || "", name: displayName, incomingMode, startedAt: Date.now() };
    state.timerInterval = window.setInterval(tick, 1000);

    const callingName = page.querySelector("#phoneVideoCallingName");
    const callingStatus = page.querySelector("#phoneVideoCallingStatus");
    const callName = page.querySelector("#phoneVideoName");
    const timerEl = page.querySelector("#phoneVideoTimer");
    if (callingName) callingName.textContent = displayName;
    if (callingStatus) callingStatus.textContent = "正在呼叫…";
    if (callName) callName.textContent = displayName;
    if (timerEl) timerEl.textContent = "00:00";

    showView("video-calling");
    window.setTimeout(() => {
      if (!state.active || state.active.id !== state.active.id) return;
      // 接通
      const callName2 = page.querySelector("#phoneVideoName");
      if (callName2) callName2.textContent = state.active.name;
      const timer2 = page.querySelector("#phoneVideoTimer");
      if (timer2) timer2.textContent = "00:00";
      state.active.startedAt = Date.now();
      showView("video-call");
      appendTranscript("video", null, "视频已接通（离线演示）。");
      if (events && Array.isArray(events)) {
        events.forEach((item) => {
          window.setTimeout(() => {
            if (state.active) appendTranscript("video", null, String(item?.text || "（视频事件）"));
          }, 900);
        });
      }
    }, 1800);
    return true;
  }

  function appendTranscript(kind, text, fallback) {
    if (kind === "voice") {
      const voice = page?.querySelector("#phoneVideoNarration");
      if (voice) {
        const span = voice.querySelector("span");
        if (span) span.textContent = String(text || fallback || "");
        voice.setAttribute("aria-hidden", "false");
      }
      return;
    }
    const host = page?.querySelector("#phoneVideoTranscript");
    if (!host) return;
    const bubble = document.createElement("div");
    bubble.className = "phone-video-transcript-line";
    bubble.textContent = String(text || fallback || "");
    host.appendChild(bubble);
    host.scrollTop = host.scrollHeight;
  }

  function endVideo() {
    if (state.timerInterval) window.clearInterval(state.timerInterval);
    state.timerInterval = 0;
    state.active = null;
    const phoneApp = window.PhoneApp;
    if (phoneApp?.state?.().active) {
      showView("call");
    } else {
      showView("calls");
      if (phoneApp?.open) phoneApp.open("calls");
    }
    return true;
  }

  // ---------- QQ / 电话 调用契约 ----------
  function incoming(contactId, options) {
    const payload = options && typeof options === "object" ? options : {};
    if (state.active) return Promise.resolve(false);
    const name = String(payload.opening || payload.name || "").trim() || contactId;
    beginVideo(contactId, name, { incomingMode: true, events: payload.events || null });
    return Promise.resolve(true);
  }

  function outgoing(name, number, contactId) {
    if (state.active) return false;
    beginVideo(contactId || number, name || number || "视频通话");
    return true;
  }

  function bindEvents() {
    if (!page || page.dataset.phoneVideoBound === "1") return;
    page.dataset.phoneVideoBound = "1";

    page.querySelectorAll('[data-phone-video-calling-control="end"], [data-phone-video-control="end"]').forEach((btn) => {
      btn.addEventListener("click", endVideo);
    });

    page.querySelectorAll("#phoneVideoCallingMinimize, #phoneVideoMinimize").forEach((btn) => {
      btn.addEventListener("click", () => { if (state.active) showView("calls"); });
    });

    const sendVideo = () => {
      const input = page.querySelector("#phoneVideoInput");
      const value = (input?.value || "").trim();
      if (!value || !state.active) return;
      appendTranscript("video", value);
      if (input) input.value = "";
      window.setTimeout(() => {
        if (state.active) appendTranscript("video", null, "（离线演示回复）看到了～");
      }, 1100);
    };
    const sendBtn = page.querySelector("#phoneVideoSend");
    if (sendBtn) sendBtn.addEventListener("click", sendVideo);
    const inputEl = page.querySelector("#phoneVideoInput");
    if (inputEl) inputEl.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); sendVideo(); }
    });
    const heart = page.querySelector("#phoneVideoHeart");
    if (heart) heart.addEventListener("click", () => {
      if (state.active) appendTranscript("video", null, "（对方发来消息）能听到吗？");
    });

    page.querySelectorAll("[data-phone-video-control]").forEach((control) => {
      control.addEventListener("click", () => {
        if (control.dataset.phoneVideoControl === "end") return;
        control.classList.toggle("is-active");
      });
    });
  }

  function open() {
    bindEvents();
    return true;
  }

  function close() {
    return true;
  }

  function stateInfo() {
    return { active: Boolean(state.active), name: state.active?.name || null };
  }

  window.PhoneVideoApp = Object.freeze({
    open,
    close,
    incoming,
    outgoing,
    endVideo,
    state: stateInfo
  });
})();
console.log("[Phone] 视频通话模块已加载");
