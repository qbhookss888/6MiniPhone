const ThemeCustomization = (() => {
      const root = document.documentElement;
      const drawerOverlay = document.getElementById("theme-drawer-overlay");
      const drawer = document.getElementById("theme-global-drawer");
      const drawerTitle = document.getElementById("theme-drawer-title");
      const drawerBody = document.getElementById("theme-drawer-body");
      const modalOverlay = document.getElementById("theme-modal-overlay");
      const modal = modalOverlay.querySelector(".global-modal");
      const modalContent = modal.querySelector(".global-modal-content");
      const modalTitle = document.getElementById("theme-modal-title");
      const modalMessage = document.getElementById("theme-modal-message");
      const modalExtra = document.getElementById("theme-modal-extra");
      const modalInput = document.getElementById("theme-modal-input");
      const modalVoiceInput = document.getElementById("theme-modal-voice-input");
      const modalActions = document.getElementById("theme-modal-actions");
      const modalCancel = document.getElementById("theme-modal-cancel");
      const modalConfirm = document.getElementById("theme-modal-confirm");
      const wallpaperFileInput = document.getElementById("wallpaper-file-input");
      const desktopWallpaperImage = document.getElementById("desktop-wallpaper-image");
      const iconFileInput = document.getElementById("icon-file-input");
      const fontFileInput = document.getElementById("font-file-input");
      const themeImportFileInput = document.getElementById("theme-import-file-input");

      const PERSISTENCE_VERSION = myPhoneConfig.version;
      // 音乐持久化键属于数据库协议，不允许音乐运行层与备份层分别维护白名单。
      const MUSIC_STATE_KEYS = Object.freeze({
        library: "library",
        stats: "playStats",
        comments: "comments",
        playback: "playback",
        settings: "settings"
      });
      // 设置默认值同时参与设置页初始化与历史数据迁移判定，必须只有这一份定义。
      // 迁移层用它识别被坏版本写入的“较新默认值”，设置页用它补齐新增字段。
      const SETTINGS_DEFAULTS = Object.freeze({
        accountProtection: true,
        sensitiveConfirm: true,
        autoLock: false,
        notifications: true,
        notificationPreview: true,
        notificationSound: false,
        keepalive: true,
        hiddenPageTasks: true,
        apiProvider: "openai",
        apiBaseUrl: "https://api.openai.com/v1",
        apiKey: "",
        apiModel: "",
        apiModels: [],
        apiTemperature: 0.7,
        apiStream: false,
        apiPresets: [],
        apiPresetId: "",
        imageProvider: "openai",
        imageBaseUrl: "https://api.openai.com/v1",
        imageApiKey: "",
        imageModels: ["gpt-image-2", "gpt-image-1.5", "gpt-image-1", "gpt-image-1-mini"],
        imageModel: "gpt-image-2",
        imageProviderProfiles: {},
        imagePresets: [],
        imagePresetId: "",
        imageSize: "1024x1024",
        imageAspectRatio: "1:1",
        imageResolution: "1K",
        imageQuality: "auto",
        imageOutputFormat: "png",
        imageBackground: "auto",
        imageCompression: 100,
        imageCount: 1,
        imageSteps: 28,
        imageGuidance: 5,
        imageSeed: -1,
        imageSampler: "k_euler",
        imageSystemPrompt: "",
        imageNegativePrompt: "",
        imageTimeout: 120,
        imageAutoCompress: true,
        imageSafetyCheck: true,
        imagePromptOptimize: true,
        ttsProvider: "system",
        ttsBaseUrl: "",
        ttsApiKey: "",
        ttsModel: "system",
        ttsModels: ["system"],
        ttsVoice: "",
        ttsVoices: [],
        ttsProviderProfiles: {},
        ttsPresets: [],
        ttsPresetId: "",
        ttsGroupId: "",
        ttsLanguage: "auto",
        ttsInstructions: "",
        ttsRate: 1,
        ttsPitch: 1,
        ttsVolume: 1,
        ttsGain: 0,
        ttsFormat: "mp3",
        ttsSampleRate: 32000,
        ttsBitrate: 128,
        ttsStability: 0.5,
        ttsSimilarity: 0.75,
        ttsStyle: 0,
        ttsSpeakerBoost: true,
        ttsTemperature: 0.7,
        ttsTopP: 0.7,
        ttsLatency: "balanced",
        ttsNormalize: true,
        ttsChunkLength: 300,
        ttsStreaming: false,
        ttsTimeout: 60,
        ttsTestText: "你好，这是一段语音试听。",
        mcpEnabled: false,
        mcpToolCalls: true,
        mcpForegroundConfirm: true,
        assistantEnabled: true,
        assistantContext: true,
        assistantSuggestions: false,
        assistantMode: "standard",
        memoryHybridEnabled: false,
        memoryEmbeddingModel: "text-embedding-3-small"
      });
      const LEGACY_DEFAULT_DEVELOPER_CSS_0380 = `:root {
  --global-page-start: 30px;
  --global-page-content-gap: 16px;
  --global-drawer-radius: 34px;
  --global-drawer-inline: clamp(16px, 4.8vw, 24px);
  --global-drawer-section-gap: 16px;
  --global-control-height: 44px;
  --global-section-radius: 28px;
  --global-modal-radius: 24px;
  --global-scrollbar-size: 4px;
  --global-scrollbar-thumb: #000000;
  --global-scrollbar-track: transparent;
  --global-scrollbar-radius: 999px;
  --global-scrollbar-inset: 4px;
  --global-scrollbar-min-thumb: 28px;
  --global-scrollbar-opacity: .82;
  --global-scrollbar-hide-delay: 720ms;
  --parent-radius: 26px;
  --ui-control-radius: 20px;
}`;
      // System-owned geometry tokens are runtime facts, not theme preferences.
      // Historical backups may contain old developer CSS that redefines these variables;
      // importing that CSS must never be allowed to override the current viewport/safe-area model.
      const SYSTEM_OWNED_GEOMETRY_VARIABLES = Object.freeze(new Set([
        "--qwq-shell-height",
        "--qwq-viewport-width",
        "--qwq-viewport-height",
        "--global-device-safe-top",
        "--global-device-safe-bottom",
        "--global-system-safe-bottom",
        "--global-home-area-height",
        "--global-home-min-height"
      ]));

      function stripSystemOwnedDeveloperVariables(source) {
        const css = typeof source === "string" ? source : "";
        if (!css) return css;
        return css.replace(/(--[A-Za-z0-9_-]+)\s*:\s*([^;{}]+);/g, (declaration, key) => {
          return SYSTEM_OWNED_GEOMETRY_VARIABLES.has(String(key).trim()) ? "" : declaration;
        });
      }

      function normalizeDeveloperPresets(value) {
        if (!Array.isArray(value)) return [];
        return value.filter((item) => item && typeof item === "object" && !Array.isArray(item) && !(item instanceof Blob))
          .map((item) => ({
            ...item,
            css: typeof item.css === "string" ? stripSystemOwnedDeveloperVariables(item.css) : item.css
          }));
      }

      const INITIAL_DEVELOPER_TEMPLATE = `:root {
  --global-page-content-gap: 16px;
  --global-drawer-radius: 34px;
  --global-drawer-inline: clamp(16px, 4.8vw, 24px);
  --global-drawer-section-gap: 16px;
  --global-control-height: 44px;
  --global-section-radius: 28px;
  --global-modal-radius: 24px;
  --global-scrollbar-size: 4px;
  --global-scrollbar-thumb: #000000;
  --global-scrollbar-track: transparent;
  --global-scrollbar-radius: 999px;
  --global-scrollbar-inset: 4px;
  --global-scrollbar-min-thumb: 28px;
  --global-scrollbar-opacity: .82;
  --global-scrollbar-hide-delay: 720ms;
  --parent-radius: 26px;
  --ui-control-radius: 20px;
}`;
      const LEGACY_DEFAULT_DEVELOPER_CSS_082 = `:root {
  --global-page-start: 30px;
  --global-page-content-gap: 16px;
  --global-drawer-radius: 34px;
  --global-drawer-inline: clamp(16px, 4.8vw, 24px);
  --global-drawer-section-gap: 16px;
  --global-control-height: 44px;
  --global-section-radius: 28px;
  --global-modal-radius: 24px;
  --global-scrollbar-size: 0px;
  --global-scrollbar-horizontal-size: 0px;
  --global-scrollbar-thumb: transparent;
  --parent-radius: 26px;
  --ui-control-radius: 20px;
}`;

      const THEME_COLORS = ["#000000", "#3A3A3C", "#7C7C80", "#B8B8BC", "#FFFFFF"];
      const ICON_COLORS = ["#FFFFFF", "#111111", "#5F646B", "#8999A8", "#9EAA9F"];
      const FONT_DEFAULT_STACK = '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif';

      // 单一持久化源：沿用 清柳 历史真实 IndexedDB 与真实聚合主键。
      // 运行时只读写 active / settings / profile；历史 domain-kv / mask.presets
      // 只允许由开库后的 revision 迁移收口，正常业务不做兼容双读或双写。
      const QWQ_STABLE_DATABASE_NAME = "MobileDesktopThemeDB";
      if (myPhoneConfig.persistence.databaseName !== QWQ_STABLE_DATABASE_NAME) {
        throw new Error(`清柳 database identity changed: ${myPhoneConfig.persistence.databaseName}`);
      }
      const db = new Dexie(QWQ_STABLE_DATABASE_NAME);

      /*
       * IndexedDB 连接生命周期协议
       *
       * Edge 会冻结后台标签页/PWA 页面。被冻结页面若仍持有旧 schema 连接，新的
       * versionchange 会依法一直 blocked；这不是“加载慢”，而是两个页面对同一物理库
       * 的所有权冲突。这里以稳定频道协调 schema 交接，并在页面进入 frozen/pagehide
       * 前主动释放连接。协议只管理连接所有权，不复制数据、不切库，也不重试事务。
       */
      const PERSISTENCE_COORDINATION_CHANNEL = `${QWQ_STABLE_DATABASE_NAME}:schema-owner`;
      const PERSISTENCE_CONTEXT_ID = globalThis.crypto?.randomUUID?.()
        || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
      const TARGET_NATIVE_DATABASE_VERSION = Math.round(Number(myPhoneConfig.persistence.dexieSchemaRevision) * 10);
      const persistenceChannel = QWQPersistenceContext.crossVersionGuaranteed
        && typeof globalThis.BroadcastChannel === "function"
        ? new BroadcastChannel(PERSISTENCE_COORDINATION_CHANNEL)
        : null;

      function closeDatabaseForLifecycle({ allowReopen = true } = {}) {
        if (!db.isOpen()) return false;
        db.close({ disableAutoOpen: !allowReopen });
        return true;
      }

      persistenceChannel?.addEventListener("message", (event) => {
        const message = event.data;
        if (!message || message.sender === PERSISTENCE_CONTEXT_ID) return;
        if (message.type !== "release-for-schema-upgrade") return;
        const requestedVersion = Number(message.targetNativeVersion) || 0;
        if (requestedVersion <= TARGET_NATIVE_DATABASE_VERSION) return;
        const released = closeDatabaseForLifecycle({ allowReopen: false });
        if (released) {
          persistenceChannel.postMessage({
            type: "schema-connection-released",
            sender: PERSISTENCE_CONTEXT_ID,
            targetNativeVersion: requestedVersion
          });
        }
      });

      document.addEventListener("freeze", () => closeDatabaseForLifecycle({ allowReopen: true }));
      window.addEventListener("pagehide", () => closeDatabaseForLifecycle({ allowReopen: true }));

      // 历史曾出现过同一 schema revision 的不同分支，因此最终结构必须是所有已发布表/索引的并集。
      // v31 仅把最终结构交给 Dexie 直升，不再注册会解析历史用户行的中间 upgrade 回调。
      const DATABASE_SCHEMA_V16 = Object.freeze({
        themeState: "&key, scope, updatedAt",
        contacts: "&contactId, displayName, nickname, name, group, avatarAssetId, characterId, status, createdAt, updatedAt, [characterId+updatedAt]",
        characterTemplates: "&templateId, nickname, name, persona, avatarAssetId, defaultWorldBookId, createdAt, updatedAt",
        characters: "&characterId, templateId, contactId, name, persona, avatarAssetId, worldBookId, createdAt, updatedAt, [contactId+createdAt], [templateId+updatedAt], [worldBookId+updatedAt]",
        mediaAssets: "&assetId, kind, ownerType, ownerId, createdAt",
        worldBooks: "&worldBookId, &name, createdAt, updatedAt",
        worldBookEntries: "&entryId, worldBookId, priority, injectionPosition, createdAt, updatedAt, [worldBookId+priority], [worldBookId+updatedAt], [worldBookId+injectionPosition]",
        worldBookBindings: "&bindingId, conversationId, worldBookId, entryId, createdAt, updatedAt, [conversationId+worldBookId]"
      });
      const DATABASE_SCHEMA_V17 = Object.freeze({
        ...DATABASE_SCHEMA_V16,
        // v17 已发布物理 schema：运行时元数据与用户数据分表。
        persistenceMeta: "&key, updatedAt"
      });
      const DATABASE_SCHEMA_V19 = Object.freeze({
        ...DATABASE_SCHEMA_V17,
        // v19 源头模型：面具预设即 QQ 账号；联系人按账号隔离。世界书显式区分 global/local。
        contacts: "&contactId, accountId, displayName, nickname, name, group, avatarAssetId, characterId, status, createdAt, updatedAt, [accountId+displayName], [characterId+updatedAt]",
        worldBooks: "&worldBookId, &name, scope, createdAt, updatedAt"
      });
      const DATABASE_SCHEMA_V20 = Object.freeze({
        ...DATABASE_SCHEMA_V19,
        // v20 正式加入聊天记录业务表：按 QQ 账号 + 会话隔离，消息本体不再依赖 DOM 生命周期。
        chatMessages: "&messageId, accountId, conversationId, role, createdAt, updatedAt, [accountId+conversationId], [conversationId+createdAt]"
      });
      const DATABASE_SCHEMA_V21 = Object.freeze({
        ...DATABASE_SCHEMA_V20,
        // v21 让会话首页可以直接定位每个会话的末条消息，禁止为摘要全量解码历史记录及图片 Blob。
        chatMessages: "&messageId, accountId, conversationId, role, createdAt, updatedAt, [accountId+conversationId], [conversationId+createdAt], [accountId+conversationId+createdAt+messageId]"
      });
      // v22 不改变物理表结构；它是正式的数据连续性迁移节点。
      const DATABASE_SCHEMA_V22 = DATABASE_SCHEMA_V21;
      // v23 stores 不变：只负责在正式聚合记录验证完成后清理历史 themeState 键。
      const DATABASE_SCHEMA_V23 = DATABASE_SCHEMA_V22;
      // v24 将每个会话的聊天设置纳入同一 IndexedDB，避免 localStorage 双写和账号串数据。
      const DATABASE_SCHEMA_V24 = Object.freeze({
        ...DATABASE_SCHEMA_V23,
        chatSettings: "&conversationId, accountId, updatedAt, [accountId+updatedAt]"
      });
      // v25 正式加入表情包分组与表情数据；表情 URL 与描述独立持久化，不依赖页面 DOM。
      const DATABASE_SCHEMA_V25 = Object.freeze({
        ...DATABASE_SCHEMA_V24,
        stickerGroups: "&groupId, &name, createdAt, updatedAt",
        stickers: "&stickerId, groupId, url, createdAt, updatedAt, [groupId+createdAt], [groupId+url]"
      });
      // v26 将 QQ 钱包并入唯一 IndexedDB，结束钱包 localStorage 独立存储。
      const DATABASE_SCHEMA_V26 = Object.freeze({
        ...DATABASE_SCHEMA_V25,
        wallets: "&accountId, updatedAt"
      });
      // v27 不新增业务表；它是旧 V0.0.109 分支已经发布过的连续性节点。
      const DATABASE_SCHEMA_V27 = DATABASE_SCHEMA_V26;
      // v28 仍不改物理表结构，但必须是新的、不可复用的数据连续性节点。
      // 已经打开过任意 v27 分支的浏览器不会再次执行 v27 upgrader；
      // 因此“再次修 v27 代码”对这些浏览器没有任何作用，必须升到 v28。
      const DATABASE_SCHEMA_V28 = DATABASE_SCHEMA_V27;
      // v29 不改变物理表结构。它只修复启动连续性：正式 IndexedDB 必须先于任何
      // 历史 localStorage 恢复成为可读取状态，且历史坏记录不得阻断现有数据库 hydration。
      const DATABASE_SCHEMA_V29 = DATABASE_SCHEMA_V28;
      // v30 已发布 musicState 独立业务表；后续 revision 必须保持所有已发布表的并集，
      // 绝不能因换基线遗漏旧表，否则 Dexie 会把遗漏表视为删除。
      const DATABASE_SCHEMA_V30 = Object.freeze({
        ...DATABASE_SCHEMA_V29,
        musicState: "&key, updatedAt"
      });
      // v31 起结构升级与用户数据迁移彻底分离：Dexie upgrade 只负责表和索引，
      // active/settings/profile 与业务关系统一在 db.open() 成功后迁移。
      const DATABASE_SCHEMA_V31 = DATABASE_SCHEMA_V30;
      // v32 修复已发布 v31 的基线回退：恢复 v30 musicState，并强制重新执行 QQ 关系连续性语义。
      const DATABASE_SCHEMA_V32 = DATABASE_SCHEMA_V31;
      // v33 不删除、不重命名任何表。它是新的连续性节点：重新执行历史账号归属整理，
      // 专门接回“旧版本已有联系人/聊天，但当时尚未建立当前 QQ 账号实体”的数据。
      const DATABASE_SCHEMA_V33 = DATABASE_SCHEMA_V32;
      // v34 仍保持全部历史表和索引。它只提供新的、单调递增的迁移节点；线上/线下
      // 继续共用 chatMessages 表，conversationMode 只作为渲染表面标签。
      const DATABASE_SCHEMA_V34 = DATABASE_SCHEMA_V33;
      // v35 新增正式主屏布局表；仍保持历史所有表与索引的并集。
      const DATABASE_SCHEMA_V35 = Object.freeze({
        ...DATABASE_SCHEMA_V34,
        homeScreenState: "&key, updatedAt"
      });
      // v36 首次把“一个 QQ 账号 = 一个唯一身份”落为独立实体表。
      const DATABASE_SCHEMA_V36 = Object.freeze({
        ...DATABASE_SCHEMA_V35,
        qqAccountProfiles: "&accountId, nickname, name, avatarAssetId, coverAssetId, createdAt, updatedAt"
      });
      // v38：登录标识唯一性由账号仓库的事务约束维护，不再交给 IndexedDB 唯一索引。
      // 这是迁移顺序的结构性修正：旧数据必须先能成功开库，迁移器才有机会校验/收口冲突；
      // 否则历史重复标识会在 onupgradeneeded 创建唯一索引时提前终止整个数据库升级。
      // 物理表名 qqAccountProfiles 仅为既有 IndexedDB 原位升级保留，运行时语义始终是完整 QQ account。
      const DATABASE_SCHEMA_V38 = Object.freeze({
        ...DATABASE_SCHEMA_V36,
        qqAccountProfiles: "&accountId, qqNumber, phoneNumber, nickname, name, avatarAssetId, coverAssetId, registeredAt, createdAt, updatedAt",
        qqAccountState: "&key, accountId, updatedAt"
      });
      // v39 建立 Shared Memory Core 的唯一长期事实表。
      // Schema 升级只创建表与索引；历史 coreMemory 的用户数据迁移由 Memory Repository 在系统连续性完成后执行。
      const DATABASE_SCHEMA_V39 = Object.freeze({
        ...DATABASE_SCHEMA_V38,
        memory_items: [
          "&id", "schemaVersion", "accountId", "memorySpaceKey", "characterId", "sourceConversationId",
          "status", "subjectKey", "category", "factType", "scope", "sourceApp", "sourceSurface",
          "occurredAt", "createdAt", "updatedAt", "*keywords", "*entityKeys", "*sourceIds",
          "[accountId+memorySpaceKey+status]", "[memorySpaceKey+category+status]",
          "[accountId+subjectKey+status]", "[sourceApp+sourceSurface]"
        ].join(",")
      });
      // v40 只扩展 memory_items 的原子记忆检索键；历史内容不在 versionchange 中改写。
      // schemaVersion=2 / fingerprint / batchId 的数据归一化由 Memory Repository 在正式业务链中幂等执行。
      const DATABASE_SCHEMA_V40 = Object.freeze({
        ...DATABASE_SCHEMA_V39,
        memory_items: [
          "&id", "schemaVersion", "accountId", "memorySpaceKey", "characterId", "sourceConversationId",
          "status", "subjectKey", "category", "factType", "scope", "sourceApp", "sourceSurface",
          "fingerprint", "batchId", "originKind", "occurredAt", "createdAt", "updatedAt",
          "*keywords", "*entityKeys", "*sourceIds",
          "[accountId+memorySpaceKey+status]", "[memorySpaceKey+category+status]",
          "[accountId+subjectKey+status]", "[sourceApp+sourceSurface]",
          "[accountId+memorySpaceKey+fingerprint]", "[accountId+memorySpaceKey+factType+status]",
          "[accountId+memorySpaceKey+updatedAt]"
        ].join(",")
      });
      // v41 建立生命周期治理所需的稳定事实槽、命题指纹、证据与审计事件索引。
      // memory_items 仍是唯一事实源；memory_evidence / memory_lifecycle_events 只记录来源证据和治理决策，不参与事实双写。
      const DATABASE_SCHEMA_V41 = Object.freeze({
        ...DATABASE_SCHEMA_V40,
        memory_items: [
          "&id", "schemaVersion", "lifecycleRevision", "accountId", "memorySpaceKey", "characterId", "sourceConversationId",
          "status", "subjectKey", "category", "factType", "scope", "sourceApp", "sourceSurface",
          "fingerprint", "predicateKey", "valueKey", "lifecycleKey", "propositionFingerprint", "evidenceKey",
          "conflictGroupId", "batchId", "originKind", "occurredAt", "firstObservedAt", "lastObservedAt", "createdAt", "updatedAt",
          "*keywords", "*entityKeys", "*sourceIds",
          "[accountId+memorySpaceKey]", "[accountId+memorySpaceKey+status]", "[memorySpaceKey+category+status]",
          "[accountId+subjectKey+status]", "[sourceApp+sourceSurface]",
          "[accountId+memorySpaceKey+fingerprint]", "[accountId+memorySpaceKey+factType+status]",
          "[accountId+memorySpaceKey+updatedAt]", "[accountId+memorySpaceKey+lifecycleKey+status]",
          "[accountId+memorySpaceKey+propositionFingerprint+status]"
        ].join(","),
        memory_evidence: [
          "&id", "memoryId", "evidenceKey", "accountId", "memorySpaceKey", "sourceApp", "sourceSurface",
          "batchId", "observedAt", "createdAt", "*sourceIds",
          "[memoryId+evidenceKey]", "[accountId+memorySpaceKey+memoryId]"
        ].join(","),
        memory_lifecycle_events: [
          "&id", "accountId", "memorySpaceKey", "memoryId", "decision", "lifecycleKey", "propositionFingerprint",
          "batchId", "createdAt", "[accountId+memorySpaceKey+createdAt]", "[memoryId+createdAt]",
          "[accountId+memorySpaceKey+decision]"
        ].join(",")
      });
      // v42 为阶段 4 精确召回建立账号+记忆空间命名空间内的派生检索键。
      // retrievalKeys 只加速 canonical memory_items 的确定性查找，不是第二事实源；
      // 旧行由 Repository 在开库后幂等补齐，禁止在 versionchange 中遍历用户数据。
      const DATABASE_SCHEMA_V42 = Object.freeze({
        ...DATABASE_SCHEMA_V41,
        memory_items: [
          "&id", "schemaVersion", "lifecycleRevision", "retrievalRevision", "accountId", "memorySpaceKey", "characterId", "sourceConversationId",
          "status", "subjectKey", "category", "factType", "scope", "sourceApp", "sourceSurface",
          "fingerprint", "predicateKey", "valueKey", "lifecycleKey", "propositionFingerprint", "evidenceKey",
          "conflictGroupId", "batchId", "originKind", "occurredAt", "firstObservedAt", "lastObservedAt", "createdAt", "updatedAt",
          "*keywords", "*entityKeys", "*sourceIds", "*retrievalKeys",
          "[accountId+memorySpaceKey]", "[accountId+memorySpaceKey+status]", "[memorySpaceKey+category+status]",
          "[accountId+subjectKey+status]", "[sourceApp+sourceSurface]",
          "[accountId+memorySpaceKey+fingerprint]", "[accountId+memorySpaceKey+factType+status]",
          "[accountId+memorySpaceKey+updatedAt]", "[accountId+memorySpaceKey+status+updatedAt]",
          "[accountId+memorySpaceKey+lifecycleKey+status]", "[accountId+memorySpaceKey+propositionFingerprint+status]"
        ].join(",")
      });
      // v43 为阶段 5 Hybrid 召回新增派生向量缓存。
      // memory_embeddings 只保存可由 canonical memory_items + 当前 embedding 配置重新生成的向量，
      // 不是事实源；每条记录绑定 accountId + memorySpaceKey + memoryId + contentFingerprint。
      const DATABASE_SCHEMA_V43 = Object.freeze({
        ...DATABASE_SCHEMA_V42,
        memory_embeddings: [
          "&id", "embeddingRevision", "memoryId", "accountId", "memorySpaceKey", "contentFingerprint",
          "providerKey", "model", "dimensions", "createdAt", "updatedAt",
          "[accountId+memorySpaceKey]", "[memoryId+contentFingerprint]", "[providerKey+model]"
        ].join(",")
      });
      // v44 为阶段 6 的冲突成组召回与无原文 Recall Telemetry 建立派生索引。
      // memory_recall_telemetry 只保存匿名化检索指标，不保存 query/content，也不是事实源。
      const DATABASE_SCHEMA_V44 = Object.freeze({
        ...DATABASE_SCHEMA_V43,
        memory_items: [
          "&id", "schemaVersion", "lifecycleRevision", "retrievalRevision", "accountId", "memorySpaceKey", "characterId", "sourceConversationId",
          "status", "subjectKey", "category", "factType", "scope", "sourceApp", "sourceSurface",
          "fingerprint", "predicateKey", "valueKey", "lifecycleKey", "propositionFingerprint", "evidenceKey",
          "conflictGroupId", "batchId", "originKind", "occurredAt", "firstObservedAt", "lastObservedAt", "createdAt", "updatedAt",
          "*keywords", "*entityKeys", "*sourceIds", "*retrievalKeys",
          "[accountId+memorySpaceKey]", "[accountId+memorySpaceKey+status]", "[memorySpaceKey+category+status]",
          "[accountId+subjectKey+status]", "[sourceApp+sourceSurface]",
          "[accountId+memorySpaceKey+fingerprint]", "[accountId+memorySpaceKey+factType+status]",
          "[accountId+memorySpaceKey+updatedAt]", "[accountId+memorySpaceKey+status+updatedAt]",
          "[accountId+memorySpaceKey+lifecycleKey+status]", "[accountId+memorySpaceKey+propositionFingerprint+status]",
          "[accountId+memorySpaceKey+conflictGroupId+status]"
        ].join(","),
        memory_recall_telemetry: [
          "&id", "telemetryRevision", "accountId", "memorySpaceKey", "consumerApp", "consumerSurface", "purpose",
          "queryFingerprint", "createdAt", "[accountId+memorySpaceKey+createdAt]", "[consumerApp+createdAt]", "[purpose+createdAt]"
        ].join(",")
      });
      // v45 为阶段 7 正式 AccessGuard 与账号级 global 安全聚合增加权限/全局检索派生索引。
      // globalRetrievalKeys 只对 scope=global 且主体明确属于 account:user 的 canonical memory 生成；
      // 其他角色/关系事实即使被误标 global 也不会跨好友空间传播。
      const DATABASE_SCHEMA_V45 = Object.freeze({
        ...DATABASE_SCHEMA_V44,
        memory_items: [
          "&id", "schemaVersion", "lifecycleRevision", "retrievalRevision", "accessRevision", "globalRetrievalRevision", "accountId", "memorySpaceKey", "characterId", "sourceConversationId",
          "status", "subjectKey", "category", "factType", "scope", "sourceApp", "sourceSurface",
          "fingerprint", "predicateKey", "valueKey", "lifecycleKey", "propositionFingerprint", "evidenceKey",
          "conflictGroupId", "batchId", "originKind", "occurredAt", "firstObservedAt", "lastObservedAt", "createdAt", "updatedAt",
          "*keywords", "*entityKeys", "*sourceIds", "*retrievalKeys", "*globalRetrievalKeys",
          "[accountId+memorySpaceKey]", "[accountId+memorySpaceKey+status]", "[memorySpaceKey+category+status]",
          "[accountId+subjectKey+status]", "[sourceApp+sourceSurface]",
          "[accountId+memorySpaceKey+fingerprint]", "[accountId+memorySpaceKey+factType+status]",
          "[accountId+memorySpaceKey+updatedAt]", "[accountId+memorySpaceKey+status+updatedAt]",
          "[accountId+memorySpaceKey+lifecycleKey+status]", "[accountId+memorySpaceKey+propositionFingerprint+status]",
          "[accountId+memorySpaceKey+conflictGroupId+status]", "[accountId+scope+status]"
        ].join(",")
      });
      // v46 为阶段 11 的账号用户 canonical 归一化与 evidence provenance 建立正式来源索引。
      // memory_evidence 记录来源会话/角色，只用于证据、删除级联和审计；canonical 事实仍只在 memory_items。
      const DATABASE_SCHEMA_V46 = Object.freeze({
        ...DATABASE_SCHEMA_V45,
        memory_items: [
          "&id", "schemaVersion", "lifecycleRevision", "retrievalRevision", "accessRevision", "globalRetrievalRevision", "evidenceProvenanceRevision", "accountId", "memorySpaceKey", "characterId", "sourceConversationId",
          "status", "subjectKey", "category", "factType", "scope", "sourceApp", "sourceSurface",
          "fingerprint", "predicateKey", "valueKey", "lifecycleKey", "propositionFingerprint", "evidenceKey",
          "conflictGroupId", "batchId", "originKind", "occurredAt", "firstObservedAt", "lastObservedAt", "createdAt", "updatedAt",
          "*keywords", "*entityKeys", "*sourceIds", "*retrievalKeys", "*globalRetrievalKeys",
          "[accountId+memorySpaceKey]", "[accountId+memorySpaceKey+status]", "[memorySpaceKey+category+status]",
          "[accountId+subjectKey+status]", "[sourceApp+sourceSurface]",
          "[accountId+memorySpaceKey+fingerprint]", "[accountId+memorySpaceKey+factType+status]",
          "[accountId+memorySpaceKey+updatedAt]", "[accountId+memorySpaceKey+status+updatedAt]",
          "[accountId+memorySpaceKey+lifecycleKey+status]", "[accountId+memorySpaceKey+propositionFingerprint+status]",
          "[accountId+memorySpaceKey+conflictGroupId+status]", "[accountId+scope+status]"
        ].join(","),
        memory_evidence: [
          "&id", "memoryId", "evidenceKey", "accountId", "memorySpaceKey", "sourceApp", "sourceSurface",
          "sourceConversationId", "sourceCharacterId", "provenanceRevision", "batchId", "observedAt", "createdAt", "*sourceIds",
          "[memoryId+evidenceKey]", "[accountId+memorySpaceKey+memoryId]", "[accountId+sourceConversationId]", "[accountId+sourceCharacterId]"
        ].join(",")
      });
      // v47 将自动长期记忆生产游标从 QQ chatSettings 拆回 Shared Memory Core。
      // memory_producer_checkpoints 只保存可重建的处理进度/计数，不保存消息正文，也不是第二事实源。
      const DATABASE_SCHEMA_V47 = Object.freeze({
        ...DATABASE_SCHEMA_V46,
        memory_producer_checkpoints: [
          "&id", "checkpointRevision", "accountId", "memorySpaceKey", "producerApp", "conversationId",
          "cursorCreatedAt", "cursorMessageId", "processedCount", "onlineCount", "offlineCount", "updatedAt",
          "[accountId+producerApp+conversationId]", "[accountId+memorySpaceKey+producerApp]"
        ].join(",")
      });
      // v48 是物理 schema 完整性收口节点。历史上同一 revision 曾出现不同分支，
      // 已经安装到 v47 的浏览器不会再次执行同版本 onupgradeneeded，导致逻辑 Table 存在、
      // 物理 object store 却缺失，最终在好友头像等事务建立时抛 NotFoundError。
      // v48 不复制、不重置用户数据，只让 IndexedDB 按最终 schema 并集完成一次正式 versionchange。
      const DATABASE_SCHEMA_V48 = Object.freeze({
        ...DATABASE_SCHEMA_V47
      });
      // v49 正式接入 YIU Calendar 源页面所需业务表；仍沿用 清柳 唯一 MobileDesktopThemeDB。
      // 不新建数据库、不做 localStorage/sessionStorage 兼容写入。
      const DATABASE_SCHEMA_V49 = Object.freeze({
        ...DATABASE_SCHEMA_V48,
        calendarItems: "++id, date, type, createdAt",
        healthRecords: "++id, date, metric, createdAt"
      });
      // v50 将正在进行的 QQ 角色生成任务纳入正式 Dexie 生命周期。
      // 这里只保存可恢复的作业元数据，不保存模型响应正文；同一账号/会话最多一个未完成作业。
      const DATABASE_SCHEMA_V50 = Object.freeze({
        ...DATABASE_SCHEMA_V49,
        chatGenerationJobs: "[accountId+conversationId], accountId, conversationId, status, replyGroupId, conversationMode, createdAt, updatedAt"
      });
      const DATABASE_SCHEMA = DATABASE_SCHEMA_V50;

      const PERSISTENCE_LAYOUT = "aggregate-records-v2";
      const PERSISTENCE_KEYS = Object.freeze(["active", "settings", "profile"]);
      const LEGACY_DOMAIN_KEYS = Object.freeze({
        active: ["theme.appearance", "theme.icons", "theme.fonts", "theme.developer"],
        settings: ["settings.security", "settings.notifications", "settings.api", "settings.image", "settings.tts", "settings.extensions", "settings.assistant", "settings.active"],
        profile: ["profile.mask", "profile.active"]
      });
      const LEGACY_MASK_KEY = "mask.presets";

      function persistenceRecordTime(record) {
        const value = Number(record?.updatedAt);
        return Number.isFinite(value) ? value : 0;
      }

      function persistenceRecordValue(record) {
        return record?.value && typeof record.value === "object" && !Array.isArray(record.value)
          ? { ...record.value }
          : null;
      }

      function mergePersistenceValue(baseRecord, sourceRecord, targetKey) {
        const sourceValue = persistenceRecordValue(sourceRecord);
        if (!sourceValue) return baseRecord;
        if (!baseRecord) {
          return {
            key: targetKey,
            version: PERSISTENCE_VERSION,
            value: { ...sourceValue },
            updatedAt: persistenceRecordTime(sourceRecord)
          };
        }
        const baseValue = persistenceRecordValue(baseRecord) || {};
        const baseTime = persistenceRecordTime(baseRecord);
        const sourceTime = persistenceRecordTime(sourceRecord);
        const next = { ...baseValue };
        if (sourceTime >= baseTime) {
          Object.assign(next, sourceValue);
        } else {
          Object.entries(sourceValue).forEach(([key, value]) => {
            if (!Object.prototype.hasOwnProperty.call(next, key)) next[key] = value;
          });
        }
        return {
          key: targetKey,
          version: PERSISTENCE_VERSION,
          value: next,
          updatedAt: Math.max(baseTime, sourceTime)
        };
      }

      function projectLegacySettings(value) {
        const next = value && typeof value === "object" && !Array.isArray(value) ? { ...value } : {};
        if (next.imageSource === "api") {
          if (!next.imageProvider && typeof next.apiProvider === "string") next.imageProvider = next.apiProvider;
          if (!next.imageBaseUrl && typeof next.apiBaseUrl === "string") next.imageBaseUrl = next.apiBaseUrl;
          if (!next.imageApiKey && typeof next.apiKey === "string") next.imageApiKey = next.apiKey;
        }
        if (next.ttsSource === "api") {
          if (!next.ttsProvider && typeof next.apiProvider === "string") next.ttsProvider = next.apiProvider;
          if (!next.ttsBaseUrl && typeof next.apiBaseUrl === "string") next.ttsBaseUrl = next.apiBaseUrl;
          if (!next.ttsApiKey && typeof next.apiKey === "string") next.ttsApiKey = next.apiKey;
        }
        // V0.0.380 shipped an unconfigured OpenAI TTS profile as the default.
        // It looked enabled but could never synthesize without a key. Only migrate that exact untouched default
        // to the browser's real SpeechSynthesis provider; configured/custom TTS remains untouched.
        const untouched0380Tts = String(next.ttsProvider || "") === "openai"
          && String(next.ttsBaseUrl || "") === "https://api.openai.com/v1"
          && !String(next.ttsApiKey || "").trim()
          && String(next.ttsModel || "") === "gpt-4o-mini-tts"
          && String(next.ttsVoice || "") === "coral"
          && (!Array.isArray(next.ttsPresets) || next.ttsPresets.length === 0)
          && (!next.ttsProviderProfiles || (typeof next.ttsProviderProfiles === "object" && Object.keys(next.ttsProviderProfiles).length === 0));
        if (untouched0380Tts) {
          next.ttsProvider = "system";
          next.ttsBaseUrl = "";
          next.ttsApiKey = "";
          next.ttsModel = "system";
          next.ttsModels = ["system"];
          next.ttsVoice = "";
          next.ttsVoices = [];
        }
        return next;
      }

      function canonicalizePersistenceRecords(records) {
        const map = new Map((Array.isArray(records) ? records : [])
          .filter((record) => record && typeof record.key === "string")
          .map((record) => [record.key, record]));

        let active = map.get("active") || null;
        let settings = map.get("settings") || null;
        let profile = map.get("profile") || null;

        [...LEGACY_DOMAIN_KEYS.active]
          .map((key) => map.get(key)).filter(Boolean)
          .sort((a, b) => persistenceRecordTime(a) - persistenceRecordTime(b))
          .forEach((record) => { active = mergePersistenceValue(active, record, "active"); });
        [...LEGACY_DOMAIN_KEYS.settings]
          .map((key) => map.get(key)).filter(Boolean)
          .sort((a, b) => persistenceRecordTime(a) - persistenceRecordTime(b))
          .forEach((record) => { settings = mergePersistenceValue(settings, record, "settings"); });
        [...LEGACY_DOMAIN_KEYS.profile]
          .map((key) => map.get(key)).filter(Boolean)
          .sort((a, b) => persistenceRecordTime(a) - persistenceRecordTime(b))
          .forEach((record) => { profile = mergePersistenceValue(profile, record, "profile"); });

        if (active?.value) {
          const value = { ...active.value };
          delete value.maskPresets;
          delete value.activeMaskPresetId;
          if (typeof value.developerCss === "string") {
            value.developerCss = stripSystemOwnedDeveloperVariables(value.developerCss);
          }
          if (Array.isArray(value.developerPresets)) {
            value.developerPresets = normalizeDeveloperPresets(value.developerPresets);
          }
          active = { ...active, key: "active", version: PERSISTENCE_VERSION, value };
        }
        if (settings?.value) settings = { ...settings, key: "settings", version: PERSISTENCE_VERSION, value: projectLegacySettings(settings.value) };
        if (profile?.value) {
          const value = { ...profile.value };
          delete value.maskPresets;
          profile = { ...profile, key: "profile", version: PERSISTENCE_VERSION, value };
        }
        return [active, settings, profile].filter(Boolean);
      }

      function legacyMaskSources(records) {
        const rows = Array.isArray(records) ? records : [];
        const map = new Map(rows.filter((record) => record && typeof record.key === "string").map((record) => [record.key, record]));
        const candidates = [];
        const maskRecord = persistenceRecordValue(map.get(LEGACY_MASK_KEY));
        if (maskRecord) candidates.push(maskRecord);
        for (const key of ["active", "profile"]) {
          const value = persistenceRecordValue(map.get(key));
          if (value && (Array.isArray(value.maskPresets) || value.activeMaskPresetId)) candidates.push(value);
        }
        return candidates;
      }

      // v16 已发布迁移的一部分：此转换语义必须永久冻结。
      // 历史头像损坏只能表示“该头像不可转换”，不能让整个 IndexedDB schema 升级回滚。
      function decodeLegacyImageDataUrlV16(value) {
        if (typeof value !== "string") return null;
        const match = value.match(/^data:([^;,]+)?(;base64)?,(.*)$/s);
        if (!match) return null;
        try {
          const mime = match[1] || "application/octet-stream";
          const payload = match[3] || "";
          const binary = match[2] ? atob(payload) : decodeURIComponent(payload);
          const bytes = new Uint8Array(binary.length);
          for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index) & 0xff;
          return new Blob([bytes], { type: mime });
        } catch (error) {
          console.error("legacy data URL decode failed", error);
          return null;
        }
      }

      async function migrateLegacyMaskPresets(transaction, records, profileRecord) {
        const templateTable = transaction.table("characterTemplates");
        const assetTable = transaction.table("mediaAssets");
        const sources = legacyMaskSources(records);
        const legacyById = new Map();
        let requestedActiveId = profileRecord?.value?.activeMaskPresetId || null;

        for (const source of sources) {
          if (!requestedActiveId && typeof source.activeMaskPresetId === "string") requestedActiveId = source.activeMaskPresetId;
          const presets = Array.isArray(source.maskPresets) ? source.maskPresets : [];
          presets.forEach((preset, index) => {
            if (!preset || typeof preset !== "object") return;
            const rawId = String(preset.templateId || preset.id || "").trim();
            const fallbackSeed = String(preset.nickname || preset.name || "")
              .split("")
              .reduce((sum, char) => ((sum * 31) + char.charCodeAt(0)) | 0, 7);
            const id = rawId || `legacy-mask-${index}-${Math.abs(fallbackSeed)}`;
            if (!legacyById.has(id)) legacyById.set(id, preset);
          });
        }

        const now = Date.now();
        for (const [templateId, legacy] of legacyById) {
          const existing = await templateTable.get(templateId);
          const nickname = String(legacy.nickname || legacy.displayName || legacy.name || "").trim();
          const name = String(legacy.name || "").trim();
          const persona = String(legacy.persona ?? legacy.settingContent ?? legacy.content ?? "").replace(/\r\n?/g, "\n").trim();
          let avatarAssetId = existing?.avatarAssetId || (typeof legacy.avatarAssetId === "string" ? legacy.avatarAssetId : null);

          if (!avatarAssetId) {
            let avatarBlob = legacy.avatar instanceof Blob ? legacy.avatar : null;
            if (!avatarBlob) avatarBlob = decodeLegacyImageDataUrlV16(legacy.avatar);
            if (avatarBlob instanceof Blob && String(avatarBlob.type || "").startsWith("image/")) {
              const persistentAvatarBlob = avatarBlob;
              avatarAssetId = `asset-legacy-mask-${templateId}`;
              const existingAsset = await assetTable.get(avatarAssetId);
              if (!existingAsset) {
                await assetTable.put({
                  assetId: avatarAssetId,
                  kind: "character-template-avatar",
                  ownerType: "character-template",
                  ownerId: templateId,
                  mime: persistentAvatarBlob.type || "application/octet-stream",
                  size: persistentAvatarBlob.size,
                  blob: persistentAvatarBlob,
                  createdAt: Number(legacy.createdAt) || now,
                  updatedAt: Number(legacy.updatedAt) || now
                });
              }
            }
          }

          await templateTable.put({
            ...legacy,
            templateId,
            nickname: existing?.nickname || nickname || name,
            name: existing?.name || name,
            persona: existing?.persona || persona,
            avatarAssetId,
            defaultWorldBookId: existing?.defaultWorldBookId || legacy.defaultWorldBookId || null,
            createdAt: Number(existing?.createdAt || legacy.createdAt) || now,
            updatedAt: Math.max(Number(existing?.updatedAt || 0), Number(legacy.updatedAt || 0), now)
          });
        }

        if (requestedActiveId && !(await templateTable.get(String(requestedActiveId)))) requestedActiveId = null;
        const profileValue = {
          ...(profileRecord?.value && typeof profileRecord.value === "object" && !Array.isArray(profileRecord.value) ? profileRecord.value : {}),
          activeMaskPresetId: requestedActiveId || null
        };
        delete profileValue.maskPresets;
        return {
          key: "profile",
          version: PERSISTENCE_VERSION,
          value: profileValue,
          updatedAt: now
        };
      }

      /*
       * v35 连续升级协议（源头规则）
       * 1. MobileDesktopThemeDB 永不随应用版本改名；
       * 2. IndexedDB versionchange 只负责最终表与索引，不读取或改写用户记录；
       * 3. 历史聚合、面具、业务关系在 db.open() 成功后迁移，单条坏数据不得回滚开库；
       * 4. 正常运行只读正式 active/settings/profile 与业务表，不做历史 key 双读或双写。
       */
      const SCHEMA_FINGERPRINT = (() => {
        const raw = JSON.stringify(DATABASE_SCHEMA);
        let hash = 0;
        for (let index = 0; index < raw.length; index += 1) {
          hash = (Math.imul(31, hash) + raw.charCodeAt(index)) | 0;
        }
        return `fp${(hash >>> 0).toString(36)}`;
      })();
      const SCHEMA_FINGERPRINT_KEY = "schema.current";

      // 注册连续发布的物理 schema。Dexie 根据浏览器中的实际结构直接升级到当前 v50；
      // 表集合始终是历史已发布结构的并集，避免旧表因遗漏而被误删。
      db.version(40).stores(DATABASE_SCHEMA_V40);
      db.version(41).stores(DATABASE_SCHEMA_V41);
      db.version(42).stores(DATABASE_SCHEMA_V42);
      db.version(43).stores(DATABASE_SCHEMA_V43);
      db.version(44).stores(DATABASE_SCHEMA_V44);
      db.version(45).stores(DATABASE_SCHEMA_V45);
      db.version(46).stores(DATABASE_SCHEMA_V46);
      db.version(47).stores(DATABASE_SCHEMA_V47);
      db.version(48).stores(DATABASE_SCHEMA_V48);
      db.version(49).stores(DATABASE_SCHEMA_V49);
      db.version(50).stores(DATABASE_SCHEMA_V50);

      function cloneSerializable(value) {
        if (value === undefined) return {};
        if (value === null || typeof value !== "object") return value;
        if (typeof structuredClone === "function") return structuredClone(value);
        if (value instanceof Blob) return value.slice(0, value.size, value.type);
        if (value instanceof ArrayBuffer) return value.slice(0);
        if (ArrayBuffer.isView(value)) return value.slice ? value.slice() : new value.constructor(value);
        if (Array.isArray(value)) return value.map((item) => cloneSerializable(item));
        return Object.fromEntries(Object.entries(value).map(([key, item]) => [
          key,
          item && typeof item === "object" ? cloneSerializable(item) : item
        ]));
      }

      function containsEmbeddedImageData(value, seen = new WeakSet()) {
        if (typeof value === "string") return value.startsWith("data:image/");
        if (!value || typeof value !== "object" || value instanceof Blob || value instanceof ArrayBuffer || ArrayBuffer.isView(value)) return false;
        if (seen.has(value)) return false;
        seen.add(value);
        if (Array.isArray(value)) return value.some((item) => containsEmbeddedImageData(item, seen));
        return Object.values(value).some((item) => containsEmbeddedImageData(item, seen));
      }

      function themeMediaSlot(slot) { return `theme:${String(slot || "")}`; }

      const QWQ_IMAGE_MAX_BYTES = 4 * 1024 * 1024;
      const QWQ_IMAGE_ACCEPT = ".jpg,.jpeg,.jpge,.png,.gif,.webp,.wep,image/jpeg,image/png,image/gif,image/webp";
      const QWQ_CHAT_MEDIA_ACCEPT = `${QWQ_IMAGE_ACCEPT},.mp4,video/mp4`;
      const QWQ_ALLOWED_IMAGE_MIMES = new Set(["image/jpeg", "image/png", "image/gif", "image/webp"]);

      function uploadMimeFromName(name = "") {
        const extension = String(name || "").trim().toLowerCase().split("?")[0].split("#")[0].split(".").pop();
        const map = {
          jpg: "image/jpeg",
          jpeg: "image/jpeg",
          jpge: "image/jpeg",
          png: "image/png",
          gif: "image/gif",
          webp: "image/webp",
          wep: "image/webp",
          mp4: "video/mp4"
        };
        return map[extension] || "";
      }

      async function sniffUploadMime(blob) {
        const bytes = new Uint8Array(await blob.slice(0, 512).arrayBuffer());
        const has = (...signature) => signature.every((value, index) => bytes[index] === value);
        if (has(0xFF, 0xD8, 0xFF)) return "image/jpeg";
        if (has(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)) return "image/png";
        if (bytes.length >= 6) {
          const head6 = String.fromCharCode(...bytes.slice(0, 6));
          if (head6 === "GIF87a" || head6 === "GIF89a") return "image/gif";
        }
        if (bytes.length >= 12) {
          const riff = String.fromCharCode(...bytes.slice(0, 4));
          const webp = String.fromCharCode(...bytes.slice(8, 12));
          if (riff === "RIFF" && webp === "WEBP") return "image/webp";
          if (String.fromCharCode(...bytes.slice(4, 8)) === "ftyp") {
            const brand = String.fromCharCode(...bytes.slice(8, 12)).toLowerCase();
            if (["isom", "iso2", "iso3", "iso4", "iso5", "iso6", "mp41", "mp42", "avc1", "mmp4", "dash", "msnv", "m4v "].includes(brand)) return "video/mp4";
          }
        }
        return "";
      }

      async function materializeBlobForPersistence(blob, mimeOverride = "") {
        if (!(blob instanceof Blob) || !blob.size) throw new Error("持久化媒体内容无效");
        const type = String(mimeOverride || blob.type || "application/octet-stream").toLowerCase().split(";")[0].trim() || "application/octet-stream";
        // File input on Android/Chromium may be backed by a temporary content URI. IndexedDB
        // cannot reliably clone that external backing store after the picker lifetime ends and
        // throws: "Error preparing Blob/File data to be stored in object store". Read the
        // bytes once and create a document-owned Blob before it reaches any object store.
        const bytes = await blob.arrayBuffer();
        return new Blob([bytes], { type });
      }

      async function materializeBinaryForPersistence(value, seen = new WeakMap()) {
        if (value instanceof Blob) {
          if (seen.has(value)) return seen.get(value);
          const persistentBlob = await materializeBlobForPersistence(value);
          seen.set(value, persistentBlob);
          return persistentBlob;
        }
        if (value instanceof ArrayBuffer) return value.slice(0);
        if (ArrayBuffer.isView(value)) return value.slice ? value.slice() : new value.constructor(value);
        if (!value || typeof value !== "object") return value;
        if (seen.has(value)) return seen.get(value);
        const target = Array.isArray(value) ? [] : {};
        seen.set(value, target);
        if (Array.isArray(value)) {
          for (const item of value) target.push(await materializeBinaryForPersistence(item, seen));
        } else {
          for (const [key, item] of Object.entries(value)) target[key] = await materializeBinaryForPersistence(item, seen);
        }
        return target;
      }

      async function normalizePickedMediaBlob(blob, { allowVideo = false } = {}) {
        if (!(blob instanceof Blob) || !blob.size) throw new Error("请选择有效的媒体文件");
        const declared = String(blob.type || "").toLowerCase().split(";")[0].trim();
        const detected = await sniffUploadMime(blob);
        const named = uploadMimeFromName(typeof File !== "undefined" && blob instanceof File ? blob.name : "");
        const mime = detected || (QWQ_ALLOWED_IMAGE_MIMES.has(declared) || (allowVideo && declared === "video/mp4") ? declared : "") || named;
        if (QWQ_ALLOWED_IMAGE_MIMES.has(mime)) {
          return materializeBlobForPersistence(blob, mime);
        }
        if (allowVideo && mime === "video/mp4") {
          return materializeBlobForPersistence(blob, mime);
        }
        throw new Error(allowVideo
          ? "仅支持 JPG / JPEG / JPGE、PNG、GIF、WEBP / WEP、MP4"
          : "仅支持 JPG / JPEG / JPGE、PNG、GIF、WEBP / WEP 图片");
      }

      async function normalizePickedImageBlob(blob) {
        return normalizePickedMediaBlob(blob, { allowVideo: false });
      }

      function readImageAsDataUrl(blob) {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.addEventListener("load", () => resolve(String(reader.result || "")), { once: true });
          reader.addEventListener("error", () => reject(reader.error || new Error("图片读取失败")), { once: true });
          reader.readAsDataURL(blob);
        });
      }

      function decodeDataUrlImage(dataUrl) {
        return new Promise((resolve, reject) => {
          const image = new Image();
          image.decoding = "async";
          image.addEventListener("load", () => resolve(image), { once: true });
          image.addEventListener("error", () => reject(new Error("图片解码失败")), { once: true });
          image.src = dataUrl;
        });
      }

      function canvasToBlob(canvas, mime, quality) {
        return new Promise((resolve) => {
          if (typeof canvas.toBlob !== "function") {
            resolve(null);
            return;
          }
          canvas.toBlob(resolve, mime, quality);
        });
      }

      async function prepareImageBlob(blob, options = {}) {
        const source = await normalizePickedImageBlob(blob);
        const maxSide = Math.max(160, Math.min(4096, Number(options.maxSide) || 2048));
        const maxBytes = Math.max(256 * 1024, Number(options.maxBytes) || QWQ_IMAGE_MAX_BYTES);
        const initialQuality = Math.max(.5, Math.min(.95, Number(options.quality) || .9));
        const sourceType = String(source.type || "").toLowerCase();
        const forceReencode = options.forceReencode === true;
        // User media keeps its intrinsic pixel dimensions by default. Compression may change
        // encoding/quality; resizing remains an explicit opt-in behavior for future callers.
        const preserveDimensions = options.preserveDimensions !== false;
        const preserveAlpha = options.preserveAlpha === true || sourceType === "image/png" || sourceType === "image/webp" || sourceType === "image/gif";

        // GIF 在 4MB 以内保留原始动画；超过阈值时进入统一压缩链，避免超大 Blob 直接进入 IndexedDB。
        if (sourceType === "image/gif" && source.size <= maxBytes) return source;

        let image = null;
        let bitmap = null;
        try {
          image = await decodeDataUrlImage(await readImageAsDataUrl(source));
        } catch (imageError) {
          if (typeof createImageBitmap === "function") {
            try {
              bitmap = await createImageBitmap(source, { imageOrientation: "from-image" });
            } catch (error) { console.error("createImageBitmap fallback failed", error); }
          }
          if (!bitmap) throw imageError;
        }

        const width = Number(image?.naturalWidth || image?.width || bitmap?.width || 0);
        const height = Number(image?.naturalHeight || image?.height || bitmap?.height || 0);
        if (!width || !height) {
          bitmap?.close?.();
          throw new Error("图片尺寸读取失败");
        }

        // Intrinsic bitmap dimensions are source data, not container geometry. Image surfaces
        // crop/position at render time; the persistence pipeline must not silently resize uploads.
        // maxSide remains available only for an explicit caller that opts into resizing.
        const scale = preserveDimensions ? 1 : Math.min(1, maxSide / Math.max(width, height));
        const needsResize = !preserveDimensions && scale < 1;
        const needsCompression = source.size > maxBytes;
        if (!needsResize && !needsCompression && !forceReencode) {
          bitmap?.close?.();
          return source;
        }

        let targetWidth = Math.max(1, Math.round(width * scale));
        let targetHeight = Math.max(1, Math.round(height * scale));
        const requestedMime = ["image/jpeg", "image/png", "image/webp"].includes(options.outputMime) ? options.outputMime : "";
        let targetMime = requestedMime || (needsCompression ? "image/webp" : sourceType === "image/png" ? "image/png" : sourceType === "image/webp" ? "image/webp" : "image/jpeg");
        if (preserveAlpha && targetMime === "image/jpeg") targetMime = "image/webp";
        let quality = initialQuality;
        let best = null;

        const encode = async () => {
          const canvas = document.createElement("canvas");
          canvas.width = targetWidth;
          canvas.height = targetHeight;
          const context = canvas.getContext("2d", { alpha: targetMime !== "image/jpeg" });
          if (!context) return null;
          context.imageSmoothingEnabled = true;
          context.imageSmoothingQuality = "high";
          context.drawImage(image || bitmap, 0, 0, targetWidth, targetHeight);
          let output = await canvasToBlob(canvas, targetMime, quality);
          if (!output && targetMime !== "image/webp") {
            targetMime = "image/webp";
            output = await canvasToBlob(canvas, targetMime, quality);
          }
          return output instanceof Blob && output.size ? output : null;
        };

        for (let attempt = 0; attempt < 9; attempt += 1) {
          const output = await encode();
          if (output && (!best || output.size < best.size)) best = output;
          if (output && output.size <= maxBytes) {
            bitmap?.close?.();
            return output;
          }

          if (attempt < 4 && targetMime !== "image/png") {
            quality = Math.max(.5, quality - .1);
          } else {
            if (targetMime === "image/png") targetMime = "image/webp";
            if (preserveDimensions) {
              // User media may reduce encoding quality/format to satisfy the storage contract,
              // but it must never reduce width/height. Continue quality-only attempts, then fail.
              quality = Math.max(.38, quality - .08);
              if (quality <= .38) break;
              continue;
            }
            const currentSize = output?.size || best?.size || source.size;
            let ratio = Math.max(.52, Math.min(.88, Math.sqrt(maxBytes / Math.max(currentSize, maxBytes + 1)) * .92));
            const longest = Math.max(targetWidth, targetHeight);
            if (longest <= 160) break;
            ratio = Math.max(160 / longest, ratio);
            const nextWidth = Math.max(1, Math.floor(targetWidth * ratio));
            const nextHeight = Math.max(1, Math.floor(targetHeight * ratio));
            if (nextWidth === targetWidth && nextHeight === targetHeight) break;
            targetWidth = nextWidth;
            targetHeight = nextHeight;
            quality = Math.min(initialQuality, .82);
          }
        }

        bitmap?.close?.();
        if (best && best.size <= maxBytes) return best;
        throw new Error("图片压缩后仍超过 4MB，请换一张分辨率更低的图片");
      }

      async function prepareMediaBlob(blob, options = {}) {
        const source = await normalizePickedMediaBlob(blob, { allowVideo: true });
        if (source.type === "video/mp4") return source;
        return prepareImageBlob(source, options);
      }

      function binaryExtension(mime = "") {
        const map = {
          "image/jpeg": "jpg",
          "image/png": "png",
          "image/webp": "webp",
          "image/gif": "gif",
          "image/avif": "avif",
          "image/bmp": "bmp",
          "image/svg+xml": "svg",
          "video/mp4": "mp4"
        };
        return map[mime] || "bin";
      }

      const BINARY_ZIP_MARKER = "__mobileDesktopBinaryAsset__";

      async function encodeBinaryForZip(value, files, context = { index: 0, blobs: new WeakMap() }) {
        if (value instanceof Blob) {
          let path = context.blobs.get(value);
          if (!path) {
            const ext = binaryExtension(value.type);
            path = `assets/blob-${String(context.index++).padStart(4, "0")}.${ext}`;
            context.blobs.set(value, path);
            files[path] = new Uint8Array(await value.arrayBuffer());
          }
          return { [BINARY_ZIP_MARKER]: "blob", path, type: value.type || "application/octet-stream", size: value.size };
        }
        if (value instanceof ArrayBuffer) {
          const path = `assets/buffer-${String(context.index++).padStart(4, "0")}.bin`;
          files[path] = new Uint8Array(value);
          return { [BINARY_ZIP_MARKER]: "arraybuffer", path, size: value.byteLength };
        }
        if (ArrayBuffer.isView(value)) {
          const path = `assets/view-${String(context.index++).padStart(4, "0")}.bin`;
          files[path] = new Uint8Array(value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength));
          return { [BINARY_ZIP_MARKER]: "uint8array", path, size: value.byteLength };
        }
        if (Array.isArray(value)) return Promise.all(value.map((item) => encodeBinaryForZip(item, files, context)));
        if (value && typeof value === "object") {
          const next = {};
          for (const [key, item] of Object.entries(value)) next[key] = await encodeBinaryForZip(item, files, context);
          return next;
        }
        return value;
      }

      async function decodeBinaryFromZip(value, files) {
        if (Array.isArray(value)) return Promise.all(value.map((item) => decodeBinaryFromZip(item, files)));
        if (value && typeof value === "object") {
          if (value[BINARY_ZIP_MARKER] && typeof value.path === "string") {
            const bytes = files[value.path];
            if (!(bytes instanceof Uint8Array)) throw new Error(`missing binary asset: ${value.path}`);
            if (value[BINARY_ZIP_MARKER] === "blob") return new Blob([bytes], { type: value.type || "application/octet-stream" });
            if (value[BINARY_ZIP_MARKER] === "arraybuffer") return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
            if (value[BINARY_ZIP_MARKER] === "uint8array") return new Uint8Array(bytes);
          }
          const next = {};
          for (const [key, item] of Object.entries(value)) next[key] = await decodeBinaryFromZip(item, files);
          return next;
        }
        return value;
      }

      const createDefaultState = () => ({
        drawerType: null,
        wallpaper: null,
        wallpapers: [],
        selectedWallpaperId: null,
        iconRadius: myPhoneConfig.themeCustomization.iconRadiusDefault,
        iconScale: myPhoneConfig.themeCustomization.iconScaleDefault,
        customIcons: {},
        pendingIconId: null,
        fontFamily: null,
        fontSource: null,
        fontSize: myPhoneConfig.themeCustomization.fontSizeDefault,
        fontWeight: myPhoneConfig.themeCustomization.fontWeightDefault,
        fontPresets: [],
        selectedPresetId: null,
        themeColor: myPhoneConfig.themeCustomization.themeColorDefault,
        iconColor: myPhoneConfig.themeCustomization.iconColorDefault || "#FFFFFF",
        themeTexture: myPhoneConfig.themeCustomization.themeTextureDefault,
        displayScale: myPhoneConfig.themeCustomization.displayScaleDefault,
        developerCss: INITIAL_DEVELOPER_TEMPLATE,
        developerPresets: [],
        selectedDeveloperPresetId: null,
        modalAction: null,
        modalCancelAction: null
      });

      const state = createDefaultState();
      const originalIcons = new Map();
      // 图标定制的多选只属于当前抽屉会话，不写入主题持久化状态。
      // 一个文件可批量应用到全部所选 App；多个文件则按所选顺序一一对应。
      const selectedIconIds = new Set();
      let pendingIconIds = [];
      const developerVariableKeys = new Set();

      myPhoneConfig.themeCustomization.appIconTargets.forEach((target) => {
        const element = document.querySelector(target.selector);
        if (element) originalIcons.set(target.id, element.innerHTML);
      });

      function appendIcon(element, name) {
        const icon = QWQSystemUI.createIcon({
          provider: "fontawesome",
          family: "classic",
          style: "solid",
          name,
          format: "inline-svg"
        });
        if (icon) element.appendChild(icon);
      }

      function createActionButton(label, iconName = null, className = "") {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `ui-action-button ${className}`.trim();
        if (iconName) appendIcon(button, iconName);
        const text = document.createElement("span");
        text.textContent = label;
        button.appendChild(text);
        return button;
      }

      function createSection(title) {
        const section = document.createElement("section");
        section.className = "ui-section";
        section.dataset.uiTemplate = "global-drawer-section";
        if (title) {
          const heading = document.createElement("h3");
          heading.className = "ui-section-title";
          heading.textContent = title;
          section.appendChild(heading);
        }
        return section;
      }

      function appendSectionContent(section, ...nodes) {
        section.append(...nodes);
        return section;
      }

      function createPresetSelect({ ariaLabel, items, selectedId = "", emptyLabel = "暂无预设", getLabel = (item) => item.name }) {
        const select = document.createElement("select");
        select.className = "native-select";
        select.setAttribute("aria-label", ariaLabel);

        if (!items.length) {
          const empty = document.createElement("option");
          empty.value = "";
          empty.textContent = emptyLabel;
          select.appendChild(empty);
          select.value = "";
          return select;
        }

        const placeholder = document.createElement("option");
        placeholder.value = "";
        placeholder.textContent = "选择预设";
        select.appendChild(placeholder);
        items.forEach((item) => {
          const option = document.createElement("option");
          option.value = item.id;
          option.textContent = getLabel(item);
          select.appendChild(option);
        });
        select.value = selectedId || "";
        return select;
      }

      function createPresetBlock({
        title,
        ariaLabel,
        items,
        selectedId = "",
        emptyLabel = "暂无预设",
        getLabel = (item) => item.name,
        saveDisabled = false,
        removeDisabled = false,
        onChange,
        onSave,
        onRemove
      }) {
        const section = createSection(title);
        const select = createPresetSelect({ ariaLabel, items, selectedId, emptyLabel, getLabel });
        if (typeof onChange === "function") select.addEventListener("change", onChange);

        const actions = document.createElement("div");
        actions.className = "ui-action-row";
        const save = createActionButton("存为预设", "box-archive");
        const remove = createActionButton("删除预设", "trash-can", "is-danger");
        save.disabled = Boolean(saveDisabled);
        remove.disabled = Boolean(removeDisabled);
        if (typeof onSave === "function") save.addEventListener("click", onSave);
        if (typeof onRemove === "function") remove.addEventListener("click", onRemove);
        actions.append(save, remove);
        appendSectionContent(section, select, actions);
        return { section, select, save, remove };
      }

      function createRangeRow(label, value, min, max, step, format, onInput) {
        const row = document.createElement("label");
        row.className = "ui-range-row";

        const name = document.createElement("span");
        name.className = "ui-range-label";
        name.textContent = label;

        const input = document.createElement("input");
        input.className = "global-range";
        input.type = "range";
        input.min = String(min);
        input.max = String(max);
        input.step = String(step);
        input.value = String(value);

        const output = document.createElement("span");
        output.className = "ui-range-value";
        output.textContent = format(value);

        const updateRangeProgress = (current) => {
          const percent = ((Number(current) - Number(min)) / (Number(max) - Number(min))) * 100;
          input.style.setProperty("--range-progress", `${Math.max(0, Math.min(100, percent))}%`);
        };
        updateRangeProgress(value);

        ["pointerdown", "pointermove", "pointerup", "pointercancel", "click"].forEach((eventName) => {
          input.addEventListener(eventName, (event) => event.stopPropagation());
        });

        input.addEventListener("input", () => {
          const next = Number(input.value);
          updateRangeProgress(next);
          output.textContent = format(next);
          onInput(next);
        });

        row.append(name, input, output);
        return row;
      }

      function serializableState() {
        return {
          appVersion: PERSISTENCE_VERSION,
          wallpaper: state.wallpaper,
          wallpapers: state.wallpapers,
          selectedWallpaperId: state.selectedWallpaperId,
          iconRadius: state.iconRadius,
          iconScale: state.iconScale,
          customIcons: state.customIcons,
          fontSource: state.fontSource,
          fontSize: state.fontSize,
          fontWeight: state.fontWeight,
          fontPresets: state.fontPresets,
          selectedPresetId: state.selectedPresetId,
          themeColor: state.themeColor,
          iconColor: state.iconColor,
          themeTexture: state.themeTexture,
          displayScale: state.displayScale,
          developerCss: state.developerCss,
          developerPresets: state.developerPresets,
          selectedDeveloperPresetId: state.selectedDeveloperPresetId
        };
      }

      function normalizeStoredState(value) {
        if (!value || typeof value !== "object") return {};
        const defaults = createDefaultState();
        const owns = (key) => Object.prototype.hasOwnProperty.call(value, key);
        const record = (candidate) => candidate
          && typeof candidate === "object"
          && !Array.isArray(candidate)
          && !(candidate instanceof Blob);
        const finite = (candidate, minimum, maximum, fallback) => {
          const parsed = Number(candidate);
          return Number.isFinite(parsed) ? Math.max(minimum, Math.min(maximum, parsed)) : fallback;
        };
        const nullableId = (candidate) => typeof candidate === "string" && candidate.trim() ? candidate : null;
        const imageValue = (candidate) => candidate instanceof Blob || typeof candidate === "string" ? candidate : null;
        const normalized = {};

        if (owns("wallpaper")) normalized.wallpaper = imageValue(value.wallpaper);
        if (owns("wallpapers")) normalized.wallpapers = Array.isArray(value.wallpapers)
          ? value.wallpapers.filter(record)
          : defaults.wallpapers;
        if (owns("selectedWallpaperId")) normalized.selectedWallpaperId = nullableId(value.selectedWallpaperId);
        if (owns("iconRadius")) normalized.iconRadius = finite(value.iconRadius, 12, 50, defaults.iconRadius);
        if (owns("iconScale")) normalized.iconScale = finite(value.iconScale, 75, 115, defaults.iconScale);
        if (owns("customIcons")) {
          normalized.customIcons = record(value.customIcons)
            ? Object.fromEntries(Object.entries(value.customIcons).filter(([, image]) => image instanceof Blob || typeof image === "string"))
            : defaults.customIcons;
        }
        if (owns("fontSource")) {
          normalized.fontSource = record(value.fontSource) && typeof value.fontSource.value === "string" && value.fontSource.value
            ? { type: value.fontSource.type === "url" ? "url" : "data", value: value.fontSource.value }
            : defaults.fontSource;
        }
        if (owns("fontSize")) normalized.fontSize = finite(value.fontSize, 80, 130, defaults.fontSize);
        if (owns("fontWeight")) normalized.fontWeight = finite(value.fontWeight, 300, 700, defaults.fontWeight);
        if (owns("fontPresets")) normalized.fontPresets = Array.isArray(value.fontPresets)
          ? value.fontPresets.filter(record)
          : defaults.fontPresets;
        if (owns("selectedPresetId")) normalized.selectedPresetId = nullableId(value.selectedPresetId);
        if (owns("themeColor")) normalized.themeColor = /^#[0-9a-f]{6}$/i.test(String(value.themeColor || ""))
          ? String(value.themeColor).toUpperCase()
          : defaults.themeColor;
        if (owns("iconColor")) normalized.iconColor = /^#[0-9a-f]{6}$/i.test(String(value.iconColor || ""))
          ? String(value.iconColor).toUpperCase()
          : defaults.iconColor;
        else if (owns("themeColor")) normalized.iconColor = contrastFor(normalized.themeColor || defaults.themeColor);
        if (owns("themeTexture")) {
          const texture = String(value.themeTexture || "").toLowerCase();
          normalized.themeTexture = texture === "frosted" ? "frosted" : "default";
        }
        if (owns("displayScale")) normalized.displayScale = finite(value.displayScale, 80, 120, defaults.displayScale);
        if (owns("developerCss")) normalized.developerCss = typeof value.developerCss === "string"
          ? stripSystemOwnedDeveloperVariables(value.developerCss)
          : defaults.developerCss;
        if (owns("developerPresets")) normalized.developerPresets = Array.isArray(value.developerPresets)
          ? normalizeDeveloperPresets(value.developerPresets)
          : defaults.developerPresets;
        if (owns("selectedDeveloperPresetId")) normalized.selectedDeveloperPresetId = nullableId(value.selectedDeveloperPresetId);
        // V0.0.082 的默认开发者模板错误地把全局滚动条 token 设为 0，
        // 会在 core.css 之后再次覆盖唯一全局样式。只迁移“完全等于旧默认模板”的记录，
        // 用户真正手写的开发者 CSS 一字不改。
        if (normalized.developerCss === LEGACY_DEFAULT_DEVELOPER_CSS_082 || normalized.developerCss === LEGACY_DEFAULT_DEVELOPER_CSS_0380) {
          normalized.developerCss = INITIAL_DEVELOPER_TEMPLATE;
        }
        return normalized;
      }

      function createCoalescedRecordWriter(writeRecord, delay = 140) {
        let latestSource;
        let timer = 0;
        let inFlight = Promise.resolve();
        let waiters = [];

        function clearTimer() {
          if (!timer) return;
          window.clearTimeout(timer);
          timer = 0;
        }

        function flush() {
          clearTimer();
          if (latestSource === undefined) return inFlight;
          const source = latestSource;
          const batch = waiters;
          latestSource = undefined;
          waiters = [];

          const run = async () => writeRecord(cloneSerializable(source));
          inFlight = inFlight.then(run, run);
          inFlight.then(
            (value) => batch.forEach(({ resolve }) => resolve(value)),
            (error) => batch.forEach(({ reject }) => reject(error))
          );
          return inFlight;
        }

        function request(source, { immediate = false } = {}) {
          latestSource = source;
          const completion = new Promise((resolve, reject) => waiters.push({ resolve, reject }));
          clearTimer();
          if (immediate) void flush();
          else timer = window.setTimeout(() => { void flush(); }, delay);
          return completion;
        }

        return Object.freeze({ request, flush });
      }

      const themeRecordWriter = createCoalescedRecordWriter(async (snapshot) => {
        await ready;
        if (!persistenceHydrated) throw new Error("Persistence hydration did not complete; write blocked");
        await db.themeState.put({
          key: "active",
          version: PERSISTENCE_VERSION,
          value: snapshot,
          updatedAt: Date.now()
        });
      });
      const settingsRecordWriter = createCoalescedRecordWriter(async (source) => {
        await ready;
        if (!persistenceHydrated) throw new Error("Persistence hydration did not complete; write blocked");
        await db.themeState.put({
          key: "settings",
          version: PERSISTENCE_VERSION,
          value: projectLegacySettings(source),
          updatedAt: Date.now()
        });
      });
      let profileWriteQueue = Promise.resolve();

      function enqueueThemeWrite(source, options = {}) {
        return themeRecordWriter.request(source, options);
      }

      function enqueueSettingsWrite(source, options = {}) {
        return settingsRecordWriter.request(source, options);
      }

      async function persistNow() {
        // 任何主题写入都必须发生在旧数据完成 hydration 之后。
        // 旧实现只等 databaseReady：数据库刚打开但 active 尚未读回时，
        // 若用户或初始化逻辑触发一次保存，会把 createDefaultState() 的整份默认快照
        // 覆盖到上一版本数据上。这里直接把写入门槛提升为 ready，并在 ready 之后
        // 才生成 snapshot，从源头消除“先写默认值、后读旧值”的竞态。
        await ready;
        if (!persistenceHydrated) {
          throw new Error("Persistence hydration did not complete; write blocked");
        }
        const snapshot = await materializeBinaryForPersistence(serializableState());
        await enqueueThemeWrite(snapshot, { immediate: true });
      }

      async function loadSettingsState() {
        await databaseReady;
        const record = await db.themeState.get("settings");
        return cloneSerializable(projectLegacySettings(record?.value));
      }

      function reportPersistenceWriteFailure(error, channel) {
        console.error(`[清柳 persistence] ${channel} 写入失败；本次写入未提交，后续保存仍可继续。`, error);
      }

      function saveSettingsState(value) {
        void enqueueSettingsWrite(value).catch((error) => {
          reportPersistenceWriteFailure(error, "settings");
        });
      }

      async function saveSettingsStateNow(value) {
        const snapshot = await materializeBinaryForPersistence(value);
        await enqueueSettingsWrite(snapshot, { immediate: true });
      }

      async function loadProfileState() {
        await databaseReady;
        const record = await db.themeState.get("profile");
        return cloneSerializable(
          record?.value && typeof record.value === "object" && !Array.isArray(record.value)
            ? record.value
            : {}
        );
      }

      async function saveProfileStateNow(value) {
        const patch = cloneSerializable(
          value && typeof value === "object" && !Array.isArray(value) ? value : {}
        );
        const run = async () => {
          await ready;
          if (!persistenceHydrated) throw new Error("Persistence hydration did not complete; write blocked");
          await db.transaction("rw", db.themeState, async () => {
            const current = await db.themeState.get("profile");
            const previous = current?.value && typeof current.value === "object" && !Array.isArray(current.value)
              ? current.value
              : {};
            await db.themeState.put({
              key: "profile",
              version: PERSISTENCE_VERSION,
              value: cloneSerializable({ ...previous, ...patch }),
              updatedAt: Date.now()
            });
          });
        };
        profileWriteQueue = profileWriteQueue.then(run, run);
        await profileWriteQueue;
        document.dispatchEvent(new CustomEvent("qwq:profile-state-change", {
          detail: { keys: Object.keys(patch), updatedAt: Date.now() }
        }));
      }

      let scheduledThemePersistTimer = 0;
      let scheduledThemePersistPromise = null;

      async function commitScheduledThemePersist() {
        if (scheduledThemePersistTimer) {
          window.clearTimeout(scheduledThemePersistTimer);
          scheduledThemePersistTimer = 0;
        }
        if (scheduledThemePersistPromise) return scheduledThemePersistPromise;
        scheduledThemePersistPromise = (async () => {
          await databaseReady;
          await ready;
          if (!persistenceHydrated) throw new Error("Persistence hydration did not complete; write blocked");
          // 外层已经完成真正 debounce，这里直接 immediate 提交最新快照。
          // 这样拖动一个 range 只产生一次序列化/一次 IndexedDB 写，不再积累数百个 waiter microtask。
          await enqueueThemeWrite(serializableState(), { immediate: true });
        })();
        try { return await scheduledThemePersistPromise; }
        finally { scheduledThemePersistPromise = null; }
      }

      function schedulePersist() {
        window.clearTimeout(scheduledThemePersistTimer);
        scheduledThemePersistTimer = window.setTimeout(() => {
          scheduledThemePersistTimer = 0;
          void commitScheduledThemePersist().catch((error) => reportPersistenceWriteFailure(error, "theme"));
        }, 160);
      }

      function flushQueuedPersistence() {
        if (scheduledThemePersistTimer) {
          void commitScheduledThemePersist().catch((error) => reportPersistenceWriteFailure(error, "theme"));
        } else {
          void themeRecordWriter.flush().catch((error) => reportPersistenceWriteFailure(error, "theme"));
        }
        void settingsRecordWriter.flush().catch((error) => reportPersistenceWriteFailure(error, "settings"));
      }

      window.addEventListener("pagehide", flushQueuedPersistence, { passive: true });
      document.addEventListener("visibilitychange", () => {
        if (document.hidden) flushQueuedPersistence();
      });

      function contrastFor(hex) {
        const normalized = String(hex || "#000000").replace("#", "").padEnd(6, "0").slice(0, 6);
        const r = parseInt(normalized.slice(0, 2), 16);
        const g = parseInt(normalized.slice(2, 4), 16);
        const b = parseInt(normalized.slice(4, 6), 16);
        const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        return luminance > 0.62 ? "#000000" : "#FFFFFF";
      }

      function applyThemeColor(color, persist = true) {
        state.themeColor = /^#[0-9a-f]{6}$/i.test(color) ? color.toUpperCase() : "#000000";
        root.style.setProperty("--theme-color", state.themeColor);
        root.style.setProperty("--theme-color-contrast", contrastFor(state.themeColor));
        if (persist) schedulePersist();
      }

      function applyIconColor(color, persist = true) {
        state.iconColor = /^#[0-9a-f]{6}$/i.test(color) ? color.toUpperCase() : String(myPhoneConfig.themeCustomization.iconColorDefault || "#FFFFFF").toUpperCase();
        root.style.setProperty("--theme-icon-color", state.iconColor);
        if (persist) schedulePersist();
      }

      function applyThemeTexture(texture, persist = true) {
        state.themeTexture = texture === "frosted" ? "frosted" : "default";
        root.dataset.themeTexture = state.themeTexture;
        if (persist) schedulePersist();
      }

      function applyDisplayScale(value, persist = true) {
        state.displayScale = Math.max(80, Math.min(120, Number(value) || 100));
        root.style.setProperty("--display-scale", String(state.displayScale / 100));
        if (persist) schedulePersist();
      }

      function syncWallpaperView(imageValue) {
        if (desktopWallpaperImage) {
          void window.QWQMediaSurface?.setImage?.(desktopWallpaperImage, "theme:wallpaper:desktop-node", imageValue, {
            identity:imageValue, hiddenWhenEmpty:true, alt:""
          });
        }

        document.querySelectorAll(".wallpaper-preview-image").forEach((image, index) => {
          if (!image.dataset.qwqMediaSlot) image.dataset.qwqMediaSlot = `theme:wallpaper:preview-node:${index}`;
          void window.QWQMediaSurface?.setImage?.(image, image.dataset.qwqMediaSlot, imageValue, {
            identity:imageValue, hiddenWhenEmpty:true, alt:""
          });
        });
      }

      function applyWallpaper(imageValue, persist = true) {
        state.wallpaper = imageValue || null;
        syncWallpaperView(state.wallpaper);
        if (persist) schedulePersist();
      }

      function getWallpaperPresets() {
        return state.wallpapers
          .filter((item) => item && typeof item === "object" && item.blob instanceof Blob && item.blob.size)
          .map((item) => ({ id:String(item.id || ""), name:String(item.name || "壁纸预设"), blob:item.blob }));
      }

      function getWallpaperPreset(presetId) {
        const id = String(presetId || "");
        if (!id) return null;
        const item = state.wallpapers.find((entry) => String(entry?.id || "") === id);
        return item && item.blob instanceof Blob && item.blob.size
          ? { id:String(item.id), name:String(item.name || "壁纸预设"), blob:item.blob }
          : null;
      }

      function setIconContent(target, imageValue) {
        // 主屏图标和滚动条/开关预览采用同一条原子图片提交链：旧图标在新图标
        // 解码完成前保持不动，避免设置变更或主屏重排时先清空再回填。
        const runtimeElement = document.querySelector(`.icon-shell[data-app-id="${CSS.escape(target.id)}"]`);
        const element = runtimeElement || document.querySelector(target.selector);
        if (!element) return;
        const slot = themeMediaSlot(`home-icon:${target.id}`);
        if (!imageValue) {
          window.QWQMediaSurface?.release?.(slot);
          element.classList.remove("has-custom-theme-icon");
          element.innerHTML = originalIcons.get(target.id) || "";
          return;
        }
        const existing = element.querySelector('img[data-theme-custom-icon="true"]');
        const image = existing || document.createElement("img");
        image.alt = "";
        image.dataset.themeCustomIcon = "true";
        void window.QWQMediaSurface?.setImage?.(image, slot, imageValue, {identity:imageValue,alt:""}).then((applied)=>{
          if(!applied || !element.isConnected) return;
          element.classList.add("has-custom-theme-icon");
          if(image.parentElement !== element || element.childElementCount !== 1) element.replaceChildren(image);
        });
      }

      function applyHomeIconToShell(appId, element) {
        if (!element || !appId) return false;
        const customIcons = state.customIcons && typeof state.customIcons === "object" && !Array.isArray(state.customIcons)
          ? state.customIcons
          : {};
        const imageValue = customIcons[appId] || null;
        if (!imageValue) return false;
        const image = document.createElement("img");
        image.alt = "";
        image.dataset.themeCustomIcon = "true";
        void window.QWQMediaSurface?.setImage?.(image, themeMediaSlot(`home-icon:${appId}`), imageValue, {identity:imageValue,alt:""}).then((applied)=>{
          if(!applied || !element.isConnected) return;
          element.classList.add("has-custom-theme-icon");
          element.replaceChildren(image);
        });
        return true;
      }

      function applyIconState(persist = true) {
        root.style.setProperty("--custom-icon-radius", `${state.iconRadius}%`);
        root.style.setProperty("--custom-icon-scale", String(state.iconScale / 100));
        const customIcons = state.customIcons && typeof state.customIcons === "object" && !Array.isArray(state.customIcons)
          ? state.customIcons
          : {};
        myPhoneConfig.themeCustomization.appIconTargets.forEach((target) => {
          setIconContent(target, customIcons[target.id] || null);
        });
        if (persist) schedulePersist();
      }

      function applyFontMetrics(persist = true) {
        root.style.setProperty("--user-font-size-scale", String(state.fontSize / 100));
        root.style.setProperty("--user-font-weight", String(state.fontWeight));
        if (persist) schedulePersist();
      }

      async function applyFontSource(source, persist = true) {
        state.fontSource = source && source.value ? { type: source.type === "url" ? "url" : "data", value: String(source.value) } : null;
        if (!state.fontSource) {
          state.fontFamily = null;
          root.style.setProperty("--user-font-family", FONT_DEFAULT_STACK);
          if (persist) schedulePersist();
          return true;
        }

        const family = `ThemePersistentFont${Date.now()}`;
        try {
          const safeValue = state.fontSource.value.replace(/"/g, "\\\"");
          const fontFace = new FontFace(family, `url("${safeValue}")`);
          const loaded = await fontFace.load();
          document.fonts.add(loaded);
          state.fontFamily = `"${family}"`;
          root.style.setProperty("--user-font-family", state.fontFamily);
          if (persist) schedulePersist();
          return true;
        } catch (error) {
          console.error("theme font apply failed", error);
          if (persist) {
            GlobalModal.alert({
              title: "字体加载失败",
              message: "请确认文件格式或 URL 可以直接访问字体文件。",
              confirmLabel: "知道了",
              action: "dismiss"
            });
          }
          return false;
        }
      }

      function applyDeveloperCss(text, persist = true) {
        developerVariableKeys.forEach((key) => root.style.removeProperty(key));
        developerVariableKeys.clear();
        applyThemeTexture(state.themeTexture, false);
        applyThemeColor(state.themeColor, false);
        applyIconColor(state.iconColor, false);
        applyDisplayScale(state.displayScale, false);
        root.style.setProperty("--custom-icon-radius", `${state.iconRadius}%`);
        root.style.setProperty("--custom-icon-scale", String(state.iconScale / 100));
        root.style.setProperty("--user-font-size-scale", String(state.fontSize / 100));
        root.style.setProperty("--user-font-weight", String(state.fontWeight));
        root.style.setProperty("--user-font-family", state.fontFamily || FONT_DEFAULT_STACK);
        syncWallpaperView(state.wallpaper);
        const css = stripSystemOwnedDeveloperVariables(typeof text === "string" ? text : "");
        state.developerCss = css;
        const matcher = /(--[A-Za-z0-9_-]+)\s*:\s*([^;{}]+);/g;
        let match;
        while ((match = matcher.exec(css))) {
          const key = match[1].trim();
          const value = match[2].trim();
          if (!key || !value || SYSTEM_OWNED_GEOMETRY_VARIABLES.has(key)) continue;
          root.style.setProperty(key, value);
          developerVariableKeys.add(key);
        }
        // Theme application runs after QWQViewport during hydration. Reassert the runtime
        // viewport immediately so an already-mounted page cannot retain an old inline value.
        window.QWQViewport?.settle?.();
        if (persist) schedulePersist();
      }

      async function applyAllState({ waitForFont = true } = {}) {
        applyThemeTexture(state.themeTexture, false);
        applyThemeColor(state.themeColor, false);
        applyIconColor(state.iconColor, false);
        applyDisplayScale(state.displayScale, false);
        applyWallpaper(state.wallpaper, false);
        applyIconState(false);
        applyFontMetrics(false);
        const fontTask = applyFontSource(state.fontSource, false);
        applyDeveloperCss(state.developerCss || INITIAL_DEVELOPER_TEMPLATE, false);
        if (waitForFont) await fontTask;
        else void fontTask;
      }


      const INTERNAL_CONTINUITY_REVISION = 34;
      const INTERNAL_CONTINUITY_MARKER = "internal.continuity.state";
      const LEGACY_IMPORT_REVISION = 34;
      const LEGACY_HYDRATION_REVISION = 34;
      const LEGACY_HYDRATION_MARKER = "legacy.hydration.state";
      // 迁移状态使用一个稳定主键，revision 决定是否需要执行新的迁移语义。
      // 这样旧 completed 标记不会跳过新语义，也不会继续堆叠平行 marker 主键。
      const LEGACY_BOOTSTRAP_MARKER = "legacy.import.state";
      const PRIOR_DATA_RELATION_MARKER_KEYS = Object.freeze([
        "data.relations.v2",
        "data.relations.v3",
        "data.relations.v4",
        "data.relations.v5",
        "data.relations.v6",
        "data.relations.v7",
        "data.relations.v8",
        "data.relations.v9",
        "data.relations.v10",
        "data.relations.v11",
        "data.relations.v12"
      ]);
      const LEGACY_MINIDEXIE_KEY = `__QWQ_MINIDEXIE__:${myPhoneConfig.persistence.databaseName}`;
      const LEGACY_LOCAL_MASK_KEY = "qwq-mask-presets";

      async function priorDataRelationMarkers() {
        const rows = await db.persistenceMeta.bulkGet(PRIOR_DATA_RELATION_MARKER_KEYS);
        return rows.filter((row) => row?.value?.completed === true)
          .sort((left, right) => Number(right?.updatedAt || 0) - Number(left?.updatedAt || 0));
      }

      function latestRelationMarkerForCounter(markers, counterKey) {
        return (Array.isArray(markers) ? markers : [])
          .find((marker) => Number(marker?.value?.[counterKey] || 0) > 0) || null;
      }

      function recordWasWrittenByRelationMigration(record, marker, counterKey) {
        if (!record || !marker || Number(marker?.value?.[counterKey] || 0) <= 0) return false;
        const recordTime = Number(record.updatedAt || 0);
        const markerTime = Number(marker.updatedAt || 0);
        // 旧关系迁移在一个事务中以同一个 now 写业务行，随后立即写 marker。
        // 只认这一小段时间窗，用户后续主动编辑产生的新时间戳绝不能被重挂。
        return recordTime > 0 && markerTime > 0 && Math.abs(markerTime - recordTime) <= 15000;
      }

      async function migrateInternalPersistenceContinuityOnce() {
        const marker = await db.persistenceMeta.get(INTERNAL_CONTINUITY_MARKER);
        if (marker?.value?.completed === true
          && Number(marker.value.revision || 0) >= INTERNAL_CONTINUITY_REVISION) return marker.value;

        const report = {
          revision: INTERNAL_CONTINUITY_REVISION,
          completed: false,
          aggregatesWritten: 0,
          masksMigrated: false,
          templateNicknamesRepaired: 0,
          worldBookScopesRepaired: 0,
          issues: [],
          completedAt: null
        };

        let records = [];
        try {
          records = await db.themeState.toArray();
          const canonical = canonicalizePersistenceRecords(records);
          for (const record of canonical) {
            try {
              await db.themeState.put({
                ...record,
                key: record.key,
                version: PERSISTENCE_VERSION,
                updatedAt: persistenceRecordTime(record) || Date.now()
              });
              report.aggregatesWritten += 1;
            } catch (error) {
              legacyIssue(report, "themeState", "record-rejected", `${record?.key || "unknown"}: ${error?.message || error}`);
            }
          }
        } catch (error) {
          legacyIssue(report, "themeState", "recovery-failed", error?.message || error);
        }

        if (records.length) {
          try {
            await db.transaction("rw", db.themeState, db.characterTemplates, db.mediaAssets, async () => {
              const currentProfile = await db.themeState.get("profile");
              const profile = await migrateLegacyMaskPresets(
                { table: (name) => db.table(name) },
                records,
                currentProfile || null
              );
              await db.themeState.put(profile);
            });
            report.masksMigrated = true;
          } catch (error) {
            legacyIssue(report, "maskPresets", "migration-failed", error?.message || error);
          }
        }

        try {
          await db.characterTemplates.toCollection().modify((template) => {
            if (typeof template.nickname !== "string" || !template.nickname.trim()) {
              template.nickname = typeof template.name === "string" ? template.name.trim() : "";
              report.templateNicknamesRepaired += 1;
            }
          });
        } catch (error) {
          legacyIssue(report, "characterTemplates", "table-recovery-failed", error?.message || error);
        }

        try {
          await db.worldBooks.toCollection().modify((worldBook) => {
            if (worldBook.scope !== "global" && worldBook.scope !== "local") {
              worldBook.scope = "local";
              report.worldBookScopesRepaired += 1;
            }
          });
        } catch (error) {
          legacyIssue(report, "worldBooks", "table-recovery-failed", error?.message || error);
        }

        const retryableCodes = new Set(["recovery-failed", "migration-failed", "table-recovery-failed"]);
        const retryableFailures = report.issues.filter((issue) => retryableCodes.has(issue.code));
        report.completed = retryableFailures.length === 0;
        report.completedAt = report.completed ? new Date().toISOString() : null;
        if (report.completed) {
          await db.persistenceMeta.put({
            key: INTERNAL_CONTINUITY_MARKER,
            value: cloneSerializable(report),
            updatedAt: Date.now()
          });
        }
        return report;
      }

      function legacyIssue(report, source, code, detail = "") {
        const normalizedDetail = String(detail || "");
        report.issues.push({ source, code, detail: normalizedDetail });
        console.error("[清柳 legacy recovery]", source, code, normalizedDetail);
      }

      function legacyRecoveryBlank(value) {
        if (value === undefined || value === null || value === "") return true;
        if (Array.isArray(value)) return value.length === 0;
        if (value && typeof value === "object" && !(value instanceof Blob) && !(value instanceof ArrayBuffer) && !ArrayBuffer.isView(value)) {
          return Object.keys(value).length === 0;
        }
        return false;
      }

      function activePersistenceDefaults() {
        const defaults = createDefaultState();
        return {
          wallpaper: defaults.wallpaper,
          wallpapers: defaults.wallpapers,
          selectedWallpaperId: defaults.selectedWallpaperId,
          iconRadius: defaults.iconRadius,
          iconScale: defaults.iconScale,
          customIcons: defaults.customIcons,
          fontSource: defaults.fontSource,
          fontSize: defaults.fontSize,
          fontWeight: defaults.fontWeight,
          fontPresets: defaults.fontPresets,
          selectedPresetId: defaults.selectedPresetId,
          themeColor: defaults.themeColor,
          iconColor: defaults.iconColor,
          themeTexture: defaults.themeTexture,
          displayScale: defaults.displayScale,
          developerCss: defaults.developerCss,
          developerPresets: defaults.developerPresets,
          selectedDeveloperPresetId: defaults.selectedDeveloperPresetId
        };
      }

      function valuesStructurallyEqual(left, right) {
        if (left === right) return true;
        if (Array.isArray(left) || Array.isArray(right)) {
          return Array.isArray(left) && Array.isArray(right)
            && left.length === right.length
            && left.every((item, index) => valuesStructurallyEqual(item, right[index]));
        }
        if (left && right && typeof left === "object" && typeof right === "object"
          && !(left instanceof Blob) && !(right instanceof Blob)
          && !(left instanceof ArrayBuffer) && !(right instanceof ArrayBuffer)
          && !ArrayBuffer.isView(left) && !ArrayBuffer.isView(right)) {
          const leftKeys = Object.keys(left);
          const rightKeys = Object.keys(right);
          return leftKeys.length === rightKeys.length
            && leftKeys.every((key) => Object.prototype.hasOwnProperty.call(right, key)
              && valuesStructurallyEqual(left[key], right[key]));
        }
        return false;
      }

      function isGeneratedEmptyMusicLibrary(value) {
        if (!value || typeof value !== "object" || Array.isArray(value)) return false;
        const playlists = Array.isArray(value.playlists) ? value.playlists : [];
        const hasPlaylistData = playlists.some((playlist) => {
          const id = String(playlist?.id || "");
          const isGeneratedSystemList = id === "music-liked-system" || id === "music-downloads-system";
          return !isGeneratedSystemList || (Array.isArray(playlist?.songs) && playlist.songs.length > 0);
        });
        const stats = value.playStats && typeof value.playStats === "object" ? value.playStats : {};
        const musicProfile = value.profile && typeof value.profile === "object" ? value.profile : {};
        const profileIsDefault = (!musicProfile.nickname || musicProfile.nickname === "清柳 Listener")
          && (!musicProfile.account || musicProfile.account === "listener")
          && (!musicProfile.signature || musicProfile.signature === "黑白之间，继续听。")
          && !musicProfile.avatar;
        return !hasPlaylistData
          && (!Array.isArray(value.recent) || value.recent.length === 0)
          && (!Array.isArray(value.followedArtists) || value.followedArtists.length === 0)
          && Number(stats.totalSeconds || 0) === 0
          && (!stats.days || Object.keys(stats.days).length === 0)
          && (!stats.tracks || Object.keys(stats.tracks).length === 0)
          && profileIsDefault;
      }

      function isGeneratedProfileFieldDefault(field, value) {
        if (field === "musicLibrary") return isGeneratedEmptyMusicLibrary(value);
        if (field === "musicPlaybackState") {
          return value && typeof value === "object" && !Array.isArray(value)
            && !value.track
            && Number(value.currentTime || 0) === 0
            && (!value.playMode || value.playMode === "order");
        }
        return false;
      }

      function musicStateValueLooksEmpty(key, value) {
        if (key === MUSIC_STATE_KEYS.library) return !value || isGeneratedEmptyMusicLibrary(value);
        if (key === MUSIC_STATE_KEYS.stats) {
          if (!value || typeof value !== "object" || Array.isArray(value)) return true;
          return Number(value.totalSeconds || 0) <= 0
            && (!value.days || Object.keys(value.days).length === 0)
            && (!value.tracks || Object.keys(value.tracks).length === 0);
        }
        if (key === MUSIC_STATE_KEYS.comments) {
          if (!value || typeof value !== "object" || Array.isArray(value)) return true;
          return !Object.values(value).some((bucket) =>
            (Array.isArray(bucket?.localComments) && bucket.localComments.length > 0)
            || (Array.isArray(bucket?.likedIds) && bucket.likedIds.length > 0)
          );
        }
        if (key === MUSIC_STATE_KEYS.playback) {
          if (!value || typeof value !== "object" || Array.isArray(value)) return true;
          return !String(value?.track?.id || "")
            && Number(value.currentTime || 0) <= 0
            && (!value.playMode || value.playMode === "order");
        }
        if (key === MUSIC_STATE_KEYS.settings) {
          if (!value || typeof value !== "object" || Array.isArray(value)) return true;
          return !Object.prototype.hasOwnProperty.call(value, "volume") || Number(value.volume) === 1;
        }
        return legacyRecoveryBlank(value);
      }

      function mergeUniqueProfileRows(currentRows, legacyRows, identity, limit = Infinity) {
        const merged = [];
        const seen = new Set();
        for (const row of [...(Array.isArray(currentRows) ? currentRows : []), ...(Array.isArray(legacyRows) ? legacyRows : [])]) {
          const key = identity(row);
          if (!key || seen.has(key)) continue;
          seen.add(key);
          merged.push(cloneSerializable(row));
          if (merged.length >= limit) break;
        }
        return merged;
      }

      function mergeMusicLibraryContinuity(currentValue, legacyValue) {
        const current = currentValue && typeof currentValue === "object" && !Array.isArray(currentValue) ? currentValue : {};
        const legacy = legacyValue && typeof legacyValue === "object" && !Array.isArray(legacyValue) ? legacyValue : {};
        const currentPlaylists = Array.isArray(current.playlists) ? current.playlists : [];
        const legacyPlaylists = Array.isArray(legacy.playlists) ? legacy.playlists : [];
        const legacyPlaylistById = new Map(legacyPlaylists.map((item) => [String(item?.id || ""), item]));
        const playlists = currentPlaylists.map((item) => {
          const id = String(item?.id || "");
          const historical = legacyPlaylistById.get(id);
          legacyPlaylistById.delete(id);
          if (!historical) return cloneSerializable(item);
          const currentSongs = Array.isArray(item?.songs) ? item.songs : [];
          const legacySongs = Array.isArray(historical?.songs) ? historical.songs : [];
          return {
            ...cloneSerializable(historical),
            ...cloneSerializable(item),
            songs: mergeUniqueProfileRows(currentSongs, legacySongs, (song) => String(song?.id || ""))
          };
        });
        for (const item of legacyPlaylistById.values()) playlists.push(cloneSerializable(item));

        const currentStats = current.playStats && typeof current.playStats === "object" ? current.playStats : {};
        const legacyStats = legacy.playStats && typeof legacy.playStats === "object" ? legacy.playStats : {};
        const currentProfile = current.profile && typeof current.profile === "object" ? current.profile : {};
        const legacyProfile = legacy.profile && typeof legacy.profile === "object" ? legacy.profile : {};
        const profileDefaults = {
          nickname: "清柳 Listener",
          account: "listener",
          signature: "黑白之间，继续听。",
          avatar: ""
        };
        const profile = { ...cloneSerializable(currentProfile) };
        for (const [field, historical] of Object.entries(legacyProfile)) {
          const hasCurrent = Object.prototype.hasOwnProperty.call(profile, field);
          const currentIsDefault = Object.prototype.hasOwnProperty.call(profileDefaults, field)
            && valuesStructurallyEqual(profile[field], profileDefaults[field]);
          if ((!hasCurrent || legacyRecoveryBlank(profile[field]) || currentIsDefault)
            && !legacyRecoveryBlank(historical)) profile[field] = cloneSerializable(historical);
        }

        return {
          ...cloneSerializable(legacy),
          ...cloneSerializable(current),
          playlists,
          recent: mergeUniqueProfileRows(current.recent, legacy.recent, (track) => String(track?.id || ""), 30),
          followedArtists: mergeUniqueProfileRows(
            current.followedArtists,
            legacy.followedArtists,
            (artist) => String(artist?.artistId || artist?.name || "").toLocaleLowerCase("zh-CN"),
            100
          ),
          playStats: {
            ...cloneSerializable(legacyStats),
            ...cloneSerializable(currentStats),
            totalSeconds: Math.max(Number(currentStats.totalSeconds || 0), Number(legacyStats.totalSeconds || 0)),
            days: { ...cloneSerializable(legacyStats.days || {}), ...cloneSerializable(currentStats.days || {}) },
            tracks: { ...cloneSerializable(legacyStats.tracks || {}), ...cloneSerializable(currentStats.tracks || {}) }
          },
          profile
        };
      }

      const PROFILE_FIELD_MERGERS = Object.freeze({
        qqProfileCovers(current, legacy) {
          return { ...cloneSerializable(legacy || {}), ...cloneSerializable(current || {}) };
        },
        musicCommentState(current, legacy) {
          const next = { ...cloneSerializable(legacy || {}), ...cloneSerializable(current || {}) };
          for (const trackId of new Set([...Object.keys(legacy || {}), ...Object.keys(current || {})])) {
            const currentBucket = current?.[trackId] && typeof current[trackId] === "object" ? current[trackId] : {};
            const legacyBucket = legacy?.[trackId] && typeof legacy[trackId] === "object" ? legacy[trackId] : {};
            next[trackId] = {
              ...cloneSerializable(legacyBucket),
              ...cloneSerializable(currentBucket),
              localComments: mergeUniqueProfileRows(
                currentBucket.localComments,
                legacyBucket.localComments,
                (item) => String(item?.id || `${item?.time || ""}:${item?.content || ""}`),
                200
              ),
              likedIds: mergeUniqueProfileRows(
                currentBucket.likedIds,
                legacyBucket.likedIds,
                (id) => String(id || ""),
                500
              )
            };
          }
          return next;
        },
        musicLibrary: mergeMusicLibraryContinuity,
        phoneRecents(current, legacy) {
          return mergeUniqueProfileRows(
            current,
            legacy,
            (item) => `${item?.at || ""}:${item?.contactId || ""}:${item?.number || ""}:${item?.direction || ""}`,
            50
          ).sort((left, right) => Number(right?.at || 0) - Number(left?.at || 0));
        }
      });

      function isFreshDefaultAggregate(record, key) {
        const value = persistenceRecordValue(record);
        if (!value) return true;
        if (key === "active") {
          const defaults = activePersistenceDefaults();
          const comparable = Object.fromEntries(Object.entries(value).filter(([field]) => field !== "appVersion"));
          return valuesStructurallyEqual(comparable, defaults);
        }
        if (key === "settings") {
          const comparable = Object.fromEntries(Object.entries(value).filter(([field]) => field !== "appVersion"));
          return valuesStructurallyEqual(comparable, SETTINGS_DEFAULTS);
        }
        if (key === "profile") {
          const fields = Object.keys(value);
          return fields.length === 0
            || fields.every((field) => (field === "activeMaskPresetId" && !value[field])
              || legacyRecoveryBlank(value[field])
              || isGeneratedProfileFieldDefault(field, value[field]));
        }
        return false;
      }

      // 旧 MiniDexie 快照是“用户历史源”，而 IndexedDB 里可能已经被某个坏版本写入
      // 一份时间戳更晚的默认值。单纯按 updatedAt 取新值会让默认快照永久压住真实旧数据。
      // v31 仅在开库后的一次性迁移阶段做恢复合并：
      // - 当前 active/profile 仍是完整默认态时，历史值整体胜出；
      // - 其余情况绝不覆盖当前非空字段，只用历史值补当前缺失/空字段；
      // - 运行期仍只读正式 IndexedDB，不形成双读兜底。
      function recoverLegacyAggregateRecord(currentRecord, legacyRecord, key) {
        if (!legacyRecord) return currentRecord;
        if (!currentRecord) return { ...legacyRecord, key, version: PERSISTENCE_VERSION };
        const currentValue = persistenceRecordValue(currentRecord) || {};
        const legacyValue = persistenceRecordValue(legacyRecord) || {};
        if (isFreshDefaultAggregate(currentRecord, key)) {
          return {
            ...legacyRecord,
            key,
            version: PERSISTENCE_VERSION,
            value: { ...legacyValue },
            updatedAt: Math.max(persistenceRecordTime(currentRecord), persistenceRecordTime(legacyRecord))
          };
        }
        const next = { ...currentValue };
        const defaults = key === "active"
          ? activePersistenceDefaults()
          : (key === "settings" ? SETTINGS_DEFAULTS : null);
        for (const [field, legacyValueAtField] of Object.entries(legacyValue)) {
          const hasCurrent = Object.prototype.hasOwnProperty.call(next, field);
          const profileMerger = key === "profile" ? PROFILE_FIELD_MERGERS[field] : null;
          if (profileMerger && hasCurrent && !legacyRecoveryBlank(legacyValueAtField)) {
            next[field] = profileMerger(next[field], legacyValueAtField);
            continue;
          }
          const currentIsGeneratedDefault = hasCurrent
            && defaults
            && Object.prototype.hasOwnProperty.call(defaults, field)
            && valuesStructurallyEqual(next[field], defaults[field]);
          const currentIsGeneratedProfileDefault = key === "profile"
            && hasCurrent
            && isGeneratedProfileFieldDefault(field, next[field]);
          if ((!hasCurrent || legacyRecoveryBlank(next[field]) || currentIsGeneratedDefault || currentIsGeneratedProfileDefault)
            && !legacyRecoveryBlank(legacyValueAtField)) {
            next[field] = cloneSerializable(legacyValueAtField);
          }
        }
        return {
          ...currentRecord,
          key,
          version: PERSISTENCE_VERSION,
          value: next,
          updatedAt: Math.max(persistenceRecordTime(currentRecord), persistenceRecordTime(legacyRecord))
        };
      }

      function recoverLegacyAggregateSources(legacyRecords, currentRecords) {
        const legacyMap = new Map(canonicalizePersistenceRecords(legacyRecords).map((record) => [record.key, record]));
        const currentMap = new Map(canonicalizePersistenceRecords(currentRecords).map((record) => [record.key, record]));
        return PERSISTENCE_KEYS.map((key) => recoverLegacyAggregateRecord(
          currentMap.get(key) || null,
          legacyMap.get(key) || null,
          key
        )).filter(Boolean);
      }

      function legacyEntityBlank(value) {
        if (value === undefined || value === null || value === "") return true;
        if (Array.isArray(value)) return value.length === 0;
        if (value && typeof value === "object" && !(value instanceof Blob) && !(value instanceof ArrayBuffer) && !ArrayBuffer.isView(value)) {
          return Object.keys(value).length === 0;
        }
        return false;
      }

      function mergeLegacyEntityMissingFields(existing, legacy) {
        const next = cloneSerializable(existing || {});
        let changed = false;
        for (const [field, value] of Object.entries(legacy || {})) {
          if (!Object.prototype.hasOwnProperty.call(next, field) || (legacyEntityBlank(next[field]) && !legacyEntityBlank(value))) {
            next[field] = cloneSerializable(value);
            changed = true;
          }
        }
        return { value: next, changed };
      }

      async function putLegacyEntitySafely(table, row, primaryKey, report, sourceName) {
        const key = row?.[primaryKey];
        try {
          await table.put(cloneSerializable(row));
          return true;
        } catch (error) {
          const errorName = String(error?.name || "");
          // MiniDexie 不会真正执行 IndexedDB 的 unique index 约束；历史快照里可能
          // 出现同名不同 ID。恢复时保留 ID/引用关系，仅为唯一 name 生成一个不冲突名称。
          if ((errorName === "ConstraintError" || /constraint/i.test(String(error?.message || "")))
            && (sourceName === "worldBooks" || sourceName === "stickerGroups")
            && typeof row?.name === "string" && row.name.trim()) {
            const baseName = row.name.trim();
            for (let index = 1; index <= 99; index += 1) {
              const suffix = index === 1 ? "（旧数据）" : `（旧数据 ${index}）`;
              const candidate = `${baseName}${suffix}`;
              const occupied = await table.where("name").equals(candidate).first();
              if (occupied) continue;
              try {
                await table.put({ ...cloneSerializable(row), name: candidate });
                legacyIssue(report, sourceName, "unique-name-recovered", `${String(key)}: ${baseName} -> ${candidate}`);
                return true;
              } catch (retryError) {
                if (index === 99) legacyIssue(report, sourceName, "record-rejected", retryError?.message || retryError);
              }
            }
          }
          legacyIssue(report, sourceName, "record-rejected", `${String(key)}: ${error?.message || error}`);
          return false;
        }
      }

      async function mergeLegacyEntityTable(table, rows, primaryKey, report, sourceName) {
        if (rows === undefined) return 0;
        if (!Array.isArray(rows)) {
          legacyIssue(report, sourceName, "invalid-table-shape", "expected array");
          return 0;
        }
        let imported = 0;
        let rejected = 0;
        for (const row of rows) {
          if (!row || typeof row !== "object" || Array.isArray(row)) {
            rejected += 1;
            continue;
          }
          const key = row[primaryKey];
          if (key === undefined || key === null || key === "") {
            rejected += 1;
            continue;
          }
          try {
            const existing = await table.get(key);
            if (!existing) {
              if (await putLegacyEntitySafely(table, row, primaryKey, report, sourceName)) imported += 1;
              else rejected += 1;
              continue;
            }
            // 正式 IndexedDB 永远优先。历史快照只补缺失字段，绝不再按时间戳
            // 覆盖现有行，避免旧 MiniDexie 快照反向污染已经正常保存的数据。
            const merged = mergeLegacyEntityMissingFields(existing, row);
            if (merged.changed) {
              if (await putLegacyEntitySafely(table, merged.value, primaryKey, report, sourceName)) imported += 1;
              else rejected += 1;
            }
          } catch (error) {
            rejected += 1;
            legacyIssue(report, sourceName, "record-read-failed", `${String(key)}: ${error?.message || error}`);
          }
        }
        if (rejected) {
          report.rejected[sourceName] = rejected;
          legacyIssue(report, sourceName, "invalid-records", `${rejected} record(s) were not importable`);
        }
        return imported;
      }

      function readLegacyLocalStorageSource(key) {
        try {
          const storage = globalThis.localStorage;
          if (!storage) return { status: "unavailable", value: null, error: "localStorage unavailable" };
          const raw = storage.getItem(key);
          if (raw === null) return { status: "missing", value: null, error: "" };
          try {
            return { status: "ok", value: JSON.parse(raw), error: "" };
          } catch (error) {
            console.error("legacy localStorage JSON parse failed", error);
            return { status: "invalid-json", value: null, error: String(error?.message || error) };
          }
        } catch (error) {
          console.error("legacy localStorage read failed", error);
          return { status: "unavailable", value: null, error: String(error?.message || error) };
        }
      }

      async function migrateHistoricalHydrationStateOnce() {
        const marker = await db.persistenceMeta.get(LEGACY_HYDRATION_MARKER);
        if (marker?.value?.completed === true
          && Number(marker.value.revision || 0) >= LEGACY_HYDRATION_REVISION) return marker.value;

        const miniSource = readLegacyLocalStorageSource(LEGACY_MINIDEXIE_KEY);
        const maskSource = readLegacyLocalStorageSource(LEGACY_LOCAL_MASK_KEY);
        let miniSnapshot = miniSource.value;
        let standaloneMasks = maskSource.value;
        const report = {
          revision: LEGACY_HYDRATION_REVISION,
          completed: false,
          mode: "critical-aggregate-only",
          sources: { miniDexie: miniSource.status, standaloneMasks: maskSource.status },
          templatesImported: 0,
          aggregatesWritten: 0,
          standaloneMasksImported: 0,
          issues: [],
          completedAt: null
        };

        if (miniSource.error) legacyIssue(report, "miniDexie", miniSource.status, miniSource.error);
        if (maskSource.error) legacyIssue(report, "standaloneMasks", maskSource.status, maskSource.error);
        if (miniSnapshot !== null) {
          const valid = miniSnapshot && typeof miniSnapshot === "object" && !Array.isArray(miniSnapshot)
            && miniSnapshot.tables && typeof miniSnapshot.tables === "object" && !Array.isArray(miniSnapshot.tables);
          if (!valid) {
            legacyIssue(report, "miniDexie", "invalid-snapshot-shape", "tables object missing");
            miniSnapshot = null;
          }
        }
        if (standaloneMasks !== null && !Array.isArray(standaloneMasks)) {
          legacyIssue(report, "standaloneMasks", "invalid-cache-shape", "expected array");
          standaloneMasks = null;
        }

        const legacyTables = miniSnapshot?.tables || {};
        // profile.activeMaskPresetId 可能只指向历史 characterTemplates 表。首屏阶段仅导入
        // 这张轻量身份表，确保聚合 profile 不会误清合法外键；聊天/媒体等大表仍留给业务门闩。
        if (Array.isArray(legacyTables.characterTemplates) && legacyTables.characterTemplates.length) {
          try {
            report.templatesImported = await mergeLegacyEntityTable(
              db.characterTemplates,
              legacyTables.characterTemplates,
              "templateId",
              report,
              "characterTemplates"
            );
          } catch (error) {
            legacyIssue(report, "characterTemplates", "table-recovery-failed", error?.message || error);
          }
        }

        if (legacyTables.themeState !== undefined && !Array.isArray(legacyTables.themeState)) {
          legacyIssue(report, "themeState", "invalid-table-shape", "expected array");
        } else if (legacyTables.themeState?.length) {
          try {
            const currentState = await db.themeState.toArray();
            const previousRelationMarkers = await priorDataRelationMarkers();
            const previousRelations = latestRelationMarkerForCounter(previousRelationMarkers, "profileAccountRecovered");
            const currentProfile = currentState.find((record) => record?.key === "profile");
            if (currentProfile && previousRelations?.value?.profileAccountRecovered === true
              && recordWasWrittenByRelationMigration(currentProfile, previousRelations, "profileAccountRecovered")) {
              currentProfile.value = {
                ...(currentProfile.value && typeof currentProfile.value === "object" ? currentProfile.value : {}),
                activeMaskPresetId: null
              };
            }
            const canonical = recoverLegacyAggregateSources(legacyTables.themeState, currentState);
            const canonicalMap = new Map(canonical.map((record) => [record.key, record]));
            try {
              const profile = await migrateLegacyMaskPresets(
                { table: (name) => db.table(name) },
                [...legacyTables.themeState],
                canonicalMap.get("profile") || null
              );
              canonicalMap.set("profile", profile);
            } catch (error) {
              legacyIssue(report, "maskPresets", "migration-failed", error?.message || error);
            }
            for (const record of canonicalMap.values()) {
              try {
                await db.themeState.put({ ...record, updatedAt: persistenceRecordTime(record) || Date.now() });
                report.aggregatesWritten += 1;
              } catch (error) {
                legacyIssue(report, "themeState", "record-rejected", `${record?.key || "unknown"}: ${error?.message || error}`);
              }
            }
          } catch (error) {
            legacyIssue(report, "themeState", "recovery-failed", error?.message || error);
          }
        }

        if (Array.isArray(standaloneMasks) && standaloneMasks.length) {
          try {
            const currentProfile = await db.themeState.get("profile");
            const profile = await migrateLegacyMaskPresets(
              { table: (name) => db.table(name) },
              [{ key: LEGACY_MASK_KEY, value: { maskPresets: standaloneMasks, activeMaskPresetId: null }, updatedAt: 0 }],
              currentProfile || null
            );
            await db.themeState.put(profile);
            report.standaloneMasksImported = standaloneMasks.length;
          } catch (error) {
            legacyIssue(report, "standaloneMasks", "migration-failed", error?.message || error);
          }
        }

        const retryableCodes = new Set(["table-recovery-failed", "recovery-failed", "migration-failed"]);
        const retryableFailures = report.issues.filter((issue) => retryableCodes.has(issue.code));
        const storageUnavailable = miniSource.status === "unavailable" || maskSource.status === "unavailable";
        report.completed = !storageUnavailable && retryableFailures.length === 0;
        report.completedAt = report.completed ? new Date().toISOString() : null;
        await db.persistenceMeta.put({ key: LEGACY_HYDRATION_MARKER, value: cloneSerializable(report), updatedAt: Date.now() });
        return report;
      }

      async function migrateHistoricalLocalStorageOnce() {
        const marker = await db.persistenceMeta.get(LEGACY_BOOTSTRAP_MARKER);
        if (marker?.value?.suppressed === true) return marker.value;
        if (marker?.value?.completed === true
          && Number(marker.value.revision || 0) >= LEGACY_IMPORT_REVISION) return marker.value;

        const miniSource = readLegacyLocalStorageSource(LEGACY_MINIDEXIE_KEY);
        const maskSource = readLegacyLocalStorageSource(LEGACY_LOCAL_MASK_KEY);
        let miniSnapshot = miniSource.value;
        let standaloneMasks = maskSource.value;
        const report = {
          revision: LEGACY_IMPORT_REVISION,
          completed: false,
          outcome: "pending",
          mode: "non-blocking-recovery",
          sources: {
            miniDexie: miniSource.status,
            standaloneMasks: maskSource.status
          },
          miniDexieFound: false,
          standaloneMaskFound: false,
          imported: {},
          rejected: {},
          issues: [],
          completedAt: null
        };

        if (miniSource.error) legacyIssue(report, "miniDexie", miniSource.status, miniSource.error);
        if (maskSource.error) legacyIssue(report, "standaloneMasks", maskSource.status, maskSource.error);

        if (miniSnapshot !== null) {
          const validSnapshot = miniSnapshot
            && typeof miniSnapshot === "object"
            && !Array.isArray(miniSnapshot)
            && miniSnapshot.tables
            && typeof miniSnapshot.tables === "object"
            && !Array.isArray(miniSnapshot.tables);
          if (!validSnapshot) {
            legacyIssue(report, "miniDexie", "invalid-snapshot-shape", "tables object missing");
            miniSnapshot = null;
          }
        }
        if (standaloneMasks !== null && !Array.isArray(standaloneMasks)) {
          legacyIssue(report, "standaloneMasks", "invalid-cache-shape", "expected array");
          standaloneMasks = null;
        }

        report.miniDexieFound = !!miniSnapshot;
        report.standaloneMaskFound = Array.isArray(standaloneMasks);
        const legacyTables = miniSnapshot?.tables || {};

        // 这里故意不再使用“一条坏记录即可回滚全部 13 表”的大事务。
        // 历史缓存只是恢复输入；正式 IndexedDB 已经成功打开后，任何历史坏行都只能被拒绝并记录，
        // 绝不能使 databaseReady 失败，更不能阻止 active/settings/profile 的正常 hydration。
        // 先恢复实体表，尤其是 characterTemplates。profile.activeMaskPresetId 可能只引用
        // characterTemplates 表中的账号，而不是嵌在 themeState.maskPresets 里；旧顺序先迁 profile
        // 会把这个合法账号误判为不存在并清空。
        const entitySpecs = [
          ["contacts", db.contacts, "contactId"],
          ["characterTemplates", db.characterTemplates, "templateId"],
          ["characters", db.characters, "characterId"],
          ["mediaAssets", db.mediaAssets, "assetId"],
          ["worldBooks", db.worldBooks, "worldBookId"],
          ["worldBookEntries", db.worldBookEntries, "entryId"],
          ["worldBookBindings", db.worldBookBindings, "bindingId"],
          ["chatMessages", db.chatMessages, "messageId"],
          ["chatSettings", db.chatSettings, "conversationId"],
          ["stickerGroups", db.stickerGroups, "groupId"],
          ["stickers", db.stickers, "stickerId"],
          ["wallets", db.wallets, "accountId"],
          ["musicState", db.musicState, "key"]
        ];
        for (const [name, table, primaryKey] of entitySpecs) {
          try {
            const count = await mergeLegacyEntityTable(table, legacyTables[name], primaryKey, report, name);
            if (count) report.imported[name] = count;
          } catch (error) {
            legacyIssue(report, name, "table-recovery-failed", error?.message || error);
          }
        }

        if (legacyTables.themeState !== undefined && !Array.isArray(legacyTables.themeState)) {
          legacyIssue(report, "themeState", "invalid-table-shape", "expected array");
        } else if (legacyTables.themeState?.length) {
          try {
            const currentState = await db.themeState.toArray();
            const previousRelationMarkers = await priorDataRelationMarkers();
            const previousRelations = latestRelationMarkerForCounter(
              previousRelationMarkers,
              "profileAccountRecovered"
            );
            const currentProfile = currentState.find((record) => record?.key === "profile");
            if (previousRelations?.value?.profileAccountRecovered === true
              && recordWasWrittenByRelationMigration(currentProfile, previousRelations, "profileAccountRecovered")) {
              currentProfile.value = {
                ...(currentProfile.value && typeof currentProfile.value === "object" ? currentProfile.value : {}),
                activeMaskPresetId: null
              };
            }
            const canonical = recoverLegacyAggregateSources(legacyTables.themeState, currentState);
            const canonicalMap = new Map(canonical.map((record) => [record.key, record]));
            try {
              const profile = await migrateLegacyMaskPresets(
                { table: (name) => db.table(name) },
                [...legacyTables.themeState],
                canonicalMap.get("profile") || null
              );
              canonicalMap.set("profile", profile);
            } catch (error) {
              legacyIssue(report, "maskPresets", "migration-failed", error?.message || error);
            }
            let importedState = 0;
            for (const record of canonicalMap.values()) {
              try {
                await db.themeState.put({
                  ...record,
                  updatedAt: persistenceRecordTime(record) || Date.now()
                });
                importedState += 1;
              } catch (error) {
                legacyIssue(report, "themeState", "record-rejected", `${record?.key || "unknown"}: ${error?.message || error}`);
              }
            }
            if (importedState) report.imported.themeState = importedState;
          } catch (error) {
            legacyIssue(report, "themeState", "recovery-failed", error?.message || error);
          }
        }



        if (Array.isArray(standaloneMasks) && standaloneMasks.length) {
          try {
            const syntheticRecords = [{
              key: LEGACY_MASK_KEY,
              value: { maskPresets: standaloneMasks, activeMaskPresetId: null },
              updatedAt: 0
            }];
            const currentProfile = await db.themeState.get("profile");
            const profile = await migrateLegacyMaskPresets(
              { table: (name) => db.table(name) },
              syntheticRecords,
              currentProfile || null
            );
            await db.themeState.put(profile);
            report.imported.standaloneMasks = standaloneMasks.length;
          } catch (error) {
            legacyIssue(report, "standaloneMasks", "migration-failed", error?.message || error);
          }
        }

        const storageUnavailable = miniSource.status === "unavailable" || maskSource.status === "unavailable";
        // 单表/单记录隔离不能等同于“整次迁移成功”。瞬时 IndexedDB 读写失败、
        // 聚合恢复失败或面具转换失败时不写 completed=true，下一次启动必须继续补齐；
        // 只有确定无法自动修复的坏 JSON/坏行才作为 issues 留痕并结束本轮。
        const retryableIssueCodes = new Set([
          "table-recovery-failed",
          "record-read-failed",
          "recovery-failed",
          "migration-failed"
        ]);
        const retryableFailures = report.issues.filter((issue) => retryableIssueCodes.has(issue.code));
        report.retryableFailures = retryableFailures.length;
        report.completed = !storageUnavailable && retryableFailures.length === 0;
        report.outcome = report.completed
          ? (report.issues.length ? "completed-with-issues" : "completed")
          : "source-unavailable";
        report.completedAt = report.completed ? new Date().toISOString() : null;
        try {
          await db.persistenceMeta.put({
            key: LEGACY_BOOTSTRAP_MARKER,
            value: cloneSerializable(report),
            updatedAt: Date.now()
          });
        } catch (error) {
          legacyIssue(report, "persistenceMeta", "marker-write-failed", error?.message || error);
        }
        return report;
      }

      async function suppressHistoricalImport(reason = "user-reset") {
        await databaseReady;
        const value = {
          revision: LEGACY_IMPORT_REVISION,
          completed: true,
          suppressed: true,
          outcome: "suppressed",
          reason: String(reason || "user-reset"),
          completedAt: new Date().toISOString()
        };
        await db.persistenceMeta.put({
          key: LEGACY_BOOTSTRAP_MARKER,
          value,
          updatedAt: Date.now()
        });
        return value;
      }

      db.on("versionchange", () => {
        // 旧页面一旦看到同 Origin 的新 schema 升级请求，永久关闭本页连接，禁止旧代码
        // 在交接后自动重开并继续写新库。
        db.close({ disableAutoOpen: true });
        console.warn("[清柳 persistence] 数据库已由另一页面升级；当前旧页面连接已关闭，请使用最新版本继续。 ");
      });

      db.on("blocked", () => {
        // blocked 本身不会失败或超时；再次广播连接交接，目标旧页面收到后关闭连接，
        // 当前原生 open 请求会由 IndexedDB 自动继续，不创建第二次 open/重试链。
        persistenceChannel?.postMessage({
          type: "release-for-schema-upgrade",
          sender: PERSISTENCE_CONTEXT_ID,
          targetNativeVersion: TARGET_NATIVE_DATABASE_VERSION
        });
        console.warn("[清柳 persistence] 数据库升级正在等待旧页面释放连接。");
      });

      // 持久化启动错误会在数据库异步初始化阶段发生，因此错误 UI 必须先于
      // databaseReady 建立，避免错误处理路径反过来触发 TDZ/ReferenceError。
      let modalClosePending = false;
      let modalCloseTimer = 0;
      let modalOpenRevision = 0;
      let modalActionRunning = false;
      let activeVoiceFillSession = null;

      function voiceFillRecognitionConstructor() {
        return window.SpeechRecognition || window.webkitSpeechRecognition || null;
      }

      function insertVoiceFillText(target, spokenText) {
        if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)) return false;
        const text = String(spokenText || "").trim();
        if (!text) return false;
        const start = Number.isFinite(target.selectionStart) ? target.selectionStart : target.value.length;
        const end = Number.isFinite(target.selectionEnd) ? target.selectionEnd : start;
        const before = target.value.slice(0, start);
        const after = target.value.slice(end);
        const needsSpacer = before && !/[\s，。！？、；：,.!?;:]$/.test(before);
        const inserted = `${needsSpacer ? " " : ""}${text}`;
        target.value = `${before}${inserted}${after}`;
        const cursor = before.length + inserted.length;
        try { target.setSelectionRange(cursor, cursor); } catch (_) {}
        target.dispatchEvent(new Event("input", { bubbles: true }));
        return true;
      }

      function stopVoiceFill() {
        const session = activeVoiceFillSession;
        activeVoiceFillSession = null;
        if (!session) return;
        try { session.recognition.abort(); } catch (_) {}
        session.button?.classList.remove("is-listening");
        session.button?.setAttribute("aria-pressed", "false");
      }

      function startVoiceFill(target, button) {
        const Recognition = voiceFillRecognitionConstructor();
        if (!Recognition || !(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)) return false;
        if (activeVoiceFillSession?.button === button) {
          stopVoiceFill();
          return true;
        }
        stopVoiceFill();
        const recognition = new Recognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = String(document.documentElement.lang || navigator.language || "zh-CN");
        activeVoiceFillSession = { recognition, button, target };
        button?.classList.add("is-listening");
        button?.setAttribute("aria-pressed", "true");
        recognition.addEventListener("result", (event) => {
          let transcript = "";
          for (let index = event.resultIndex || 0; index < event.results.length; index += 1) {
            if (event.results[index]?.isFinal !== false) transcript += event.results[index]?.[0]?.transcript || "";
          }
          insertVoiceFillText(target, transcript);
        });
        const finish = () => {
          if (activeVoiceFillSession?.recognition === recognition) activeVoiceFillSession = null;
          button?.classList.remove("is-listening");
          button?.setAttribute("aria-pressed", "false");
        };
        recognition.addEventListener("end", finish, { once: true });
        recognition.addEventListener("error", finish, { once: true });
        try {
          recognition.start();
          return true;
        } catch (error) {
          finish();
          console.error("voice fill start failed", error);
          return false;
        }
      }

      function createVoiceFillButton(target, label = "语音填写") {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "global-modal-voice-input global-text-voice-fill";
        button.setAttribute("aria-label", label);
        button.setAttribute("aria-pressed", "false");
        const icon = document.createElement("i");
        icon.className = "fa-solid fa-microphone";
        icon.setAttribute("aria-hidden", "true");
        const text = document.createElement("span");
        text.textContent = label;
        button.append(icon, text);
        if (!voiceFillRecognitionConstructor()) {
          button.disabled = true;
          button.title = "当前浏览器不支持语音填写";
        } else {
          button.addEventListener("click", () => startVoiceFill(target, button));
        }
        return button;
      }

      function createFullscreenButton(target, title = "设定内容") {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "ui-text-fullscreen-button";
        button.setAttribute("aria-label", `全屏填写${title}`);
        button.title = `全屏填写${title}`;
        const icon = document.createElement("i");
        icon.className = "fa-solid fa-expand";
        icon.setAttribute("aria-hidden", "true");
        button.appendChild(icon);
        button.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          TextEntryUI.openFullscreenEditor({ title, source: target });
        });
        return button;
      }

      function cssTransitionDurationMs(variableName, fallbackMs) {
        const value = getComputedStyle(document.documentElement).getPropertyValue(variableName).trim();
        const numeric = Number.parseFloat(value);
        if (!Number.isFinite(numeric)) return fallbackMs;
        if (value.endsWith("ms")) return Math.max(0, numeric);
        if (value.endsWith("s")) return Math.max(0, numeric * 1000);
        return Math.max(0, numeric * 1000);
      }

      function clearModalCloseTimer() {
        if (!modalCloseTimer) return;
        window.clearTimeout(modalCloseTimer);
        modalCloseTimer = 0;
      }

      function setModalNodeVisible(node, visible, displayValue = "") {
        const show = Boolean(visible);
        node.hidden = !show;
        if (show) {
          node.removeAttribute("hidden");
          node.style.display = displayValue;
          node.setAttribute("aria-hidden", "false");
        } else {
          node.setAttribute("hidden", "");
          node.style.display = "none";
          node.setAttribute("aria-hidden", "true");
        }
      }

      function finalizeModalClose() {
        if (!modalClosePending || modalOverlay.classList.contains("is-open")) return;
        clearModalCloseTimer();
        modalClosePending = false;
        modalOverlay.classList.remove("is-mounted");
        modalOverlay.setAttribute("aria-hidden", "true");
        modalActionRunning = false;
        modalConfirm.disabled = false;
        modalCancel.disabled = false;
        stopVoiceFill();
        modalExtra.replaceChildren();
        setModalNodeVisible(modalExtra, false);
        if (modalVoiceInput) setModalNodeVisible(modalVoiceInput, false);
      }

      const GlobalModal = {
        open({
          title,
          message = "",
          input = false,
          inputPlaceholder = "输入预设名称",
          inputValue = "",
          confirmLabel = "确认",
          cancelLabel = "取消",
          showCancel = true,
          danger = false,
          size = "default",
          content = null,
          action,
          cancelAction = null
        }) {
          stopVoiceFill();
          modalOpenRevision += 1;
          clearModalCloseTimer();
          state.modalAction = action;
          state.modalCancelAction = cancelAction;
          modalClosePending = false;
          modalActionRunning = false;
          modalConfirm.disabled = false;
          modalCancel.disabled = false;
          modal.dataset.size = ["small", "default", "large", "fullscreen"].includes(size) ? size : "default";
          modalTitle.textContent = String(title ?? "");
          const normalizedMessage = String(message ?? "");
          modalMessage.replaceChildren(document.createTextNode(normalizedMessage));
          setModalNodeVisible(modalMessage, normalizedMessage.length > 0, "block");
          modalExtra.replaceChildren();
          setModalNodeVisible(modalExtra, false);
          if (typeof content === "function") {
            setModalNodeVisible(modalExtra, true, "block");
            content(modalExtra);
          } else if (content instanceof Node) {
            setModalNodeVisible(modalExtra, true, "block");
            modalExtra.appendChild(content);
          } else if (typeof content === "string" && content) {
            setModalNodeVisible(modalExtra, true, "block");
            modalExtra.textContent = content;
          }
          setModalNodeVisible(modalInput, Boolean(input), "block");
          if (modalVoiceInput) {
            setModalNodeVisible(modalVoiceInput, Boolean(input), "inline-flex");
            modalVoiceInput.disabled = !voiceFillRecognitionConstructor();
            modalVoiceInput.title = modalVoiceInput.disabled ? "当前浏览器不支持语音填写" : "语音填写";
            modalVoiceInput.classList.remove("is-listening");
            modalVoiceInput.setAttribute("aria-pressed", "false");
          }
          modalInput.value = input ? String(inputValue) : "";
          modalInput.setCustomValidity("");
          modalInput.placeholder = input ? inputPlaceholder : "";
          modalCancel.textContent = cancelLabel;
          setModalNodeVisible(modalCancel, Boolean(showCancel), "block");
          modalActions.dataset.actionCount = showCancel ? "2" : "1";
          modalConfirm.textContent = confirmLabel;
          modalConfirm.classList.toggle("is-danger", danger);
          if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
          modalOverlay.classList.add("is-mounted");
          modalOverlay.setAttribute("aria-hidden", "false");
          void modalOverlay.offsetWidth;
          modalOverlay.classList.add("is-open");
          scheduleGlobalOverlayFocusedControlVisibility();
          window.QWQIcons?.hydrate(modal);
        },

        alert(config) {
          this.open({ ...config, input: false, showCancel: false });
        },

        confirm(config) {
          this.open({ ...config, input: false, showCancel: true });
        },

        prompt(config) {
          this.open({ ...config, input: true, showCancel: true });
        },

        async cancel() {
          if (modalActionRunning) return;
          const cancelAction = state.modalCancelAction;
          if (typeof cancelAction === "function") {
            const revision = modalOpenRevision;
            modalActionRunning = true;
            modalConfirm.disabled = true;
            modalCancel.disabled = true;
            try {
              const shouldClose = await cancelAction({ input: modalInput, content: modalExtra });
              if (revision !== modalOpenRevision) return;
              if (shouldClose !== false) this.close();
            } finally {
              if (revision === modalOpenRevision && modalOverlay.classList.contains("is-open")) {
                modalActionRunning = false;
                modalConfirm.disabled = false;
                modalCancel.disabled = false;
              }
            }
            return;
          }
          this.close();
        },

        close() {
          stopVoiceFill();
          modalOpenRevision += 1;
          state.modalAction = null;
          state.modalCancelAction = null;
          if (!modalOverlay.classList.contains("is-mounted")) return;
          modalClosePending = true;
          modalOverlay.classList.remove("is-open");
          modalOverlay.setAttribute("aria-hidden", "true");
          clearModalCloseTimer();
          modalCloseTimer = window.setTimeout(
            finalizeModalClose,
            cssTransitionDurationMs("--global-modal-transition-duration", 200) + 80
          );
        }
      };

      const TextEntryUI = Object.freeze({
        createVoiceFillButton,
        createFullscreenButton,
        stopVoiceFill,
        openFullscreenEditor({ title = "设定内容", source = null, value = "", placeholder = "", onApply = null } = {}) {
          const editor = document.createElement("div");
          editor.className = "global-fullscreen-editor";
          const textarea = document.createElement("textarea");
          textarea.className = "global-fullscreen-editor-textarea";
          textarea.placeholder = placeholder || source?.placeholder || "填写内容";
          textarea.value = source ? String(source.value || "") : String(value || "");
          const voiceButton = createVoiceFillButton(textarea);
          editor.append(textarea, voiceButton);
          GlobalModal.open({
            title,
            size: "fullscreen",
            content: editor,
            confirmLabel: "完成",
            cancelLabel: "取消",
            action: async () => {
              const nextValue = textarea.value;
              if (source instanceof HTMLInputElement || source instanceof HTMLTextAreaElement) {
                source.value = nextValue;
                source.dispatchEvent(new Event("input", { bubbles: true }));
                source.dispatchEvent(new Event("change", { bubbles: true }));
              }
              if (typeof onApply === "function") {
                const applied = await onApply(nextValue);
                if (applied === false) return false;
              }
              return true;
            }
          });
          requestAnimationFrame(() => textarea.focus({ preventScroll: true }));
          return textarea;
        }
      });


      // 只有 IndexedDB 打开或正式 active hydration 失败才属于致命初始化错误。
      // 单次业务写入失败、历史 localStorage 无效都不能把整个会话永久锁死。
      let persistenceFatalNotified = false;
      function notePersistenceFatal(error, stage = "unknown") {
        const errorName = typeof error?.name === "string" && error.name ? error.name : "Error";
        const detail = `${errorName}: ${String(error?.message || error || "未知错误")}`;
        console.error(`[清柳 persistence] 核心持久化初始化失败（${stage}），已阻断默认状态写入。`, error);
        if (persistenceFatalNotified) return;
        persistenceFatalNotified = true;
        GlobalModal.alert({
          title: "本地数据初始化失败",
          message: `持久化初始化停在“${stage}”：${detail}\n\n为避免默认状态覆盖已有数据，本次会话不会进入持久化写入。`,
          confirmLabel: "知道了",
          action: "dismiss"
        });
      }

      const CHAT_TIMELINE_MIGRATION_KEY = "chat.timeline.v1";

      async function migrateUnifiedChatTimelineOnce() {
        const previous = await db.persistenceMeta.get(CHAT_TIMELINE_MIGRATION_KEY);
        if (previous?.value?.completed === true) return previous.value;
        const report = {
          completed: false,
          messagesTagged: 0,
          producerProgressTouched: 0,
          producerProgressOwner: "QWQMemoryRepository",
          completedAt: null
        };

        // Theme/system continuity only owns the physical chat timeline tag. Producer progress
        // belongs to Memory Repository (v9) and must remain byte-for-byte available until that
        // domain migration can prove account / conversation / message-cursor ownership.
        await db.transaction("rw", db.chatMessages, db.persistenceMeta, async () => {
          // 使用游标原位迁移，任何时刻只解码一条消息。历史图片/视频 Blob 不再被
          // toArray 一次性克隆进 JS 堆，避免 Edge 在大聊天库上形成长时间主线程停顿。
          await db.chatMessages.toCollection().modify((message) => {
            const mode = message?.conversationMode === "offline-longform" || message?.payload?.conversationMode === "offline-longform"
              ? "offline-longform"
              : "online-chat";
            if (message?.conversationMode === mode) return;
            message.conversationMode = mode;
            report.messagesTagged += 1;
          });

          report.completed = true;
          report.completedAt = new Date().toISOString();
          await db.persistenceMeta.put({
            key: CHAT_TIMELINE_MIGRATION_KEY,
            value: cloneSerializable(report),
            updatedAt: Date.now()
          });
        });
        return report;
      }

      // 历史账号关系一次性收口：旧版本曾把 QQ 登录账户、联系人 owner 与可挂载面具拆分。
      // v13 只承认真实认证账号 / canonical 账号实体为 owner；未知历史 owner 不再被当成“有效账号”。
      // 旧 userPresetId 由后续 qq.accounts.v6 迁移统一清空，不参与当前身份解析。
      const DATA_RELATION_MIGRATION_KEY = "data.relations.v13";
      const CONTINUITY_TABLE_NAMES = Object.freeze([
        "themeState", "contacts", "characterTemplates", "characters", "mediaAssets",
        "worldBooks", "worldBookEntries", "worldBookBindings", "chatMessages",
        "chatSettings", "stickerGroups", "stickers", "wallets", "musicState", "homeScreenState",
        "qqAccountProfiles", "qqAccountState"
      ]);

      function relationMigrationUid(prefix) {
        const raw = globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
        return `${prefix}-${raw}`;
      }

      async function snapshotUserTableCounts() {
        const entries = await Promise.all(CONTINUITY_TABLE_NAMES.map(async (name) => {
          const table = db.table(name);
          return [name, await table.count()];
        }));
        return Object.fromEntries(entries);
      }

      function assertNoUserTableRegression(before, after, phase) {
        const reduced = CONTINUITY_TABLE_NAMES.filter((name) => Number(after[name] || 0) < Number(before[name] || 0));
        if (reduced.length) {
          throw new Error(`${phase} reduced user data: ${reduced.map((name) => `${name} ${before[name]}→${after[name]}`).join(", ")}`);
        }
      }

      async function migrateDataRelationsOnce({ force = false } = {}) {
        const previous = await db.persistenceMeta.get(DATA_RELATION_MIGRATION_KEY);
        if (!force && previous?.value?.completed) return previous.value;
        const priorRelationRows = await priorDataRelationMarkers();
        const priorContactRelations = latestRelationMarkerForCounter(priorRelationRows, "contactsLinkedToAccount");
        const priorMessageRelations = latestRelationMarkerForCounter(priorRelationRows, "chatMessagesLinkedToAccount");
        const priorChatSettingsRelations = latestRelationMarkerForCounter(priorRelationRows, "chatSettingsLinkedToAccount");

        const report = {
          completed: false,
          mode: "authoritative-owner-v13",
          contactsLinkedToAccount: 0,
          chatMessagesLinkedToAccount: 0,
          chatSettingsLinkedToAccount: 0,
          profileAccountRecovered: false,
          continuityAccountCreated: false,
          characterLinksRepaired: 0,
          charactersCreated: 0,
          unresolvedContacts: 0,
          deferred: false,
          danglingAvatarLinks: 0,
          danglingWorldBookLinks: 0,
          danglingBindings: 0,
          orphanEntries: 0,
          orphanCharacters: 0,
          orphanAssets: 0,
          completedAt: null
        };

        await db.transaction(
          "rw",
          db.themeState,
          db.contacts,
          db.characterTemplates,
          db.characters,
          db.mediaAssets,
          db.worldBooks,
          db.worldBookEntries,
          db.worldBookBindings,
          db.chatMessages,
          db.chatSettings,
          db.qqAccountProfiles,
          db.qqAccountState,
          db.persistenceMeta,
          async () => {
            const chatMessages = [];
            const [contacts, templates, worldBooks, entries, assetPrimaryKeys, characters, bindings, , chatSettings, accountRows, accountSessionState, profileRecord] = await Promise.all([
              db.contacts.toArray(),
              db.characterTemplates.toArray(),
              db.worldBooks.toArray(),
              db.worldBookEntries.toArray(),
              // 关系审计只需要 assetId。primaryKeys 不会把图片/视频 Blob 克隆进内存。
              db.mediaAssets.toCollection().primaryKeys(),
              db.characters.toArray(),
              db.worldBookBindings.toArray(),
              // 消息关系只需要身份、会话与时间字段；游标逐条投影后立即释放原消息，
              // 禁止在启动迁移中持有整个聊天正文及媒体 payload。
              db.chatMessages.toCollection().each((message) => {
                chatMessages.push({
                  messageId: message.messageId,
                  accountId: message.accountId,
                  conversationId: message.conversationId,
                  createdAt: message.createdAt,
                  updatedAt: message.updatedAt
                });
              }),
              db.chatSettings.toArray(),
              db.qqAccountProfiles.toArray(),
              db.qqAccountState.get("session"),
              db.themeState.get("profile")
            ]);
            const now = Date.now();
            const contactIds = new Set(contacts.map((item) => item.contactId));
            const templateIds = new Set(templates.map((item) => item.templateId));
            const profileValue = profileRecord?.value && typeof profileRecord.value === "object" && !Array.isArray(profileRecord.value)
              ? profileRecord.value
              : {};
            const authAccounts = profileValue.qqAuth?.accounts && typeof profileValue.qqAuth.accounts === "object" && !Array.isArray(profileValue.qqAuth.accounts)
              ? profileValue.qqAuth.accounts
              : {};
            const authoritativeAccountIds = new Set([
              ...Object.keys(authAccounts),
              ...accountRows.filter(isCanonicalQqLoginAccount).map((row) => String(row.accountId || ""))
            ].map((value) => String(value || "").trim()).filter(Boolean));
            const validAccountIds = new Set(authoritativeAccountIds);

            const hasHistoricalQqData = contacts.length > 0 || chatMessages.length > 0 || chatSettings.length > 0;
            if (validAccountIds.size === 0 && hasHistoricalQqData) {
              validAccountIds.add("qwq-continuity-account-v33");
              report.continuityAccountCreated = true;
            }

            const worldBookIds = new Set(worldBooks.map((item) => item.worldBookId));
            const assetIds = new Set(assetPrimaryKeys);
            const characterById = new Map(characters.map((item) => [item.characterId, item]));
            const charactersByContact = new Map();
            for (const character of characters) {
              if (!character.contactId) continue;
              const list = charactersByContact.get(character.contactId) || [];
              list.push(character);
              charactersByContact.set(character.contactId, list);
            }
            const canonicalSessionId = typeof accountSessionState?.accountId === "string"
              && validAccountIds.has(accountSessionState.accountId)
              ? accountSessionState.accountId
              : null;
            const legacySessionId = typeof profileValue.qqAuth?.session?.accountId === "string"
              && validAccountIds.has(profileValue.qqAuth.session.accountId)
              ? profileValue.qqAuth.session.accountId
              : null;
            const rememberedAccountId = typeof profileValue.activeQqAccountId === "string"
              && validAccountIds.has(profileValue.activeQqAccountId)
              ? profileValue.activeQqAccountId
              : null;
            const legacyAccountId = typeof profileValue.activeMaskPresetId === "string"
              && validAccountIds.has(profileValue.activeMaskPresetId)
              ? profileValue.activeMaskPresetId
              : null;
            const profileAccountId = canonicalSessionId || legacySessionId || rememberedAccountId || legacyAccountId;
            // Never guess among multiple real accounts. Unknown historical owners are only attached when there is
            // a concrete session/legacy pointer or exactly one authoritative owner; otherwise they remain unresolved.
            const resolvedFallbackAccountId = profileAccountId
              || (validAccountIds.size === 1 ? Array.from(validAccountIds)[0] : null);
            report.profileAccountRecovered = false;

            const resolvedAccountByContact = new Map();
            for (const contact of contacts) {
              const patch = {};
              const legacyPresetId = typeof contact.userPresetId === "string" && templateIds.has(contact.userPresetId)
                ? contact.userPresetId
                : null;
              const accountWasGenerated = recordWasWrittenByRelationMigration(
                contact,
                priorContactRelations,
                "contactsLinkedToAccount"
              );
              let resolvedAccountId = typeof contact.accountId === "string" && validAccountIds.has(contact.accountId)
                && !(accountWasGenerated && resolvedFallbackAccountId && contact.accountId !== resolvedFallbackAccountId)
                ? contact.accountId
                : null;
              if (!resolvedAccountId) {
                resolvedAccountId = resolvedFallbackAccountId;
                if (resolvedAccountId) {
                  patch.accountId = resolvedAccountId;
                  report.contactsLinkedToAccount += 1;
                } else {
                  report.unresolvedContacts += 1;
                }
              }
              if (contact.userPresetId !== null && contact.userPresetId !== undefined && !legacyPresetId) {
                patch.userPresetId = null;
              }
              resolvedAccountByContact.set(contact.contactId, resolvedAccountId || null);

              let canonical = contact.characterId ? characterById.get(contact.characterId) : null;
              if (!canonical || canonical.contactId !== contact.contactId) {
                canonical = (charactersByContact.get(contact.contactId) || [])[0] || null;
              }
              if (!canonical) {
                canonical = {
                  characterId: relationMigrationUid("character"),
                  contactId: contact.contactId,
                  name: String(contact.note || contact.nickname || contact.name || contact.displayName || "未命名角色").split(/\r?\n/)[0].trim() || "未命名角色",
                  persona: String(contact.settingContent || ""),
                  avatarAssetId: contact.avatarAssetId || null,
                  worldBookId: null,
                  createdAt: Number(contact.createdAt) || now,
                  updatedAt: now
                };
                await db.characters.add(canonical);
                characterById.set(canonical.characterId, canonical);
                report.charactersCreated += 1;
              }
              if (contact.characterId !== canonical.characterId) {
                patch.characterId = canonical.characterId;
                report.characterLinksRepaired += 1;
              }
              if (Object.keys(patch).length) {
                patch.updatedAt = now;
                await db.contacts.update(contact.contactId, patch);
              }
            }

            for (const message of chatMessages) {
              const contactAccountId = resolvedAccountByContact.get(message.conversationId) || null;
              const validAccount = typeof message.accountId === "string" && validAccountIds.has(message.accountId);
              const accountWasGenerated = recordWasWrittenByRelationMigration(
                message,
                priorMessageRelations,
                "chatMessagesLinkedToAccount"
              );
              const nextAccountId = contactAccountId
                || (!validAccount || accountWasGenerated ? resolvedFallbackAccountId : message.accountId);
              if (!nextAccountId || message.accountId === nextAccountId) continue;
              await db.chatMessages.update(message.messageId, { accountId: nextAccountId, updatedAt: Math.max(Number(message.updatedAt || 0), now) });
              report.chatMessagesLinkedToAccount += 1;
            }

            for (const settingsRow of chatSettings) {
              const contactAccountId = resolvedAccountByContact.get(settingsRow.conversationId) || null;
              const validAccount = typeof settingsRow.accountId === "string" && validAccountIds.has(settingsRow.accountId);
              const accountWasGenerated = recordWasWrittenByRelationMigration(
                settingsRow,
                priorChatSettingsRelations,
                "chatSettingsLinkedToAccount"
              );
              const nextAccountId = contactAccountId
                || (!validAccount || accountWasGenerated ? resolvedFallbackAccountId : settingsRow.accountId);
              if (!nextAccountId || settingsRow.accountId === nextAccountId) continue;
              await db.chatSettings.update(settingsRow.conversationId, { accountId: nextAccountId, updatedAt: Math.max(Number(settingsRow.updatedAt || 0), now) });
              report.chatSettingsLinkedToAccount += 1;
            }

            for (const item of contacts) {
              if (item.avatarAssetId && !assetIds.has(item.avatarAssetId)) report.danglingAvatarLinks += 1;
            }
            for (const item of templates) {
              if (item.avatarAssetId && !assetIds.has(item.avatarAssetId)) report.danglingAvatarLinks += 1;
              if (item.defaultWorldBookId && !worldBookIds.has(item.defaultWorldBookId)) report.danglingWorldBookLinks += 1;
            }
            for (const item of characters) {
              if (item.contactId && !contactIds.has(item.contactId)) report.orphanCharacters += 1;
              if (item.avatarAssetId && !assetIds.has(item.avatarAssetId)) report.danglingAvatarLinks += 1;
              if (item.worldBookId && !worldBookIds.has(item.worldBookId)) report.danglingWorldBookLinks += 1;
            }
            const entryById = new Map(entries.map((entry) => [entry.entryId, entry]));
            for (const entry of entries) {
              if (!worldBookIds.has(entry.worldBookId)) report.orphanEntries += 1;
            }
            for (const binding of bindings) {
              const entry = binding.entryId === null ? null : entryById.get(binding.entryId);
              if (!worldBookIds.has(binding.worldBookId) || (binding.entryId !== null && (!entry || entry.worldBookId !== binding.worldBookId))) {
                report.danglingBindings += 1;
              }
            }
            const referencedAssets = new Set([
              ...contacts.map((item) => item.avatarAssetId).filter(Boolean),
              ...templates.map((item) => item.avatarAssetId).filter(Boolean),
              ...characters.map((item) => item.avatarAssetId).filter(Boolean)
            ]);
            report.orphanAssets = assetPrimaryKeys.filter((assetId) => !referencedAssets.has(assetId)).length;

            // 历史关系迁移不再用 characterTemplates 数量判断完成；
            // 当前账号身份由后续 v38 QQ account 迁移收口到唯一账号实体。
            // 新建联系人走正式 repository，备份导入会显式 force reconcile；因此空库或
            // 已全部归属的数据库都应一次完成，不能因“没有面具模板”在每次启动重扫全表。
            // Ambiguous ownership with multiple real accounts is intentionally not guessed. Re-scanning the same
            // immutable ambiguity on every startup cannot resolve it, so the one-time audit completes and reports it.
            report.completed = true;
            report.deferred = false;
            report.completedAt = new Date().toISOString();
            await db.persistenceMeta.put({
              key: DATA_RELATION_MIGRATION_KEY,
              value: cloneSerializable(report),
              updatedAt: Date.now()
            });
          }
        );
        return report;
      }

      // v38：QQ 账号域二次教研收口。账号实体仍是 owner 根节点，进一步修正迁移顺序与身份生命周期，
      // 不复制参考实现：QQ号、手机号、凭据、头像、资料、面具仍归同一账号实体；
      // qqAccountState 只保存会话指针。未认证旧身份只允许作为同表 continuity-draft 短暂托管，首个真实注册后原子删除。
      const QQ_ACCOUNT_MIGRATION_KEY = "qq.accounts.v6";
      const QQ_CONTINUITY_ACCOUNT_ID = "qwq-continuity-account-v33";

      function normalizeQqAccountText(value, maxLength = 200000) {
        return String(value ?? "").replace(/\r\n?/g, "\n").trim().slice(0, maxLength);
      }

      function normalizeQqAccountUserText(value) {
        return String(value ?? "").replace(/\r\n?/g, "\n").trim();
      }

      function normalizeLegacyQqCredential(value) {
        if (!value || typeof value !== "object" || Array.isArray(value)) return null;
        const algorithm = normalizeQqAccountText(value.algorithm, 40);
        const salt = normalizeQqAccountText(value.salt, 400);
        const hash = normalizeQqAccountText(value.hash, 400);
        const iterations = Number.parseInt(value.iterations, 10) || 0;
        if (!algorithm || !salt || !hash) return null;
        if (algorithm === "pbkdf2-sha256") {
          if (iterations < 1000) return null;
          return { algorithm, salt, hash, iterations };
        }
        if (algorithm === "local-fallback-v1") return { algorithm, salt, hash };
        return null;
      }

      function normalizeLegacyQqAccountProfile(value = {}) {
        const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
        return {
          nickname: normalizeQqAccountUserText(source.nickname || source.displayName),
          name: normalizeQqAccountUserText(source.name),
          persona: normalizeQqAccountUserText(source.persona ?? source.settingContent),
          signature: normalizeQqAccountUserText(source.signature || source.bio),
          gender: normalizeQqAccountUserText(source.gender),
          birthday: normalizeQqAccountUserText(source.birthday),
          constellation: normalizeQqAccountUserText(source.constellation),
          location: normalizeQqAccountUserText(source.location || source.current),
          origin: normalizeQqAccountUserText(source.origin),
          tags: normalizeQqAccountUserText(source.tags),
          likes: normalizeQqAccountUserText(source.likes) || "0",
          level: Math.max(1, Math.min(4095, Number.parseInt(source.level, 10) || 1)),
          avatarBlob: source.avatarBlob instanceof Blob && source.avatarBlob.size ? source.avatarBlob : null,
          avatarAssetId: typeof source.avatarAssetId === "string" && source.avatarAssetId ? source.avatarAssetId : null,
          coverAssetId: typeof source.coverAssetId === "string" && source.coverAssetId ? source.coverAssetId : null,
          createdAt: Number(source.createdAt) || 0,
          updatedAt: Number(source.updatedAt) || 0
        };
      }

      function isCanonicalQqLoginAccount(row) {
        if (!row || typeof row !== "object" || row.status === "continuity-draft") return false;
        return Boolean(
          normalizeQqAccountText(row.accountId, 180)
          && /^\d{5,12}$/.test(normalizeQqAccountText(row.qqNumber, 12))
          && normalizeLegacyQqCredential(row.credential)
        );
      }

      function legacyQqIdentityScore(profile) {
        if (!profile) return 0;
        let score = 0;
        if (profile.avatarAssetId || profile.avatarBlob) score += 20;
        if (profile.coverAssetId) score += 16;
        if (profile.persona) score += 14;
        if (profile.nickname && profile.nickname !== "^ω^") score += 10;
        if (profile.name) score += 8;
        if (profile.signature) score += 6;
        if (profile.tags) score += 4;
        if (profile.gender || profile.birthday || profile.constellation || profile.location || profile.origin) score += 3;
        if (profile.likes && profile.likes !== "0") score += 2;
        if ((Number(profile.level) || 1) > 1) score += 2;
        return score;
      }

      async function migrateQqAccountsOnce({ force = false } = {}) {
        const previous = await db.persistenceMeta.get(QQ_ACCOUNT_MIGRATION_KEY);
        if (!force && previous?.value?.completed) return previous.value;
        const report = {
          completed: false,
          accounts: 0,
          accountsCreated: 0,
          accountsMerged: 0,
          avatarAssetsCreated: 0,
          coverAssetsCreated: 0,
          continuityDraftCreated: false,
          conversationMasksCleared: 0,
          staleProfileRowsRemoved: 0,
          legacyProfileFieldsRemoved: 0,
          sessionMigrated: false,
          completedAt: null
        };

        await db.transaction(
          "rw",
          db.themeState,
          db.qqAccountProfiles,
          db.qqAccountState,
          db.characterTemplates,
          db.mediaAssets,
          db.contacts,
          db.persistenceMeta,
          async () => {
            const now = Date.now();
            const profileRecord = await db.themeState.get("profile");
            const profileValue = profileRecord?.value && typeof profileRecord.value === "object" && !Array.isArray(profileRecord.value)
              ? { ...profileRecord.value }
              : {};
            const auth = profileValue.qqAuth && typeof profileValue.qqAuth === "object" && !Array.isArray(profileValue.qqAuth)
              ? profileValue.qqAuth
              : {};
            const legacyAuthAccounts = auth.accounts && typeof auth.accounts === "object" && !Array.isArray(auth.accounts)
              ? auth.accounts
              : {};
            const existingRows = await db.qqAccountProfiles.toArray();
            const existingById = new Map(existingRows.map((row) => [String(row?.accountId || "").trim(), row]));
            const legacyProfiles = profileValue.qqProfiles && typeof profileValue.qqProfiles === "object" && !Array.isArray(profileValue.qqProfiles)
              ? profileValue.qqProfiles
              : {};
            const legacyCovers = profileValue.qqProfileCovers && typeof profileValue.qqProfileCovers === "object" && !Array.isArray(profileValue.qqProfileCovers)
              ? profileValue.qqProfileCovers
              : {};
            const activeLegacyPresetId = typeof profileValue.activeMaskPresetId === "string" ? profileValue.activeMaskPresetId : "";
            const activeLegacyPreset = activeLegacyPresetId ? await db.characterTemplates.get(activeLegacyPresetId) : null;
            const legacyAccountIds = Object.keys(legacyAuthAccounts).map((value) => String(value || "").trim()).filter(Boolean);
            const accountIds = Array.from(new Set([
              ...legacyAccountIds,
              ...existingRows
                .filter((row) => row?.status !== "continuity-draft" && row?.credential && row?.qqNumber)
                .map((row) => String(row.accountId || "").trim())
            ].filter(Boolean)));
            report.accounts = accountIds.length;

            const singleLegacyPreset = accountIds.length === 1 ? activeLegacyPreset : null;
            const rootFallback = normalizeLegacyQqAccountProfile({
              nickname: profileValue.nickname || profileValue.displayName,
              name: profileValue.name,
              persona: profileValue.persona || profileValue.settingContent,
              signature: profileValue.signature || profileValue.bio,
              updatedAt: profileRecord?.updatedAt
            });
            const textFields = ["nickname", "name", "persona", "signature", "gender", "birthday", "constellation", "location", "origin", "tags", "likes"];

            for (const accountId of accountIds) {
              if (accountId === QQ_CONTINUITY_ACCOUNT_ID) {
                throw new Error("QQ账号迁移失败：真实账号占用了迁移保留标识。旧账号层未清理。");
              }
              const legacyAuth = legacyAuthAccounts[accountId] && typeof legacyAuthAccounts[accountId] === "object"
                ? legacyAuthAccounts[accountId]
                : {};
              const existing = existingById.get(accountId) || null;
              const qqNumber = normalizeQqAccountText(legacyAuth.qqNumber || existing?.qqNumber, 12).replace(/\D/g, "");
              if (!/^\d{5,12}$/.test(qqNumber)) {
                throw new Error(`QQ账号迁移失败：账号 ${accountId} 缺少有效的自定义QQ号。旧账号层未清理。`);
              }
              const credential = normalizeLegacyQqCredential(legacyAuth.credential || existing?.credential);
              if (!credential) {
                throw new Error(`QQ账号迁移失败：QQ号 ${qqNumber} 的登录凭据算法无效或数据不完整。旧账号层未清理。`);
              }
              const phoneNumber = normalizeQqAccountUserText(legacyAuth.phoneNumber || existing?.phoneNumber);
              const accountTemplate = await db.characterTemplates.get(accountId);
              const source = normalizeLegacyQqAccountProfile(
                legacyProfiles[accountId]
                || accountTemplate
                || singleLegacyPreset
                || rootFallback
              );
              const existingUpdatedAt = Number(existing?.updatedAt) || 0;
              const sourceUpdatedAt = Number(source.updatedAt) || 0;
              const merged = existing ? { ...existing } : { accountId };
              delete merged.status;
              let changed = !existing;

              for (const field of textFields) {
                const current = normalizeQqAccountUserText(existing?.[field]);
                const incoming = normalizeQqAccountUserText(source[field]);
                const shouldImport = incoming && (!current || sourceUpdatedAt > existingUpdatedAt);
                const next = shouldImport ? incoming : current;
                const normalizedNext = field === "nickname" ? (next || "^ω^") : field === "likes" ? (next || "0") : next;
                if (merged[field] !== normalizedNext) changed = true;
                merged[field] = normalizedNext;
              }
              const nextLevel = Math.max(1, Math.min(4095, Number.parseInt(existing?.level ?? source.level, 10) || 1));
              if (merged.level !== nextLevel) changed = true;
              merged.level = nextLevel;

              let avatarAssetId = existing?.avatarAssetId || source.avatarAssetId || null;
              if (avatarAssetId && !(await db.mediaAssets.get(avatarAssetId))) avatarAssetId = null;
              if (!avatarAssetId && source.avatarBlob instanceof Blob) {
                const persistentAvatarBlob = source.avatarBlob;
                avatarAssetId = relationMigrationUid("asset");
                await db.mediaAssets.add({
                  assetId: avatarAssetId,
                  kind: "qq-account-avatar",
                  ownerType: "qq-account",
                  ownerId: accountId,
                  mime: persistentAvatarBlob.type || "application/octet-stream",
                  size: persistentAvatarBlob.size,
                  blob: persistentAvatarBlob,
                  createdAt: now,
                  updatedAt: now
                });
                report.avatarAssetsCreated += 1;
                changed = true;
              }
              merged.avatarAssetId = avatarAssetId;

              let coverAssetId = existing?.coverAssetId || source.coverAssetId || null;
              if (coverAssetId && !(await db.mediaAssets.get(coverAssetId))) coverAssetId = null;
              const legacyCover = legacyCovers[accountId];
              if (!coverAssetId && legacyCover instanceof Blob && legacyCover.size) {
                const persistentCoverBlob = legacyCover;
                coverAssetId = relationMigrationUid("asset");
                await db.mediaAssets.add({
                  assetId: coverAssetId,
                  kind: "qq-account-cover",
                  ownerType: "qq-account",
                  ownerId: accountId,
                  mime: persistentCoverBlob.type || "application/octet-stream",
                  size: persistentCoverBlob.size,
                  blob: persistentCoverBlob,
                  createdAt: now,
                  updatedAt: now
                });
                report.coverAssetsCreated += 1;
                changed = true;
              }
              merged.coverAssetId = coverAssetId;
              merged.accountId = accountId;
              merged.qqNumber = qqNumber;
              if (phoneNumber) merged.phoneNumber = phoneNumber;
              else delete merged.phoneNumber;
              merged.credential = credential;
              merged.registeredAt = Number(legacyAuth.registeredAt) || Number(existing?.registeredAt) || Number(existing?.createdAt) || now;
              merged.createdAt = Number(existing?.createdAt) || merged.registeredAt || now;
              merged.updatedAt = changed || legacyAuthAccounts[accountId] ? now : existingUpdatedAt || now;

              await db.qqAccountProfiles.put(merged);
              if (existing) report.accountsMerged += 1;
              else report.accountsCreated += 1;
            }

            const storedAccounts = accountIds.length ? await db.qqAccountProfiles.bulkGet(accountIds) : [];
            if (storedAccounts.length !== accountIds.length || !storedAccounts.every((row, index) => (
              row && row.accountId === accountIds[index] && isCanonicalQqLoginAccount(row)
            ))) {
              throw new Error("QQ账号实体迁移完整性校验失败。旧账号层未清理。");
            }

            const identifierOwners = new Map();
            for (const row of storedAccounts) {
              for (const identifier of [String(row?.qqNumber || "").trim(), String(row?.phoneNumber || "").trim()].filter(Boolean)) {
                const owner = identifierOwners.get(identifier);
                if (owner && owner !== row.accountId) {
                  throw new Error(`QQ账号迁移失败：登录标识 ${identifier} 同时属于多个账号。数据已保留，未执行旧层清理。`);
                }
                identifierOwners.set(identifier, row.accountId);
              }
            }
            const validAccountIds = new Set(storedAccounts.map((row) => row.accountId));

            // No real login account yet: preserve exactly one richest legacy identity as a canonical lifecycle draft.
            // It never participates in get/list/session/login and is atomically adopted by the first real registration.
            if (validAccountIds.size === 0) {
              const candidates = [];
              for (const row of existingRows) {
                const sourceId = String(row?.accountId || "").trim();
                const profile = normalizeLegacyQqAccountProfile(row);
                if (legacyQqIdentityScore(profile) > 0) candidates.push({ sourceId, profile });
              }
              for (const [sourceId, value] of Object.entries(legacyProfiles)) {
                const profile = normalizeLegacyQqAccountProfile(value);
                if (legacyQqIdentityScore(profile) > 0) candidates.push({ sourceId:String(sourceId || "").trim(), profile });
              }
              if (activeLegacyPreset) {
                const profile = normalizeLegacyQqAccountProfile(activeLegacyPreset);
                if (legacyQqIdentityScore(profile) > 0) candidates.push({ sourceId:activeLegacyPresetId, profile });
              }
              if (legacyQqIdentityScore(rootFallback) > 0) candidates.push({ sourceId:"profile-root", profile:rootFallback });
              candidates.sort((a, b) => (
                legacyQqIdentityScore(b.profile) - legacyQqIdentityScore(a.profile)
                || Number(b.profile.updatedAt || 0) - Number(a.profile.updatedAt || 0)
              ));
              const donor = candidates[0] || null;
              if (donor) {
                const profile = donor.profile;
                let avatarAssetId = profile.avatarAssetId || null;
                if (avatarAssetId && !(await db.mediaAssets.get(avatarAssetId))) avatarAssetId = null;
                if (!avatarAssetId && profile.avatarBlob instanceof Blob) {
                  const persistentAvatarBlob = profile.avatarBlob;
                  avatarAssetId = relationMigrationUid("asset");
                  await db.mediaAssets.add({
                    assetId: avatarAssetId,
                    kind: "qq-account-avatar",
                    ownerType: "qq-account",
                    ownerId: QQ_CONTINUITY_ACCOUNT_ID,
                    mime: persistentAvatarBlob.type || "application/octet-stream",
                    size: persistentAvatarBlob.size,
                    blob: persistentAvatarBlob,
                    createdAt: now,
                    updatedAt: now
                  });
                  report.avatarAssetsCreated += 1;
                }
                let coverAssetId = profile.coverAssetId || null;
                if (coverAssetId && !(await db.mediaAssets.get(coverAssetId))) coverAssetId = null;
                const donorLegacyCover = legacyCovers[donor.sourceId];
                if (!coverAssetId && donorLegacyCover instanceof Blob && donorLegacyCover.size) {
                  const persistentCoverBlob = donorLegacyCover;
                  coverAssetId = relationMigrationUid("asset");
                  await db.mediaAssets.add({
                    assetId: coverAssetId,
                    kind: "qq-account-cover",
                    ownerType: "qq-account",
                    ownerId: QQ_CONTINUITY_ACCOUNT_ID,
                    mime: persistentCoverBlob.type || "application/octet-stream",
                    size: persistentCoverBlob.size,
                    blob: persistentCoverBlob,
                    createdAt: now,
                    updatedAt: now
                  });
                  report.coverAssetsCreated += 1;
                }
                for (const assetId of [avatarAssetId, coverAssetId].filter(Boolean)) {
                  const media = await db.mediaAssets.get(assetId);
                  if (media?.ownerType === "qq-account") await db.mediaAssets.update(assetId, { ownerId:QQ_CONTINUITY_ACCOUNT_ID, updatedAt:now });
                }
                await db.qqAccountProfiles.put({
                  accountId: QQ_CONTINUITY_ACCOUNT_ID,
                  status: "continuity-draft",
                  nickname: profile.nickname || "^ω^",
                  name: profile.name,
                  persona: profile.persona,
                  signature: profile.signature,
                  gender: profile.gender,
                  birthday: profile.birthday,
                  constellation: profile.constellation,
                  location: profile.location,
                  origin: profile.origin,
                  tags: profile.tags,
                  likes: profile.likes || "0",
                  level: profile.level,
                  avatarAssetId,
                  coverAssetId,
                  registeredAt: 0,
                  createdAt: Number(profile.createdAt) || now,
                  updatedAt: now
                });
                report.continuityDraftCreated = true;
              }
            }

            const currentRows = await db.qqAccountProfiles.toArray();
            const staleProfileIds = currentRows
              .map((row) => String(row?.accountId || "").trim())
              .filter((accountId) => accountId
                && !validAccountIds.has(accountId)
                && !(validAccountIds.size === 0 && accountId === QQ_CONTINUITY_ACCOUNT_ID));
            if (staleProfileIds.length) {
              await db.qqAccountProfiles.bulkDelete(staleProfileIds);
              report.staleProfileRowsRemoved = staleProfileIds.length;
            }

            const [currentSessionState, currentLastUsedState] = await Promise.all([
              db.qqAccountState.get("session"),
              db.qqAccountState.get("last-used")
            ]);
            const legacySessionId = String(auth.session?.accountId || "").trim();
            const persistedSessionId = String(currentSessionState?.accountId || "").trim();
            const rememberedId = String(profileValue.activeQqAccountId || "").trim();
            const persistedLastUsedId = String(currentLastUsedState?.accountId || "").trim();
            const resolvedSessionId = validAccountIds.has(legacySessionId)
              ? legacySessionId
              : validAccountIds.has(persistedSessionId)
                ? persistedSessionId
                : null;
            const lastAccountId = resolvedSessionId
              || (validAccountIds.has(persistedLastUsedId) ? persistedLastUsedId : null)
              || (validAccountIds.has(rememberedId) ? rememberedId : null)
              || storedAccounts[0]?.accountId
              || null;
            if (resolvedSessionId) {
              await db.qqAccountState.put({
                key: "session",
                accountId: resolvedSessionId,
                signedInAt: validAccountIds.has(legacySessionId)
                  ? Number(auth.session?.signedInAt) || now
                  : Number(currentSessionState?.signedInAt) || now,
                updatedAt: now
              });
              report.sessionMigrated = validAccountIds.has(legacySessionId);
            } else {
              await db.qqAccountState.delete("session");
            }
            if (lastAccountId) {
              await db.qqAccountState.put({ key: "last-used", accountId: lastAccountId, updatedAt: now });
            } else {
              await db.qqAccountState.delete("last-used");
            }

            const contactsWithConversationMask = await db.contacts.filter((contact) => Boolean(contact?.userPresetId)).toArray();
            if (contactsWithConversationMask.length) {
              await db.contacts.filter((contact) => Boolean(contact?.userPresetId)).modify({ userPresetId: null, updatedAt: now });
              report.conversationMasksCleared = contactsWithConversationMask.length;
            }

            const cleanedProfileValue = { ...profileValue };
            for (const field of ["qqAuth", "activeQqAccountId", "qqIdentityModelVersion", "qqProfiles", "qqProfileCovers", "activeMaskPresetId"]) {
              if (!Object.prototype.hasOwnProperty.call(cleanedProfileValue, field)) continue;
              delete cleanedProfileValue[field];
              report.legacyProfileFieldsRemoved += 1;
            }
            if (profileRecord || Object.keys(cleanedProfileValue).length) {
              await db.themeState.put({
                key: "profile",
                version: PERSISTENCE_VERSION,
                value: cloneSerializable(cleanedProfileValue),
                updatedAt: Math.max(Number(profileRecord?.updatedAt || 0), now)
              });
            }

            report.completed = true;
            report.completedAt = new Date().toISOString();
            await db.persistenceMeta.put({
              key: QQ_ACCOUNT_MIGRATION_KEY,
              value: cloneSerializable(report),
              updatedAt: Date.now()
            });
          }
        );
        return report;
      }

      const MUSIC_STATE_MIGRATION_KEY = "music.state.v2";
      const MUSIC_PROFILE_FIELDS = Object.freeze({
        musicLibrary: MUSIC_STATE_KEYS.library,
        musicCommentState: MUSIC_STATE_KEYS.comments,
        musicPlaybackState: MUSIC_STATE_KEYS.playback,
        musicSettings: MUSIC_STATE_KEYS.settings
      });

      async function migrateMusicStateFromProfileOnce() {
        const profileRecord = await db.themeState.get("profile");
        const profileValue = profileRecord?.value && typeof profileRecord.value === "object" && !Array.isArray(profileRecord.value)
          ? { ...profileRecord.value }
          : {};
        const legacyEntries = Object.entries(MUSIC_PROFILE_FIELDS)
          .filter(([field]) => Object.prototype.hasOwnProperty.call(profileValue, field));
        const previous = await db.persistenceMeta.get(MUSIC_STATE_MIGRATION_KEY);
        if (!legacyEntries.length && previous?.value?.completed) return previous.value;

        const report = { completed: false, imported: 0, removedLegacyProfileFields: 0, completedAt: null };
        await db.transaction("rw", db.themeState, db.musicState, db.persistenceMeta, async () => {
          const currentProfile = await db.themeState.get("profile");
          const currentValue = currentProfile?.value && typeof currentProfile.value === "object" && !Array.isArray(currentProfile.value)
            ? { ...currentProfile.value }
            : {};
          for (const [field, key] of Object.entries(MUSIC_PROFILE_FIELDS)) {
            if (!Object.prototype.hasOwnProperty.call(currentValue, field)) continue;
            const legacyValue = currentValue[field];
            const existing = await db.musicState.get(key);
            const legacyMeaningful = !musicStateValueLooksEmpty(key, legacyValue);
            const existingEmpty = !existing || musicStateValueLooksEmpty(key, existing.value);
            if (existingEmpty && legacyMeaningful) {
              await db.musicState.put({
                key,
                value: cloneSerializable(legacyValue),
                updatedAt: Math.max(Number(existing?.updatedAt) || 0, Number(currentProfile?.updatedAt) || Date.now())
              });
              report.imported += 1;
            }
            delete currentValue[field];
            report.removedLegacyProfileFields += 1;
          }
          if (report.removedLegacyProfileFields > 0 && currentProfile) {
            await db.themeState.put({
              ...currentProfile,
              key: "profile",
              version: PERSISTENCE_VERSION,
              value: cloneSerializable(currentValue),
              updatedAt: Math.max(Number(currentProfile.updatedAt || 0), Date.now())
            });
          }
          report.completed = true;
          report.completedAt = new Date().toISOString();
          await db.persistenceMeta.put({ key: MUSIC_STATE_MIGRATION_KEY, value: cloneSerializable(report), updatedAt: Date.now() });
        });
        return report;
      }

      // Shared Memory legacy bootstrap migration is owned by Apps/memory/memory-repository.js.
      // Theme owns database/system continuity only and must not read or write memory_items as a memory-domain migration.

      let persistenceRuntime = null;
      const databaseReady = (async () => {
        const stage = "indexeddb-open";
        try {
          // IndexedDB 原生 open 是唯一版本判定源。禁止在关键路径前置数据库枚举：
          // Edge 的本地文件/隐私分区可能让枚举长期 pending，
          // 导致 open 根本没有开始且页面没有任何可报告的数据库错误。
          await db.open();
          const nativeDatabase = db.backendDB();
          const missingStores = Object.keys(DATABASE_SCHEMA).filter((name)=>!nativeDatabase.objectStoreNames.contains(name));
          if(missingStores.length){
            throw new Error(`IndexedDB schema incomplete after v${myPhoneConfig.persistence.dexieSchemaRevision} upgrade: missing object stores ${missingStores.join(", ")}`);
          }
          return true;
        } catch (error) {
          notePersistenceFatal(error, stage);
          throw error;
        }
      })();

      let hydrationContinuityPromise = null;
      function ensureHydrationContinuity() {
        if (!hydrationContinuityPromise) {
          hydrationContinuityPromise = (async () => {
            await databaseReady;
            // 这两项可能提供 active/settings/profile 的历史正式值，必须在首屏读取前完成，
            // 否则默认主屏有机会先写入并遮住旧版本数据。其余业务大表迁移不在此门闩。
            let internalContinuity;
            try {
              internalContinuity = await migrateInternalPersistenceContinuityOnce();
            } catch (error) {
              console.error("[清柳 persistence] 内部旧数据整理失败，已隔离；继续读取正式记录。", error);
              internalContinuity = { completed: false, outcome: "failed-nonfatal", error: String(error?.message || error) };
            }

            let legacyHydration;
            try {
              legacyHydration = await migrateHistoricalHydrationStateOnce();
            } catch (error) {
              console.error("[清柳 persistence] 历史聚合状态恢复失败，已隔离；正式 IndexedDB 继续启动。", error);
              legacyHydration = { completed: false, outcome: "failed-nonfatal", issues: [{ source: "legacy", code: "unexpected", detail: String(error?.message || error) }] };
            }
            return Object.freeze({ internalContinuity, legacyHydration });
          })();
        }
        return hydrationContinuityPromise;
      }

      async function runContinuityMigrations() {
        let stage = "continuity-inspection";
        try {
          await databaseReady;
          const { internalContinuity, legacyHydration } = await ensureHydrationContinuity();

          // 已完成的一次性迁移使用 marker 直接走热启动快路径。过去每次刷新后第一次打开
          // QQ/电话/音乐仍会做 17 张表 count + 多轮迁移入口检查；这些工作对已迁移数据库没有业务价值。
          const settledMarkers = await db.persistenceMeta.bulkGet([
            LEGACY_BOOTSTRAP_MARKER,
            CHAT_TIMELINE_MIGRATION_KEY,
            MUSIC_STATE_MIGRATION_KEY,
            DATA_RELATION_MIGRATION_KEY,
            SCHEMA_FINGERPRINT_KEY
          ]);
          const settledFingerprint = settledMarkers[4]?.value;
          const hotPathRevision = Number(myPhoneConfig.persistence.dexieSchemaRevision);
          const canUseContinuityHotPath = settledMarkers.slice(0, 4).every((row) => row?.value?.completed === true)
            && Number(settledFingerprint?.schemaRevision) === hotPathRevision
            && settledFingerprint?.fingerprint === SCHEMA_FINGERPRINT;
          if (canUseContinuityHotPath) {
            const aggregateRecords = await db.themeState.bulkGet(PERSISTENCE_KEYS);
            const inheritedRecordVersions = Array.from(new Set(aggregateRecords
              .map((record) => typeof record?.version === "string" ? record.version : "")
              .filter(Boolean)));
            const hasAggregateData = aggregateRecords.some((record) => {
              const value = record?.value;
              return value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length > 0;
            });
            persistenceRuntime = Object.freeze({
              databaseName: db.name,
              installedVersion: db.verno,
              targetVersion: hotPathRevision,
              origin: QWQPersistenceContext.origin,
              protocol: QWQPersistenceContext.protocol,
              crossVersionGuaranteed: QWQPersistenceContext.crossVersionGuaranteed,
              continuityStatus: hasAggregateData ? "existing-data" : "empty-database",
              existingUserRecordCount: hasAggregateData ? 1 : 0,
              inheritedRecordVersions,
              countsBeforeRuntimeMigration: null,
              countsAfterRuntimeMigration: null,
              fingerprintMismatch: false,
              schemaMetadataError: null,
              internalContinuity,
              legacyHydration,
              legacyImport: settledMarkers[0].value,
              unifiedChatTimeline: settledMarkers[1].value,
              musicStateMigration: settledMarkers[2].value,
              dataRelations: settledMarkers[3].value,
              hotStart: true
            });
            return persistenceRuntime;
          }
          // 聊天、音乐与业务关系迁移不再属于首屏开库协议。它们由真正读取业务数据的
          // App 通过 continuityReady 串行取得所有权；主屏只等待正式聚合记录。
          // 连续性审计读取彼此独立，并行完成固定数量的 IndexedDB 请求。
          const [countsBeforeRuntimeMigration, aggregateRecordsBeforeMigration, previous, relationMarkerBefore] = await Promise.all([
            snapshotUserTableCounts(),
            db.themeState.bulkGet(PERSISTENCE_KEYS),
            db.persistenceMeta.get(SCHEMA_FINGERPRINT_KEY),
            db.persistenceMeta.get(DATA_RELATION_MIGRATION_KEY)
          ]);
          const existingAggregateRecords = aggregateRecordsBeforeMigration.filter((record) => {
            const value = record?.value;
            if (!value || typeof value !== "object" || Array.isArray(value)) return false;
            if (record.key === "profile") {
              return Boolean(value.activeMaskPresetId)
                || Object.keys(value).some((key) => key !== "activeMaskPresetId");
            }
            return Object.keys(value).some((key) => key !== "appVersion");
          });
          const inheritedRecordVersions = Array.from(new Set(existingAggregateRecords
            .map((record) => typeof record?.version === "string" ? record.version : "")
            .filter(Boolean)));

          // schema 契约元数据与用户数据分表；检查/写入元数据不会再污染 themeState。
          const previousFingerprint = previous?.value?.fingerprint || null;
          const previousRevision = Number(previous?.value?.schemaRevision);
          const currentRevision = Number(myPhoneConfig.persistence.dexieSchemaRevision);
          const fingerprintMismatch = Number.isFinite(previousRevision)
            && previousRevision === currentRevision
            && previousFingerprint
            && previousFingerprint !== SCHEMA_FINGERPRINT;
          if (fingerprintMismatch) {
            // 指纹只用于诊断开发分支是否误复用 revision。用户可能已经打开过同 revision
            // 的另一分支；物理数据库成功打开后，不得因为诊断元数据阻断旧数据读取。
            console.warn(`[清柳 persistence] schema 指纹与同 revision 历史分支不同（${currentRevision}），已按实际 IndexedDB 结构继续。`);
          }

          let schemaMetadataError = null;
          try {
            await db.persistenceMeta.put({
              key: SCHEMA_FINGERPRINT_KEY,
              value: {
                fingerprint: SCHEMA_FINGERPRINT,
                schemaRevision: currentRevision,
                checkedAt: Date.now()
              },
              updatedAt: Date.now()
            });
          } catch (error) {
            schemaMetadataError = String(error?.message || error);
            console.warn("[清柳 persistence] schema 诊断元数据写入失败；不影响正式数据读取。", error);
          }

          let legacyImport;
          try {
            // 聚合状态已经在首屏前完成；这里才恢复联系人、聊天、媒体等业务大表。
            legacyImport = await migrateHistoricalLocalStorageOnce();
          } catch (error) {
            console.error("[清柳 persistence] 历史业务数据恢复失败，已隔离；正式 IndexedDB 保持可用。", error);
            legacyImport = { completed: false, outcome: "failed-nonfatal", issues: [{ source: "legacy", code: "unexpected", detail: String(error?.message || error) }] };
          }

          let unifiedChatTimeline;
          try {
            // Historical import may have just restored untagged messages. Tag them in
            // place in the canonical chatMessages table; no duplicate stores or copies.
            unifiedChatTimeline = await migrateUnifiedChatTimelineOnce();
          } catch (error) {
            console.error("[清柳 persistence] 统一聊天时间线迁移失败；原始消息保持不变。", error);
            unifiedChatTimeline = { completed: false, outcome: "failed-nonfatal", error: String(error?.message || error) };
          }

          let musicStateMigration;
          try {
            // 历史恢复可能刚把旧 profile.music* 字段救回；随后一次性搬回独立 musicState。
            musicStateMigration = await migrateMusicStateFromProfileOnce();
          } catch (error) {
            console.error("[清柳 persistence] 音乐状态迁移失败；旧 profile 字段保持原样，未删除。", error);
            musicStateMigration = { completed: false, error: String(error?.message || error) };
          }

          let dataRelations;
          let relationMigrationSucceeded = false;
          try {
            dataRelations = await migrateDataRelationsOnce();
            relationMigrationSucceeded = true;
          } catch (error) {
            console.error("[清柳 persistence] 关系整理失败，已隔离；原始业务表仍按原样读取。", error);
            dataRelations = { completed: false, outcome: "failed-nonfatal", error: String(error?.message || error) };
          }

          // QQ 账号身份属于 QQ 数据域，不再阻塞系统首屏启动；由 QQ 模块初始化时执行并显式传播错误。
          // Shared Memory bootstrap 迁移不再属于 Theme continuity；Memory Repository 会在正式记忆读写前取得所有权。
          const relationMigrationRan = !relationMarkerBefore?.value?.completed && relationMigrationSucceeded;
          const runtimeMigrationRan = relationMigrationRan;
          const countsAfterRuntimeMigration = runtimeMigrationRan
            ? await snapshotUserTableCounts()
            : countsBeforeRuntimeMigration;
          if (runtimeMigrationRan) {
            assertNoUserTableRegression(countsBeforeRuntimeMigration, countsAfterRuntimeMigration, "startup migration");
          }
          const aggregateRecordsAfterMigration = await db.themeState.bulkGet(PERSISTENCE_KEYS);
          const aggregateCountAfterMigration = aggregateRecordsAfterMigration.filter((record) => {
            const value = record?.value;
            return value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length;
          }).length;
          const userRecordCountAfterMigration = Object.entries(countsAfterRuntimeMigration)
            .filter(([name]) => name !== "themeState")
            .reduce((sum, [, value]) => sum + Number(value || 0), aggregateCountAfterMigration);
          const continuityStatus = userRecordCountAfterMigration > 0 || inheritedRecordVersions.length
            ? "existing-data"
            : "empty-database";

          persistenceRuntime = Object.freeze({
            databaseName: db.name,
            installedVersion: db.verno,
            targetVersion: currentRevision,
            origin: QWQPersistenceContext.origin,
            protocol: QWQPersistenceContext.protocol,
            crossVersionGuaranteed: QWQPersistenceContext.crossVersionGuaranteed,
            continuityStatus,
            existingUserRecordCount: userRecordCountAfterMigration,
            inheritedRecordVersions,
            countsBeforeRuntimeMigration,
            countsAfterRuntimeMigration,
            fingerprintMismatch,
            schemaMetadataError,
            internalContinuity,
            legacyHydration,
            legacyImport,
            unifiedChatTimeline,
            musicStateMigration,
            dataRelations
          });
          return persistenceRuntime;
        } catch (error) {
          notePersistenceFatal(error, stage);
          throw error;
        }
      }

      let persistenceHydrated = false;
      const ready = (async () => {
        let stage = "database-ready";
        try {
          await databaseReady;
          stage = "hydration-continuity";
          await ensureHydrationContinuity();
          stage = "active-record-read";
          const activeRecord = await db.themeState.get("active");
          const stored = normalizeStoredState(activeRecord?.value);
          if (Object.keys(stored).length) Object.assign(state, stored);
          // 数据就绪与字体解码/网络加载彻底解耦：字体失败或很慢不能锁住全部 App。
          stage = "active-state-apply";
          await applyAllState({ waitForFont: false });
          persistenceHydrated = true;

        } catch (error) {
          persistenceHydrated = false;
          notePersistenceFatal(error, stage);
          throw error;
        }
      })();

      let continuityPromise = null;
      function ensureContinuityReady() {
        if (!continuityPromise) {
          // ready 先提交首屏主题与主屏布局。之后同一页面的所有业务 App 共享这一条
          // 迁移 Promise，禁止并发跑两套关系扫描或重复占用 Edge 的写事务队列。
          continuityPromise = (async () => {
            await ready;
            return runContinuityMigrations();
          })();
        }
        return continuityPromise;
      }

      let drawerClosePending = false;
      let drawerCloseTimer = 0;
      let drawerOpenRevision = 0;

      function clearDrawerCloseTimer() {
        if (!drawerCloseTimer) return;
        window.clearTimeout(drawerCloseTimer);
        drawerCloseTimer = 0;
      }

      function emitDrawerClosed(type, reason = "close") {
        if (!type) return;
        document.dispatchEvent(new CustomEvent("qwq:global-drawer-closed", { detail: { type, reason } }));
      }

      function finalizeDrawerClose() {
        if (!drawerClosePending || drawerOverlay.classList.contains("is-open")) return;
        const closedType = state.drawerType;
        clearDrawerCloseTimer();
        drawerClosePending = false;
        drawerOverlay.classList.remove("is-mounted");
        drawerOverlay.setAttribute("aria-hidden", "true");
        drawer.classList.remove("is-dragging");
        drawer.style.removeProperty("--global-drawer-drag-offset");
        drawerBody.replaceChildren();
        drawerTitle.textContent = "";
        delete drawer.dataset.type;
        state.drawerType = null;
        emitDrawerClosed(closedType);
      }



      // Focus contract for the single global overlay system.
      // The browser resizes the layout viewport for the soft keyboard; the active overlay only
      // needs to keep its focused control inside its own scroll host.
      let overlayFocusVisibilityFrame = 0;
      function activeOverlayScrollHost() {
        const active = document.activeElement;
        if (!(active instanceof HTMLElement)) return null;
        if (modalOverlay.classList.contains("is-open") && modalContent?.contains(active)) return modalContent;
        if (drawerOverlay.classList.contains("is-open") && drawerBody.contains(active)) return drawerBody;
        return null;
      }

      function keepGlobalOverlayFocusedControlVisible() {
        overlayFocusVisibilityFrame = 0;
        const scrollHost = activeOverlayScrollHost();
        const active = document.activeElement;
        if (!scrollHost || !(active instanceof HTMLElement)) return;
        const hostRect = scrollHost.getBoundingClientRect();
        const targetRect = active.getBoundingClientRect();
        const inset = 12;
        if (targetRect.bottom > hostRect.bottom - inset) {
          scrollHost.scrollTop += targetRect.bottom - hostRect.bottom + inset;
        } else if (targetRect.top < hostRect.top + inset) {
          scrollHost.scrollTop -= hostRect.top + inset - targetRect.top;
        }
      }

      function scheduleGlobalOverlayFocusedControlVisibility() {
        if (overlayFocusVisibilityFrame) return;
        overlayFocusVisibilityFrame = requestAnimationFrame(keepGlobalOverlayFocusedControlVisible);
      }

      const GlobalDrawer = {
        async open({ type, title, render }) {
          const revision = ++drawerOpenRevision;
          clearDrawerCloseTimer();
          drawerClosePending = false;
          if (state.drawerType && state.drawerType !== type) {
            const replacedType = state.drawerType;
            state.drawerType = null;
            emitDrawerClosed(replacedType, "replace");
          }
          state.drawerType = type;
          drawer.dataset.type = String(type || "");
          drawerTitle.textContent = title;
          drawerBody.scrollTop = 0;
          drawerBody.replaceChildren();
          drawer.classList.remove("is-dragging");
          drawer.style.removeProperty("--global-drawer-drag-offset");
          drawerOverlay.classList.add("is-mounted");
          drawerOverlay.classList.remove("is-open");
          drawerOverlay.setAttribute("aria-hidden", "true");

          try {
            await ready;
            if (revision !== drawerOpenRevision) return false;
            // Build drawer contents while the sheet is still translated off-screen.
            // Image-bearing drawers therefore never expose an empty first frame.
            await render();
            if (revision !== drawerOpenRevision) return false;
            window.QWQIcons?.hydrate(drawerBody);
            await window.QWQLifecycle?.waitForLocalImages?.(drawerBody);
            if (revision !== drawerOpenRevision) return false;
            drawerBody.scrollTop = 0;
            drawerOverlay.setAttribute("aria-hidden", "false");
            void drawerOverlay.offsetWidth;
            drawerOverlay.classList.add("is-open");
            document.dispatchEvent(new CustomEvent("qwq:global-drawer-opened", { detail: { type: state.drawerType } }));
            scheduleGlobalOverlayFocusedControlVisibility();
            return true;
          } catch (error) {
            if (revision === drawerOpenRevision) GlobalDrawer.close();
            throw error;
          }
        },

        close() {
          drawerOpenRevision += 1;
          if (!drawerOverlay.classList.contains("is-mounted")) {
            const closedType = state.drawerType;
            drawerBody.replaceChildren();
            drawerTitle.textContent = "";
            delete drawer.dataset.type;
            state.drawerType = null;
            emitDrawerClosed(closedType);
            return;
          }
          if (drawer.contains(document.activeElement)) document.activeElement.blur();
          drawerClosePending = true;
          drawerOverlay.classList.remove("is-open");
          drawerOverlay.setAttribute("aria-hidden", "true");
          clearDrawerCloseTimer();
          drawerCloseTimer = window.setTimeout(
            finalizeDrawerClose,
            cssTransitionDurationMs("--global-drawer-transition-duration", 280) + 80
          );
        }
      };



      drawer.addEventListener("transitionend", (event) => {
        if (event.target === drawer && event.propertyName === "transform") finalizeDrawerClose();
      });

      // 全局浮层属于触发它的 route。离开 route 时必须同步收口，不能让 QQ/联系人等
      // 抽屉继续 fixed 在新页面上，形成“半个 QQ 叠在主屏”的跨页面残影。
      document.addEventListener("qwq:route-will-change", (event) => {
        const from = String(event.detail?.from || "");
        const to = String(event.detail?.to || "");
        if (!from || !to || from === to) return;
        if (drawerOverlay.classList.contains("is-mounted")) GlobalDrawer.close();
        if (modalOverlay.classList.contains("is-mounted")) GlobalModal.close();
      });

      const scheduleOverlayFocusAfterFocus = () => {
        scheduleGlobalOverlayFocusedControlVisibility();
        window.setTimeout(scheduleGlobalOverlayFocusedControlVisibility, 40);
      };
      drawerBody.addEventListener("focusin", scheduleOverlayFocusAfterFocus, { passive:true });
      modalContent?.addEventListener("focusin", scheduleOverlayFocusAfterFocus, { passive:true });
      window.addEventListener("resize", scheduleGlobalOverlayFocusedControlVisibility, { passive:true });

      modal.addEventListener("transitionend", (event) => {
        if (event.target === modal && (event.propertyName === "transform" || event.propertyName === "opacity")) finalizeModalClose();
      });


      function renderThemeColorDrawer() {
        const buildColorSection = ({ title, colors, current, ariaPrefix, onApply }) => {
          const section = createSection(title);
          const grid = document.createElement("div");
          grid.className = "theme-color-grid";
          colors.forEach((color) => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "theme-color-swatch";
            button.style.setProperty("--swatch", color);
            button.classList.toggle("is-selected", current === color);
            button.setAttribute("aria-label", `${ariaPrefix} ${color}`);
            button.addEventListener("click", () => {
              onApply(color);
              renderThemeColorDrawerIntoCurrent();
            });
            grid.appendChild(button);
          });

          const customPicker = document.createElement("input");
          customPicker.type = "color";
          customPicker.className = "theme-hidden-input";
          customPicker.value = /^#[0-9A-F]{6}$/.test(current) ? current : colors[0];
          customPicker.setAttribute("aria-label", `选择自定义${ariaPrefix}`);

          const custom = document.createElement("button");
          custom.type = "button";
          custom.className = "theme-color-custom";
          custom.classList.toggle("is-selected", !colors.includes(current));
          custom.setAttribute("aria-label", `添加自定义${ariaPrefix}`);
          appendIcon(custom, "plus");
          custom.addEventListener("click", () => customPicker.click());
          customPicker.addEventListener("input", () => onApply(customPicker.value));
          customPicker.addEventListener("change", () => renderThemeColorDrawerIntoCurrent());
          grid.append(custom, customPicker);
          appendSectionContent(section, grid);
          return section;
        };

        const colorSection = buildColorSection({
          title: "主题色",
          colors: THEME_COLORS,
          current: state.themeColor,
          ariaPrefix: "主题色",
          onApply: applyThemeColor
        });

        const iconColorSection = buildColorSection({
          title: "图标色",
          colors: ICON_COLORS,
          current: state.iconColor,
          ariaPrefix: "图标色",
          onApply: applyIconColor
        });

        const textureSection = createSection("主题质感");
        const select = document.createElement("select");
        select.className = "native-select";
        select.setAttribute("aria-label", "选择主题质感");
        [
          ["default", "默认"],
          ["frosted", "磨砂"]
        ].forEach(([value, label]) => {
          const option = document.createElement("option");
          option.value = value;
          option.textContent = label;
          select.appendChild(option);
        });
        select.value = state.themeTexture;
        select.addEventListener("change", () => applyThemeTexture(select.value));
        appendSectionContent(textureSection, select);
        drawerBody.append(colorSection, iconColorSection, textureSection);
      }

      function renderThemeColorDrawerIntoCurrent() {
        if (state.drawerType !== "theme-color") return;
        drawerBody.replaceChildren();
        renderThemeColorDrawer();
      }

      function renderWallpaperDrawer() {
        const previewSection = createSection("主屏幕预览");
        const preview = document.createElement("div");
        preview.className = "wallpaper-preview";
        const previewImage = document.createElement("img");
        previewImage.className = "wallpaper-preview-image";
        previewImage.alt = "";
        previewImage.setAttribute("aria-hidden", "true");
        preview.appendChild(previewImage);
        previewImage.dataset.qwqMediaSlot = "theme:wallpaper:drawer-preview";
        void window.QWQMediaSurface?.setImage?.(previewImage, previewImage.dataset.qwqMediaSlot, state.wallpaper, {
          identity:state.wallpaper, hiddenWhenEmpty:true, alt:""
        });

        const actions = document.createElement("div");
        actions.className = "ui-action-row";
        const add = createActionButton("添加壁纸", "image", "is-primary");
        const restore = createActionButton("还原壁纸", "rotate-left");
        add.addEventListener("click", () => wallpaperFileInput.click());
        restore.addEventListener("click", () => {
          state.selectedWallpaperId = null;
          applyWallpaper(null);
          renderWallpaperDrawerIntoCurrent();
        });
        actions.append(add, restore);
        appendSectionContent(previewSection, preview, actions);

        const { section: presetSection } = createPresetBlock({
          title: "壁纸预设",
          ariaLabel: "选择壁纸预设",
          items: state.wallpapers,
          selectedId: state.selectedWallpaperId,
          emptyLabel: "暂无预设",
          saveDisabled: !state.wallpaper,
          removeDisabled: !state.selectedWallpaperId,
          onChange: (event) => {
            const preset = state.wallpapers.find((item) => item.id === event.currentTarget.value);
            if (!preset) {
              state.selectedWallpaperId = null;
              schedulePersist();
              return;
            }
            state.selectedWallpaperId = preset.id;
            applyWallpaper(preset.blob);
            renderWallpaperDrawerIntoCurrent();
          },
          onSave: () => {
            if (!state.wallpaper) return;
            GlobalModal.prompt({
              title: "保存壁纸预设",
              message: "为当前主屏幕壁纸命名并保存。",
              inputPlaceholder: "输入壁纸预设名称",
              confirmLabel: "保存",
              action: "save-wallpaper-preset"
            });
          },
          onRemove: () => {
            const preset = state.wallpapers.find((item) => item.id === state.selectedWallpaperId);
            if (!preset) return;
            GlobalModal.confirm({
              title: "删除壁纸预设",
              message: `确认删除“${preset.name}”？`,
              confirmLabel: "删除",
              danger: true,
              action: "delete-wallpaper-preset"
            });
          }
        });
        drawerBody.append(previewSection, presetSection);
      }

      function renderWallpaperDrawerIntoCurrent() {
        if (state.drawerType !== "home-wallpaper") return;
        drawerBody.replaceChildren();
        renderWallpaperDrawer();
      }

      function renderIconDrawer() {
        const controlSection = createSection("图标外观");
        const controls = document.createElement("div");
        controls.className = "ui-control-list";
        controls.append(
          createRangeRow("图标圆角", state.iconRadius, 12, 50, 1, (value) => `${value}%`, (value) => {
            state.iconRadius = value;
            root.style.setProperty("--custom-icon-radius", `${value}%`);
            document.querySelectorAll(".icon-custom-preview").forEach((node) => node.style.borderRadius = `${value}%`);
            schedulePersist();
          }),
          createRangeRow("图标尺寸", state.iconScale, 75, 115, 1, (value) => `${value}%`, (value) => {
            state.iconScale = value;
            root.style.setProperty("--custom-icon-scale", String(value / 100));
            schedulePersist();
          })
        );
        appendSectionContent(controlSection, controls);

        const gridSection = createSection("图标定制");
        const selectionBar = document.createElement("div");
        selectionBar.className = "icon-custom-selection-bar";
        const selectionStatus = document.createElement("span");
        selectionStatus.className = "icon-custom-selection-status";
        const selectionActions = document.createElement("div");
        selectionActions.className = "icon-custom-selection-actions";
        const selectAll = createActionButton("全选", null, "is-compact");
        const clearSelection = createActionButton("清除", null, "is-compact");
        selectionActions.append(selectAll, clearSelection);
        selectionBar.append(selectionStatus, selectionActions);

        const grid = document.createElement("div");
        grid.className = "icon-custom-grid";
        const syncSelectionUi = () => {
          const count = selectedIconIds.size;
          selectionStatus.textContent = count ? `已选择 ${count} 个图标` : "可多选需要更换的图标";
          grid.querySelectorAll(".icon-custom-item").forEach((node) => {
            const selected = selectedIconIds.has(node.dataset.iconTargetId || "");
            node.classList.toggle("is-selected", selected);
            node.setAttribute("aria-pressed", selected ? "true" : "false");
          });
          replaceSelected.disabled = count === 0;
          clearSelection.disabled = count === 0;
          selectAll.disabled = count === myPhoneConfig.themeCustomization.appIconTargets.length;
        };

        myPhoneConfig.themeCustomization.appIconTargets.forEach((target) => {
          const button = document.createElement("button");
          button.type = "button";
          button.className = "icon-custom-item";
          button.dataset.iconTargetId = target.id;
          button.setAttribute("aria-label", `选择${myPhoneConfig.appNames[target.id]}图标`);
          button.setAttribute("aria-pressed", "false");

          const preview = document.createElement("span");
          preview.className = "icon-custom-preview";
          const custom = state.customIcons[target.id];
          if (custom) {
            const image = document.createElement("img");
            image.alt = "";
            image.dataset.themeCustomIconPreview = "true";
            preview.appendChild(image);
            void window.QWQMediaSurface?.setImage?.(image, themeMediaSlot(`icon-drawer-preview:${target.id}`), custom, {identity:custom,alt:""});
          } else {
            const source = document.querySelector(target.selector);
            if (source) preview.innerHTML = originalIcons.get(target.id) || source.innerHTML;
          }
          const check = document.createElement("span");
          check.className = "icon-custom-check";
          check.setAttribute("aria-hidden", "true");
          check.textContent = "✓";
          preview.appendChild(check);

          const name = document.createElement("span");
          name.className = "icon-custom-name";
          name.textContent = myPhoneConfig.appNames[target.id] || target.id;
          button.append(preview, name);
          button.addEventListener("click", () => {
            if (selectedIconIds.has(target.id)) selectedIconIds.delete(target.id);
            else selectedIconIds.add(target.id);
            syncSelectionUi();
          });
          grid.appendChild(button);
        });

        const replaceSelected = createActionButton("更换所选图标", "image", "is-wide");
        replaceSelected.addEventListener("click", () => {
          pendingIconIds = myPhoneConfig.themeCustomization.appIconTargets
            .map((target) => target.id)
            .filter((id) => selectedIconIds.has(id));
          if (!pendingIconIds.length) return;
          state.pendingIconId = pendingIconIds[0] || null;
          iconFileInput.click();
        });
        selectAll.addEventListener("click", () => {
          myPhoneConfig.themeCustomization.appIconTargets.forEach((target) => selectedIconIds.add(target.id));
          syncSelectionUi();
        });
        clearSelection.addEventListener("click", () => {
          selectedIconIds.clear();
          syncSelectionUi();
        });

        appendSectionContent(gridSection, selectionBar);
        appendSectionContent(gridSection, grid);
        appendSectionContent(gridSection, replaceSelected);

        const restore = createActionButton("还原所有图标", "rotate-left", "is-wide");
        restore.addEventListener("click", () => {
          state.customIcons = {};
          selectedIconIds.clear();
          pendingIconIds = [];
          applyIconState();
          renderIconDrawerIntoCurrent();
        });
        appendSectionContent(gridSection, restore);
        syncSelectionUi();
        drawerBody.append(controlSection, gridSection);
      }

      function renderIconDrawerIntoCurrent() {
        if (state.drawerType !== "icon-customization") return;
        drawerBody.replaceChildren();
        renderIconDrawer();
      }

      function renderFontDrawer() {
        const previewSection = createSection("字体预览");
        const preview = document.createElement("div");
        preview.className = "font-preview";
        const titleSample = document.createElement("div");
        titleSample.className = "font-preview-title";
        titleSample.textContent = "Theme.";
        const sample = document.createElement("div");
        sample.className = "font-preview-sample";
        sample.textContent = "Aa · 中文 / English";
        const note = document.createElement("small");
        note.textContent = "主标题尺寸与当前字重会同步显示在预览中 · 1234567890";
        preview.append(titleSample, sample, note);
        appendSectionContent(previewSection, preview);

        const controlSection = createSection("字体参数");
        const controls = document.createElement("div");
        controls.className = "ui-control-list";
        controls.append(
          createRangeRow("字体大小", state.fontSize, 80, 130, 1, (value) => `${value}%`, (value) => {
            state.fontSize = value;
            applyFontMetrics();
          }),
          createRangeRow("字重", state.fontWeight, 300, 700, 100, (value) => String(value), (value) => {
            state.fontWeight = value;
            applyFontMetrics();
          })
        );
        appendSectionContent(controlSection, controls);

        const { section: presetSection } = createPresetBlock({
          title: "字体预设",
          ariaLabel: "选择字体预设",
          items: state.fontPresets,
          selectedId: state.selectedPresetId,
          emptyLabel: "暂无预设",
          removeDisabled: !state.selectedPresetId,
          onChange: async (event) => {
            const preset = state.fontPresets.find((item) => item.id === event.currentTarget.value);
            if (!preset) {
              state.selectedPresetId = null;
              schedulePersist();
              return;
            }
            state.selectedPresetId = preset.id;
            state.fontSize = preset.size;
            state.fontWeight = preset.weight;
            applyFontMetrics(false);
            await applyFontSource(preset.source || null, false);
            schedulePersist();
            renderFontDrawerIntoCurrent();
          },
          onSave: () => {
            GlobalModal.prompt({
              title: "保存字体预设",
              message: "输入字体名后保存当前字体、字号与字重。",
              inputPlaceholder: "输入字体预设名称",
              confirmLabel: "保存",
              action: "save-font-preset"
            });
          },
          onRemove: () => {
            const preset = state.fontPresets.find((item) => item.id === state.selectedPresetId);
            if (!preset) return;
            GlobalModal.confirm({
              title: "删除字体预设",
              message: `确认删除“${preset.name}”？`,
              confirmLabel: "删除",
              danger: true,
              action: "delete-font-preset"
            });
          }
        });

        const sourceSection = createSection("字体来源");
        const sourceRow = document.createElement("div");
        sourceRow.className = "font-source-row";
        const localButton = document.createElement("button");
        localButton.type = "button";
        localButton.className = "font-local-button global-emphasis-shell";
        appendIcon(localButton, "folder-open");
        const localText = document.createElement("span");
        localText.textContent = "本地文件";
        localButton.appendChild(localText);
        localButton.addEventListener("click", () => fontFileInput.click());

        const urlControl = document.createElement("div");
        urlControl.className = "font-url-control";
        const urlInput = document.createElement("input");
        urlInput.className = "font-url-input";
        urlInput.type = "url";
        urlInput.inputMode = "url";
        urlInput.placeholder = "字体 URL（woff/woff2/ttf）";
        if (state.fontSource?.type === "url") urlInput.value = state.fontSource.value;
        const urlApply = document.createElement("button");
        urlApply.type = "button";
        urlApply.className = "font-url-apply";
        urlApply.setAttribute("aria-label", "应用字体 URL");
        appendIcon(urlApply, "font");
        urlApply.addEventListener("click", async () => {
          const url = urlInput.value.trim();
          if (!url) return;
          state.selectedPresetId = null;
          if (await applyFontSource({ type: "url", value: url })) renderFontDrawerIntoCurrent();
        });
        urlControl.append(urlInput, urlApply);
        sourceRow.append(localButton, urlControl);
        appendSectionContent(sourceSection, sourceRow);

        const restore = createActionButton("还原字体", "rotate-left", "is-wide");
        restore.addEventListener("click", async () => {
          state.fontSource = null;
          state.fontSize = myPhoneConfig.themeCustomization.fontSizeDefault;
          state.fontWeight = myPhoneConfig.themeCustomization.fontWeightDefault;
          state.selectedPresetId = null;
          applyFontMetrics(false);
          await applyFontSource(null, false);
          schedulePersist();
          renderFontDrawerIntoCurrent();
        });
        appendSectionContent(sourceSection, restore);

        drawerBody.append(previewSection, controlSection, presetSection, sourceSection);
      }

      function renderFontDrawerIntoCurrent() {
        if (state.drawerType !== "font") return;
        drawerBody.replaceChildren();
        renderFontDrawer();
      }

      function renderInterfaceDisplayDrawer() {
        const displaySection = createSection("显示缩放");
        const controls = document.createElement("div");
        controls.className = "ui-control-list";
        controls.appendChild(
          createRangeRow("显示缩放", state.displayScale, 80, 120, 1, (value) => `${value}%`, (value) => applyDisplayScale(value))
        );
        appendSectionContent(displaySection, controls);
        drawerBody.appendChild(displaySection);
      }

      async function copyText(text) {
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(text);
          return;
        }
        const textarea = document.createElement("textarea");
        textarea.value = text;
        textarea.setAttribute("readonly", "");
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        textarea.remove();
      }

      function renderDeveloperDrawer() {
        const { section: presetSection } = createPresetBlock({
          title: "开发者预设",
          ariaLabel: "选择开发者预设",
          items: state.developerPresets,
          selectedId: state.selectedDeveloperPresetId,
          emptyLabel: "暂无预设",
          removeDisabled: !state.selectedDeveloperPresetId,
          onChange: (event) => {
            const preset = state.developerPresets.find((item) => item.id === event.currentTarget.value);
            if (!preset) {
              state.selectedDeveloperPresetId = null;
              schedulePersist();
              return;
            }
            state.selectedDeveloperPresetId = preset.id;
            applyDeveloperCss(preset.css || INITIAL_DEVELOPER_TEMPLATE);
            renderDeveloperDrawerIntoCurrent();
          },
          onSave: () => {
            GlobalModal.prompt({
              title: "保存开发者预设",
              message: "为当前全局样式变量命名并保存。",
              inputPlaceholder: "输入开发者预设名称",
              confirmLabel: "保存",
              action: "save-developer-preset"
            });
          },
          onRemove: () => {
            const preset = state.developerPresets.find((item) => item.id === state.selectedDeveloperPresetId);
            if (!preset) return;
            GlobalModal.confirm({
              title: "删除开发者预设",
              message: `确认删除“${preset.name}”？`,
              confirmLabel: "删除",
              danger: true,
              action: "delete-developer-preset"
            });
          }
        });

        const editorSection = createSection("样式输入");
        const textarea = document.createElement("textarea");
        textarea.className = "developer-textarea global-scroll";
        textarea.spellcheck = false;
        textarea.autocapitalize = "off";
        textarea.autocomplete = "off";
        textarea.value = state.developerCss || INITIAL_DEVELOPER_TEMPLATE;
        textarea.addEventListener("input", () => applyDeveloperCss(textarea.value));
        const editorHeading = editorSection.querySelector(".ui-section-title");
        editorHeading?.classList.add("has-fullscreen");
        editorHeading?.appendChild(TextEntryUI.createFullscreenButton(textarea, "样式输入"));
        appendSectionContent(editorSection, textarea);

        const actionsSection = createSection("样式操作");
        const actions = document.createElement("div");
        actions.className = "ui-action-row";
        const copy = createActionButton("复制初始模板", "copy", "global-emphasis-shell");
        const restore = createActionButton("还原初始样式", "rotate-left");
        copy.addEventListener("click", async () => {
          try { await copyText(INITIAL_DEVELOPER_TEMPLATE); } catch (error) { console.error(error); }
        });
        restore.addEventListener("click", () => {
          state.selectedDeveloperPresetId = null;
          applyDeveloperCss(INITIAL_DEVELOPER_TEMPLATE);
          renderDeveloperDrawerIntoCurrent();
        });
        actions.append(copy, restore);
        appendSectionContent(actionsSection, actions);
        drawerBody.append(presetSection, editorSection, actionsSection);
      }

      function renderDeveloperDrawerIntoCurrent() {
        if (state.drawerType !== "developer-mode") return;
        drawerBody.replaceChildren();
        renderDeveloperDrawer();
      }

      function byteSize(value, seen = new WeakSet()) {
        if (value === null || value === undefined) return 0;
        if (value instanceof Blob) return value.size;
        if (value instanceof ArrayBuffer) return value.byteLength;
        if (ArrayBuffer.isView(value)) return value.byteLength;
        if (typeof value === "string") return new Blob([value]).size;
        if (typeof value === "number" || typeof value === "boolean") return new Blob([String(value)]).size;
        if (Array.isArray(value)) return value.reduce((sum, item) => sum + byteSize(item, seen), 0);
        if (typeof value === "object") {
          if (seen.has(value)) return 0;
          seen.add(value);
          return Object.entries(value).reduce((sum, [key, item]) => sum + new Blob([key]).size + byteSize(item, seen), 0);
        }
        return 0;
      }

      function formatBytes(bytes) {
        const value = Number(bytes) || 0;
        if (value < 1024) return `${value} B`;
        if (value < 1024 * 1024) return `${(value / 1024).toFixed(value < 10240 ? 1 : 0)} KB`;
        return `${(value / (1024 * 1024)).toFixed(2)} MB`;
      }

      function calculateCacheStats() {
        const wallpaperBytes = byteSize(state.wallpaper) + byteSize(state.wallpapers);
        const iconBytes = byteSize(state.customIcons);
        const fontBytes = byteSize(state.fontSource) + byteSize(state.fontPresets.map((item) => item.source || null));
        const configSnapshot = serializableState();
        configSnapshot.wallpaper = null;
        configSnapshot.wallpapers = state.wallpapers.map(({ id, name }) => ({ id, name }));
        configSnapshot.customIcons = {};
        configSnapshot.fontSource = null;
        configSnapshot.fontPresets = state.fontPresets.map(({ id, name, size, weight }) => ({ id, name, size, weight }));
        const configBytes = byteSize(configSnapshot);
        return [
          { label: "壁纸缓存", bytes: wallpaperBytes, color: "#111111" },
          { label: "图标缓存", bytes: iconBytes, color: "#555555" },
          { label: "字体缓存", bytes: fontBytes, color: "#999999" },
          { label: "主题配置", bytes: configBytes, color: "#DDDDDD" }
        ];
      }

      function createCacheDistribution(stats, total, centerLabel = "缓存") {
        const visual = document.createElement("div");
        visual.className = "cache-visual";

        const totalLine = document.createElement("div");
        totalLine.className = "cache-total-line";
        const totalCopy = document.createElement("div");
        totalCopy.className = "cache-total-copy";
        const totalLabel = document.createElement("span");
        totalLabel.className = "cache-total-label";
        totalLabel.textContent = centerLabel;
        const totalNote = document.createElement("span");
        totalNote.className = "cache-total-note";
        totalNote.textContent = "当前持久化数据占比";
        totalCopy.append(totalLabel, totalNote);
        const totalValue = document.createElement("span");
        totalValue.className = "cache-total-value";
        totalValue.textContent = formatBytes(total);
        totalLine.append(totalCopy, totalValue);

        const meter = document.createElement("div");
        meter.className = "cache-meter";
        meter.setAttribute("role", "img");
        meter.setAttribute("aria-label", `${centerLabel}圆角矩形分布统计图`);
        stats.forEach((item) => {
          const percent = total ? item.bytes / total : 0;
          const segment = document.createElement("span");
          segment.className = "cache-meter-segment";
          segment.style.setProperty("--segment-color", item.color);
          segment.style.flexGrow = String(total ? Math.max(item.bytes, total * 0.02) : 1);
          segment.style.flexBasis = "0";
          segment.title = `${item.label} · ${formatBytes(item.bytes)} · ${(percent * 100).toFixed(1)}%`;
          meter.appendChild(segment);
        });

        visual.append(totalLine, meter);
        return visual;
      }

      function createCachePanel(stats, centerLabel = "缓存") {
        const total = stats.reduce((sum, item) => sum + item.bytes, 0);
        const panel = document.createElement("div");
        panel.className = "cache-preview";
        const distribution = createCacheDistribution(stats, total, centerLabel);
        const legend = document.createElement("div");
        legend.className = "cache-legend";
        stats.forEach((item) => {
          const row = document.createElement("div");
          row.className = "cache-legend-row";
          const dot = document.createElement("span");
          dot.className = "cache-dot";
          dot.style.setProperty("--dot", item.color);
          const name = document.createElement("span");
          name.className = "cache-legend-name";
          name.textContent = item.label;
          const value = document.createElement("span");
          value.className = "cache-legend-value";
          const percent = total ? ((item.bytes / total) * 100).toFixed(1) : "0.0";
          value.textContent = `${formatBytes(item.bytes)} · ${percent}%`;
          row.append(dot, name, value);
          legend.appendChild(row);
        });
        panel.append(distribution, legend);
        return panel;
      }

      async function renderThemeBackupDrawer() {
        const stats = calculateCacheStats();
        const previewSection = createSection("缓存统计");
        appendSectionContent(previewSection, createCachePanel(stats, "主题缓存"));

        const actionsSection = createSection("主题数据");
        const actions = document.createElement("div");
        actions.className = "ui-action-row";
        const exportButton = createActionButton("导出主题", "file-export", "is-primary");
        const importButton = createActionButton("导入主题", "file-import");
        exportButton.addEventListener("click", exportThemeBackup);
        importButton.addEventListener("click", () => themeImportFileInput.click());
        actions.append(exportButton, importButton);
        appendSectionContent(actionsSection, actions);
        drawerBody.append(previewSection, actionsSection);
      }

      async function renderThemeBackupDrawerIntoCurrent() {
        if (state.drawerType !== "theme-backup") return;
        drawerBody.replaceChildren();
        await renderThemeBackupDrawer();
      }

      async function exportThemeBackup() {
        await persistNow();
        if (window.HomeScreenManager?.persistNow) await window.HomeScreenManager.persistNow();
        const homeScreenState = window.HomeScreenManager?.getState?.()
          || (await db.homeScreenState.get("active"))?.value
          || null;
        const manifest = {
          format: "MobileDesktopThemeBackupZip",
          version: PERSISTENCE_VERSION,
          exportedAt: new Date().toISOString(),
          imagePersistence: "indexeddb-blob",
          binaryAssets: "zip-raw-v1",
          includes: ["themeState", "homeScreenState"]
        };
        const files = { "manifest.json": JSON.stringify(manifest, null, 2) };
        const encodedPayload = await encodeBinaryForZip({
          themeState: serializableState(),
          homeScreenState
        }, files);
        files["theme-state.json"] = JSON.stringify(encodedPayload.themeState, null, 2);
        files["home-screen-state.json"] = JSON.stringify(encodedPayload.homeScreenState, null, 2);
        const blob = ZipArchive.create(files);
        window.QWQFileDownload.saveBlob(blob, `清柳+主题备份+${PERSISTENCE_VERSION}.zip`);
      }

      async function importThemeBackupFile(file) {
        const files = await ZipArchive.read(file);
        const manifest = JSON.parse(ZipArchive.text(files, "manifest.json"));
        const encodedState = JSON.parse(ZipArchive.text(files, "theme-state.json"));
        if (manifest?.format !== "MobileDesktopThemeBackupZip" || !encodedState || typeof encodedState !== "object") {
          throw new Error("invalid theme backup");
        }
        const importedState = await decodeBinaryFromZip(encodedState, files);
        if (containsEmbeddedImageData(importedState)) throw new Error("unsupported embedded image data");

        let importedHomeState = null;
        if (files["home-screen-state.json"]) {
          const encodedHomeState = JSON.parse(ZipArchive.text(files, "home-screen-state.json"));
          importedHomeState = await decodeBinaryFromZip(encodedHomeState, files);
          if (containsEmbeddedImageData(importedHomeState)) throw new Error("unsupported embedded image data");
          if (importedHomeState !== null) {
            if (!window.HomeScreenManager?.prepareImportedState || !window.HomeScreenManager?.importState) {
              throw new Error("home screen import unavailable");
            }
            window.HomeScreenManager.prepareImportedState(importedHomeState);
          }
        }

        const activeDrawer = state.drawerType;
        Object.assign(state, createDefaultState(), normalizeStoredState(importedState));
        state.drawerType = activeDrawer;
        await applyAllState();
        await persistNow();
        if (importedHomeState) await window.HomeScreenManager.importState(importedHomeState);
      }

      function confirmThemeRestoreDefaults() {
        GlobalModal.confirm({
          title: "还原默认",
          message: "将清除当前主题定制、预设、壁纸、图标、字体与开发者样式，并恢复初始主题。",
          confirmLabel: "还原",
          cancelLabel: "取消",
          danger: true,
          action: async () => {
            const activeDrawer = state.drawerType;
            Object.assign(state, createDefaultState());
            state.drawerType = activeDrawer;
            await applyAllState();
            await persistNow();
            if (activeDrawer === "theme-backup") await renderThemeBackupDrawerIntoCurrent();
            return true;
          }
        });
      }

      async function confirmModalAction() {
        const action = state.modalAction;
        if (typeof action === "function") {
          if (modalActionRunning) return;
          const revision = modalOpenRevision;
          modalActionRunning = true;
          modalConfirm.disabled = true;
          modalCancel.disabled = true;
          try {
            const shouldClose = await action({ input: modalInput, content: modalExtra });
            // action 内若打开了新的弹窗，旧 action 绝不能把新弹窗一起关掉。
            if (revision !== modalOpenRevision) return;
            if (shouldClose !== false) GlobalModal.close();
          } finally {
            if (revision === modalOpenRevision && modalOverlay.classList.contains("is-open")) {
              modalActionRunning = false;
              modalConfirm.disabled = false;
              modalCancel.disabled = false;
            }
          }
          return;
        }
        if (action === "save-wallpaper-preset") {
          const name = modalInput.value.trim();
          if (!name || !state.wallpaper) {
            modalInput.placeholder = "请输入壁纸预设名称";
            return;
          }
          const preset = {
            id: `wallpaper-preset-${Date.now()}`,
            name,
            blob: state.wallpaper
          };
          state.wallpapers.push(preset);
          state.selectedWallpaperId = preset.id;
          await persistNow();
          GlobalModal.close();
          renderWallpaperDrawerIntoCurrent();
          return;
        }
        if (action === "delete-wallpaper-preset") {
          state.wallpapers = state.wallpapers.filter((preset) => preset.id !== state.selectedWallpaperId);
          state.selectedWallpaperId = null;
          await persistNow();
          GlobalModal.close();
          renderWallpaperDrawerIntoCurrent();
          return;
        }
        if (action === "save-font-preset") {
          const name = modalInput.value.trim();
          if (!name) {
            modalInput.placeholder = "请输入字体预设名称";
            return;
          }
          const preset = {
            id: `font-preset-${Date.now()}`,
            name,
            source: state.fontSource ? { ...state.fontSource } : null,
            size: state.fontSize,
            weight: state.fontWeight
          };
          state.fontPresets.push(preset);
          state.selectedPresetId = preset.id;
          await persistNow();
          GlobalModal.close();
          renderFontDrawerIntoCurrent();
          return;
        }
        if (action === "delete-font-preset") {
          state.fontPresets = state.fontPresets.filter((preset) => preset.id !== state.selectedPresetId);
          state.selectedPresetId = null;
          await persistNow();
          GlobalModal.close();
          renderFontDrawerIntoCurrent();
          return;
        }
        if (action === "save-developer-preset") {
          const name = modalInput.value.trim();
          if (!name) {
            modalInput.placeholder = "请输入开发者预设名称";
            return;
          }
          const preset = {
            id: `developer-preset-${Date.now()}`,
            name,
            css: state.developerCss || INITIAL_DEVELOPER_TEMPLATE
          };
          state.developerPresets.push(preset);
          state.selectedDeveloperPresetId = preset.id;
          await persistNow();
          GlobalModal.close();
          renderDeveloperDrawerIntoCurrent();
          return;
        }
        if (action === "delete-developer-preset") {
          state.developerPresets = state.developerPresets.filter((preset) => preset.id !== state.selectedDeveloperPresetId);
          state.selectedDeveloperPresetId = null;
          await persistNow();
          GlobalModal.close();
          renderDeveloperDrawerIntoCurrent();
          return;
        }
        GlobalModal.close();
      }

      drawerOverlay.addEventListener("click", (event) => {
        if (event.target === drawerOverlay) GlobalDrawer.close();
      });

      let drawerDragStartY = null;
      let drawerDragOffset = 0;
      let drawerDragging = false;
      let drawerDragPointerId = null;
      let drawerDragStartedOnHeader = false;
      let drawerDragPaintRaf = 0;
      let drawerDragPendingOffset = 0;

      function paintDrawerDrag(offset) {
        drawerDragPendingOffset = offset;
        if (drawerDragPaintRaf) return;
        drawerDragPaintRaf = requestAnimationFrame(() => {
          drawerDragPaintRaf = 0;
          drawer.style.setProperty("--global-drawer-drag-offset", `${drawerDragPendingOffset}px`);
        });
      }

      function resetDrawerDrag() {
        if (drawerDragPointerId !== null && drawer.hasPointerCapture?.(drawerDragPointerId)) {
          drawer.releasePointerCapture(drawerDragPointerId);
        }
        if (drawerDragPaintRaf) cancelAnimationFrame(drawerDragPaintRaf);
        drawerDragPaintRaf = 0;
        drawerDragPendingOffset = 0;
        drawerDragStartY = null;
        drawerDragOffset = 0;
        drawerDragging = false;
        drawerDragPointerId = null;
        drawerDragStartedOnHeader = false;
        drawer.classList.remove("is-dragging");
        drawer.style.removeProperty("--global-drawer-drag-offset");
      }

      drawer.addEventListener("pointerdown", (event) => {
        if (!drawerOverlay.classList.contains("is-open")) return;
        if (event.pointerType === "mouse" && event.button !== 0) return;
        if (event.target.closest("input, select, textarea, button, a, [contenteditable], .global-range")) return;
        drawerDragStartedOnHeader = Boolean(event.target.closest(".global-drawer-header"));
        if (!drawerDragStartedOnHeader && drawerBody.scrollTop > 0) return;
        drawerDragStartY = event.clientY;
        drawerDragOffset = 0;
        drawerDragging = false;
        drawerDragPointerId = event.pointerId;
        // 不在 pointerdown 抢捕获。Edge 会把普通点击错误地留给 drawer，导致内部可点击项失效。
      });

      drawer.addEventListener("pointermove", (event) => {
        if (drawerDragStartY === null || event.pointerId !== drawerDragPointerId) return;
        const delta = event.clientY - drawerDragStartY;
        if (delta <= 0) return;
        if (!drawerDragging && !drawerDragStartedOnHeader && drawerBody.scrollTop > 0) {
          resetDrawerDrag();
          return;
        }
        // 只有形成明确下拉（8px）才进入 drag，并在此时捕获指针。
        // 轻触/点击保持浏览器原生命中链，不再被手势层劫持。
        if (!drawerDragging && delta < 8) return;
        if (!drawerDragging) {
          drawerDragging = true;
          try { drawer.setPointerCapture?.(event.pointerId); } catch (error) { console.error("drawer pointer capture failed", error); }
        }
        drawerDragOffset = delta;
        drawer.classList.add("is-dragging");
        // 高频指针事件只保留最新位移；每个显示帧最多提交一次 transform 变量。
        paintDrawerDrag(delta);
        if (event.cancelable) event.preventDefault();
      });

      const finishDrawerDrag = (event) => {
        if (drawerDragStartY === null || event.pointerId !== drawerDragPointerId) return;
        const threshold = Number.parseFloat(getComputedStyle(root).getPropertyValue("--global-drawer-close-threshold"));
        const shouldClose = drawerDragging && drawerDragOffset >= threshold;
        resetDrawerDrag();
        if (shouldClose) GlobalDrawer.close();
      };
      drawer.addEventListener("pointerup", finishDrawerDrag);
      drawer.addEventListener("pointercancel", finishDrawerDrag);

      modalCancel.addEventListener("click", () => GlobalModal.cancel());
      modalConfirm.addEventListener("click", confirmModalAction);
      modalVoiceInput?.addEventListener("click", () => startVoiceFill(modalInput, modalVoiceInput));
      modalInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") confirmModalAction();
      });
      document.addEventListener("keydown", (event) => {
        if (event.key !== "Escape") return;
        if (modalOverlay.classList.contains("is-open")) {
          GlobalModal.cancel();
        } else if (drawerOverlay.classList.contains("is-open")) {
          GlobalDrawer.close();
        }
      });

      wallpaperFileInput.addEventListener("change", async () => {
        const file = wallpaperFileInput.files?.[0];
        wallpaperFileInput.value = "";
        if (!file) return;
        try {
          const imageBlob = await prepareImageBlob(file, { maxSide: 2160, quality: .9 });
          state.selectedWallpaperId = null;
          applyWallpaper(imageBlob);
          renderWallpaperDrawerIntoCurrent();
        } catch (error) {
          console.error("wallpaper image processing failed", error);
          GlobalModal.alert({
            title: "壁纸无法使用",
            message: error?.message || "图片处理失败，请换一张图片重试。",
            confirmLabel: "知道了",
            action: "dismiss"
          });
        }
      });

      iconFileInput.addEventListener("change", async () => {
        const files = Array.from(iconFileInput.files || []);
        iconFileInput.value = "";
        const targetIds = pendingIconIds.length
          ? [...pendingIconIds]
          : (state.pendingIconId ? [state.pendingIconId] : []);
        pendingIconIds = [];
        state.pendingIconId = null;
        if (!files.length || !targetIds.length) return;
        if (files.length !== 1 && files.length !== targetIds.length) {
          GlobalModal.alert({
            title: "图标数量不匹配",
            message: `当前选择了 ${targetIds.length} 个 App。请选择 1 张图片批量应用，或选择 ${targetIds.length} 张图片按顺序一一替换。`,
            confirmLabel: "知道了",
            action: "dismiss"
          });
          return;
        }
        try {
          const prepared = [];
          for (const file of files) {
            prepared.push(await prepareImageBlob(file, {
              maxBytes: QWQ_IMAGE_MAX_BYTES,
              quality: .9,
              preserveDimensions: true,
              preserveAlpha: true
            }));
          }
          targetIds.forEach((targetId, index) => {
            const imageBlob = prepared.length === 1 ? prepared[0] : prepared[index];
            state.customIcons[targetId] = imageBlob;
            const target = myPhoneConfig.themeCustomization.appIconTargets.find((item) => item.id === targetId);
            if (target) setIconContent(target, imageBlob);
          });
          schedulePersist();
          renderIconDrawerIntoCurrent();
        } catch (error) {
          console.error("app icon image processing failed", error);
          GlobalModal.alert({
            title: "图标无法使用",
            message: error?.message || "图片处理失败，请换一张图片重试。",
            confirmLabel: "知道了",
            action: "dismiss"
          });
        }
      });

      fontFileInput.addEventListener("change", () => {
        const file = fontFileInput.files?.[0];
        fontFileInput.value = "";
        if (!file) return;
        const reader = new FileReader();
        reader.addEventListener("load", async () => {
          state.selectedPresetId = null;
          if (await applyFontSource({ type: "data", value: String(reader.result) })) renderFontDrawerIntoCurrent();
        });
        reader.readAsDataURL(file);
      });

      themeImportFileInput.addEventListener("change", async () => {
        const file = themeImportFileInput.files?.[0];
        themeImportFileInput.value = "";
        if (!file) return;
        try {
          await importThemeBackupFile(file);
          await renderThemeBackupDrawerIntoCurrent();
        } catch (error) {
          console.error(error);
          GlobalModal.alert({
            title: "导入失败",
            message: "主题 ZIP 备份无效、损坏或不是本页面导出的标准备份。",
            confirmLabel: "知道了",
            action: "dismiss"
          });
        }
      });

      async function openItem(itemId, itemName) {
        if (itemId === "restore-default") {
          confirmThemeRestoreDefaults();
          return true;
        }
        const renderers = {
          "theme-color": renderThemeColorDrawer,
          "home-wallpaper": renderWallpaperDrawer,
          "icon-customization": renderIconDrawer,
          "font": renderFontDrawer,
          "interface-display": renderInterfaceDisplayDrawer,
          "developer-mode": renderDeveloperDrawer,
          "theme-backup": renderThemeBackupDrawer
        };
        const render = renderers[itemId];
        if (!render) return false;
        await GlobalDrawer.open({ type: itemId, title: itemName, render });
        return true;
      }

      const DrawerUI = Object.freeze({
        createSection,
        appendSectionContent,
        createActionButton,
        createRangeRow,
        createPresetSelect,
        createPresetBlock,
        createCachePanel,
        calculateCacheStats,
        byteSize
      });

      return {
        build: String(PERSISTENCE_VERSION || "V0.0.231").replace(/^V/i, ""),
        openItem,
        ready,
        databaseReady,
        get continuityReady() { return ensureContinuityReady(); },
        db,
        GlobalDrawer,
        GlobalModal,
        TextEntryUI,
        DrawerUI,
        loadSettingsState,
        saveSettingsState,
        saveSettingsStateNow,
        loadProfileState,
        saveProfileStateNow,
        saveThemeStateNow: persistNow,
        encodeBinaryForZip,
        decodeBinaryFromZip,
        containsEmbeddedImageData,
        prepareImageBlob,
        prepareMediaBlob,
        materializeBlobForPersistence,
        imageAccept: QWQ_IMAGE_ACCEPT,
        chatMediaAccept: QWQ_CHAT_MEDIA_ACCEPT,
        imageMaxBytes: QWQ_IMAGE_MAX_BYTES,
        canonicalizePersistenceRecords,
        persistenceKeys: PERSISTENCE_KEYS,
        stripSystemOwnedDeveloperVariables,
        persistenceLayout: PERSISTENCE_LAYOUT,
        musicStateKeys: MUSIC_STATE_KEYS,
        settingsDefaults: SETTINGS_DEFAULTS,
        suppressHistoricalImport,
        migrateQqAccounts: (options) => migrateQqAccountsOnce(options),
        reconcileDataRelations: async () => {
          const relations = await migrateDataRelationsOnce({ force: true });
          const accounts = await migrateQqAccountsOnce({ force: true });
          return { relations, accounts };
        },
        getPersistenceRuntime: () => persistenceRuntime,
        getWallpaperPresets,
        getWallpaperPreset,
        applyHomeIconToShell
      };
    })();
window.ThemeCustomization = ThemeCustomization;