const MusicApp = (() => {
      const root = document.getElementById("page-music-app");
      if(!root) return Object.freeze({ open:()=>false, close:()=>false });

      // 搜索仅使用第三方兼容代理，不直连网易云官方搜索；播放页只在当前歌曲上按需请求歌词、红心数与评论。
      const SEARCH_API_BASES = Object.freeze([
        "https://zm.wwoyun.cn",
        "https://www.musicapi.cn",
        "https://zm.armoe.cn",
        "https://ncm.zhenxin.me",
        "https://ncmapi.btwoa.com"
      ]);
      const META_API_BASES = Object.freeze([
        "https://moefurina-neteasecloudmusicapienhanced.hf.space",
        ...SEARCH_API_BASES
      ]);
      const METING_API = "https://api.qijieya.cn/meting/";
      const NETEASE_RED_COUNT_API = "https://music.163.com/api/song/red/count";
      const NETEASE_RED_COUNT_READER = "https://r.jina.ai/https://music.163.com/api/song/red/count?songId=";
      const SEARCH_LIMIT = 20;
      const SEARCH_CACHE_TTL = 5 * 60 * 1000;
      const REQUEST_TIMEOUT = 4500;
      const SEARCH_REQUEST_TIMEOUT = 12000;
      const LIKED_PLAYLIST_ID = "music-liked-system";
      const DOWNLOADS_PLAYLIST_ID = "music-downloads-system";
      const PLAY_MODES = Object.freeze(["order","shuffle","repeat-one"]);
      const MUSIC_STATE_KEYS = ThemeCustomization.musicStateKeys;

      const audio = new Audio();
      audio.preload = "none";
      let currentView = "home";
      let playerReturnView = "home";
      let commentsReturnView = "player";
      let currentTrack = null;
      let playing = false;
      let playMode = "order";
      let filter = "all";
      let searchKeyword = "";
      let searchResults = [];
      let searchLoading = false;
      let searchError = "";
      let searchRequestId = 0;
      let searchController = null;
      let playbackRequestId = 0;
      let lastSearchRenderKey = "";
      let libraryHydrated = false;
      let libraryHydrating = null;
      let playStatsSplitReady = false;
      let library = { playlists: [], recent: [], followedArtists: [], playStats: { totalSeconds:0, days:{}, tracks:{} }, profile:{ nickname:"清柳 Listener", account:"listener", signature:"黑白之间，继续听。", avatar:"" } };
      let activeArtist = null;
      let activePlaylistId = "";
      let detailReturnView = "profile";
      let similarQueue = [];
      let selectedPlaybackDevice = "本机";
      let sleepTimer = 0;
      let sleepTimerDeadline = 0;
      const MUSIC_DETAIL_VIEWS = new Set(["artist","history","following","playlist","encyclopedia"]);
      const MUSIC_RETURNABLE_VIEWS = new Set(["home","search","profile","following","artist","history","playlist","encyclopedia","player"]);
      let listenSampleTrackId = "";
      let listenSampleTime = 0;
      let listenPersistAt = 0;
      let lyricsVisible = false;
      let activeLyricIndex = -1;
      let sheetOpen = false;
      let restoredPlaybackTime = 0;
      let playbackPersistAt = 0;
      let commentState = {};
      let musicSettings = { volume:1 };
      let commentReplyTarget = null;
      let commentReplyObserver = null;
      const commentReplyExpanded = new Set();
      const commentReplyHidden = new Set();
      const searchCache = new Map();
      const trackMetaCache = new Map();
      const artistInfoCache = new Map();
      let preferredSearchApiBase = SEARCH_API_BASES[0];

      const esc = (value)=>String(value ?? "").replace(/[&<>"']/g,(ch)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
      const uid = (prefix)=>`${prefix}-${globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,10)}`}`;
      let musicImageSurfaceId = 0;
      function musicSurfaceSlot(node,hint="image"){
        if(!node) return `music:${hint}:detached`;
        if(!node.dataset.musicMediaSlot) node.dataset.musicMediaSlot = `music:${hint}:${++musicImageSurfaceId}`;
        return node.dataset.musicMediaSlot;
      }
      function setMusicBackground(node,hint,source,{className=""}={}){
        if(!node) return Promise.resolve(false);
        return window.QWQMediaSurface?.setBackground?.(node,musicSurfaceSlot(node,hint),source,{identity:source,className,emptyValue:""}) || Promise.resolve(false);
      }
      function hydrateMusicImageSurfaces(scope=root){
        scope?.querySelectorAll?.("[data-music-image-source]").forEach((node)=>{
          const source=String(node.dataset.musicImageSource||"").trim();
          void setMusicBackground(node,node.dataset.musicImageHint||"template",source,{className:node.dataset.musicImageClass||""});
        });
      }
      const iconRefresh = ()=>{
        const drawerBody = sheetOpen ? document.getElementById("theme-drawer-body") : null;
        window.QWQIcons?.hydrate(root, drawerBody);
        hydrateMusicImageSurfaces(root);
        if(drawerBody) hydrateMusicImageSurfaces(drawerBody);
      };
      document.addEventListener("qwq:global-drawer-closed",(event)=>{
        if(event.detail?.type === "music") sheetOpen = false;
      });

      function formatDuration(seconds){
        const safe = Math.max(0, Math.floor(Number(seconds) || 0));
        const min = Math.floor(safe / 60);
        const sec = safe % 60;
        return `${String(min).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
      }

      function formatMetric(value){
        const n = Number(value);
        if(!Number.isFinite(n) || n < 0) return "--";
        if(n >= 100000000) return `${(n / 100000000).toFixed(n >= 1000000000 ? 0 : 1).replace(/\.0$/,'')}亿`;
        if(n >= 10000) return `${(n / 10000).toFixed(n >= 100000 ? 0 : 1).replace(/\.0$/,'')}万`;
        return String(Math.round(n));
      }

      function formatSocialMetric(value){
        if(value === null || value === undefined || value === "") return "--";
        const parsed = Number(value);
        if(!Number.isFinite(parsed) || parsed < 0) return "--";
        const n = Math.max(0,Math.floor(parsed));
        if(n >= 9990000) return "999w+";
        if(n >= 10000) return `${Math.min(999,Math.max(1,Math.floor(n / 10000)))}w+`;
        if(n >= 1000) return "999+";
        return String(n);
      }

      function formatListenDuration(seconds){
        const safe = Math.max(0,Math.floor(Number(seconds) || 0));
        if(safe < 60) return safe ? `${safe}s` : "0m";
        const hours = Math.floor(safe / 3600);
        const minutes = Math.floor((safe % 3600) / 60);
        if(hours >= 100) return `${hours}h`;
        if(hours) return `${hours}h ${minutes}m`;
        return `${Math.max(1,minutes)}m`;
      }

      function localDayKey(date=new Date()){
        const y = date.getFullYear();
        const m = String(date.getMonth()+1).padStart(2,"0");
        const d = String(date.getDate()).padStart(2,"0");
        return `${y}-${m}-${d}`;
      }

      function currentWeekDayKeys(){
        const now = new Date();
        const day = now.getDay() || 7;
        const monday = new Date(now.getFullYear(),now.getMonth(),now.getDate() - day + 1);
        const keys = [];
        for(let i=0;i<7;i++){
          const next = new Date(monday.getFullYear(),monday.getMonth(),monday.getDate()+i);
          if(next > now) break;
          keys.push(localDayKey(next));
        }
        return keys;
      }

      function primaryArtist(value){
        return String(value || "未知歌手").split(/\s*\/\s*|\s*[,&，、]\s*/)[0].trim() || "未知歌手";
      }

      function formatDateTime(value){
        const time = Number(value) || 0;
        if(!time) return "--";
        try{
          return new Intl.DateTimeFormat("zh-CN",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false}).format(new Date(time));
        }catch(error){ console.error("[Music] time format failed", error); return "--"; }
      }

      function normalizeMusicProfile(raw){
        const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
        const account = String(source.account || "listener").trim().replace(/^@+/,"") || "listener";
        return {
          nickname:String(source.nickname || "清柳 Listener").trim() || "清柳 Listener",
          account,
          signature:String(source.signature || "黑白之间，继续听。").trim() || "黑白之间，继续听。",
          avatar:String(source.avatar || "").trim()
        };
      }

      function normalizeArtist(raw){
        const name = primaryArtist(raw?.name ?? raw);
        if(!name) return null;
        return {
          name,
          cover:String(raw?.cover || "").trim(),
          avatar:String(raw?.avatar || raw?.picUrl || "").trim(),
          artistId:Number(raw?.artistId || raw?.id || 0) || 0,
          followedAt:Number(raw?.followedAt) || Date.now()
        };
      }

      function normalizePlayStats(raw){
        const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
        const days = {};
        for(const [key,value] of Object.entries(source.days || {})){
          if(/^\d{4}-\d{2}-\d{2}$/.test(key) && Number(value) > 0) days[key] = Math.max(0,Number(value) || 0);
        }
        const tracks = {};
        for(const [id,value] of Object.entries(source.tracks || {})){
          const track = normalizeTrack(value?.track || value);
          if(!track) continue;
          tracks[String(id)] = {
            track,
            playCount:Math.max(0,Math.floor(Number(value?.playCount) || 0)),
            seconds:Math.max(0,Number(value?.seconds) || 0),
            firstPlayedAt:Math.max(0,Number(value?.firstPlayedAt) || 0),
            lastPlayedAt:Math.max(0,Number(value?.lastPlayedAt) || 0)
          };
        }
        return { totalSeconds:Math.max(0,Number(source.totalSeconds) || 0), days, tracks };
      }

      function normalizeTrack(raw){
        const id = String(raw?.id ?? "").trim();
        if(!id) return null;
        const durationMs = Math.max(0, Number(raw?.durationMs ?? raw?.dt ?? 0) || 0);
        return {
          id,
          title:String(raw?.title ?? raw?.name ?? "未命名歌曲").trim() || "未命名歌曲",
          artist:String(raw?.artist ?? "未知歌手").trim() || "未知歌手",
          album:String(raw?.album ?? "未知专辑").trim() || "未知专辑",
          cover:String(raw?.cover ?? "").trim(),
          durationMs,
          time:durationMs ? formatDuration(durationMs / 1000) : String(raw?.time || "--:--"),
          src:String(raw?.src ?? "").trim(),
          artistId:Number(raw?.artistId ?? raw?.ar?.[0]?.id ?? raw?.artists?.[0]?.id ?? 0) || 0,
          popularity:Math.max(0, Number(raw?.popularity ?? raw?.pop ?? raw?.score ?? raw?.hotScore ?? 0) || 0)
        };
      }

      function normalizeLibrary(raw){
        const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
        const playlists = Array.isArray(source.playlists) ? source.playlists.map((item)=>{
          const songs = Array.isArray(item?.songs) ? item.songs.map(normalizeTrack).filter(Boolean) : [];
          return {
            id:String(item?.id || uid("music-playlist")),
            name:String(item?.name || "未命名歌单").trim() || "未命名歌单",
            system:item?.system === "liked" ? "liked" : "",
            cover:String(item?.cover || "").trim(),
            songs,
            createdAt:Number(item?.createdAt) || Date.now(),
            updatedAt:Number(item?.updatedAt) || Date.now()
          };
        }) : [];
        let liked = playlists.find((item)=>item.id === LIKED_PLAYLIST_ID || item.system === "liked");
        const regular = playlists.filter((item)=>item !== liked && item.id !== LIKED_PLAYLIST_ID);
        if(!liked){
          liked = { id:LIKED_PLAYLIST_ID, name:"我喜欢的音乐", system:"liked", cover:"", songs:[], createdAt:Date.now(), updatedAt:Date.now() };
        }else{
          liked.id = LIKED_PLAYLIST_ID;
          liked.name = "我喜欢的音乐";
          liked.system = "liked";
        }
        const recent = Array.isArray(source.recent) ? source.recent.map(normalizeTrack).filter(Boolean).slice(0,30) : [];
        const followedArtists = Array.isArray(source.followedArtists) ? source.followedArtists.map(normalizeArtist).filter(Boolean).filter((item,index,all)=>all.findIndex((other)=>other.name.toLocaleLowerCase("zh-CN") === item.name.toLocaleLowerCase("zh-CN")) === index).slice(0,100) : [];
        const playStats = normalizePlayStats(source.playStats);
        const profile = normalizeMusicProfile(source.profile);
        return { playlists:[liked,...regular], recent, followedArtists, playStats, profile };
      }

      function normalizePlaybackState(raw){
        const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
        const track = normalizeTrack(source.track);
        if(track) track.src = ""; // 音源地址可能过期；刷新后只恢复曲目信息，真正播放时重新解析。
        const mode = PLAY_MODES.includes(source.playMode) ? source.playMode : "order";
        return { track, currentTime:Math.max(0,Number(source.currentTime) || 0), playMode:mode };
      }

      function normalizeMusicSettings(raw){
        const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
        const volume = Number(source.volume);
        return { volume:Number.isFinite(volume) ? Math.max(0,Math.min(1,volume)) : 1 };
      }

      async function writeMusicState(key, value){
        await ThemeCustomization.databaseReady;
        await ThemeCustomization.db.musicState.put({ key:String(key), value, updatedAt:Date.now() });
        return true;
      }

      function normalizeCommentState(raw){
        const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
        const result = {};
        for(const [trackId,value] of Object.entries(source)){
          if(!trackId || !value || typeof value !== "object" || Array.isArray(value)) continue;
          const locals = Array.isArray(value.localComments) ? value.localComments.map((item)=>{
            const content = String(item?.content || "").trim();
            if(!content) return null;
            return {
              id:String(item?.id || uid("music-comment")),
              nickname:"我",
              content,
              time:Number(item?.time) || Date.now(),
              likedCount:Math.max(0,Number(item?.likedCount) || 0),
              parentId:String(item?.parentId || ""),
              replyToName:String(item?.replyToName || "")
            };
          }).filter(Boolean).slice(-200) : [];
          const likedIds = Array.isArray(value.likedIds) ? [...new Set(value.likedIds.map((id)=>String(id || "")).filter(Boolean))].slice(-500) : [];
          result[String(trackId)] = { localComments:locals, likedIds };
        }
        return result;
      }

      function commentBucket(trackId=currentTrack?.id){
        const id = String(trackId || "");
        if(!id) return { localComments:[], likedIds:[] };
        if(!commentState[id]) commentState[id] = { localComments:[], likedIds:[] };
        return commentState[id];
      }

      let playbackWriteQueue = Promise.resolve();
      function persistPlaybackState(force=false){
        if(!libraryHydrated || !currentTrack) return Promise.resolve();
        const now = Date.now();
        if(!force && now - playbackPersistAt < 3500) return Promise.resolve();
        playbackPersistAt = now;
        const clean = normalizeTrack(currentTrack);
        if(clean) clean.src = "";
        const snapshot = {
          track:clean,
          currentTime:Math.max(0,Number(audio.currentTime) || restoredPlaybackTime || 0),
          playMode,
          updatedAt:now
        };
        const run = ()=>writeMusicState(MUSIC_STATE_KEYS.playback, snapshot);
        const task = playbackWriteQueue.then(run,run);
        playbackWriteQueue = task.catch((error)=>{ console.error("[Music] playback persistence failed",error); });
        return task;
      }

      let commentWriteQueue = Promise.resolve();
      function persistCommentState(){
        if(!libraryHydrated) return Promise.resolve();
        const snapshot = JSON.parse(JSON.stringify(commentState));
        const run = ()=>writeMusicState(MUSIC_STATE_KEYS.comments, snapshot);
        const task = commentWriteQueue.then(run,run);
        commentWriteQueue = task.catch((error)=>{ console.error("[Music] comment persistence failed",error); });
        return task;
      }

      async function hydrateLibrary(){
        if(libraryHydrated) return library;
        if(libraryHydrating) return libraryHydrating;
        libraryHydrating = (async()=>{
          try{
            await ThemeCustomization.databaseReady;
            const [libraryRecord, statsRecord, commentRecord, playbackRecord, settingsRecord] = await ThemeCustomization.db.musicState.bulkGet([
              MUSIC_STATE_KEYS.library,
              MUSIC_STATE_KEYS.stats,
              MUSIC_STATE_KEYS.comments,
              MUSIC_STATE_KEYS.playback,
              MUSIC_STATE_KEYS.settings
            ]);
            library = normalizeLibrary(libraryRecord?.value);
            // V0.0.407: listening stats use an independent state key. Legacy library.playStats
            // remains the migration source until the dedicated key has been durably written.
            const hasSplitStats = Boolean(statsRecord?.value && typeof statsRecord.value === "object");
            const hasLegacyStats = Boolean(libraryRecord?.value && typeof libraryRecord.value === "object" && libraryRecord.value.playStats);
            if(hasSplitStats) library.playStats = normalizePlayStats(statsRecord.value);
            playStatsSplitReady = hasSplitStats || !hasLegacyStats;
            if(!playStatsSplitReady){
              try{
                await writeMusicState(MUSIC_STATE_KEYS.stats, JSON.parse(JSON.stringify(normalizePlayStats(library.playStats))));
                playStatsSplitReady = true;
              }catch(error){
                // Keep legacy stats inside the library snapshot until a later dedicated stats write succeeds.
                console.error("[Music] legacy playStats split migration failed", error);
              }
            }
            commentState = normalizeCommentState(commentRecord?.value);
            musicSettings = normalizeMusicSettings(settingsRecord?.value);
            audio.volume = musicSettings.volume;
            const restored = normalizePlaybackState(playbackRecord?.value);
            currentTrack = restored.track || null;
            restoredPlaybackTime = restored.currentTime;
            playMode = restored.playMode;
            audio.loop = playMode === "repeat-one";
            libraryHydrated = true;
            return library;
          }catch(error){
            console.error("[Music] state hydration failed; persistence writes remain blocked", error);
            throw error;
          }finally{
            libraryHydrating = null;
          }
        })();
        return libraryHydrating;
      }

      // 音乐运行期唯一数据源：同一个 MobileDesktopThemeDB.musicState 业务表。
      // library/stats/comments/playback/settings 分键写入；播放计时不能再每 8 秒序列化整个歌单库。
      function stableLibrarySnapshot(source=library){
        const snapshot = {
          playlists:JSON.parse(JSON.stringify(source.playlists || [])),
          recent:JSON.parse(JSON.stringify(source.recent || [])),
          followedArtists:JSON.parse(JSON.stringify(source.followedArtists || [])),
          profile:JSON.parse(JSON.stringify(source.profile || {}))
        };
        // If the one-time split write failed, retain the legacy field so a profile/playlist edit
        // cannot erase historical listening stats before the dedicated stats key exists.
        if(!playStatsSplitReady) snapshot.playStats = JSON.parse(JSON.stringify(normalizePlayStats(source.playStats)));
        return snapshot;
      }

      let libraryWriteQueue = Promise.resolve();
      function persistLibrary(){
        if(!libraryHydrated) return Promise.resolve(false);
        const snapshot = stableLibrarySnapshot();
        const run = ()=>writeMusicState(MUSIC_STATE_KEYS.library, snapshot);
        const task = libraryWriteQueue.then(run, run);
        libraryWriteQueue = task.catch((error)=>{ console.error("[Music] library persistence failed", error); });
        return task;
      }

      let statsWriteQueue = Promise.resolve();
      function persistPlayStats(){
        if(!libraryHydrated) return Promise.resolve(false);
        const snapshot = JSON.parse(JSON.stringify(normalizePlayStats(library.playStats)));
        const run = async()=>{
          await writeMusicState(MUSIC_STATE_KEYS.stats, snapshot);
          playStatsSplitReady = true;
          return true;
        };
        const task = statsWriteQueue.then(run, run);
        statsWriteQueue = task.catch((error)=>{ console.error("[Music] playStats persistence failed", error); });
        return task;
      }

      let settingsWriteQueue = Promise.resolve();
      function persistMusicSettings(){
        if(!libraryHydrated) return Promise.resolve(false);
        const snapshot = normalizeMusicSettings(musicSettings);
        const run = ()=>writeMusicState(MUSIC_STATE_KEYS.settings, snapshot);
        const task = settingsWriteQueue.then(run, run);
        settingsWriteQueue = task.catch((error)=>{ console.error("[Music] settings persistence failed", error); });
        return task;
      }

      function likedPlaylist(){
        let liked = library.playlists.find((item)=>item.id === LIKED_PLAYLIST_ID);
        if(!liked){
          liked = { id:LIKED_PLAYLIST_ID, name:"我喜欢的音乐", system:"liked", cover:"", songs:[], createdAt:Date.now(), updatedAt:Date.now() };
          library.playlists.unshift(liked);
        }
        return liked;
      }

      function downloadsPlaylist(){
        let downloads = library.playlists.find((item)=>item.id === DOWNLOADS_PLAYLIST_ID || item.system === "downloads");
        if(!downloads){
          downloads = { id:DOWNLOADS_PLAYLIST_ID, name:"本地与下载", system:"downloads", cover:"", songs:[], createdAt:Date.now(), updatedAt:Date.now() };
          library.playlists.push(downloads);
        }else{
          downloads.id = DOWNLOADS_PLAYLIST_ID;
          downloads.name = "本地与下载";
          downloads.system = "downloads";
        }
        return downloads;
      }

      function isTrackLiked(track){
        if(!track) return false;
        return likedPlaylist().songs.some((item)=>item.id === track.id);
      }

      async function toggleTrackLiked(track){
        if(!track) return false;
        const playlist = likedPlaylist();
        const index = playlist.songs.findIndex((item)=>item.id === track.id);
        if(index >= 0) playlist.songs.splice(index,1);
        else playlist.songs.unshift(normalizeTrack(track));
        playlist.updatedAt = Date.now();
        renderPlaylists();
        if(activePlaylistId === playlist.id) renderPlaylistPage();
        renderPlayer();
        await persistLibrary();
        return index < 0;
      }

      function parseSearchSongs(data){
        const songs = Array.isArray(data?.result?.songs) ? data.result.songs : [];
        return songs.slice(0,SEARCH_LIMIT).map((item)=>{
          const artists = Array.isArray(item?.ar) ? item.ar : Array.isArray(item?.artists) ? item.artists : [];
          const artist = artists.length ? artists.map((one)=>one?.name).filter(Boolean).join(" / ") : "未知歌手";
          const album = item?.al?.name || item?.album?.name || "未知专辑";
          return normalizeTrack({
            id:item?.id,
            title:item?.name,
            artist,
            album,
            cover:item?.al?.picUrl || item?.album?.picUrl || "",
            durationMs:item?.dt || item?.duration || 0,
            artistId:artists?.[0]?.id || 0,
            popularity:item?.pop || item?.score || 0
          });
        }).filter(Boolean);
      }

      async function fetchJson(url, parentSignal, timeout = REQUEST_TIMEOUT){
        const controller = new AbortController();
        const onAbort = ()=>controller.abort(parentSignal?.reason);
        if(parentSignal?.aborted) controller.abort(parentSignal.reason);
        else parentSignal?.addEventListener?.("abort",onAbort,{once:true});
        let timedOut = false;
        const timer = setTimeout(()=>{
          timedOut = true;
          controller.abort("timeout");
        },Math.max(1,Number(timeout) || REQUEST_TIMEOUT));
        try{
          const response = await fetch(url,{signal:controller.signal,cache:"no-store"});
          if(!response.ok) throw new Error(`HTTP_${response.status}`);
          return await response.json();
        }catch(error){
          // 代理自身超时必须继续尝试下一个候选；只有父级 signal 才代表用户取消搜索。
          if(timedOut && !parentSignal?.aborted) throw new Error("TIMEOUT");
          throw error;
        }finally{
          clearTimeout(timer);
          parentSignal?.removeEventListener?.("abort",onAbort);
        }
      }

      async function fetchText(url, parentSignal, timeout = REQUEST_TIMEOUT + 3500){
        const controller = new AbortController();
        const onAbort = ()=>controller.abort(parentSignal?.reason);
        if(parentSignal?.aborted) controller.abort(parentSignal.reason);
        else parentSignal?.addEventListener?.("abort",onAbort,{once:true});
        const timer = setTimeout(()=>controller.abort("timeout"),timeout);
        try{
          const response = await fetch(url,{signal:controller.signal,cache:"no-store"});
          if(!response.ok) throw new Error(`HTTP_${response.status}`);
          return await response.text();
        }finally{
          clearTimeout(timer);
          parentSignal?.removeEventListener?.("abort",onAbort);
        }
      }

      async function fetchFromBases(bases,path,signal){
        let lastError = null;
        for(const base of bases){
          if(signal?.aborted) throw new DOMException("Aborted","AbortError");
          try{
            return await fetchJson(`${base}${path}`,signal);
          }catch(error){
            if(error?.name === "AbortError") throw error;
            lastError = error;
          }
        }
        throw lastError || new Error("music_api_unavailable");
      }

      async function searchRemote(keyword, signal){
        let lastError = null;
        const encoded = encodeURIComponent(keyword);
        const orderedBases = [preferredSearchApiBase,...SEARCH_API_BASES]
          .filter((base,index,all)=>base && all.indexOf(base) === index);
        for(const path of ["cloudsearch","search"]){
          for(const base of orderedBases){
            if(signal?.aborted) throw new DOMException("Aborted","AbortError");
            try{
              const url = `${base}/${path}?keywords=${encoded}&limit=${SEARCH_LIMIT}&timestamp=${Date.now()}`;
              const parsed = parseSearchSongs(await fetchJson(url,signal,SEARCH_REQUEST_TIMEOUT));
              if(parsed.length){
                preferredSearchApiBase = base;
                return parsed;
              }
            }catch(error){
              if(error?.name === "AbortError") throw error;
              lastError = error;
            }
          }
        }
        if(lastError) throw lastError;
        return [];
      }

      function filteredSearchResults(){
        if(filter === "all" || filter === "song") return searchResults;
        const q = String(searchKeyword || "").toLocaleLowerCase("zh-CN");
        if(filter === "artist") return searchResults.filter((track)=>String(track?.artist || "").toLocaleLowerCase("zh-CN").includes(q));
        if(filter === "album") return searchResults.filter((track)=>String(track?.album || "").toLocaleLowerCase("zh-CN").includes(q));
        return searchResults;
      }

      // ---------- 搜索 UI ----------
      // 此前 index.html 的搜索框/结果容器/筛选按钮在 JS 侧零引用，搜索完全不可用。
      function localSearch(keyword){
        const q = String(keyword || "").trim().toLocaleLowerCase("zh-CN");
        if(!q) return [];
        const pool = [];
        (library?.recent || []).forEach((item)=>item && pool.push(item));
        (library?.queue || []).forEach((item)=>item && pool.push(item));
        (library?.liked || []).forEach((item)=>item && pool.push(item));
        (library?.playlists || []).forEach((pl)=>(pl?.songs || []).forEach((item)=>item && pool.push(item)));
        const seen = new Set();
        return pool.filter((track)=>{
          const id = String(track?.id ?? "");
          if(!id || seen.has(id)) return false;
          const hay = [track?.title, track?.artist, track?.album]
            .filter(Boolean).join(" ").toLocaleLowerCase("zh-CN");
          if(!hay.includes(q)) return false;
          seen.add(id);
          return true;
        });
      }

      function renderSearch(){
        const host = root?.querySelector("[data-music-search-results]");
        const stateNode = root?.querySelector("[data-music-search-state]");
        if(!host) return;
        if(searchLoading){
          if(stateNode) stateNode.textContent = "正在搜索…";
          host.innerHTML = '<div class="music-search-empty">正在搜索…</div>';
          return;
        }
        if(!String(searchKeyword || "").trim()){
          if(stateNode) stateNode.textContent = "输入关键词后按回车搜索";
          host.innerHTML = "";
          return;
        }
        const rows = filteredSearchResults();
        const fallbackNote = searchError === "remote-failed" ? " · 远端不可用，已用本地曲库"
          : searchError === "remote-empty" ? " · 远端无结果，已用本地曲库" : "";
        if(stateNode){
          stateNode.textContent = rows.length
            ? `找到 ${rows.length} 首${fallbackNote}`
            : `没有匹配结果${fallbackNote}`;
        }
        host.innerHTML = trackRows(rows);
      }

      async function runSearch(keyword){
        const next = String(keyword ?? "").trim();
        searchKeyword = next;
        if(searchController){ try{ searchController.abort(); }catch(_){} searchController = null; }
        if(!next){
          searchResults = [];
          searchError = "";
          searchLoading = false;
          lastSearchRenderKey = "";
          renderSearch();
          return [];
        }
        searchLoading = true;
        searchError = "";
        searchResults = [];
        const requestId = ++searchRequestId;
        const controller = new AbortController();
        searchController = controller;
        renderSearch();
        try{
          const parsed = await searchRemote(next, controller.signal);
          if(requestId !== searchRequestId) return searchResults;
          searchResults = parsed;
          if(!parsed.length){
            const local = localSearch(next);
            if(local.length){ searchResults = local; searchError = "remote-empty"; }
          }
        }catch(error){
          if(error?.name === "AbortError" || requestId !== searchRequestId) return searchResults;
          console.warn(TAG, "远端搜索不可用，回退本地曲库", error);
          searchResults = localSearch(next);
          searchError = "remote-failed";
        }finally{
          if(requestId === searchRequestId){
            searchLoading = false;
            if(searchController === controller) searchController = null;
            renderSearch();
          }
        }
        return searchResults;
      }

      function openSearch(keyword){
        setMusicView("search");
        openPanel("search");
        const input = root?.querySelector("[data-music-search-input]");
        if(input) input.value = String(keyword || "");
        void runSearch(keyword);
        return true;
      }

      function bindSearchUi(){
        const input = root?.querySelector("[data-music-search-input]");
        if(input && input.dataset.musicSearchBound !== "1"){
          input.dataset.musicSearchBound = "1";
          input.addEventListener("keydown",(event)=>{
            if(event.key !== "Enter") return;
            event.preventDefault();
            void runSearch(input.value);
          });
        }
        const clear = root?.querySelector("[data-music-search-clear]");
        if(clear && clear.dataset.musicSearchBound !== "1"){
          clear.dataset.musicSearchBound = "1";
          clear.addEventListener("click",()=>{
            if(input) input.value = "";
            void runSearch("");
            if(input) input.focus();
          });
        }
      }

      function trackRows(source,{allowAdd=false}={}){
        if(!source.length) return '<div class="music-search-empty">没有可显示的音乐</div>';
        return `<div class="music-track-list">${source.map((track,index)=>{
          const coverStyle = track.cover ? ` data-music-image-source="${esc(track.cover)}" data-music-image-hint="track-cover" data-music-image-class="has-cover"` : "";
          return `<div class="music-track-row" role="button" tabindex="0" data-music-song-id="${esc(track.id)}"><span class="music-track-cover${track.cover ? " has-cover" : ""}"${coverStyle}>${String(index + 1).padStart(2,"0")}</span><span class="music-track-copy"><span class="music-track-title">${esc(track.title)}</span><span class="music-track-artist">${esc(track.artist)} · ${esc(track.album)}</span></span>${allowAdd ? `<button class="music-track-action" type="button" data-music-add-song="${esc(track.id)}" aria-label="添加到歌单"><i class="fa-solid fa-plus music-fa-icon" aria-hidden="true"></i></button>` : `<span class="music-track-time">${esc(track.time)}</span>`}</div>`;
        }).join("")}</div>`;
      }

      function renderHome(){
        const host = root.querySelector("[data-music-home-list]");
        if(!host) return;
        const recent = library.recent.slice(0,5);
        host.classList.toggle("is-empty",!recent.length);
        host.innerHTML = recent.length
          ? trackRows(recent).replace(/^<div class="music-track-list">|<\/div>$/g,"")
          : '<div class="music-playlist-empty">播放过的歌曲会出现在这里</div>';
        hydrateMusicImageSurfaces(host);
      }

      function artistCacheKey(value){
        return primaryArtist(value).toLocaleLowerCase("zh-CN");
      }

      function cachedArtistInfo(name){
        const key = artistCacheKey(name);
        let info = artistInfoCache.get(key);
        if(!info){
          info = { name:primaryArtist(name), artistId:0, avatar:"", catalogTracks:[], followingCount:null, followersCount:null, loaded:false, loadedAt:0, loading:false, error:null, promise:null };
          artistInfoCache.set(key, info);
        }
        return info;
      }

      function artistFallbackAvatar(name, explicit=""){
        if(explicit) return explicit;
        const followed = library.followedArtists.find((item)=>artistCacheKey(item.name) === artistCacheKey(name));
        if(followed?.avatar) return followed.avatar;
        if(followed?.cover) return followed.cover;
        const covers = [...new Set([
          ...artistTracks(name).map((track)=>track.cover).filter(Boolean),
          ...library.recent.filter((track)=>artistCacheKey(track.artist) === artistCacheKey(name)).map((track)=>track.cover).filter(Boolean)
        ])];
        if(!covers.length) return "";
        const seed = [...artistCacheKey(name)].reduce((sum,ch)=>sum + ch.charCodeAt(0),0);
        return covers[seed % covers.length] || covers[0] || "";
      }

      function parseArtistCandidates(data){
        const source = Array.isArray(data?.result?.artists)
          ? data.result.artists
          : Array.isArray(data?.artists)
            ? data.artists
            : Array.isArray(data?.data?.artists)
              ? data.data.artists
              : [];
        return source.map((item)=>({
          id:Number(item?.id) || 0,
          name:primaryArtist(item?.name),
          avatar:String(item?.picUrl || item?.img1v1Url || item?.avatarUrl || item?.cover || "").replace(/^http:/i,"https:"),
          musicSize:Math.max(0, Number(item?.musicSize || item?.trackCount || 0) || 0)
        })).filter((item)=>item.name);
      }

      function normalizeArtistSongs(data,fallbackName="",fallbackArtistId=0){
        const songs = Array.isArray(data?.songs)
          ? data.songs
          : Array.isArray(data?.data?.songs)
            ? data.data.songs
            : Array.isArray(data?.result?.songs)
              ? data.result.songs
              : [];
        const seen = new Set();
        return songs.map((item)=>normalizeTrack({
          id:item?.id,
          title:item?.name,
          artist:Array.isArray(item?.ar)
            ? item.ar.map((one)=>one?.name).filter(Boolean).join(" / ")
            : Array.isArray(item?.artists)
              ? item.artists.map((one)=>one?.name).filter(Boolean).join(" / ")
              : fallbackName,
          album:item?.al?.name || item?.album?.name || "未知专辑",
          cover:item?.al?.picUrl || item?.album?.picUrl || item?.picUrl || "",
          durationMs:item?.dt || item?.duration || 0,
          artistId:item?.ar?.[0]?.id || item?.artists?.[0]?.id || fallbackArtistId,
          popularity:item?.pop || item?.score || item?.hot || item?.hotScore || 0
        })).filter((track)=>{
          if(!track || seen.has(track.id)) return false;
          if(fallbackName && artistCacheKey(track.artist) !== artistCacheKey(fallbackName)) return false;
          seen.add(track.id);
          return true;
        });
      }

      async function resolveArtistIdentity(name,artistIdHint=0){
        const clean = primaryArtist(name);
        if(!clean) return { artistId:0, avatar:"", name:"" };
        const encoded = encodeURIComponent(clean);
        let lastError = null;
        for(const base of SEARCH_API_BASES){
          try{
            const data = await fetchJson(`${base}/search?keywords=${encoded}&type=100&limit=8&timestamp=${Date.now()}`);
            const candidates = parseArtistCandidates(data);
            if(candidates.length){
              const needle = clean.toLocaleLowerCase("zh-CN");
              const best = candidates.find((item)=>item.name.toLocaleLowerCase("zh-CN") === needle)
                || candidates.find((item)=>item.name.toLocaleLowerCase("zh-CN").includes(needle) || needle.includes(item.name.toLocaleLowerCase("zh-CN")))
                || candidates[0];
              return { artistId:best.id || Number(artistIdHint) || 0, avatar:best.avatar || "", name:best.name || clean };
            }
          }catch(error){ lastError = error; }
        }
        if(lastError) console.warn("[Music] artist search failed",lastError);
        return { artistId:Number(artistIdHint) || 0, avatar:"", name:clean };
      }

      async function fetchArtistDetailAvatar(artistId){
        if(!(Number(artistId) > 0)) return "";
        const paths = [
          `/artist/detail?id=${encodeURIComponent(artistId)}&timestamp=${Date.now()}`,
          `/artists?id=${encodeURIComponent(artistId)}&timestamp=${Date.now()}`,
          `/artist?id=${encodeURIComponent(artistId)}&timestamp=${Date.now()}`
        ];
        for(const path of paths){
          try{
            const data = await fetchFromBases(META_API_BASES,path);
            const artist = data?.data?.artist || data?.artist || data?.artists?.[0] || data?.artists || {};
            const avatar = String(artist?.cover || artist?.picUrl || artist?.img1v1Url || artist?.avatarUrl || "").replace(/^http:/i,"https:");
            if(avatar) return avatar;
          }catch(error){ console.warn("[Music] artist avatar candidate failed",error); }
        }
        return "";
      }

      function firstArtistMetric(...values){
        for(const value of values){
          const number = Number(value);
          if(Number.isFinite(number) && number >= 0) return Math.floor(number);
        }
        return null;
      }

      function parseArtistSocialStats(payload){
        const data = payload?.data && typeof payload.data === "object" ? payload.data : payload || {};
        const artist = data?.artist || payload?.artist || {};
        const profile = data?.profile || data?.user?.profile || payload?.profile || payload?.user?.profile || artist?.profile || {};
        const followingCount = firstArtistMetric(
          data?.followCnt,
          data?.followCount,
          data?.follows,
          data?.followingCount,
          profile?.follows,
          profile?.followCount,
          artist?.follows,
          artist?.followCount
        );
        const followersCount = firstArtistMetric(
          data?.fansCnt,
          data?.fansCount,
          data?.followersCount,
          data?.followeds,
          data?.followedCount,
          profile?.followeds,
          profile?.followersCount,
          profile?.followedCount,
          artist?.fansCnt,
          artist?.fansCount,
          artist?.followersCount
        );
        return { followingCount, followersCount };
      }

      async function fetchArtistSocialStats(artistId){
        if(!(Number(artistId) > 0)) return { followingCount:null, followersCount:null };
        const paths = [
          `/artist/follow/count?id=${encodeURIComponent(artistId)}&timestamp=${Date.now()}`,
          `/artist/detail/dynamic?id=${encodeURIComponent(artistId)}&timestamp=${Date.now()}`,
          `/artist/detail?id=${encodeURIComponent(artistId)}&timestamp=${Date.now()}`
        ];
        let followingCount = null;
        let followersCount = null;
        for(const path of paths){
          try{
            const data = await fetchFromBases(META_API_BASES,path);
            const stats = parseArtistSocialStats(data);
            if(followingCount == null && stats.followingCount != null) followingCount = stats.followingCount;
            if(followersCount == null && stats.followersCount != null) followersCount = stats.followersCount;
            if(followingCount != null && followersCount != null) break;
          }catch(error){ console.warn("[Music] artist social stats candidate failed",error); }
        }
        return { followingCount, followersCount };
      }

      async function fetchArtistCatalog(artistId,name){
        if(!(Number(artistId) > 0)) return [];
        let catalog = [];
        const paths = [
          `/artist/songs?id=${encodeURIComponent(artistId)}&limit=100&offset=0&order=time&timestamp=${Date.now()}`,
          `/artist/songs?id=${encodeURIComponent(artistId)}&limit=80&offset=0&order=time&timestamp=${Date.now()}`
        ];
        for(const path of paths){
          try{
            const data = await fetchFromBases(META_API_BASES,path);
            catalog = normalizeArtistSongs(data,name,artistId);
            if(catalog.length >= 20) break;
          }catch(error){ console.warn("[Music] artist catalog candidate failed",error); }
        }
        if(catalog.length < 20){
          const encoded = encodeURIComponent(name);
          for(const base of SEARCH_API_BASES){
            try{
              const data = await fetchJson(`${base}/search?keywords=${encoded}&type=1&limit=100&timestamp=${Date.now()}`);
              const extra = normalizeArtistSongs(data,name,artistId);
              const seen = new Set(catalog.map((track)=>track.id));
              catalog.push(...extra.filter((track)=>!seen.has(track.id) && seen.add(track.id)));
              if(catalog.length >= 20) break;
            }catch(error){ console.warn("[Music] artist catalog search fallback failed",error); }
          }
        }
        return catalog
          .sort((a,b)=>(Number(b.popularity)||0)-(Number(a.popularity)||0) || (Number(b.durationMs)||0)-(Number(a.durationMs)||0) || String(a.title).localeCompare(String(b.title),"zh-CN"))
          .slice(0,20);
      }

      async function loadArtistRemote(artist,{force=false}={}){
        if(!artist?.name) return null;
        const info = cachedArtistInfo(artist.name);
        const fresh = info.loaded && info.loadedAt > 0 && Date.now() - info.loadedAt < 15 * 60 * 1000;
        if(!force && fresh) return info;
        if(info.promise) return info.promise;
        info.loading = true;
        info.error = null;
        const requestName = artist.name;
        info.promise = (async()=>{
          let artistId = Number(artist.artistId || info.artistId || 0) || 0;
          let avatar = String(artist.avatar || info.avatar || "").replace(/^http:/i,"https:");
          if(!artistId || !avatar){
            const identity = await resolveArtistIdentity(requestName,artistId);
            artistId = identity.artistId || artistId;
            avatar = avatar || identity.avatar || "";
          }
          const [detailAvatar,catalogTracks,socialStats] = artistId
            ? await Promise.all([
                avatar ? Promise.resolve("") : fetchArtistDetailAvatar(artistId),
                fetchArtistCatalog(artistId,requestName),
                fetchArtistSocialStats(artistId)
              ])
            : ["",[],{followingCount:null,followersCount:null}];
          avatar = avatar || detailAvatar || "";
          info.artistId = artistId || 0;
          info.avatar = avatar || "";
          info.catalogTracks = catalogTracks.length ? catalogTracks : info.catalogTracks;
          if(socialStats?.followingCount != null) info.followingCount = socialStats.followingCount;
          if(socialStats?.followersCount != null) info.followersCount = socialStats.followersCount;
          info.loaded = true;
          info.loadedAt = Date.now();
          const followed = library.followedArtists.find((item)=>artistCacheKey(item.name) === artistCacheKey(requestName));
          if(followed){
            let changed = false;
            if(info.avatar && followed.avatar !== info.avatar){ followed.avatar = info.avatar; changed = true; }
            if(info.artistId && Number(followed.artistId || 0) !== info.artistId){ followed.artistId = info.artistId; changed = true; }
            if(!followed.cover){ const fallback = artistFallbackAvatar(requestName); if(fallback){ followed.cover = fallback; changed = true; } }
            if(changed) void persistLibrary();
          }
          return info;
        })().catch((error)=>{
          console.warn("[Music] artist profile load failed",error);
          info.error = String(error?.message || "artist_profile_load_failed");
          info.loaded = true;
          info.loadedAt = Date.now();
          return info;
        }).finally(()=>{
          info.loading = false;
          info.promise = null;
          if(activeArtist && artistCacheKey(activeArtist.name) === artistCacheKey(requestName)){
            if(info.artistId && !activeArtist.artistId) activeArtist.artistId = info.artistId;
            if(info.avatar && !activeArtist.avatar) activeArtist.avatar = info.avatar;
            renderArtist();
          }
          renderFollowedArtists();
        });
        renderArtist();
        return info.promise;
      }

      function preloadArtistForPlayback(track=currentTrack){
        const clean = normalizeTrack(track);
        if(!clean?.artist) return null;
        const name = primaryArtist(clean.artist);
        if(!name || name === "未知歌手") return null;
        const followed = library.followedArtists.find((item)=>artistCacheKey(item.name) === artistCacheKey(name));
        const snapshot = {
          name,
          cover:String(clean.cover || followed?.cover || ""),
          avatar:String(followed?.avatar || ""),
          artistId:Number(clean.artistId || followed?.artistId || 0) || 0
        };
        // 播放页只触发后台预加载，不阻塞页面渲染和音频播放。
        void loadArtistRemote(snapshot);
        return snapshot;
      }

      function artistTracks(name){
        const needle = artistCacheKey(name);
        const remote = cachedArtistInfo(name).catalogTracks || [];
        const pool = [
          ...remote,
          currentTrack,
          ...searchResults,
          ...library.recent,
          ...library.playlists.flatMap((playlist)=>playlist.songs),
          ...Object.values(library.playStats?.tracks || {}).map((item)=>item.track)
        ].filter(Boolean);
        const seen = new Set();
        return pool.filter((track)=>artistCacheKey(track.artist) === needle && !seen.has(track.id) && seen.add(track.id))
          .sort((a,b)=>(Number(b.popularity)||0)-(Number(a.popularity)||0) || (Number(b.durationMs)||0)-(Number(a.durationMs)||0));
      }

      function isArtistFollowed(name){
        return library.followedArtists.some((item)=>artistCacheKey(item.name) === artistCacheKey(name));
      }

      function renderFollowedArtists(){
        const host = root.querySelector("[data-music-following-list]");
        if(!host) return;
        const items = [...library.followedArtists].sort((a,b)=>(Number(b.followedAt)||0)-(Number(a.followedAt)||0));
        root.querySelectorAll("[data-music-following-count]").forEach((node)=>{ node.textContent = String(items.length); });
        if(!items.length){
          host.innerHTML = '<div class="music-playlist-empty">还没有关注歌手，去播放页点歌手名即可关注。</div>';
          return;
        }
        const fragment = document.createDocumentFragment();
        items.forEach((artist)=>{
          const row = document.createElement("div");
          row.className = "music-followed-row";
          row.dataset.musicFollowedArtist = artist.name;
          const face = document.createElement("div");
          face.className = "music-followed-face";
          face.dataset.musicSurface = "artist";
          face.dataset.musicSurfaceKey = artist.name;
          const copy = document.createElement("div");
          copy.className = "music-followed-copy";
          const name = document.createElement("div");
          name.className = "music-followed-name";
          name.textContent = artist.name || "未知歌手";
          const sub = document.createElement("div");
          sub.className = "music-followed-sub";
          const fans = Number(artist.fans) || 0;
          sub.textContent = fans ? `粉丝 ${formatMetric(fans)} · 点击取消关注` : "点击取消关注";
          copy.append(name, sub);
          const button = document.createElement("button");
          button.type = "button";
          button.className = "music-follow-button is-following";
          button.textContent = "已关注";
          button.setAttribute("aria-label", `取消关注 ${artist.name}`);
          row.append(face, copy, button);
          fragment.appendChild(row);
        });
        host.replaceChildren(fragment);
        hydrateMusicImageSurfaces(host);
      }

      function toggleFollowArtist(name, { follow = null } = {}){
        const targetName = String(name || "").trim();
        if(!targetName) return false;
        const existed = library.followedArtists.some((artist)=>artist.name.toLocaleLowerCase("zh-CN") === targetName.toLocaleLowerCase("zh-CN"));
        if(follow === true && existed) return true;
        if(follow === false && !existed) return true;
        if(existed){
          library.followedArtists = library.followedArtists.filter((artist)=>artist.name.toLocaleLowerCase("zh-CN") !== targetName.toLocaleLowerCase("zh-CN"));
        }else{
          library.followedArtists = [...library.followedArtists, normalizeArtist({ name: targetName, followedAt: Date.now() })];
        }
        persistLibrary();
        renderFollowedArtists();
        return true;
      }

      // ---------- 视图 / 面板切换（缺失尾部补全） ----------
      const VIEW_SELECTOR = "[data-music-view]";
      const PANEL_SELECTOR = "[data-music-view-panel]";

      function setMusicView(view, { resetScroll = true } = {}){
        const next = String(view || "home");
        currentView = MUSIC_RETURNABLE_VIEWS.has(next) ? next : "home";
        root.querySelectorAll(VIEW_SELECTOR).forEach((node)=>{
          const active = node.dataset.musicView === currentView;
          node.classList.toggle("is-active", active);
        });
        root.querySelectorAll(PANEL_SELECTOR).forEach((node)=>{
          const inView = String(node.dataset.musicViewPanel || "") === "home" && currentView === "home";
          node.classList.toggle("is-active", inView);
        });
        return true;
      }

      function openPanel(panel, { keepReturn = false } = {}){
        const key = String(panel || "");
        if(!key) return false;
        if(!keepReturn) playerReturnView = currentView;
        root.querySelectorAll(PANEL_SELECTOR).forEach((node)=>{
          const active = node.dataset.musicViewPanel === key;
          node.classList.toggle("is-active", active);
        });
        if(key === "following") renderFollowedArtists();
        return true;
      }

      // ---------- 通用事件委托 ----------
      function onRootClick(event){
        const target = event.target;
        if(!target || target === root || !root.contains(target)) return;
        const go = target.closest("[data-music-go]");
        if(go){
          const value = String(go.dataset.musicGo || "home");
          if(value === "player" && currentTrack) return openPanel("player");
          if(value === "home"){ setMusicView("home"); openPanel("home"); }
          else if(value === "search"){ setMusicView("search"); openPanel("search"); }
          else if(value === "profile"){ setMusicView("profile"); openPanel("profile"); }
          else setMusicView(value);
          return;
        }
        const titleAction = target.closest("[data-music-title-action]");
        if(titleAction){
          const action = String(titleAction.dataset.musicTitleAction || "");
          if(action === "home"){ setMusicView("home"); openPanel("home"); }
          else if(action === "close"){ setMusicView("home"); openPanel("home"); }
          else if(action === "detail" && currentTrack){ openPanel("playlist"); }
          return;
        }
        const back = target.closest(".music-back, [data-music-back]");
        if(back){ setMusicView("home"); openPanel("home"); return; }
        const followBtn = target.closest("[data-music-follow-button]");
        if(followBtn){ const name = followBtn.dataset.musicFollowButton || activeArtist?.name || ""; toggleFollowArtist(name, { follow: followBtn.dataset.follow !== "false" }); return; }
        const unfollow = target.closest("[data-music-unfollow]");
        if(unfollow){ const name = unfollow.dataset.musicUnfollow || ""; toggleFollowArtist(name, { follow: false }); return; }
        const filterBtn = target.closest("[data-music-filter]");
        if(filterBtn){ filter = String(filterBtn.dataset.musicFilter || "all"); root.querySelectorAll("[data-music-filter]").forEach((n)=>n.classList.toggle("is-active", n === filterBtn)); renderSearch(); return; }
        const queryCard = target.closest("[data-music-query]");
        if(queryCard){ openSearch(String(queryCard.dataset.musicQuery || "")); return; }
        const followedRow = target.closest("[data-music-followed-artist]");
        if(followedRow){ const name = followedRow.dataset.musicFollowedArtist || ""; toggleFollowArtist(name, { follow: false }); return; }
      }

      // ---------- 播放控制（无远端音频时保持状态自洽） ----------
      function pickFirstTrack(){
        if(currentTrack) return currentTrack;
        const liked = library.playlists.find((item)=>item.system === "liked");
        const pool = liked?.songs?.length ? liked.songs : library.recent;
        if(pool?.length){
          currentTrack = pool[0];
          renderHome();
        }
        return currentTrack || null;
      }

      function updatePlayUi(){
        root.classList.toggle("is-playing", playing);
        const buttons = root.querySelectorAll("[data-music-play-toggle]");
        buttons.forEach((node)=>{ node.setAttribute("aria-pressed", playing ? "true" : "false"); });
        root.querySelectorAll("[data-music-playing-title]").forEach((node)=>{
          node.textContent = currentTrack?.name || "未在播放";
        });
        root.querySelectorAll("[data-music-playing-artist]").forEach((node)=>{
          node.textContent = primaryArtist(currentTrack) || "";
        });
      }

      function toggle(force){
        const track = pickFirstTrack();
        if(!track) return false;
        playing = typeof force === "boolean" ? force : !playing;
        persistPlaybackState(true);
        updatePlayUi();
        return playing;
      }

      function next(){ return skip(true); }
      function previous(){ return skip(false); }
      function skip(forward){
        const track = pickFirstTrack();
        if(!track) return false;
        const liked = library.playlists.find((item)=>item.system === "liked");
        const queue = liked?.songs?.length ? liked.songs : library.recent;
        if(!queue?.length) return false;
        let index = queue.findIndex((item)=>item?.id === track.id);
        index = index < 0 ? 0 : index + (forward ? 1 : -1);
        if(index < 0) index = queue.length - 1;
        if(index >= queue.length) index = 0;
        currentTrack = queue[index];
        playing = true;
        persistPlaybackState(true);
        updatePlayUi();
        return true;
      }

      function toggleLike(){
        if(!currentTrack) return false;
        const liked = library.playlists.find((item)=>item.system === "liked");
        if(!liked) return false;
        const existed = liked.songs.some((item)=>item?.id === currentTrack.id);
        liked.songs = existed
          ? liked.songs.filter((item)=>item?.id !== currentTrack.id)
          : [...liked.songs, { ...currentTrack, likedAt: Date.now() }];
        persistLibrary();
        updatePlayUi();
        return true;
      }

      function backToHome(){ setMusicView("home"); openPanel("home"); return true; }

      async function ensureLibraryHydrated(){
        if(libraryHydrated || libraryHydrating) return libraryHydrating || Promise.resolve();
        libraryHydrating = (async()=>{
          try{
            const theme = window.ThemeCustomization;
            await theme?.ready;
            const db = theme?.db;
            if(!db) return;
            const [libraryRecord, statsRecord, settingsRecord] = await Promise.all([
              db.musicState.get(MUSIC_STATE_KEYS.library).catch(()=>undefined),
              db.musicState.get(MUSIC_STATE_KEYS.stats).catch(()=>undefined),
              db.musicState.get(MUSIC_STATE_KEYS.settings).catch(()=>undefined)
            ]);
            if(libraryRecord?.value) library = normalizeLibrary(libraryRecord.value);
            if(statsRecord?.value) library.playStats = normalizePlayStats(statsRecord.value);
            if(settingsRecord?.value) musicSettings = normalizeMusicSettings(settingsRecord.value);
            libraryHydrated = true;
          }catch(error){
            console.warn("[Music] library hydrate failed", error);
          }finally{
            libraryHydrating = null;
            libraryHydrated = true;
          }
        })();
        return libraryHydrating;
      }

      function hydrateLucide(){
        try{ window.lucide?.createIcons?.({ attrs: { "stroke-width": 2 } }); }catch(_){}
      }

      root.addEventListener("click", onRootClick);

      function open(view = "home"){
        if(!root) return false;
        hydrateLucide();
        bindSearchUi();
        void ensureLibraryHydrated().then(()=>{
          hydrateLucide();
          setMusicView(view);
          if(view === "home") openPanel("home");
          renderHome();
          updatePlayUi();
        });
        return true;
      }

      function close(){
        // 轻量页面生命周期：路由隐藏已移除渲染树；再次进入复用同一挂载实例。
        if(playing){ playing = false; updatePlayUi(); }
        return true;
      }

      return Object.freeze({
        open,
        close,
        previous,
        next,
        toggle,
        toggleLike,
        setView: setMusicView,
        openPanel,
        backToHome,
        search: runSearch,
        openSearch,
        state: ()=>({ view: currentView, playing, track: currentTrack ? { id: currentTrack.id, name: currentTrack.name } : null })
      });
    })();
    window.MusicApp = MusicApp;

