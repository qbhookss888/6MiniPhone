/* 清柳 Memory Lifecycle —— 生命周期处理（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryLifecycle) return;
  async function processNew(items, options) {
    const opts = options || {};
    const batchId = opts.batchId || `batch-${Date.now()}`;
    const database = window.ThemeCustomization?.db;
    const accepted = [];
    const seen = new Set();
    for (const item of Array.isArray(items) ? items : []) {
      const key = String(item?.content || "");
      if (!key || seen.has(key)) continue;
      seen.add(key);
      accepted.push({ ...item, status: "active", lifecycleKey: item.lifecycleKey || "new", batchId });
    }
    if (database?.memory_lifecycle_events && accepted.length) {
      try {
        const now = Date.now();
        await database.memory_lifecycle_events.bulkPut(accepted.map((item) => ({
          id: `evt-${now}-${Math.random().toString(36).slice(2, 8)}`,
          accountId: item.accountId || "",
          memorySpaceKey: item.memorySpaceKey || "",
          memoryId: item.id || "",
          decision: "NEW",
          lifecycleKey: item.lifecycleKey || "new",
          propositionFingerprint: item.propositionFingerprint || "",
          batchId,
          createdAt: now
        })));
      } catch (_) { }
    }
    return { accepted, skipped: (Array.isArray(items) ? items.length : 0) - accepted.length, batchId };
  }
  function decide(item) { return { memoryId: item?.id || "", decision: "NEW" }; }
  window.QWQMemoryLifecycle = Object.freeze({ processNew, decide });
})();
console.log("[Memory] lifecycle 已加载");
