/* 清柳 Memory Embedding —— 确定性简易向量（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryEmbedding) return;
  const DIMENSIONS = 32;
  function stableHashes(text) {
    const value = String(text || "");
    const hashes = [];
    for (let slot = 0; slot < DIMENSIONS; slot += 1) {
      let hash = 2166136261 ^ (slot * 2654435761);
      for (let i = 0; i < value.length; i += 1) {
        hash ^= value.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
      }
      hashes.push((hash >>> 0) / 4294967296);
    }
    return hashes;
  }
  function encode(text) {
    const vec = stableHashes(text);
    const norm = Math.sqrt(vec.reduce((sum, v) => sum + v * v, 0)) || 1;
    return { vector: vec.map((v) => v / norm), dimensions: DIMENSIONS, provider: "hash-bucket" };
  }
  function cosine(a, b) {
    if (!a?.length || !b?.length || a.length !== b.length) return 0;
    let dot = 0;
    for (let i = 0; i < a.length; i += 1) dot += a[i] * b[i];
    return dot;
  }
  window.QWQMemoryEmbedding = Object.freeze({ encode, cosine, DIMENSIONS });
})();
console.log("[Memory] embedding 已加载");
