/* 清柳 Memory Access Guard —— 访问授权（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryAccessGuard) return;
  const grants = new Map();
  function token() { return `cap-${globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`}`; }
  function claim(app) {
    const capability = { token: token(), app: String(app || "unknown"), issuedAt: Date.now() };
    grants.set(capability.token, capability);
    return capability;
  }
  function authorize(capability, request) {
    if (!capability || !grants.has(capability.token)) return false;
    const record = { ...request, grantedAt: Date.now(), capability: capability.token, app: capability.app };
    grants.set(`${capability.token}:last`, record);
    return true;
  }
  function revoke(capability) {
    if (!capability) return false;
    grants.delete(capability.token);
    return true;
  }
  function audit(capability) { return grants.get(`${capability?.token}:last`) || null; }
  window.QWQMemoryAccessGuard = Object.freeze({ claim, authorize, revoke, audit });
})();
console.log("[Memory] access guard 已加载");
