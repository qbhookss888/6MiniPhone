/* 清柳 Memory Retriever —— 混合召回（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryRetriever) return;
  async function retrieve(options) {
    const opts = options || {};
    const repository = window.QWQMemoryRepository;
    if (!repository?.recall) return [];
    const limit = Math.max(0, Number(opts.limit) || 8);
    try {
      return await repository.recall({
        accountId: opts.accountId,
        conversationId: opts.contactId || opts.conversationId || opts.characterId,
        query: opts.query || "",
        limit
      });
    } catch (_) { return []; }
  }
  window.QWQMemoryRetriever = Object.freeze({ retrieve });
})();
console.log("[Memory] retriever 已加载");
