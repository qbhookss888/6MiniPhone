/* 清柳 Memory Service —— 记忆服务门面（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryService) return;

  async function afterReply(contactId, options) {
    const opts = options || {};
    const generator = window.QWQMemoryGenerator;
    if (!generator?.extractAtoms) return { ok: true, skipped: true };
    try {
      const contact = typeof contactId === "object" ? contactId : null;
      const accountId = String(opts.accountId || contact?.accountId || "");
      const conversationId = String(opts.conversationId || contactId?.conversationId || contactId || "");
      const text = String(opts.text || "");
      const rows = Array.isArray(opts.rows) ? opts.rows : (text ? [{ content: text, role: "assistant", createdAt: Date.now() }] : []);
      if (!rows.length) return { ok: true, created: [] };
      const result = await generator.extractAtoms({ accountId, conversationId, rows });
      return { ok: true, ...result };
    } catch (error) {
      console.warn("[Memory] afterReply failed", error);
      return { ok: false, reason: String(error.message || error) };
    }
  }

  async function runMemoryMaintenance() {
    try {
      await window.QWQMemoryRepository?.ready?.();
      return { ok: true };
    } catch (_) { return { ok: false }; }
  }

  window.QWQMemoryService = Object.freeze({ afterReply, runMemoryMaintenance });
})();
console.log("[Memory] service 已加载");
