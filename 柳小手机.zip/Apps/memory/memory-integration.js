/* 清柳 Memory Integration —— 命名空间与指纹（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryIntegration) return;
  function stableHash(text) {
    let hash = 2166136261;
    const value = String(text || "");
    for (let i = 0; i < value.length; i += 1) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  }
  function memorySpaceKey(accountId) { return String(accountId || "default") || "default"; }
  function fingerprint(text) { return stableHash(String(text || "")); }
  function claimNamespace(accountId) {
    return { accountId: String(accountId || ""), memorySpaceKey: memorySpaceKey(accountId), fingerprint: fingerprint(accountId) };
  }
  function enrichFromSource(item, source) {
    const result = item && typeof item === "object" ? { ...item } : {};
    const src = source && typeof source === "object" ? source : {};
    if (src.accountId) result.accountId = src.accountId;
    if (src.conversationId) { result.sourceConversationId = src.conversationId; result.characterId = result.characterId || src.conversationId; }
    if (src.sourceApp) result.sourceApp = src.sourceApp;
    return result;
  }
  window.QWQMemoryIntegration = Object.freeze({ stableHash, memorySpaceKey, fingerprint, claimNamespace, enrichFromSource });
})();
console.log("[Memory] integration 已加载");
