/* 清柳 Memory Producers —— 生产者注册表（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryProducerRegistry) return;
  const producers = new Map();
  function register(producer) {
    const item = producer && typeof producer === "object" ? producer : {};
    const id = String(item.id || `producer-${producers.size + 1}`);
    producers.set(id, { id, app: String(item.app || "app"), run: typeof item.run === "function" ? item.run : async () => ({ produced: 0 }) });
    return id;
  }
  function list() { return Array.from(producers.values()); }
  async function runAll(context) {
    const results = [];
    for (const producer of producers.values()) {
      try { results.push({ id: producer.id, result: await producer.run(context) }); }
      catch (error) { results.push({ id: producer.id, error: String(error.message || error) }); }
    }
    return results;
  }
  // 默认 QQ 会话生产者（无模型离线时由 generator 兜底）
  register({ id: "qq-session", app: "qq", run: async (context) => {
    const generator = window.QWQMemoryGenerator;
    if (!generator?.extractAtoms) return { produced: 0 };
    try {
      return await generator.extractAtoms(context);
    } catch (_) { return { produced: 0 }; }
  } });
  window.QWQMemoryProducerRegistry = Object.freeze({ register, list, runAll });
})();
console.log("[Memory] producers 已加载");
