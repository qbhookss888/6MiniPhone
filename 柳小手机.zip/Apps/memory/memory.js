/* Memory App —— 记忆浏览（经典脚本，全局 MemoryApp）。 */
(function () {
  "use strict";
  if (window.MemoryApp) return;
  const page = document.getElementById("page-memory-app");
  const state = { accountId: "", contactId: "", contactName: "" };
  function esc(value) { return String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch])); }
  async function db() { try { await window.ThemeCustomization?.ready; } catch (_) { } return window.ThemeCustomization?.db || null; }
  function switchView(name) {
    if (!page) return;
    page.querySelectorAll(".memory-view").forEach((view) => {
      const active = view.id === ("memory-" + name + "-view");
      view.hidden = !active;
      if (active) view.dataset.active = "1"; else delete view.dataset.active;
    });
    page.dataset.memoryView = name;
  }
  async function loadAccounts() {
    const database = await db();
    if (!database?.contacts) return [];
    try {
      const rows = await database.contacts.toArray();
      const map = new Map();
      rows.forEach((row) => { const key = String(row.accountId || "default"); if (!map.has(key)) map.set(key, { accountId: key, count: 0 }); map.get(key).count += 1; });
      const accounts = Array.from(map.values());
      let counts = {};
      try { counts = (await window.QWQMemoryRepository?.counts?.()) || {}; } catch (_) { }
      accounts.forEach((a) => { a.memoryCount = counts.byAccount?.[a.accountId] || 0; });
      if (!accounts.length) accounts.push({ accountId: "default", count: 0, memoryCount: 0 });
      return accounts;
    } catch (_) { return [{ accountId: "default", count: 0, memoryCount: 0 }]; }
  }
  async function renderAccounts() {
    const host = page?.querySelector("#memory-account-list");
    const stats = page?.querySelector("#memory-account-stats");
    if (!host) return;
    const accounts = await loadAccounts();
    let total = 0;
    try { total = ((await window.QWQMemoryRepository?.counts?.()) || {}).total || 0; } catch (_) { }
    if (stats) { stats.replaceChildren(); const stat = document.createElement("span"); stat.textContent = accounts.length + " 个账号 · " + total + " 条记忆"; stats.appendChild(stat); }
    host.replaceChildren();
    accounts.forEach((account) => {
      const row = document.createElement("button"); row.type = "button"; row.className = "memory-account-card";
      const avatar = document.createElement("span"); avatar.className = "memory-account-avatar";
      avatar.textContent = account.accountId === "default" ? "默" : account.accountId.slice(0, 1).toUpperCase();
      const copy = document.createElement("span"); copy.className = "memory-account-copy";
      const name = document.createElement("strong"); name.textContent = account.accountId === "default" ? "默认账号" : account.accountId;
      const sub = document.createElement("small"); sub.textContent = account.count + " 个联系人 · " + (account.memoryCount || 0) + " 条记忆";
      copy.append(name, sub);
      const chevron = document.createElement("b"); chevron.textContent = "›";
      row.append(avatar, copy, chevron);
      row.addEventListener("click", () => openContacts(account.accountId));
      host.appendChild(row);
    });
  }
  async function renderContacts() {
    const host = page?.querySelector("#memory-contact-list");
    const context = page?.querySelector("#memory-account-context");
    const search = page?.querySelector("#memory-contact-search");
    const database = await db();
    if (context) context.textContent = state.accountId === "default" ? "默认账号" : state.accountId;
    if (!host) return;
    let contacts = [];
    if (database?.contacts) {
      try {
        const rows = await database.contacts.toArray();
        const seen = new Map();
        rows.forEach((row) => {
          if (String(row.accountId || "default") !== state.accountId) return;
          const key = row.contactId || row.displayName || row.name || "";
          if (!key || seen.has(key)) return;
          seen.set(key, row);
        });
        contacts = Array.from(seen.values());
      } catch (_) { }
    }
    const term = String(search?.value || "").trim().toLowerCase();
    const filtered = term ? contacts.filter((c) => String(c.displayName || c.name || "").toLowerCase().includes(term)) : contacts;
    host.replaceChildren();
    if (!filtered.length) {
      const empty = document.createElement("div"); empty.className = "memory-empty";
      empty.textContent = contacts.length ? "没有匹配的联系人" : "该账号还没有联系人";
      host.appendChild(empty); return;
    }
    filtered.forEach((contact) => {
      const name = String(contact.displayName || contact.name || contact.nickname || contact.contactId || "联系人");
      const row = document.createElement("button"); row.type = "button"; row.className = "memory-contact-card";
      const avatar = document.createElement("span"); avatar.className = "memory-contact-avatar"; avatar.textContent = (name[0] || "?").toUpperCase();
      const copy = document.createElement("span"); copy.className = "memory-contact-copy";
      const strong = document.createElement("strong"); strong.textContent = name; copy.appendChild(strong);
      const chevron = document.createElement("b"); chevron.textContent = "›";
      row.append(avatar, copy, chevron);
      row.addEventListener("click", () => openDetail(contact.contactId, name));
      host.appendChild(row);
    });
  }
  async function renderDetail() {
    const host = page?.querySelector("#memory-detail-view");
    if (!host) return;
    host.replaceChildren();
    const head = document.createElement("div"); head.className = "memory-detail-head";
    const back = document.createElement("button"); back.type = "button"; back.className = "memory-back-button";
    back.textContent = "‹ 返回"; back.addEventListener("click", () => { switchView("contact"); void renderContacts(); });
    const title = document.createElement("h2"); title.textContent = state.contactName || "记忆";
    head.append(back, title); host.appendChild(head);
    let rows = [];
    try { rows = await window.QWQMemoryRepository?.listByContact?.({ accountId: state.accountId, contactId: state.contactId, limit: 200 }) || []; } catch (_) { rows = []; }
    const actions = document.createElement("div"); actions.className = "memory-detail-actions";
    const addButton = document.createElement("button"); addButton.type = "button"; addButton.textContent = "＋ 新建记忆";
    addButton.addEventListener("click", () => openCreateForm(host)); actions.appendChild(addButton); host.appendChild(actions);
    if (!rows.length) {
      const empty = document.createElement("div"); empty.className = "memory-empty";
      empty.textContent = "还没有记忆，聊天中产生的长期记忆会出现在这里。";
      host.appendChild(empty); return;
    }
    const list = document.createElement("div"); list.className = "memory-list";
    rows.forEach((row) => {
      const card = document.createElement("article"); card.className = "memory-card";
      const content = document.createElement("p"); content.className = "memory-card-content"; content.textContent = row.content || "";
      const meta = document.createElement("div"); meta.className = "memory-card-meta";
      const badge = document.createElement("span"); badge.className = "memory-badge"; badge.textContent = row.category || "other";
      const stateText = document.createElement("span"); stateText.className = "memory-card-state";
      stateText.textContent = row.status === "deleted" ? "已删除" : row.status === "archived" ? "已归档" : "活跃";
      const time = document.createElement("time");
      try { time.textContent = new Intl.DateTimeFormat("zh-CN", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(row.updatedAt || row.createdAt || Date.now())); } catch (_) { }
      meta.append(badge, stateText, time);
      const actionsRow = document.createElement("div"); actionsRow.className = "memory-card-actions";
      if (row.status === "deleted") {
        const restore = document.createElement("button"); restore.type = "button"; restore.textContent = "恢复";
        restore.addEventListener("click", async () => { await window.QWQMemoryRepository?.restoreMemory?.(row.id); await renderDetail(); });
        actionsRow.appendChild(restore);
      } else {
        const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "删除";
        remove.addEventListener("click", async () => { await window.QWQMemoryRepository?.deleteMemory?.(row.id); await renderDetail(); });
        actionsRow.appendChild(remove);
      }
      card.append(content, meta, actionsRow); list.appendChild(card);
    });
    host.appendChild(list);
  }
  function openCreateForm(host) {
    const overlay = document.createElement("div"); overlay.className = "memory-form-overlay";
    const form = document.createElement("div"); form.className = "memory-form";
    const title = document.createElement("h3"); title.textContent = "新建记忆";
    const input = document.createElement("textarea"); input.placeholder = "写下这条长期记忆…"; input.className = "memory-form-input";
    const submit = document.createElement("button"); submit.type = "button"; submit.textContent = "保存";
    const cancel = document.createElement("button"); cancel.type = "button"; cancel.textContent = "取消";
    cancel.addEventListener("click", () => overlay.remove());
    submit.addEventListener("click", async () => {
      const content = input.value.trim(); if (!content) return;
      try {
        await window.QWQMemoryRepository?.createMemory?.(state.accountId, state.contactId, { content, category: "other", factType: "knowledge", subject: "other", scope: "character", importance: 0.5, confidence: 0.7, sourceApp: "memory-app" });
        overlay.remove(); await renderDetail();
      } catch (error) { console.error("[Memory] 新建失败", error); overlay.remove(); }
    });
    form.append(title, input, submit, cancel); overlay.appendChild(form);
    overlay.addEventListener("click", (event) => { if (event.target === overlay) overlay.remove(); });
    host.appendChild(overlay);
  }
  function openContacts(accountId) {
    state.accountId = String(accountId || "default");
    const search = page?.querySelector("#memory-contact-search"); if (search) search.value = "";
    switchView("contact"); void renderContacts();
  }
  function openDetail(contactId, name) {
    state.contactId = String(contactId || ""); state.contactName = String(name || "联系人");
    switchView("detail"); void renderDetail();
  }
  function bindEvents() {
    if (!page || page.dataset.memoryBound === "1") return;
    page.dataset.memoryBound = "1";
    const search = page?.querySelector("#memory-contact-search");
    if (search) search.addEventListener("input", () => void renderContacts());
    const back = page?.querySelector("#memory-page-title");
    if (back) back.addEventListener("click", () => {
      const view = page?.dataset.memoryView;
      if (view === "detail") { switchView("contact"); void renderContacts(); }
      else if (view === "contact") { switchView("accounts"); void renderAccounts(); }
      else { try { window.MyPhoneManager?.open?.(); } catch (_) { } }
    });
    const action = page?.querySelector("#memory-page-action");
    if (action) action.addEventListener("click", () => { void renderAccounts(); });
  }
  async function open() {
    if (!page) return false;
    bindEvents(); switchView("accounts"); void renderAccounts(); return true;
  }
  function close() { return true; }
  function stateInfo() { return { view: page?.dataset.memoryView || "accounts", account: state.accountId }; }
  window.MemoryApp = Object.freeze({ open, close, state: stateInfo });
})();
console.log("[Memory] 记忆 App 已加载");
