/* 清柳 Memory Generator —— 原子记忆生成（离线启发式，经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryGenerator) return;
  const TRIVIAL = /^(嗯|好的|对|是|不|哈哈|哈哈哈|呵呵|谢谢|再见|在吗|早|晚安|拜拜|哦|噢|啊|哎|行|可以|ok|好的呢)[\s。！!~～.…]*$/i;

  async function extractAtoms(context) {
    const ctx = context || {};
    const accountId = String(ctx.accountId || "");
    const conversationId = String(ctx.conversationId || ctx.contactId || "");
    const rows = Array.isArray(ctx.rows) ? ctx.rows : [];
    const repository = window.QWQMemoryRepository;
    const created = [];
    let skipped = 0;
    for (const row of rows) {
      const content = String(row?.content || row?.text || "").trim();
      if (!content || content.length < 8 || TRIVIAL.test(content)) { skipped += 1; continue; }
      const isUser = row?.role === "user" || row?.role === "self";
      const scope = isUser ? "global" : "character";
      const id = await repository?.createMemory?.(accountId, conversationId, {
        content,
        category: "event",
        factType: "event",
        subject: isUser ? "user" : "character",
        scope,
        importance: 0.45,
        confidence: 0.6,
        occurredAt: Number(row?.createdAt) || null,
        sourceApp: "qq",
        sourceSurface: "session-memory"
      });
      if (id) created.push(id);
    }
    return { created, skipped, accountId, conversationId };
  }
  window.QWQMemoryGenerator = Object.freeze({ extractAtoms });
})();
console.log("[Memory] generator 已加载");
