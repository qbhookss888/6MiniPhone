/* 清柳 Memory Schema —— 字段规范与记忆查询构建（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemorySchema) return;
  const KEY_FIELDS = ["content", "category", "factType", "subject", "subjectKey", "scope", "predicateKey", "valueKey", "keywords", "entities", "entityKeys", "sourceRefs", "sourceIds", "sourceApp", "sourceSurface", "importance", "confidence", "occurredAt", "occurredAtPrecision", "lifecycleKey", "propositionFingerprint", "evidenceKey", "conflictGroupId", "batchId", "originKind", "status", "accountId", "memorySpaceKey", "characterId", "sourceConversationId"];
  function uid(prefix) { return `${prefix}-${globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`}`; }
  function text(value, max) { return String(value ?? "").replace(/\r\n?/g, "\n").trim().slice(0, Number.isFinite(max) ? max : 2000); }
  function list(value) { const arr = Array.isArray(value) ? value : []; return arr.map((v) => String(v ?? "")).filter(Boolean).slice(0, 30); }
  function num(value) { const n = Number(value); return Number.isFinite(n) ? n : null; }

  function normalizeDraft(item, options) {
    const opts = options || {};
    const source = item && typeof item === "object" && !Array.isArray(item) ? item : {};
    if (!source.content || !text(source.content)) throw new Error("记忆内容不能为空");
    const requireLifecycle = opts.requireLifecycleKeys === true;
    const requireSource = opts.requireSourceRefs === true;
    if (requireLifecycle && (!source.predicateKey || !source.valueKey)) throw new Error("缺少生命周期键 predicateKey/valueKey");
    if (requireLifecycle && !source.category) throw new Error("缺少 category");
    if (requireLifecycle && !source.factType) throw new Error("缺少 factType");
    if (requireSource && !Array.isArray(source.sourceRefs)) throw new Error("缺少 sourceRefs");
    const normalized = { content: text(source.content, 2000) };
    KEY_FIELDS.forEach((key) => {
      if (key === "content") return;
      if (source[key] === undefined || source[key] === null) return;
      if (key === "keywords" || key === "entityKeys" || key === "sourceIds" || key === "sourceRefs") normalized[key] = list(source[key]);
      else if (key === "importance" || key === "confidence") normalized[key] = num(source[key]);
      else normalized[key] = source[key];
    });
    if (source.entities && Array.isArray(source.entities)) normalized.entities = source.entities.slice(0, 20);
    normalized.id = normalized.id || uid("memory");
    normalized.createdAt = num(source.createdAt) || Date.now();
    normalized.updatedAt = num(source.updatedAt) || normalized.createdAt;
    normalized.status = normalized.status || "active";
    normalized.keywords = list(source.keywords || (normalized.content ? normalized.content.split(/[\s,，。;；、]+/).filter((w) => w.length > 1).slice(0, 6) : []));
    if (normalized.scope === "global") normalized.scope = "global";
    else if (normalized.scope === "app") normalized.scope = "app";
    else normalized.scope = "character";
    return normalized;
  }

  function buildContextQuery(rows, currentMessage, options) {
    const opts = options || {};
    const max = Math.max(0, Number(opts.maxMessages) || 8);
    const items = Array.isArray(rows) ? rows.slice(0, max) : [];
    if (!items.length) return "";
    const lines = items.map((row, index) => {
      const content = text(row.content, 160);
      const category = row.category ? `[${row.category}]` : "";
      const when = row.occurredAt ? `（${String(row.occurredAt).slice(0, 10)}）` : "";
      return `${index + 1}. ${category}${when} ${content}`;
    });
    return lines.join("\n");
  }

  window.QWQMemorySchema = Object.freeze({
    normalizeDraft,
    buildContextQuery,
    uid,
    KEY_FIELDS
  });
})();
console.log("[Memory] schema 已加载");
