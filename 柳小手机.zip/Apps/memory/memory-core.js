/* 清柳 Memory Core —— 共享记忆运行时与 Consumer Client（经典脚本）。 */
(function () {
  "use strict";
  if (window.SharedMemoryCore) return;
  function buildPromptBlock(rows) {
    const list = Array.isArray(rows) ? rows.slice(0, 12) : [];
    if (!list.length) return "";
    const lines = list.map((row) => {
      const content = String(row?.content || "").trim().slice(0, 200);
      const category = row?.category ? `[${row.category}]` : "";
      return `- ${category} ${content}`;
    });
    return `【长期记忆】\n${lines.join("\n")}`;
  }

  function createConsumerClient(config) {
    const cfg = config || {};
    const consumerApp = String(cfg.consumerApp || "app");
    const capability = cfg.accessCapability || null;
    return {
      app: consumerApp,
      capability,
      ready: async () => window.QWQMemoryRepository?.ready?.() || true,
      recallContext: async (params) => {
        const p = params || {};
        const retriever = window.QWQMemoryRetriever;
        let rows = [];
        try {
          rows = await retriever.retrieve({
            accountId: p.accountId,
            contactId: p.conversationId || p.contactId || p.characterId,
            query: p.query || "",
            limit: Number(p.limit) || 8
          });
        } catch (_) { rows = []; }
        return {
          promptBlock: buildPromptBlock(rows),
          memories: rows.slice(0, 8),
          consumerApp,
          purpose: p.purpose || ""
        };
      },
      listRecent: async (params) => {
        const p = params || {};
        try {
          return await window.QWQMemoryRepository?.listByContact?.({
            accountId: p.accountId,
            contactId: p.conversationId || p.contactId,
            limit: Number(p.limit) || 10
          }) || [];
        } catch (_) { return []; }
      }
    };
  }

  const core = {
    build: "V0.0.420-memory-r1",
    createConsumerClient,
    ready: async () => window.QWQMemoryRepository?.ready?.() || true
  };
  window.QWQMemoryCore = Object.freeze(core);
  window.SharedMemoryCore = Object.freeze({ createConsumerClient, ready: core.ready, build: core.build });
})();
console.log("[Memory] core 已加载");
