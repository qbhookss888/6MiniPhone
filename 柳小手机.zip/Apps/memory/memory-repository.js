/* 清柳 Memory Repository —— 记忆存储核心（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryRepository) return;
  const integration = () => window.QWQMemoryIntegration;
  const schema = () => window.QWQMemorySchema;
  let readyPromise = null;

  function ready() {
    if (!readyPromise) {
      readyPromise = (async () => {
        try { await window.ThemeCustomization?.ready; } catch (_) { }
        return Boolean(window.ThemeCustomization?.db);
      })();
    }
    return readyPromise;
  }

  async function db() {
    await ready();
    return window.ThemeCustomization?.db || null;
  }

  function spaceFor(accountId) {
    return integration()?.memorySpaceKey(accountId) || String(accountId || "default");
  }

  async function put(item) {
    const database = await db();
    if (!database?.memory_items) return null;
    const now = Date.now();
    const normalized = { ...(item || {}) };
    if (!normalized.id) normalized.id = schema()?.uid?.("memory") || `memory-${now}`;
    if (!normalized.memorySpaceKey && normalized.accountId) normalized.memorySpaceKey = spaceFor(normalized.accountId);
    normalized.createdAt = normalized.createdAt || now;
    normalized.updatedAt = now;
    normalized.status = normalized.status || "active";
    try {
      await database.memory_items.put(normalized);
      return normalized.id;
    } catch (error) {
      console.warn("[Memory] put failed", error);
      return null;
    }
  }

  async function listByContact(options) {
    const database = await db();
    if (!database?.memory_items) return [];
    const opts = options || {};
    const accountId = String(opts.accountId || "");
    const contactId = String(opts.contactId || opts.conversationId || "");
    const limit = Math.max(0, Number(opts.limit) || 50);
    try {
      let collection = database.memory_items;
      if (accountId && contactId) {
        const rows = await database.memory_items.filter((row) =>
          String(row.accountId || "") === accountId &&
          (String(row.sourceConversationId || "") === contactId || String(row.characterId || "") === contactId) &&
          row.status !== "deleted"
        ).limit(limit + 5).toArray();
        return rows.slice(0, limit);
      }
      if (accountId) collection = collection.where("accountId").equals(accountId);
      const rows = await collection.filter((row) => row.status !== "deleted").reverse().sortBy("updatedAt");
      return rows.slice(0, limit);
    } catch (_) { return []; }
  }

  async function recall(options) {
    const opts = options || {};
    const limit = Math.max(0, Number(opts.limit) || 8);
    const rows = await listByContact({ accountId: opts.accountId, contactId: opts.conversationId || opts.contactId, limit: Math.max(limit, 20) });
    const query = String(opts.query || "");
    const scored = rows.map((row) => {
      let score = Number(row.importance) || 0;
      if (query) {
        const hay = `${row.content || ""} ${(row.keywords || []).join(" ")}`.toLowerCase();
        const terms = query.toLowerCase().split(/[\s,，。]+/).filter((t) => t.length > 1);
        const hits = terms.filter((t) => hay.includes(t)).length;
        score += (hits / Math.max(1, terms.length)) * 2;
      }
      return { row, score };
    });
    return scored.sort((a, b) => b.score - a.score).slice(0, limit).map((s) => s.row);
  }

  async function runSourceTimelineMutation(context, task) {
    const ctx = context && typeof context === "object" ? context : {};
    const database = await db();
    if (!database?.memory_items) return { result: { success: false, reason: "db-unavailable" } };
    const accountId = String(ctx.accountId || "");
    const conversationId = String(ctx.conversationId || "");
    const mutationType = String(ctx.mutationType || "");
    const messageIds = Array.isArray(ctx.messageIds) ? ctx.messageIds.map(String) : [];
    const now = Date.now();
    try {
      if (mutationType === "deleteMessages" && messageIds.length) {
        const rows = await database.memory_items.toArray();
        const targets = rows.filter((row) =>
          (!accountId || String(row.accountId || "") === accountId) &&
          String(row.sourceConversationId || "") === conversationId &&
          (row.sourceIds || []).some((id) => messageIds.includes(String(id)))
        );
        for (const row of targets) await database.memory_items.update(row.id, { status: "deleted", updatedAt: now });
        return { result: { success: true, deleted: targets.length, mutationType } };
      }
      if (mutationType === "deleteConversation" || mutationType === "purgeContact") {
        const rows = await listByContact({ accountId, contactId: conversationId, limit: 10000 });
        for (const row of rows) await database.memory_items.update(row.id, { status: "deleted", updatedAt: now });
        return { result: { success: true, deleted: rows.length, mutationType } };
      }
      if (mutationType === "restore") {
        return { result: { success: true, deleted: 0, mutationType } };
      }
      return { result: { success: true, deleted: 0, mutationType } };
    } catch (error) {
      console.warn("[Memory] runSourceTimelineMutation failed", error);
      return { result: { success: false, reason: String(error.message || error) } };
    }
  }

  async function counts() {
    const database = await db();
    const result = { total: 0, active: 0, byAccount: {} };
    if (!database?.memory_items) return result;
    try {
      const rows = await database.memory_items.toArray();
      result.total = rows.length;
      result.active = rows.filter((row) => row.status !== "deleted").length;
      rows.forEach((row) => {
        const key = String(row.accountId || "default");
        result.byAccount[key] = (result.byAccount[key] || 0) + 1;
      });
    } catch (_) { }
    return result;
  }

  async function listMemory(id) {
    const database = await db();
    if (!database?.memory_items || !id) return null;
    try { return (await database.memory_items.get(id)) || null; } catch (_) { return null; }
  }

  async function deleteMemory(id) {
    const database = await db();
    if (!database?.memory_items || !id) return false;
    try { await database.memory_items.update(id, { status: "deleted", updatedAt: Date.now() }); return true; } catch (_) { return false; }
  }

  async function restoreMemory(id) {
    const database = await db();
    if (!database?.memory_items || !id) return false;
    try { await database.memory_items.update(id, { status: "active", updatedAt: Date.now() }); return true; } catch (_) { return false; }
  }

  async function createMemory(accountId, conversationId, draft) {
    const now = Date.now();
    const item = schema()?.normalizeDraft ? { ...draft, accountId, sourceConversationId: conversationId, status: "active", createdAt: now, updatedAt: now } : { ...draft, accountId, sourceConversationId: conversationId, status: "active", createdAt: now, updatedAt: now };
    if (!item.id) item.id = `memory-${now}-${Math.floor(Math.random() * 1e6)}`;
    if (!item.memorySpaceKey) item.memorySpaceKey = spaceFor(accountId);
    return put(item);
  }

  window.QWQMemoryRepository = Object.freeze({
    ready,
    put,
    listByContact,
    recall,
    runSourceTimelineMutation,
    counts,
    listMemory,
    deleteMemory,
    restoreMemory,
    createMemory,
    memorySpaceKey: spaceFor
  });
})();
console.log("[Memory] repository 已加载");
