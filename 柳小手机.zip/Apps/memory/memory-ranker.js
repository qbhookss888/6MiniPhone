/* 清柳 Memory Ranker —— 排序打分（经典脚本）。 */
(function () {
  "use strict";
  if (window.QWQMemoryRanker) return;
  function rank(query, candidates) {
    const list = Array.isArray(candidates) ? candidates : [];
    const terms = String(query || "").toLowerCase().split(/[\s,，。]+/).filter((t) => t.length > 1);
    const scored = list.map((row) => {
      let score = Number(row?.importance) || 0;
      const hay = `${row?.content || ""} ${(row?.keywords || []).join(" ")}`.toLowerCase();
      const hits = terms.filter((t) => hay.includes(t)).length;
      score += (hits / Math.max(1, terms.length)) * 3;
      if (row?.status === "active") score += 0.2;
      return { row, score };
    });
    return scored.sort((a, b) => b.score - a.score).map((s) => s.row);
  }
  window.QWQMemoryRanker = Object.freeze({ rank });
})();
console.log("[Memory] ranker 已加载");
