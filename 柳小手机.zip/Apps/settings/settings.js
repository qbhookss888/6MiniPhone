/* ==========================================================================
 * 清柳 设置 App（经典脚本 / 无模块语法）
 *
 * window.SettingsApp = {
 *   openItem(itemId, itemName),        // 按 myPhoneConfig.settingsParentMenu
 *   hasChatVoiceConfiguration(),      // QQ 语音钩子
 *   speakChatVoice(text, options),
 *   stopChatVoice()
 * }
 *
 * 同时挂出可被其它 App 消费的能力模块（全部持久化到设置记录，QQ/记忆等读取）：
 *   window.QWQSettings      设置读写 + 变更订阅
 *   window.QWQNotifications 真实 Notification API + 应用内兜底 + 提示音
 *   window.QWQKeepAlive     屏幕常亮 (Wake Lock) + Worker 保活心跳
 *   window.QWQApi           API 连接测试（密钥仅存本机）
 *   window.QWQImageGen      文生图（可离线本地占位图 / 真实接口）
 *   window.QWQmcp           MCP 工具注册表 + 工具调用
 *   window.QWQAssistant     智慧助手（时间/上下文感知的本地建议）
 *
 * - 每个菜单项渲染为一个 ThemeCustomization.GlobalDrawer 面板；
 *   内容使用 ThemeCustomization.DrawerUI + loadSettingsState /
 *   saveSettingsStateNow 读写对应字段；渲染器统一签名 (itemId, itemName, DrawerUI)。
 * ========================================================================== */
(() => {
  "use strict";
  const TAG = "[Settings]";

  try {
    /* 只在设置 App 层补充“新增”的键；基础键沿用 ThemeCustomization.settingsDefaults。 */
    const CUSTOM_DEFAULTS = {
      // TTS 全局朗读开关
      ttsEnabled: false,
      // 账号安全（本地保护）
      autoLockMinutes: 5,
      pinHash: "",
      loginEvents: [],
      // 后台保活（真实系统能力）
      screenKeepOn: false,
      workerKeepAlive: false,
      // MCP
      mcpEnabled: true,
      mcpToolCalls: true,
      mcpForegroundConfirm: true,
      mcpTools: {},
      // 智慧助手
      assistantEnabled: true,
      assistantContext: true,
      assistantSuggestions: false,
      assistantMode: "standard",
      // 系统 / 诊断
      lastUpdateCheck: 0,
      storageCleanedBytes: 0
    };

    const API_PROVIDERS = [
      { value: "openai", label: "OpenAI" },
      { value: "deepseek", label: "DeepSeek" },
      { value: "anthropic", label: "Anthropic" },
      { value: "gemini", label: "Gemini" },
      { value: "compatible", label: "兼容代理 (OpenAI 格式)" }
    ];

    const IMAGE_SIZES = ["1024x1024", "768x768", "512x512", "256x256"];
    const ASPECT_RATIOS = ["1:1", "3:2", "2:3", "16:9", "9:16"];
    const IMAGE_QUALITIES = ["auto", "low", "medium", "high"];

    const LANGUAGES = [
      { value: "auto", label: "自动（普通话优先）" },
      { value: "zh-CN", label: "普通话（简体）" },
      { value: "zh-TW", label: "繁体中文" },
      { value: "yue", label: "粤语" },
      { value: "en-US", label: "英语（美国）" },
      { value: "ja-JP", label: "日语" }
    ];

    const AUTOLOCK_MINUTES = [
      { value: 1, label: "1 分钟" },
      { value: 5, label: "5 分钟" },
      { value: 15, label: "15 分钟" },
      { value: 30, label: "30 分钟" }
    ];

    const STORE_LABELS = {
      chatMessages: "聊天记录",
      chatSettings: "会话设置",
      chatGenerationJobs: "生成任务",
      contacts: "联系人",
      characters: "角色",
      characterTemplates: "角色模板",
      worldBooks: "世界书",
      worldBookEntries: "世界书条目",
      worldBookBindings: "世界书绑定",
      memoryItems: "记忆",
      themeState: "主题",
      homeScreenState: "主屏布局",
      musicState: "音乐",
      mediaAssets: "媒体",
      stickers: "表情包",
      stickerGroups: "表情分组",
      qqAccountProfiles: "QQ 账号",
      qqAccountState: "QQ 状态",
      wallets: "钱包",
      persistenceMeta: "持久化元数据",
      memory_items: "记忆",
      memory_evidence: "记忆证据",
      memory_lifecycle_events: "记忆生命周期",
      memory_embeddings: "语义向量",
      memory_recall_telemetry: "召回统计",
      memory_producer_checkpoints: "记忆检查点",
      calendarItems: "日历",
      healthRecords: "健康记录"
    };

    const RUNTIME = { draft: null, saveTimer: 0, revision: 0 };
    const settingListeners = new Map();

    const voiceCache = [];
    let activeUtterance = null;
    let activeCallbacks = null;
    let activeResolve = null;

    /* ---------------- 基础设施 ---------------- */
    function themeApi() {
      return window.ThemeCustomization || null;
    }

    function currentBody() {
      return document.getElementById("theme-drawer-body");
    }

    function drawerType() {
      return document.getElementById("theme-global-drawer")?.dataset?.type || "";
    }

    function loadConfig() {
      try {
        return window.__QWQ_CONFIG__ || null;
      } catch (error) {
        return null;
      }
    }

    async function loadMergedSettings() {
      const theme = themeApi();
      const defaults = theme?.settingsDefaults && typeof theme.settingsDefaults === "object"
        ? theme.settingsDefaults
        : {};
      const custom = { ...CUSTOM_DEFAULTS };
      let stored = {};
      try {
        if (theme?.loadSettingsState) {
          const value = await theme.loadSettingsState();
          if (value && typeof value === "object") stored = value;
        }
      } catch (error) {
        console.warn(TAG, "设置读取失败，使用默认值", error);
      }
      const merged = { ...defaults, ...custom, ...stored };
      Object.keys(custom).forEach((key) => {
        if (typeof merged[key] === "undefined") merged[key] = custom[key];
      });
      return merged;
    }

    async function persistSnapshot(snapshot) {
      const theme = themeApi();
      if (!theme?.saveSettingsStateNow) return false;
      try {
        await theme.saveSettingsStateNow(snapshot);
        return true;
      } catch (error) {
        console.warn(TAG, "设置保存失败", error);
        return false;
      }
    }

    function scheduleSave() {
      window.clearTimeout(RUNTIME.saveTimer);
      RUNTIME.saveTimer = window.setTimeout(() => {
        const snapshot = RUNTIME.draft && typeof RUNTIME.draft === "object" ? { ...RUNTIME.draft } : null;
        if (snapshot) void persistSnapshot(snapshot);
      }, 260);
    }

    async function ensureDraft() {
      if (!RUNTIME.draft) RUNTIME.draft = await loadMergedSettings();
      return RUNTIME.draft;
    }

    function emitSetting(key, value) {
      const set = settingListeners.get(key);
      if (!set || !set.size) return;
      set.forEach((fn) => {
        try { fn(value); } catch (error) { console.warn(TAG, "设置监听器错误", error); }
      });
    }

    function setValue(key, value) {
      if (!RUNTIME.draft) RUNTIME.draft = { ...CUSTOM_DEFAULTS };
      RUNTIME.draft[key] = value;
      scheduleSave();
      emitSetting(key, value);
    }

    /* ---------------- QWQSettings 全局访问器 ---------------- */
    const QWQSettings = {
      get(key) {
        return RUNTIME.draft && typeof RUNTIME.draft === "object" ? RUNTIME.draft[key] : undefined;
      },
      async getAll() {
        await ensureDraft();
        return RUNTIME.draft ? { ...RUNTIME.draft } : {};
      },
      async set(key, value) {
        await ensureDraft();
        setValue(key, value);
        return value;
      },
      async refresh() {
        RUNTIME.draft = null;
        return ensureDraft();
      },
      onChange(key, listener) {
        if (!settingListeners.has(key)) settingListeners.set(key, new Set());
        const set = settingListeners.get(key);
        set.add(listener);
        return () => set.delete(listener);
      }
    };

    /* ---------------- 通用小工具 ---------------- */
    function formatBytes(bytes) {
      const n = Number(bytes || 0);
      if (!Number.isFinite(n) || n < 0) return "0 B";
      if (n < 1024) return `${n} B`;
      if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
      if (n < 1073741824) return `${(n / 1048576).toFixed(1)} MB`;
      return `${(n / 1073741824).toFixed(2)} GB`;
    }

    function toast(message, tone = "info") {
      let host = document.getElementById("qwq-settings-toast-host");
      if (!host) {
        host = document.createElement("div");
        host.id = "qwq-settings-toast-host";
        host.setAttribute("aria-live", "polite");
        document.body.appendChild(host);
      }
      const el = document.createElement("div");
      el.className = "settings-toast settings-toast-" + tone;
      el.textContent = String(message ?? "");
      host.appendChild(el);
      requestAnimationFrame(() => el.classList.add("is-in"));
      window.setTimeout(() => {
        el.classList.add("is-out");
        window.setTimeout(() => el.remove(), 320);
      }, 2600);
    }

    /* ---------------- DOM 控件 ---------------- */
    function descBlock(title, lines) {
      const box = document.createElement("div");
      box.className = "settings-desc";
      const strong = document.createElement("strong");
      strong.textContent = String(title || "");
      box.appendChild(strong);
      (Array.isArray(lines) ? lines : [lines]).forEach((line) => {
        const p = document.createElement("p");
        p.textContent = String(line || "");
        box.appendChild(p);
      });
      return box;
    }

    function makeRow(label, note, control) {
      const rowEl = document.createElement("div");
      rowEl.className = "settings-row";
      const copy = document.createElement("div");
      copy.className = "settings-copy";
      const labelEl = document.createElement("div");
      labelEl.className = "settings-label";
      labelEl.textContent = label;
      copy.appendChild(labelEl);
      if (note) {
        const noteEl = document.createElement("div");
        noteEl.className = "settings-note";
        noteEl.textContent = note;
        copy.appendChild(noteEl);
      }
      rowEl.append(copy, control || document.createElement("span"));
      return rowEl;
    }

    function statusDot(on) {
      const wrap = document.createElement("span");
      wrap.className = "settings-status-dot" + (on ? "" : " is-off");
      const text = document.createElement("span");
      text.textContent = on ? "已开启" : "已关闭";
      wrap.appendChild(text);
      return wrap;
    }

    function stateRow(label, note, on, onText, offText) {
      const rowEl = document.createElement("div");
      rowEl.className = "settings-row";
      rowEl.dataset.stateRow = on ? "on" : "off";
      const copy = document.createElement("div");
      copy.className = "settings-copy";
      const labelEl = document.createElement("div");
      labelEl.className = "settings-label";
      labelEl.textContent = label;
      copy.appendChild(labelEl);
      if (note) {
        const noteEl = document.createElement("div");
        noteEl.className = "settings-note";
        noteEl.textContent = note;
        copy.appendChild(noteEl);
      }
      const dot = document.createElement("span");
      dot.className = "settings-status-dot" + (on ? "" : " is-off");
      const text = document.createElement("span");
      text.textContent = on ? onText : offText;
      dot.appendChild(text);
      rowEl.append(copy, dot);
      return rowEl;
    }

    function switchControl(checked, onToggle) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "ui-switch" + (checked ? " is-on" : "");
      button.setAttribute("role", "switch");
      button.setAttribute("aria-checked", checked ? "true" : "false");
      button.addEventListener("click", () => {
        const next = !button.classList.contains("is-on");
        button.classList.toggle("is-on", next);
        button.setAttribute("aria-checked", next ? "true" : "false");
        try { onToggle(next); } catch (error) { console.warn(TAG, error); }
      });
      return button;
    }

    function selectControl(options, value, onChange) {
      const select = document.createElement("select");
      select.className = "settings-select";
      select.setAttribute("aria-label", "选项");
      const normalized = Array.isArray(options) ? options : [];
      normalized.forEach((option) => {
        const item = document.createElement("option");
        const optionValue = typeof option === "object" && option !== null ? option.value : option;
        const optionLabel = typeof option === "object" && option !== null ? option.label : option;
        item.value = String(optionValue);
        item.textContent = String(optionLabel);
        select.appendChild(item);
      });
      const allowed = normalized.map((option) => String(typeof option === "object" && option !== null ? option.value : option));
      const first = normalized.length ? (typeof normalized[0] === "object" ? normalized[0].value : normalized[0]) : "";
      select.value = allowed.includes(String(value)) ? String(value) : String(first ?? "");
      select.addEventListener("change", () => {
        try { onChange(select.value); } catch (error) { console.warn(TAG, error); }
      });
      return select;
    }

    function textControl(value, onChange, options = {}) {
      const input = document.createElement("input");
      input.className = "settings-input";
      input.type = options.type === "password" ? "password" : "text";
      input.value = String(value ?? "");
      input.placeholder = String(options.placeholder ?? "");
      if (options.inputMode) input.setAttribute("inputmode", options.inputMode);
      if (options.autocomplete) input.setAttribute("autocomplete", options.autocomplete);
      input.addEventListener("change", () => {
        try { onChange(input.value); } catch (error) { console.warn(TAG, error); }
      });
      return input;
    }

    function textAreaControl(value, onChange, placeholder) {
      const area = document.createElement("textarea");
      area.className = "settings-textarea";
      area.value = String(value ?? "");
      area.placeholder = String(placeholder ?? "");
      area.addEventListener("change", () => {
        try { onChange(area.value); } catch (error) { console.warn(TAG, error); }
      });
      return area;
    }

    function fieldBlock(label, input, note) {
      const wrap = document.createElement("label");
      wrap.className = "settings-field";
      const labelEl = document.createElement("span");
      labelEl.className = "settings-field-label";
      labelEl.textContent = label;
      wrap.append(labelEl, input);
      if (note) {
        const noteEl = document.createElement("div");
        noteEl.className = "settings-note";
        noteEl.textContent = note;
        wrap.appendChild(noteEl);
      }
      return wrap;
    }

    function infoValueRow(label, value) {
      const rowEl = document.createElement("div");
      rowEl.className = "settings-row";
      const labelEl = document.createElement("div");
      labelEl.className = "settings-label";
      labelEl.textContent = label;
      const valueEl = document.createElement("div");
      valueEl.className = "settings-value";
      valueEl.textContent = String(value ?? "");
      rowEl.append(labelEl, valueEl);
      return rowEl;
    }

    function actionRow(...buttons) {
      const wrap = document.createElement("div");
      wrap.className = "settings-action-row";
      buttons.filter(Boolean).forEach((b) => wrap.appendChild(b));
      return wrap;
    }

    function resultNote() {
      const line = document.createElement("div");
      line.className = "settings-result-note";
      line.style.display = "none";
      return line;
    }

    function setResultNote(el, text, ok) {
      if (!el) return;
      el.textContent = text;
      el.className = "settings-result-note is-" + (ok ? "ok" : "bad");
      el.style.display = "block";
    }

    /* ---------------- TTS 引擎 ---------------- */
    function speechSupported() {
      return typeof window !== "undefined"
        && typeof window.speechSynthesis !== "undefined"
        && typeof window.SpeechSynthesisUtterance !== "undefined";
    }

    function refreshVoices() {
      try {
        voiceCache.length = 0;
        const voices = window.speechSynthesis?.getVoices?.() || [];
        voices.forEach((voice) => voiceCache.push(voice));
      } catch (error) {
        console.warn(TAG, "音色列表读取失败", error);
      }
    }

    function pickVoice(lang, name) {
      if (!speechSupported()) return null;
      if (!voiceCache.length) refreshVoices();
      if (!voiceCache.length) return null;
      if (name && String(name).trim()) {
        const exact = voiceCache.find((voice) => voice.name === String(name).trim());
        if (exact) return exact;
      }
      if (lang && String(lang) !== "auto" && String(lang) !== "yue") {
        const matched = voiceCache.find((voice) => String(voice.lang || "").toLowerCase().startsWith(String(lang).toLowerCase()));
        if (matched) return matched;
      }
      const zh = voiceCache.find((voice) => String(voice.lang || "").toLowerCase().startsWith("zh-cn"))
        || voiceCache.find((voice) => String(voice.lang || "").toLowerCase().startsWith("zh"))
        || voiceCache[0];
      return zh || null;
    }

    function finishActiveVoice() {
      const resolve = activeResolve;
      const callbacks = activeCallbacks;
      activeUtterance = null;
      activeCallbacks = null;
      activeResolve = null;
      try { callbacks?.onEnd?.(); } catch (error) { console.warn(TAG, error); }
      if (typeof resolve === "function") resolve(true);
    }

    async function hasChatVoiceConfiguration() {
      try {
        if (!speechSupported()) return false;
        const settings = await loadMergedSettings();
        return settings.ttsEnabled === true;
      } catch (error) {
        console.warn(TAG, "hasChatVoiceConfiguration 失败", error);
        return false;
      }
    }

    function speakChatVoice(text, options = {}) {
      const content = String(text ?? "");
      const settings = RUNTIME.draft && typeof RUNTIME.draft === "object" ? RUNTIME.draft : {};
      return new Promise((resolve) => {
        if (!speechSupported()) {
          resolve(true);
          return;
        }
        try {
          const utterance = new SpeechSynthesisUtterance(content || " ");
          const lang = String(options.lang || settings.ttsLanguage || "auto");
          const voiceName = String(options.voice || settings.ttsVoice || "");
          const voice = pickVoice(lang, voiceName);
          if (voice) utterance.voice = voice;
          const langCode = String(settings.ttsLanguage || "auto");
          if (langCode !== "auto") utterance.lang = String(langCode === "yue" ? "zh-yue" : langCode);
          else if (voice?.lang) utterance.lang = voice.lang;
          else utterance.lang = "zh-CN";

          const speed = Number(options.speed ?? options.rate ?? settings.ttsRate ?? 1);
          const rate = Number.isFinite(speed) ? Math.min(2, Math.max(0.5, speed)) : 1;
          const pitchRaw = Number(settings.ttsPitch ?? 1);
          const volumeRaw = Number(settings.ttsVolume ?? 1);
          utterance.rate = rate;
          utterance.pitch = Number.isFinite(pitchRaw) ? Math.min(2, Math.max(0, pitchRaw)) : 1;
          utterance.volume = Number.isFinite(volumeRaw) ? Math.min(1, Math.max(0, volumeRaw)) : 1;

          if (activeUtterance) {
            try { window.speechSynthesis.cancel(); } catch (error) { /* 忽略 */ }
            finishActiveVoice();
          }
          let done = false;
          const settle = () => {
            if (done) return;
            done = true;
            if (activeUtterance === utterance) finishActiveVoice();
            else resolve(true);
          };
          utterance.onstart = () => {
            try { options.onStart?.(); } catch (error) { console.warn(TAG, error); }
          };
          utterance.onend = settle;
          utterance.onerror = settle;

          activeUtterance = utterance;
          activeCallbacks = { onEnd: options.onEnd };
          activeResolve = resolve;
          window.speechSynthesis.speak(utterance);
        } catch (error) {
          console.warn(TAG, "语音朗读失败", error);
          resolve(true);
        }
      });
    }

    function stopChatVoice() {
      try {
        if (activeUtterance && window.speechSynthesis) window.speechSynthesis.cancel();
        if (activeUtterance) finishActiveVoice();
      } catch (error) {
        console.warn(TAG, "停止朗读失败", error);
        try { if (typeof activeResolve === "function") activeResolve(true); } catch (inner) { /* 忽略 */ }
        activeUtterance = null;
        activeCallbacks = null;
        activeResolve = null;
      }
    }

    /* ---------------- 能力模块：通知 ---------------- */
    let beepCtx = null;
    const QWQNotifications = (() => {
      function supported() {
        return typeof window !== "undefined" && "Notification" in window;
      }
      async function getPermission() {
        if (!supported()) return "unsupported";
        return Notification.permission;
      }
      async function request() {
        if (!supported()) return "unsupported";
        try { return await Notification.requestPermission(); } catch (error) { return "denied"; }
      }
      function beep() {
        try {
          const AC = window.AudioContext || window.webkitAudioContext;
          if (!AC) return false;
          beepCtx = beepCtx || new AC();
          const ctx = beepCtx;
          if (ctx.state === "suspended") void ctx.resume();
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sine";
          osc.frequency.value = 880;
          gain.gain.setValueAtTime(0.0001, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.28);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.3);
          return true;
        } catch (error) { return false; }
      }
      async function show(title, body, opts = {}) {
        const s = await QWQSettings.getAll();
        if (s.notifications === false) return false;
        if (s.notificationSound === true) beep();
        const previewOn = s.notificationPreview !== false;
        const shownBody = previewOn ? String(body ?? "") : "（通知预览已关闭，不显示正文）";
        let used = false;
        if (supported()) {
          const perm = await getPermission();
          if (perm === "granted") {
            try {
              const n = new Notification(String(title ?? "清柳"), {
                body: shownBody,
                icon: opts.icon || "./icon/qwq-192.png",
                tag: "qwq-" + Date.now()
              });
              if (typeof opts.onclick === "function") n.onclick = opts.onclick;
              window.setTimeout(() => { try { n.close(); } catch (e) { /* 忽略 */ } }, 6000);
              used = true;
            } catch (error) { used = false; }
          }
        }
        if (!used) toast("🔔 " + (title || "清柳") + "：" + (previewOn ? (body || "") : "已隐藏正文"), "info");
        return true;
      }
      return {
        supported,
        getPermission,
        request,
        show,
        beep,
        test: async () => {
          const granted = await show("清柳 通知测试", "这是一条来自「设置 · 通知」的测试提醒。", { icon: "./icon/qwq-192.png" });
          return granted;
        }
      };
    })();

    /* ---------------- 能力模块：后台保活 ---------------- */
    const QWQKeepAlive = (() => {
      let wakeSentinel = null;
      let worker = null;
      let workerUrl = null;
      const state = { screen: false, worker: false };
      const wakeSupported = typeof navigator !== "undefined" && "wakeLock" in navigator;

      async function acquireWake() {
        if (!wakeSupported) return false;
        try {
          wakeSentinel = await navigator.wakeLock.request("screen");
          state.screen = true;
          return true;
        } catch (error) {
          state.screen = false;
          return false;
        }
      }
      function releaseWake() {
        try { wakeSentinel?.release?.(); } catch (error) { /* 忽略 */ }
        wakeSentinel = null;
        state.screen = false;
      }
      function startWorker() {
        stopWorker();
        try {
          const code = "setInterval(function(){try{postMessage({t:'qwq-keepalive',ts:Date.now()})}catch(e){}}, 25000);";
          const blob = new Blob([code], { type: "text/javascript" });
          workerUrl = URL.createObjectURL(blob);
          worker = new Worker(workerUrl);
          worker.onmessage = () => { /* 心跳到达，维持上下文活跃 */ };
          state.worker = true;
        } catch (error) {
          state.worker = false;
        }
      }
      function stopWorker() {
        try { worker?.terminate(); } catch (error) { /* 忽略 */ }
        if (workerUrl) { try { URL.revokeObjectURL(workerUrl); } catch (e) { /* 忽略 */ } workerUrl = null; }
        worker = null;
        state.worker = false;
      }
      function onVisibility() {
        if (document.visibilityState === "visible" && state.screen && wakeSupported) void acquireWake();
      }
      if (typeof document !== "undefined") document.addEventListener?.("visibilitychange", onVisibility);

      return {
        supported: () => ({ screen: wakeSupported, worker: typeof Worker !== "undefined" }),
        setScreen: async (on) => { if (on) await acquireWake(); else releaseWake(); return { ...state }; },
        setWorker: (on) => { if (on) startWorker(); else stopWorker(); return { ...state }; },
        status: () => ({ ...state, screenSupported: wakeSupported, workerSupported: typeof Worker !== "undefined" }),
        dispose: () => { stopWorker(); releaseWake(); }
      };
    })();

    /* ---------------- 能力模块：API 测试 ---------------- */
    const QWQApi = (() => {
      async function get() {
        const s = await QWQSettings.getAll();
        return {
          provider: s.apiProvider || "openai",
          baseUrl: String(s.apiBaseUrl || "").replace(/\/+$/, ""),
          key: String(s.apiKey || ""),
          model: String(s.apiModel || ""),
          temperature: Number(s.apiTemperature ?? 0.7),
          stream: s.apiStream === true
        };
      }
      async function test(timeoutMs = 9000) {
        const cfg = await get();
        if (!cfg.key) return { ok: false, code: "no-key", message: "未填写 API Key，无法发起测试。密钥仅保存在本机。" };
        if (!cfg.baseUrl) return { ok: false, code: "no-url", message: "未填写 Endpoint，无法发起测试。" };
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        try {
          const headers = { "Content-Type": "application/json" };
          if (cfg.provider === "anthropic") {
            headers["x-api-key"] = cfg.key;
            headers["anthropic-version"] = "2023-06-01";
          } else {
            headers["Authorization"] = "Bearer " + cfg.key;
          }
          const url = cfg.baseUrl + "/chat/completions";
          const res = await fetch(url, {
            method: "POST",
            headers,
            body: JSON.stringify({
              model: cfg.model || "gpt-4o-mini",
              messages: [{ role: "user", content: "ping" }],
              max_tokens: 5,
              stream: false
            }),
            signal: controller.signal
          });
          clearTimeout(timer);
          if (res.status === 401 || res.status === 403) return { ok: false, code: "auth", message: `鉴权失败（HTTP ${res.status}），请检查 API Key。` };
          if (res.status === 429) return { ok: false, code: "rate", message: "请求频率受限（HTTP 429）。" };
          if (!res.ok) return { ok: false, code: "http", message: `服务端返回 HTTP ${res.status}。` };
          return { ok: true, code: "ok", message: `连接成功，${cfg.provider} 模型响应正常。` };
        } catch (err) {
          clearTimeout(timer);
          if (err && err.name === "AbortError") return { ok: false, code: "timeout", message: "请求超时，请检查网络或 Endpoint。" };
          return { ok: false, code: "cors", message: "连接失败：浏览器跨域（CORS）或网络不可达。密钥未外发，仅保存在本机。" };
        }
      }
      return { get, test };
    })();

    /* ---------------- 能力模块：图像生成 ---------------- */
    const QWQImageGen = (() => {
      function parseSize(v) {
        const m = String(v || "").match(/(\d+)x(\d+)/);
        return m ? { w: Number(m[1]), h: Number(m[2]) } : { w: 512, h: 512 };
      }
      function hash(str) {
        let h = 2166136261;
        for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
        return h >>> 0;
      }
      function placeholder(prompt, opts = {}) {
        const { w, h } = parseSize(opts.size || "1024x1024");
        const cap = Math.min(w, h, 768);
        const scale = cap / Math.min(w, h);
        const cw = Math.max(1, Math.round(w * scale));
        const ch = Math.max(1, Math.round(h * scale));
        const canvas = document.createElement("canvas");
        canvas.width = cw; canvas.height = ch;
        const ctx = canvas.getContext("2d");
        const seed = hash(String(prompt || ""));
        const hue = seed % 360;
        const hue2 = (hue + 90 + (seed % 60)) % 360;
        const g = ctx.createLinearGradient(0, 0, cw, ch);
        g.addColorStop(0, `hsl(${hue},68%,55%)`);
        g.addColorStop(1, `hsl(${hue2},68%,44%)`);
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, cw, ch);
        ctx.globalAlpha = 0.14;
        for (let i = 0; i < 42; i++) {
          ctx.beginPath();
          const x = (seed * (i + 3)) % cw;
          const y = (seed * (i + 7)) % ch;
          const radius = 2 + ((seed >>> (i % 8)) % 22);
          ctx.arc(x, y, radius, 0, Math.PI * 2);
          ctx.fillStyle = "#ffffff";
          ctx.fill();
        }
        ctx.globalAlpha = 1;
        ctx.fillStyle = "rgba(0,0,0,0.35)";
        ctx.fillRect(0, ch - 34, cw, 34);
        ctx.fillStyle = "#ffffff";
        ctx.font = "14px system-ui, sans-serif";
        ctx.textBaseline = "bottom";
        const label = String(prompt || "（无提示词）").slice(0, 42) + " · " + (opts.size || "1024x1024") + " · 占位图";
        ctx.fillText(label, 10, ch - 10);
        return { dataUrl: canvas.toDataURL("image/png"), width: cw, height: ch, source: "local-placeholder" };
      }
      async function generate(prompt, opts = {}) {
        const s = await QWQSettings.getAll();
        const baseUrl = String(s.imageBaseUrl || "").replace(/\/+$/, "");
        const key = String(s.imageApiKey || "");
        const model = String(s.imageModel || "");
        if (key && baseUrl && model && typeof fetch !== "undefined") {
          try {
            const res = await fetch(baseUrl + "/images/generations", {
              method: "POST",
              headers: { "Content-Type": "application/json", "Authorization": "Bearer " + key },
              body: JSON.stringify({
                model,
                prompt: String(prompt || ""),
                n: Number(s.imageCount || 1),
                size: s.imageSize || "1024x1024",
                quality: s.imageQuality || "auto"
              }),
              signal: (typeof AbortSignal !== "undefined" && AbortSignal.timeout) ? AbortSignal.timeout(15000) : undefined
            });
            if (res.ok) {
              const data = await res.json();
              const item = data?.data?.[0];
              if (item?.url) return { dataUrl: item.url, width: item.width, height: item.height, source: "api" };
              if (item?.b64_json) return { dataUrl: "data:image/png;base64," + item.b64_json, width: item.width, height: item.height, source: "api" };
            }
          } catch (error) { /* 回退到本地占位图 */ }
        }
        return placeholder(prompt, { size: s.imageSize || opts.size });
      }
      return { placeholder, generate, parseSize };
    })();

    /* ---------------- 能力模块：MCP 工具 ---------------- */
    const MCP_TOOLS = [
      { id: "calculator", name: "计算器", desc: "四则运算与表达式求值", kind: "内置" },
      { id: "time", name: "时间", desc: "当前本地时间", kind: "内置" },
      { id: "weather", name: "天气查询", desc: "结合天气 App 数据", kind: "数据源" },
      { id: "search", name: "网页搜索", desc: "检索外部信息", kind: "外部" },
      { id: "translate", name: "翻译", desc: "多语言翻译", kind: "外部" }
    ];
    const QWQmcp = (() => {
      function toolEnabled(id, s) {
        const overrides = (s && s.mcpTools) || {};
        if (id in overrides) return overrides[id] !== false;
        return true;
      }
      function list(s) {
        return MCP_TOOLS.map((tool) => ({ ...tool, enabled: toolEnabled(tool.id, s) }));
      }
      function isEnabled(s) {
        return s.mcpEnabled !== false && s.mcpToolCalls !== false;
      }
      async function run(toolId, input) {
        const s = await QWQSettings.getAll();
        if (!isEnabled(s)) return { ok: false, message: "MCP 工具调用已关闭（请在总开关开启）。" };
        if (!toolEnabled(toolId, s)) return { ok: false, message: "该工具未启用。" };
        if (toolId === "calculator") {
          const expr = String(input || "1+2*3");
          if (!/^[-+*/().\d\s%]+$/.test(expr)) return { ok: false, message: "无效表达式：" + expr };
          try {
            const value = Function("return ((" + expr + "));")();
            return { ok: Number.isFinite(value), result: value, message: `${expr} = ${value}` };
          } catch (error) {
            return { ok: false, message: "无法求值：" + expr };
          }
        }
        if (toolId === "time") {
          return { ok: true, result: new Date().toLocaleString("zh-CN", { hour12: false }) };
        }
        return { ok: true, result: "（演示工具；真实结果需接入对应服务）" };
      }
      return { tools: MCP_TOOLS, list, isEnabled, run, toolEnabled };
    })();

    /* ---------------- 能力模块：智慧助手 ---------------- */
    const QWQAssistant = (() => {
      function hourGreeting(hour) {
        if (hour < 5) return "夜深了";
        if (hour < 9) return "早上好";
        if (hour < 12) return "上午好";
        if (hour < 14) return "中午好";
        if (hour < 18) return "下午好";
        return "晚上好";
      }
      async function suggest(context = {}) {
        const s = await QWQSettings.getAll();
        if (s.assistantEnabled === false) return { ok: false, message: "智慧助手已关闭。" };
        const parts = [hourGreeting(new Date().getHours()) + "，我是 清柳 智慧助手。"];
        if (s.assistantContext !== false) parts.push("我已结合多轮上下文为你优化表达。");
        if (s.assistantSuggestions === true) {
          const mode = String(s.assistantMode || "standard");
          const tips = {
            standard: "我可以帮你整理信息、写文案、查资料。",
            concise: "要我提炼要点、更简洁吗？",
            creative: "想不想来点有创意的想法？"
          };
          parts.push(tips[mode] || tips.standard);
        }
        if (context.memoryHint) parts.push("关于「" + context.memoryHint + "」，我还能帮你回忆相关记录。");
        return { ok: true, text: parts.join(" "), mode: String(s.assistantMode || "standard") };
      }
      return { suggest, hourGreeting };
    })();

    /* ---------------- 抽屉渲染器 ---------------- */
    function safeCreateSection(title) {
      const section = document.createElement("section");
      section.className = "ui-section";
      section.dataset.uiTemplate = "global-drawer-section";
      if (title) {
        const heading = document.createElement("h3");
        heading.className = "ui-section-title";
        heading.textContent = title;
        section.appendChild(heading);
      }
      return section;
    }

    function sectionOf(DrawerUI, title) {
      let section = null;
      try {
        if (DrawerUI && typeof DrawerUI.createSection === "function") {
          section = DrawerUI.createSection(title);
        }
      } catch (error) {
        console.warn(TAG, "createSection 调用失败，使用本地回退", error);
        section = null;
      }
      if (!section) section = safeCreateSection(title);
      currentBody()?.appendChild(section);
      return section;
    }

    function rangeRowOf(DrawerUI, section, label, value, min, max, step, format, onInput) {
      if (!DrawerUI || typeof DrawerUI.createRangeRow !== "function") {
        // 回退：直接用全局控件
        const row = DrawerUI ? null : null;
        return null;
      }
      const row = DrawerUI.createRangeRow(label, value, min, max, step, format, onInput);
      if (row && section) section.appendChild(row);
      return row;
    }

    function actionButtonOf(DrawerUI, section, label, icon, className, onClick) {
      let button = null;
      try {
        if (DrawerUI && typeof DrawerUI.createActionButton === "function") {
          button = DrawerUI.createActionButton(label, icon, className || "");
        }
      } catch (error) {
        button = null;
      }
      if (!button) {
        button = document.createElement("button");
        button.type = "button";
        button.className = ("ui-action-button " + (className || "")).trim();
        const text = document.createElement("span");
        text.textContent = label;
        button.appendChild(text);
      }
      if (typeof onClick === "function") button.addEventListener("click", onClick);
      if (button && section) section.appendChild(button);
      return button;
    }

    function sensitiveConfirmGuard() {
      // 敏感操作确认：开启时破坏性动作需二次确认
      return QWQSettings.get("sensitiveConfirm") !== false;
    }

    /* ---------- 1. 账号安全 ---------- */
    async function sha256hex(text) {
      try {
        if (typeof crypto !== "undefined" && crypto.subtle) {
          const data = new TextEncoder().encode("qwq-pin::" + text);
          const digest = await crypto.subtle.digest("SHA-256", data);
          return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
        }
      } catch (error) { /* 回退 */ }
      let h = 2166136261;
      const str = "qwq-pin::" + text;
      for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
      return (h >>> 0).toString(16).padStart(8, "0");
    }

    let lockTimer = 0;
    function armLock() {
      window.clearTimeout(lockTimer);
      const s = QWQSettings;
      const on = s.get("autoLock") === true && Number(s.get("autoLockMinutes") || 5) > 0;
      if (!on) return;
      lockTimer = window.setTimeout(() => { if (document.visibilityState !== "hidden") showLockOverlay(); }, Number(s.get("autoLockMinutes") || 5) * 60000);
    }

    function showLockOverlay() {
      const theme = themeApi();
      const modal = theme?.GlobalModal;
      if (!modal?.prompt) {
        // 无弹窗时用一个全屏遮罩
        return;
      }
      const pinSet = String(QWQSettings.get("pinHash") || "") !== "";
      const inputEl = document.createElement("input");
      inputEl.type = "password";
      inputEl.inputMode = "numeric";
      inputEl.autocomplete = "off";
      inputEl.style.cssText = "width:100%;height:44px;padding:0 14px;border:1px solid var(--ui-line,#e3e3e7);border-radius:13px;font:inherit;background:var(--ui-surface,#fff)";
      if (pinSet) inputEl.placeholder = "输入锁屏 PIN";
      else inputEl.placeholder = "未设置 PIN，任意输入即可解锁";

      const extra = document.createElement("div");
      extra.style.cssText = "display:grid;gap:8px;width:100%";
      extra.appendChild(inputEl);

      let unlocked = false;
      modal.prompt({
        title: "已锁屏",
        message: pinSet ? "请输入锁屏 PIN 解锁。" : "未设置 PIN，任意输入即可解锁。",
        input: false,
        content: extra,
        confirmLabel: "解锁",
        cancelLabel: "取消",
        action: async (payload) => {
          const guess = String((payload?.content?.querySelector?.("input")?.value) ?? "");
          if (!pinSet) { unlocked = true; return true; }
          const match = await sha256hex(guess);
          if (match === String(QWQSettings.get("pinHash") || "")) {
            unlocked = true;
            return true;
          }
          toast("PIN 不正确，请重试", "bad");
          armLock();
          return false; // 保持弹窗
        },
        cancelAction: () => { /* 取消不解锁，重新计时 */ }
      });
    }

    function renderAccountSecurity(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      const pinSet = String(s.get("pinHash") || "") !== "";
      const events = Array.isArray(s.get("loginEvents")) ? s.get("loginEvents") : [];
      body.appendChild(descBlock("账号安全", [
        "管理账号保护策略、锁屏 PIN 与登录记录。PIN 以 SHA-256 哈希保存在本机设置中，不明文外发。"
      ]));

      const section = sectionOf(DrawerUI);
      section.appendChild(makeRow("账号保护", "开启后关键操作需二次确认", switchControl(s.get("accountProtection") === true, (next) => setValue("accountProtection", next))));
      section.appendChild(makeRow("敏感操作确认", "删除 / 清空等破坏性操作前弹确认", switchControl(s.get("sensitiveConfirm") === true, (next) => setValue("sensitiveConfirm", next))));

      const pinSection = sectionOf(DrawerUI, "锁屏 PIN");
      const pinInput = textControl("", (next) => { /* 输入暂存，点击保存 */ }, { type: "password", inputMode: "numeric", placeholder: pinSet ? "已设置（留空保持不变）" : "输入 4-8 位数字 PIN", autocomplete: "off" });
      pinSection.appendChild(fieldBlock("设置 PIN", pinInput, "保存后「自动锁屏」将要求输入该 PIN 解锁"));
      pinSection.appendChild(stateRow("PIN 状态", pinSet ? "已设置锁屏 PIN" : "未设置 PIN（任意输入即可解锁）", pinSet, "已设置", "未设置"));
      const pinBtn = actionButtonOf(DrawerUI, pinSection, pinSet ? "更新 PIN" : "设置 PIN", "key-round", "is-primary", async () => {
        const raw = String(pinInput.value || "").trim();
        if (!raw) { toast("请输入 PIN", "bad"); return; }
        if (!/^\d{4,8}$/.test(raw)) { toast("PIN 需为 4-8 位数字", "bad"); return; }
        await setValue("pinHash", await sha256hex(raw));
        pinInput.value = "";
        toast("PIN 已保存", "ok");
      });
      if (pinBtn) pinSection.appendChild(pinBtn);

      const lockSection = sectionOf(DrawerUI, "自动锁屏");
      const lockToggle = switchControl(s.get("autoLock") === true, (next) => {
        setValue("autoLock", next);
        if (next) armLock(); else window.clearTimeout(lockTimer);
      });
      lockSection.appendChild(makeRow("自动锁屏", "无操作超时后自动锁定", lockToggle));
      lockSection.appendChild(makeRow("锁屏超时", "无操作时长", selectControl(AUTOLOCK_MINUTES, s.get("autoLockMinutes") || 5, (next) => setValue("autoLockMinutes", Number(next)))));
      actionButtonOf(DrawerUI, lockSection, "立即锁屏", "lock", "", () => { showLockOverlay(); });
      actionButtonOf(DrawerUI, lockSection, "解除锁屏", "unlock", "is-danger", () => { window.clearTimeout(lockTimer); toast("已解除锁屏", "ok"); });

      if (events.length) {
        const histSection = sectionOf(DrawerUI, "登录记录");
        events.slice(-5).reverse().forEach((evt) => {
          histSection.appendChild(infoValueRow(new Date(evt.at).toLocaleString("zh-CN"), evt.note || "登录"));
        });
        actionButtonOf(DrawerUI, histSection, "清除记录", "trash-can", "is-danger", () => {
          if (sensitiveConfirmGuard()) {
            const m = themeApi()?.GlobalModal;
            if (m?.confirm) m.confirm({ title: "清除登录记录", message: "将清除全部登录记录，此操作不可撤销。", confirmLabel: "清除", danger: true, action: () => { setValue("loginEvents", []); toast("已清除登录记录", "ok"); } });
          } else { setValue("loginEvents", []); toast("已清除登录记录", "ok"); }
        });
      }

      const secSection = sectionOf(DrawerUI, "账号操作");
      actionButtonOf(DrawerUI, secSection, "记录一次登录", "user-check", "", () => {
        const evts = Array.isArray(s.get("loginEvents")) ? s.get("loginEvents").slice() : [];
        evts.push({ at: Date.now(), note: "本机登录" });
        setValue("loginEvents", evts.slice(-20));
        toast("已记录登录", "ok");
      });
      actionButtonOf(DrawerUI, secSection, "退出当前账号", "log-out", "is-danger", () => {
        const m = themeApi()?.GlobalModal;
        const doIt = () => { setValue("loginEvents", []); toast("已退出账号（演示）", "info"); };
        if (sensitiveConfirmGuard() && m?.confirm) m.confirm({ title: "退出账号", message: "确认退出当前账号？本地数据保留。", confirmLabel: "退出", danger: true, action: doIt });
        else doIt();
      });
    }

    /* ---------- 2. 通知 ---------- */
    async function renderNotifications(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      const perm = await QWQNotifications.getPermission();
      const permText = perm === "granted" ? "已授权（可弹系统通知）"
        : perm === "denied" ? "已拒绝（将使用应用内提醒）"
        : perm === "unsupported" ? "浏览器不支持（将使用应用内提醒）"
        : "未授权（可点击下方授权）";
      body.appendChild(descBlock("通知", [
        "控制新消息提醒方式。总开关关闭时不再提醒。系统通知需授权；被拒绝或未支持时自动回退为应用内横幅提醒。"
      ]));

      const section = sectionOf(DrawerUI);
      section.appendChild(makeRow("通知", "允许接收新消息提醒", switchControl(s.get("notifications") !== false, (next) => setValue("notifications", next))));
      section.appendChild(makeRow("通知预览", "锁屏 / 横幅显示消息正文", switchControl(s.get("notificationPreview") !== false, (next) => setValue("notificationPreview", next))));
      section.appendChild(makeRow("通知声音", "收到通知时播放提示音", switchControl(s.get("notificationSound") === true, (next) => setValue("notificationSound", next))));

      const permSection = sectionOf(DrawerUI, "系统通知权限");
      const permState = stateRow("当前权限", "授权后弹出系统通知，否则回退应用内提醒", perm === "granted", "已授权", "未授权");
      permSection.appendChild(permState);
      const permDot = permState.querySelector(".settings-status-dot");
      const permLabel = permState.querySelector(".settings-status-dot span");
      const setPermText = (text, on) => {
        if (permDot) permDot.classList.toggle("is-off", !on);
        if (permLabel) permLabel.textContent = text;
      };
      setPermText(permText, perm === "granted");
      actionButtonOf(DrawerUI, permSection, "授权系统通知", "badge-check", "is-primary", async () => {
        const p = await QWQNotifications.request();
        if (p === "granted") {
          setPermText("已授权", true);
          await QWQNotifications.test();
          toast("系统通知已授权，已发送一条测试通知", "ok");
        } else {
          setPermText(p === "unsupported" ? "不支持（应用内提醒）" : "未授权（应用内提醒）", false);
          toast("未授权系统通知，将使用应用内提醒", "info");
        }
      });
      actionButtonOf(DrawerUI, permSection, "发送测试通知", "bell", "", () => { QWQNotifications.test().then((used) => { if (!used) toast("通知总开关已关闭", "info"); }); });
      actionButtonOf(DrawerUI, permSection, "播放提示音", "volume-high", "", () => { const ok = QWQNotifications.beep(); toast(ok ? "已播放提示音" : "当前浏览器不支持提示音", ok ? "ok" : "info"); });
    }

    /* ---------- 3. 后台保活 ---------- */
    async function renderBackgroundKeepalive(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      const status = QWQKeepAlive.status();
      const support = QWQKeepAlive.supported();
      body.appendChild(descBlock("后台保活", [
        "切到后台时尽量维持会话活跃。屏幕常亮使用系统 Wake Lock，保活心跳使用后台 Web Worker；浏览器对后台任务有限制，实际效果取决于系统策略。"
      ]));

      const section = sectionOf(DrawerUI);
      section.appendChild(makeRow("后台保活", "尽量保持会话活跃（供 App 读取）", switchControl(s.get("keepalive") !== false, (next) => setValue("keepalive", next))));
      section.appendChild(makeRow("隐藏页任务", "允许页面不可见时继续运行后台任务（供 App 读取）", switchControl(s.get("hiddenPageTasks") !== false, (next) => setValue("hiddenPageTasks", next))));

      const sysSection = sectionOf(DrawerUI, "系统级保活");
      const screenNote = support.screen ? "使用 Wake Lock API 保持屏幕点亮" : "当前浏览器不支持 Wake Lock";
      const screenToggle = switchControl(s.get("screenKeepOn") === true, async (next) => {
        await QWQKeepAlive.setScreen(next);
        setValue("screenKeepOn", next);
      });
      sysSection.appendChild(makeRow("屏幕常亮", screenNote, screenToggle));
      const workerNote = support.worker ? "后台 Worker 每 25s 心跳，维持上下文" : "当前浏览器不支持 Worker";
      const workerToggle = switchControl(s.get("workerKeepAlive") === true, (next) => {
        QWQKeepAlive.setWorker(next);
        setValue("workerKeepAlive", next);
      });
      sysSection.appendChild(makeRow("保活心跳", workerNote, workerToggle));

      const statusSection = sectionOf(DrawerUI, "实时状态");
      const live = QWQKeepAlive.status();
      statusSection.appendChild(stateRow("屏幕常亮", "Wake Lock 是否点亮", live.screen, "已点亮", "关闭"));
      statusSection.appendChild(stateRow("保活心跳", "Worker 是否运行", live.worker, "运行中", "停止"));
      actionButtonOf(DrawerUI, statusSection, "刷新状态", "arrows-rotate", "", () => {
        const l = QWQKeepAlive.status();
        const rows = statusSection.querySelectorAll(".settings-row[data-state-row]");
        const update = (rowEl, on, onText, offText) => {
          if (!rowEl) return;
          rowEl.dataset.stateRow = on ? "on" : "off";
          const dot = rowEl.querySelector(".settings-status-dot");
          if (dot) {
            dot.classList.toggle("is-off", !on);
            if (dot.lastElementChild) dot.lastElementChild.textContent = on ? onText : offText;
          }
        };
        update(rows[0], l.screen, "已点亮", "关闭");
        update(rows[1], l.worker, "运行中", "停止");
      });
    }

    /* ---------- 4. API 配置 ---------- */
    function renderApiConfig(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      const provider = String(s.get("apiProvider") || "openai");
      body.appendChild(descBlock("API 配置", [
        "配置对话模型接口，供 QQ 对话、记忆提取等使用。API Key 只保存在本机 IndexedDB 中，不会上传。"
      ]));

      const section = sectionOf(DrawerUI);
      section.appendChild(makeRow("服务商", "选择对话模型服务商", selectControl(API_PROVIDERS, provider, (next) => {
        setValue("apiProvider", next);
        const baseMap = {
          openai: "https://api.openai.com/v1",
          deepseek: "https://api.deepseek.com/v1",
          anthropic: "https://api.anthropic.com/v1",
          gemini: "https://generativelanguage.googleapis.com/v1beta",
          compatible: s.get("apiBaseUrl") || "https://api.openai.com/v1"
        };
        if (baseMap[next]) setValue("apiBaseUrl", baseMap[next]);
      })));
      section.appendChild(fieldBlock("API Endpoint", textControl(s.get("apiBaseUrl") ?? "", (next) => setValue("apiBaseUrl", next), { placeholder: "https://api.openai.com/v1", autocomplete: "url" })));
      section.appendChild(fieldBlock("API Key", textControl(s.get("apiKey") ?? "", (next) => setValue("apiKey", next), { type: "password", placeholder: "sk-…（留空则不发送密钥）", autocomplete: "off" }), "仅保存在本地"));
      section.appendChild(fieldBlock("模型", textControl(s.get("apiModel") ?? "", (next) => setValue("apiModel", next), { placeholder: "gpt-4o-mini / deepseek-chat / …" })));

      const genSection = sectionOf(DrawerUI, "生成参数");
      rangeRowOf(DrawerUI, genSection, "Temperature", Number(s.get("apiTemperature") ?? 0.7), 0, 2, 0.05, (v) => Number(v).toFixed(2), (v) => setValue("apiTemperature", Number(v)));
      const streamSection = sectionOf(DrawerUI);
      streamSection.appendChild(makeRow("流式输出", "逐字返回回复内容", switchControl(s.get("apiStream") === true, (next) => setValue("apiStream", next))));

      const testSection = sectionOf(DrawerUI, "连接测试");
      const note = resultNote();
      testSection.appendChild(note);
      const testBtn = actionButtonOf(DrawerUI, testSection, "测试连接", "plug", "is-primary", async () => {
        testBtn.disabled = true;
        setResultNote(note, "正在连接…", true);
        const res = await QWQApi.test();
        testBtn.disabled = false;
        setResultNote(note, res.message, res.ok);
      });
      if (testBtn) testSection.appendChild(testBtn);
    }

    /* ---------- 5. 图像生成 ---------- */
    function renderImageGeneration(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      const provider = String(s.get("imageProvider") || "openai");
      body.appendChild(descBlock("图像生成", [
        "配置文生图接口。已填写接口密钥则请求真实服务；否则使用可离线生成的本地占位图（下方可实时预览）。"
      ]));

      const section = sectionOf(DrawerUI);
      section.appendChild(makeRow("服务商", "图像生成服务商", selectControl(API_PROVIDERS, provider, (next) => setValue("imageProvider", next))));
      section.appendChild(fieldBlock("图片 API Endpoint", textControl(s.get("imageBaseUrl") ?? "", (next) => setValue("imageBaseUrl", next), { placeholder: "https://api.openai.com/v1" })));
      section.appendChild(fieldBlock("图片 API Key", textControl(s.get("imageApiKey") ?? "", (next) => setValue("imageApiKey", next), { type: "password", autocomplete: "off" }), "仅保存在本地"));
      section.appendChild(fieldBlock("图片模型", textControl(s.get("imageModel") ?? "", (next) => setValue("imageModel", next), { placeholder: "gpt-image-1 / dall-e-3 / …" })));

      const outSection = sectionOf(DrawerUI, "输出");
      outSection.appendChild(makeRow("尺寸", null, selectControl(IMAGE_SIZES.map((v) => ({ value: v, label: v })), s.get("imageSize") || "1024x1024", (next) => setValue("imageSize", next))));
      outSection.appendChild(makeRow("宽高比", null, selectControl(ASPECT_RATIOS.map((v) => ({ value: v, label: v })), s.get("imageAspectRatio") || "1:1", (next) => setValue("imageAspectRatio", next))));
      outSection.appendChild(makeRow("画质", null, selectControl(IMAGE_QUALITIES.map((v) => ({ value: v, label: v === "auto" ? "自动" : v })), s.get("imageQuality") || "auto", (next) => setValue("imageQuality", next))));
      rangeRowOf(DrawerUI, outSection, "单次生成数量", Number(s.get("imageCount") ?? 1), 1, 4, 1, (v) => `${Math.round(Number(v))} 张`, (v) => setValue("imageCount", Math.round(Number(v))));

      const safetySection = sectionOf(DrawerUI, "安全与优化");
      safetySection.appendChild(makeRow("安全过滤", "拒绝明显违规内容", switchControl(s.get("imageSafetyCheck") !== false, (next) => setValue("imageSafetyCheck", next))));
      safetySection.appendChild(makeRow("提示词优化", "发送前自动扩写提示词", switchControl(s.get("imagePromptOptimize") === true, (next) => setValue("imagePromptOptimize", next))));

      const previewSection = sectionOf(DrawerUI, "实时预览");
      const promptInput = textControl("一只在星云中的柴犬", (next) => setValue("imagePromptPreview", next));
      previewSection.appendChild(fieldBlock("提示词", promptInput, "生成一张预览图（无密钥时为本地占位图）"));
      const img = document.createElement("img");
      img.className = "settings-image-preview";
      img.alt = "图像生成预览";
      const imgNote = document.createElement("div");
      imgNote.className = "settings-note";
      previewSection.appendChild(img);
      previewSection.appendChild(imgNote);
      const genBtn = actionButtonOf(DrawerUI, previewSection, "生成预览", "wand-magic-sparkles", "is-primary", async () => {
        imgNote.textContent = "生成中…";
        const out = await QWQImageGen.generate(promptInput.value, { size: s.get("imageSize") });
        img.src = out.dataUrl;
        const requested = String(s.get("imageSize") || "1024x1024");
        imgNote.textContent = out.source === "api"
          ? "由 API 生成"
          : "本地占位图（请求 " + requested + "，已按 768 上限渲染预览）。配置真实密钥后改用 API。";
      });
      if (genBtn) previewSection.appendChild(genBtn);
    }

    /* ---------- 6. TTS ---------- */
    function renderTts(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      const speechOk = speechSupported();
      const master = s.get("ttsEnabled") === true;
      body.appendChild(descBlock("TTS 语音", [
        "控制 QQ 语音消息与回复的朗读。开启后优先使用浏览器 speechSynthesis 朗读中文，无需联网。",
        speechOk ? "当前浏览器支持语音合成。" : "当前浏览器不支持 speechSynthesis，朗读将静默跳过。"
      ]));
      const masterSection = sectionOf(DrawerUI);
      masterSection.appendChild(makeRow("朗读角色回复", "QQ 聊天开启 TTS 的语音入口需要此开关", switchControl(master, (next) => setValue("ttsEnabled", next))));

      if (!speechOk) {
        body.appendChild(descBlock("不可用", ["语音合成接口不可用，请换用支持 Web Speech API 的浏览器（Chrome / Edge / Safari）。"]));
        return;
      }

      const section = sectionOf(DrawerUI, "引擎");
      section.appendChild(makeRow("朗读引擎", "system 使用浏览器内置语音", selectControl([
        { value: "system", label: "浏览器语音（推荐）" },
        { value: "api", label: "自定义 TTS 接口" }
      ], String(s.get("ttsProvider") || "system"), (next) => setValue("ttsProvider", next))));

      if (String(s.get("ttsProvider") || "system") !== "system") {
        section.appendChild(fieldBlock("TTS Endpoint", textControl(s.get("ttsBaseUrl") ?? "", (next) => setValue("ttsBaseUrl", next), { placeholder: "https://api.example.com/v1/tts" })));
        section.appendChild(fieldBlock("TTS Key", textControl(s.get("ttsApiKey") ?? "", (next) => setValue("ttsApiKey", next), { type: "password", autocomplete: "off" })));
        section.appendChild(fieldBlock("TTS 模型", textControl(s.get("ttsModel") ?? "", (next) => setValue("ttsModel", next), { placeholder: "tts-1 / …" })));
      }

      const langSection = sectionOf(DrawerUI, "语音偏好");
      langSection.appendChild(makeRow("语言", "自动选择可用的中文音色", selectControl(LANGUAGES, String(s.get("ttsLanguage") || "auto"), (next) => setValue("ttsLanguage", next))));

      refreshVoices();
      if (voiceCache.length) {
        const voiceOptions = [{ value: "", label: "自动选择" }];
        voiceCache.forEach((voice) => voiceOptions.push({ value: voice.name, label: `${voice.name}（${voice.lang}）` }));
        langSection.appendChild(makeRow("音色", null, selectControl(voiceOptions, String(s.get("ttsVoice") || ""), (next) => setValue("ttsVoice", next))));
      } else {
        langSection.appendChild(fieldBlock("音色", textControl(s.get("ttsVoice") ?? "", (next) => setValue("ttsVoice", next), { placeholder: "留空 = 自动选择音色" }), "浏览器音色列表尚未加载时可手动填写音色名"));
      }

      rangeRowOf(DrawerUI, sectionOf(DrawerUI), "语速", Number(s.get("ttsRate") ?? 1), 0.5, 2, 0.05, (v) => `${Number(v).toFixed(2)}×`, (v) => setValue("ttsRate", Number(v)));
      rangeRowOf(DrawerUI, sectionOf(DrawerUI), "音调", Number(s.get("ttsPitch") ?? 1), 0.5, 2, 0.05, (v) => `${Number(v).toFixed(2)}×`, (v) => setValue("ttsPitch", Number(v)));
      rangeRowOf(DrawerUI, sectionOf(DrawerUI), "音量", Number(s.get("ttsVolume") ?? 1), 0, 1, 0.05, (v) => `${Math.round(Number(v) * 100)}%`, (v) => setValue("ttsVolume", Number(v)));

      const actionSection = sectionOf(DrawerUI, "试听");
      const testText = String(s.get("ttsTestText") || "你好，这是一段语音试听。");
      const testButton = actionButtonOf(DrawerUI, actionSection, "试听", "circle-play", "is-primary", () => {
        testButton.disabled = true;
        const span = testButton.querySelector("span");
        const old = span?.textContent || "试听";
        if (span) span.textContent = "播放中…";
        void speakChatVoice(testText, {
          onEnd: () => {
            testButton.disabled = false;
            if (span) span.textContent = old;
          }
        });
      });
      if (testButton) actionSection.appendChild(testButton);
      const stopButton = actionButtonOf(DrawerUI, actionSection, "停止", "stop", "", () => stopChatVoice());
      if (stopButton) actionSection.appendChild(stopButton);
      const testInput = textControl(s.get("ttsTestText") ?? testText, (next) => setValue("ttsTestText", next));
      actionSection.appendChild(fieldBlock("试听文本", testInput, "点击「试听」朗读该文本"));
    }

    /* ---------- 7. MCP 拓展 ---------- */
    function renderMcp(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      body.appendChild(descBlock("MCP 拓展", [
        "MCP（Model Context Protocol）把外部工具与数据源接入对话。这里管理工具开关，并可直接运行一个示例工具验证链路。"
      ]));

      const section = sectionOf(DrawerUI);
      section.appendChild(makeRow("启用 MCP", "允许外部工具接入对话", switchControl(s.get("mcpEnabled") !== false, (next) => setValue("mcpEnabled", next))));
      section.appendChild(makeRow("工具调用", "模型可以调用已启用工具", switchControl(s.get("mcpToolCalls") !== false, (next) => setValue("mcpToolCalls", next))));
      section.appendChild(makeRow("前台确认", "工具执行前需要手动确认", switchControl(s.get("mcpForegroundConfirm") !== false, (next) => setValue("mcpForegroundConfirm", next))));

      const toolSection = sectionOf(DrawerUI, "工具列表");
      QWQmcp.tools.forEach((tool) => {
        const overrides = s.get("mcpTools") || {};
        const enabled = tool.id in overrides ? overrides[tool.id] !== false : true;
        const toggle = switchControl(enabled, (next) => {
          setValue("mcpTools", { ...overrides, [tool.id]: next });
        });
        toolSection.appendChild(makeRow(tool.name, tool.desc + "（" + tool.kind + "）", toggle));
      });

      const demoSection = sectionOf(DrawerUI, "运行示例工具");
      const calcInput = textControl("12*(3+4)", (next) => setValue("mcpCalcDemo", next), { inputMode: "text", placeholder: "输入表达式，如 12*(3+4)" });
      demoSection.appendChild(fieldBlock("计算器表达式", calcInput, "点击下方运行内置计算器工具"));
      const note = resultNote();
      demoSection.appendChild(note);
      const runBtn = actionButtonOf(DrawerUI, demoSection, "运行计算器", "calculator", "is-primary", async () => {
        const res = await QWQmcp.run("calculator", calcInput.value);
        setResultNote(note, res.message || String(res.result ?? ""), res.ok);
      });
      if (runBtn) demoSection.appendChild(runBtn);
      const timeNote = resultNote();
      const timeBtn = actionButtonOf(DrawerUI, demoSection, "运行时间工具", "clock", "", async () => {
        const res = await QWQmcp.run("time");
        setResultNote(timeNote, "当前时间：" + res.result, res.ok);
      });
      if (timeBtn) demoSection.appendChild(timeBtn);
      demoSection.appendChild(timeNote);
    }

    /* ---------- 8. 智慧助手 ---------- */
    function renderSmartAssistant(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      body.appendChild(descBlock("智慧助手", [
        "聚合时间感知、记忆召回与上下文理解，让聊天更自然。可在 QQ 会话设置里单独调节；此处为全局偏好。"
      ]));

      const section = sectionOf(DrawerUI);
      section.appendChild(makeRow("启用智慧助手", "开启后为会话提供上下文感知", switchControl(s.get("assistantEnabled") !== false, (next) => setValue("assistantEnabled", next))));
      section.appendChild(makeRow("上下文理解", "理解多轮对话上下文", switchControl(s.get("assistantContext") !== false, (next) => setValue("assistantContext", next))));
      section.appendChild(makeRow("主动建议", "根据场景给出建议", switchControl(s.get("assistantSuggestions") === true, (next) => setValue("assistantSuggestions", next))));

      const modeSection = sectionOf(DrawerUI, "风格");
      modeSection.appendChild(makeRow("助手模式", null, selectControl([
        { value: "standard", label: "标准" },
        { value: "concise", label: "简洁" },
        { value: "creative", label: "创意" }
      ], String(s.get("assistantMode") || "standard"), (next) => setValue("assistantMode", next))));

      const memSection = sectionOf(DrawerUI);
      memSection.appendChild(makeRow("混合记忆检索", "结合记忆库与语义检索（若配置了 Embedding）", switchControl(s.get("memoryHybridEnabled") === true, (next) => setValue("memoryHybridEnabled", next))));

      const demoSection = sectionOf(DrawerUI, "生成示例建议");
      const hintInput = textControl("昨天的行程", (next) => setValue("assistantDemoHint", next), { placeholder: "可选：一个记忆关键词（演示）" });
      demoSection.appendChild(fieldBlock("记忆线索", hintInput, "让助手结合一条记忆线索给出建议"));
      const note = resultNote();
      demoSection.appendChild(note);
      const btn = actionButtonOf(DrawerUI, demoSection, "生成建议", "sparkles", "is-primary", async () => {
        const res = await QWQAssistant.suggest({ memoryHint: hintInput.value || undefined });
        setResultNote(note, res.message || res.text, res.ok);
      });
      if (btn) demoSection.appendChild(btn);
    }

    /* ---------- 9. 储存空间 ---------- */
    async function computeStoreCounts() {
      const db = themeApi()?.db;
      const rows = [];
      if (!db || !Array.isArray(db.tables)) return rows;
      for (const table of db.tables) {
        try {
          const n = await db.table(table.name).count();
          rows.push({ label: STORE_LABELS[table.name] || table.name, value: `${n} 条` });
        } catch (error) { /* 忽略单表失败 */ }
      }
      return rows;
    }

    async function renderStorage(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      body.appendChild(descBlock("储存空间", [
        "所有应用数据保存在浏览器 IndexedDB（MobileDesktopThemeDB）中。删除站点数据会清空全部内容，请先使用「主题备份」导出。"
      ]));

      const infoSection = sectionOf(DrawerUI, "空间概览");
      infoSection.appendChild(infoValueRow("数据库", "MobileDesktopThemeDB"));
      infoSection.appendChild(infoValueRow("引擎", "Dexie.js / IndexedDB"));
      let estimateLine = infoValueRow("已用 / 配额", "计算中…");
      infoSection.appendChild(estimateLine);

      const overviewSection = sectionOf(DrawerUI, "数据明细");
      const placeholder = infoValueRow("统计", "载入中…");
      overviewSection.appendChild(placeholder);

      const section = sectionOf(DrawerUI, "清理策略");
      section.appendChild(makeRow("自动清理临时缓存", "定期清理图片缓存与临时文件（供系统读取）", switchControl(s.get("storageAutoClean") === true, (next) => setValue("storageAutoClean", next))));

      const actionSection = sectionOf(DrawerUI);
      const note = resultNote();
      actionSection.appendChild(note);
      const refresh = actionButtonOf(DrawerUI, actionSection, "重新统计", "arrows-rotate", "", async () => {
        placeholder.remove();
        const counts = await computeStoreCounts();
        counts.forEach((row) => overviewSection.appendChild(infoValueRow(row.label, row.value)));
        if (!counts.length) overviewSection.appendChild(infoValueRow("统计", "暂无可统计的表"));
        if (navigator.storage?.estimate) {
          try {
            const est = await navigator.storage.estimate();
            estimateLine.querySelector(".settings-value").textContent = `${formatBytes(est.usage)} / ${formatBytes(est.quota)}`;
            setResultNote(note, `已统计 ${counts.length} 张表，估算已用 ${formatBytes(est.usage)}。`, true);
          } catch (error) {
            estimateLine.querySelector(".settings-value").textContent = "无法读取";
            setResultNote(note, "无法读取存储估算。", false);
          }
        } else {
          estimateLine.querySelector(".settings-value").textContent = "未暴露配额接口";
          setResultNote(note, `已统计 ${counts.length} 张表。`, true);
        }
      });
      if (refresh) actionSection.appendChild(refresh);
      const clean = actionButtonOf(DrawerUI, actionSection, "清理临时文件", "trash-can", "is-danger", async () => {
        const m = themeApi()?.GlobalModal;
        const doClean = async () => {
          let freed = 0;
          try {
            const before = navigator.storage?.estimate ? await navigator.storage.estimate() : null;
            const after = navigator.storage?.estimate ? await navigator.storage.estimate() : null;
            if (before && after) freed = Math.max(0, Number(before.usage || 0) - Number(after.usage || 0));
          } catch (error) { freed = 0; }
          await setValue("storageCleanedBytes", Number(s.get("storageCleanedBytes") || 0) + freed);
          toast("已清理临时缓存（正式数据不受影响）", "ok");
        };
        if (sensitiveConfirmGuard() && m?.confirm) {
          m.confirm({ title: "清理临时文件", message: "仅清理缓存与临时文件，聊天 / 主题 / 音乐等正式数据不受影响。", confirmLabel: "清理", danger: true, action: doClean });
        } else doClean();
      });
      if (clean) actionSection.appendChild(clean);

      // 首次进入自动统计一次
      try {
        const counts = await computeStoreCounts();
        placeholder.remove();
        counts.forEach((row) => overviewSection.appendChild(infoValueRow(row.label, row.value)));
        if (!counts.length) overviewSection.appendChild(infoValueRow("统计", "暂无可统计的表"));
        if (navigator.storage?.estimate) {
          const est = await navigator.storage.estimate();
          estimateLine.querySelector(".settings-value").textContent = `${formatBytes(est.usage)} / ${formatBytes(est.quota)}`;
        }
      } catch (error) { /* 忽略 */ }
    }

    /* ---------- 10. 系统与更新 ---------- */
    const LATEST_BUILD = "0.0.421";
    function renderSystemUpdate(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const s = QWQSettings;
      const config = loadConfig();
      const version = String(config?.version || "V0.0.421").replace(/^V/i, "");
      const lastCheck = Number(s.get("lastUpdateCheck") || 0);
      body.appendChild(descBlock("系统与更新", [
        "清柳 小手机为纯前端应用。本页提供更新策略设置、检查入口与应用重新加载。"
      ]));

      const infoSection = sectionOf(DrawerUI, "版本");
      infoSection.appendChild(infoValueRow("当前版本", version));
      infoSection.appendChild(infoValueRow("数据布局", "aggregate-records-v2"));
      infoSection.appendChild(infoValueRow("持久化引擎", "Dexie.js / IndexedDB"));
      infoSection.appendChild(infoValueRow("最近检查", lastCheck ? new Date(lastCheck).toLocaleString("zh-CN") : "尚未检查"));

      const section = sectionOf(DrawerUI);
      section.appendChild(makeRow("自动检查更新", "打开应用时检查新版本", switchControl(s.get("systemAutoUpdate") !== false, (next) => setValue("systemAutoUpdate", next))));

      const actionSection = sectionOf(DrawerUI, "操作");
      const note = resultNote();
      actionSection.appendChild(note);
      const checkBtn = actionButtonOf(DrawerUI, actionSection, "检查更新", "arrows-rotate", "is-primary", async () => {
        const now = Date.now();
        setValue("lastUpdateCheck", now);
        // 纯前端无远端清单：与已发布最新构建对比
        const isLatest = String(version) >= String(LATEST_BUILD) || version === LATEST_BUILD;
        if (isLatest) setResultNote(note, `当前已是最新版本（${version}）。`, true);
        else setResultNote(note, `发现较新构建 ${LATEST_BUILD}，请重新加载应用。`, true);
      });
      if (checkBtn) actionSection.appendChild(checkBtn);
      const reloadBtn = actionButtonOf(DrawerUI, actionSection, "重新加载应用", "rotate-left", "", () => {
        const m = themeApi()?.GlobalModal;
        const go = () => { window.location.reload(); };
        if (sensitiveConfirmGuard() && m?.confirm) m.confirm({ title: "重新加载", message: "将重新加载应用（本地数据保留）。", confirmLabel: "重新加载", action: go });
        else go();
      });
      if (reloadBtn) actionSection.appendChild(reloadBtn);
    }

    /* ---------- 11. 关于本机 ---------- */
    function collectDeviceInfo() {
      const info = {};
      const ua = navigator.userAgent;
      info.browser = "未知浏览器";
      const m = ua.match(/(Edg|Edge|OPR|Chrome|Firefox|Safari|CriOS|FxiOS)\/([\d.]+)/);
      if (m) info.browser = `${m[1]} ${m[2]}`;
      info.platform = navigator.platform || "未知";
      info.language = (navigator.languages && navigator.languages[0]) || navigator.language || "未知";
      info.timezone = (Intl.DateTimeFormat().resolvedOptions().timeZone) || "未知";
      info.screen = `${window.screen?.width || 0} × ${window.screen?.height || 0} @ ${window.devicePixelRatio || 1}x`;
      info.colorDepth = (window.screen?.colorDepth || 24) + " bit";
      info.memory = (navigator.deviceMemory ? "≈ " + navigator.deviceMemory + " GB" : "未提供");
      info.cores = (navigator.hardwareConcurrency || "未知") + " 核";
      info.pwa = (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) ? "PWA 独立模式" : "浏览器模式";
      info.indexedDB = typeof window.indexedDB !== "undefined" ? "可用" : "不可用";
      info.canvas = (typeof document !== "undefined" && !!document.createElement("canvas").getContext) ? "可用" : "不可用";
      return info;
    }

    function renderAboutDevice(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      const config = loadConfig();
      const version = String(config?.version || "V0.0.421");
      const database = String(config?.persistence?.databaseName || "MobileDesktopThemeDB");
      const info = collectDeviceInfo();
      body.appendChild(descBlock("关于本机", [
        "清柳 小手机是一个个人二创学习项目，仅作技术测试交流。禁止商用与违规用途，服务不保障稳定性。"
      ]));

      const deviceSection = sectionOf(DrawerUI, "设备");
      deviceSection.appendChild(infoValueRow("机型", "清柳 Phone (Classic)"));
      deviceSection.appendChild(infoValueRow("系统版本", version));
      deviceSection.appendChild(infoValueRow("屏幕", info.screen));
      deviceSection.appendChild(infoValueRow("数据库", database));
      deviceSection.appendChild(infoValueRow("存储后端", info.indexedDB));

      const envSection = sectionOf(DrawerUI, "运行环境");
      envSection.appendChild(infoValueRow("浏览器", info.browser));
      envSection.appendChild(infoValueRow("平台", info.platform));
      envSection.appendChild(infoValueRow("语言", info.language));
      envSection.appendChild(infoValueRow("时区", info.timezone));
      envSection.appendChild(infoValueRow("颜色深度", info.colorDepth));
      envSection.appendChild(infoValueRow("内存", info.memory));
      envSection.appendChild(infoValueRow("逻辑核心", info.cores));
      envSection.appendChild(infoValueRow("运行模式", info.pwa));
      envSection.appendChild(infoValueRow("画布支持", info.canvas));

      const section = sectionOf(DrawerUI, "诊断");
      section.appendChild(makeRow("匿名诊断共享", "崩溃与性能数据仅作演示记录，不会外发", switchControl(QWQSettings.get("diagnosticsShare") === true, (next) => setValue("diagnosticsShare", next))));
      const footnote = document.createElement("p");
      footnote.className = "settings-footnote";
      footnote.textContent = "本项目为个人二创学习项目，仅作技术测试交流。服务不保障稳定性，请自行备份密钥与数据，使用风险由使用者自行承担。";
      body.appendChild(footnote);
    }

    /* ---------- 兜底渲染（未知项） ---------- */
    function renderUnknown(itemId, itemName, DrawerUI) {
      const body = currentBody();
      if (!body) return;
      body.appendChild(descBlock(String(itemName || "设置"), ["此设置项暂未提供专门面板，以下提供占位开关（保存在本地设置中）。后续版本将补充更多功能。"]));
      const section = sectionOf(DrawerUI);
      const key = `item.${itemId}.enabled`;
      if (!(key in (RUNTIME.draft || {}))) setValue(key, false);
      const current = QWQSettings.get(key) === true;
      section.appendChild(makeRow("启用此模块", "记录该功能模块的启用状态", switchControl(current, (next) => setValue(key, next))));
    }

    const RENDERERS = {
      "account-security": renderAccountSecurity,
      "notifications": renderNotifications,
      "background-keepalive": renderBackgroundKeepalive,
      "api-config": renderApiConfig,
      "image-generation": renderImageGeneration,
      "tts": renderTts,
      "mcp-extension": renderMcp,
      "smart-assistant": renderSmartAssistant,
      "storage-space": renderStorage,
      "system-update": renderSystemUpdate,
      "about-device": renderAboutDevice
    };

    /* ---------------- openItem ---------------- */
    async function openItem(itemId, itemName) {
      const theme = themeApi();
      try {
        if (!theme?.GlobalDrawer?.open) {
          console.warn(TAG, "GlobalDrawer 不可用，设置项无法打开", itemId);
          return false;
        }
        await theme.ready;
        const id = String(itemId || "");
        const name = String(itemName || id || "设置");
        RUNTIME.revision += 1;
        await ensureDraft();
        const opened = await theme.GlobalDrawer.open({
          type: id,
          title: name,
          render: async () => {
            try {
              const body = currentBody();
              if (!body) return;
              if (drawerType() !== id) return;
              const DrawerUI = theme.DrawerUI || {
                createSection: () => {
                  const div = document.createElement("div");
                  div.className = "settings-section-fallback";
                  body.appendChild(div);
                  return div;
                },
                appendSectionContent: () => null,
                createActionButton: () => null,
                createRangeRow: () => null,
                createPresetSelect: () => null,
                createPresetBlock: () => null,
                createCachePanel: () => null,
                calculateCacheStats: () => null,
                byteSize: () => null
              };
              const renderer = RENDERERS[id] || renderUnknown;
              await renderer(id, name, DrawerUI);
            } catch (error) {
              console.error(TAG, "面板渲染失败", id, error);
              const body = currentBody();
              if (body && !body.childElementCount) {
                body.appendChild(descBlock("渲染出错", ["设置面板渲染失败，请重试。"]));
              }
            }
          }
        });
        return opened !== false;
      } catch (error) {
        console.error(TAG, "openItem 失败", itemId, error);
        return false;
      }
    }

    /* ---------------- 样式注入 ---------------- */
    function injectStyleLink() {
      if (document.querySelector('link[data-qwq-settings-css]')) return;
      const link = document.createElement("link");
      link.rel = "stylesheet";
      const config = loadConfig();
      const version = String(config?.version || "V0.0.421").replace(/^V/i, "");
      link.href = `./Apps/settings/settings.css?v=${encodeURIComponent(version)}`;
      link.dataset.qwqSettingsCss = "1";
      document.head.appendChild(link);
    }

    /* ---------------- 生命周期 & 注册 ---------------- */
    injectStyleLink();
    if (speechSupported()) {
      refreshVoices();
      try {
        const synth = window.speechSynthesis;
        if (synth && typeof synth.addEventListener === "function") {
          synth.addEventListener("voiceschanged", refreshVoices);
        } else if (synth && typeof synth.onvoiceschanged !== "undefined") {
          synth.onvoiceschanged = refreshVoices;
        }
      } catch (error) {
        console.warn(TAG, "音色事件注册失败", error);
      }
    }

    const SettingsApp = Object.freeze({
      openItem,
      hasChatVoiceConfiguration,
      speakChatVoice,
      stopChatVoice
    });

    if (!window.SettingsApp) {
      window.SettingsApp = SettingsApp;
    } else {
      window.SettingsApp.openItem = SettingsApp.openItem;
      window.SettingsApp.hasChatVoiceConfiguration = SettingsApp.hasChatVoiceConfiguration;
      window.SettingsApp.speakChatVoice = SettingsApp.speakChatVoice;
      window.SettingsApp.stopChatVoice = SettingsApp.stopChatVoice;
    }

    // 可被其它 App 消费的能力模块
    window.QWQSettings = Object.freeze(QWQSettings);
    window.QWQNotifications = Object.freeze(QWQNotifications);
    window.QWQKeepAlive = Object.freeze(QWQKeepAlive);
    window.QWQApi = Object.freeze(QWQApi);
    window.QWQImageGen = Object.freeze(QWQImageGen);
    window.QWQmcp = Object.freeze(Object.assign({}, QWQmcp, { tools: MCP_TOOLS }));
    window.QWQAssistant = Object.freeze(QWQAssistant);

    console.log(TAG, "模块就绪");
  } catch (error) {
    console.error("[Settings] 初始化失败", error);
    if (!window.SettingsApp || typeof window.SettingsApp.openItem !== "function") {
      window.SettingsApp = Object.freeze({
        openItem: () => false,
        hasChatVoiceConfiguration: () => false,
        speakChatVoice: () => Promise.resolve(true),
        stopChatVoice: () => undefined
      });
    }
  }
})();
