const myPhoneConfig = window.__QWQ_CONFIG__ || JSON.parse(document.getElementById("myPhoneConfigJson").textContent);


    /*
     * 清柳 persistence identity contract
     * ---------------------------------
     * IndexedDB identity = browser Origin + databaseName, NOT databaseName alone.
     * Cross-version automatic continuity is guaranteed only when every release runs
     * under the same stable HTTP(S) Origin (same scheme + host + port).
     * Direct file:/content:/opaque-origin documents may retain data inside one file
     * context, but a newly downloaded HTML file cannot be guaranteed access to the
     * previous file's IndexedDB. This is a browser storage boundary, not a 清柳 key issue.
     */
    const QWQPersistenceContext = Object.freeze((() => {
      const protocol = String(location.protocol || "").toLowerCase();
      const origin = String(location.origin || "null");
      const stableHttpOrigin = (protocol === "http:" || protocol === "https:") && origin !== "null";
      return {
        protocol,
        origin,
        crossVersionGuaranteed: stableHttpOrigin
      };
    })());
    window.QWQPersistenceContext = QWQPersistenceContext;
    document.documentElement.dataset.persistenceOrigin = QWQPersistenceContext.crossVersionGuaranteed ? "stable" : "opaque-or-local";

    // Single source of truth for browser-side file downloads. App modules must call
    // QWQFileDownload.saveBlob() instead of carrying private download helpers.
    const QWQFileDownload = Object.freeze({
      saveBlob(blob, filename) {
        if (!(blob instanceof Blob)) throw new TypeError("download payload must be a Blob");
        const safeName = String(filename || "download").trim() || "download";
        const objectUrl = URL.createObjectURL(blob);
        const anchor = document.createElement("a");
        anchor.href = objectUrl;
        anchor.download = safeName;
        anchor.rel = "noopener";
        anchor.style.display = "none";
        document.body.appendChild(anchor);
        try {
          anchor.click();
        } finally {
          anchor.remove();
          // Some mobile download managers consume object URLs asynchronously. Revoking after one
          // second can detach a large ZIP while the browser is still copying it to Downloads.
          // Keep only this URL alive long enough for the transfer hand-off, then release it.
          window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
        }
      }
    });
    window.QWQFileDownload = QWQFileDownload;

    // Single source of truth for user-supplied text documents. Contact, mask and
    // sticker imports share the same ZIP/XML/encoding rules instead of carrying
    // private DOCX readers that drift apart over time.
    const QWQDocumentText = (() => {
      const DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

      function fileKind(file) {
        const name = String(file?.name || "").toLowerCase();
        const type = String(file?.type || "").toLowerCase();
        if (name.endsWith(".docx") || type === DOCX_MIME) return "docx";
        if (name.endsWith(".doc")) return "doc";
        if (name.endsWith(".txt") || type === "text/plain") return "txt";
        return null;
      }

      function decodeBytes(value) {
        const bytes = value instanceof Uint8Array ? value : new Uint8Array(value || 0);
        if (bytes[0] === 0xFF && bytes[1] === 0xFE) return new TextDecoder("utf-16le").decode(bytes.slice(2));
        if (bytes[0] === 0xFE && bytes[1] === 0xFF) {
          const swapped = bytes.slice(2);
          for (let index = 0; index + 1 < swapped.length; index += 2) {
            const current = swapped[index];
            swapped[index] = swapped[index + 1];
            swapped[index + 1] = current;
          }
          return new TextDecoder("utf-16le").decode(swapped);
        }
        const content = bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF ? bytes.slice(3) : bytes;
        try {
          return new TextDecoder("utf-8", { fatal: true }).decode(content);
        } catch (error) {
          console.warn("[清柳 document] UTF-8 decode failed; using GB18030", error);
          return new TextDecoder("gb18030").decode(content);
        }
      }

      function centralEntry(bytes, targetName) {
        if (bytes.length < 22) throw new Error("DOCX ZIP 目录无效");
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        const decoder = new TextDecoder("utf-8");
        let eocd = -1;
        for (let index = bytes.length - 22; index >= Math.max(0, bytes.length - 65557); index -= 1) {
          if (index + 4 <= bytes.length && view.getUint32(index, true) === 0x06054B50) {
            eocd = index;
            break;
          }
        }
        if (eocd < 0 || eocd + 22 > bytes.length) throw new Error("DOCX ZIP 目录无效");
        const entryCount = view.getUint16(eocd + 10, true);
        let offset = view.getUint32(eocd + 16, true);
        for (let index = 0; index < entryCount; index += 1) {
          if (offset + 46 > bytes.length || view.getUint32(offset, true) !== 0x02014B50) throw new Error("DOCX ZIP 目录损坏");
          const method = view.getUint16(offset + 10, true);
          const compressedSize = view.getUint32(offset + 20, true);
          const nameLength = view.getUint16(offset + 28, true);
          const extraLength = view.getUint16(offset + 30, true);
          const commentLength = view.getUint16(offset + 32, true);
          const localOffset = view.getUint32(offset + 42, true);
          const nextOffset = offset + 46 + nameLength + extraLength + commentLength;
          if (nextOffset > bytes.length) throw new Error("DOCX ZIP 目录损坏");
          const name = decoder.decode(bytes.slice(offset + 46, offset + 46 + nameLength));
          if (name === targetName) {
            if (localOffset + 30 > bytes.length || view.getUint32(localOffset, true) !== 0x04034B50) throw new Error("DOCX 本地文件头损坏");
            const localNameLength = view.getUint16(localOffset + 26, true);
            const localExtraLength = view.getUint16(localOffset + 28, true);
            const start = localOffset + 30 + localNameLength + localExtraLength;
            if (start + compressedSize > bytes.length) throw new Error("DOCX 文档内容不完整");
            return { method, compressed: bytes.slice(start, start + compressedSize) };
          }
          offset = nextOffset;
        }
        throw new Error("DOCX 中缺少 word/document.xml");
      }

      async function inflateRaw(bytes) {
        if (typeof DecompressionStream !== "function") throw new Error("当前浏览器不支持 DOCX 解压");
        const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
        return new Uint8Array(await new Response(stream).arrayBuffer());
      }

      async function extractDocx(file) {
        const bytes = new Uint8Array(await file.arrayBuffer());
        const entry = centralEntry(bytes, "word/document.xml");
        const xmlBytes = entry.method === 0 ? entry.compressed : entry.method === 8 ? await inflateRaw(entry.compressed) : null;
        if (!xmlBytes) throw new Error("DOCX 使用了不支持的压缩方式");
        const xml = new DOMParser().parseFromString(new TextDecoder("utf-8").decode(xmlBytes), "application/xml");
        if (xml.querySelector("parsererror")) throw new Error("DOCX 文档内容无法解析");
        return Array.from(xml.getElementsByTagNameNS("*", "p")).map((paragraph) => {
          const parts = [];
          paragraph.querySelectorAll("*").forEach((node) => {
            if (node.localName === "t") parts.push(node.textContent || "");
            else if (node.localName === "tab") parts.push("\t");
            else if (node.localName === "br" || node.localName === "cr") parts.push("\n");
          });
          return parts.join("");
        }).join("\n");
      }

      function extractLegacyDoc(bytes) {
        const raw8 = new TextDecoder("windows-1252").decode(bytes);
        if (/^\s*\{\\rtf/i.test(raw8)) {
          return raw8
            .replace(/\\par[d]?\b/g, "\n")
            .replace(/\\'[0-9a-f]{2}/gi, " ")
            .replace(/\\[a-z]+-?\d*\s?/gi, "")
            .replace(/[{}]/g, " ");
        }
        if (/<html[\s>]/i.test(raw8)) {
          const documentNode = new DOMParser().parseFromString(raw8, "text/html");
          return documentNode.body?.innerText || documentNode.body?.textContent || raw8;
        }
        const utf16 = new TextDecoder("utf-16le").decode(bytes);
        const collectRuns = (text) => (text.match(/[\u0020-\u007e\u00a0-\u00ff\u3000-\u30ff\u3400-\u9fff\uff00-\uffef]{4,}/g) || []).join("\n");
        const utf16Runs = collectRuns(utf16);
        const latinRuns = collectRuns(raw8);
        const score = (text) => (text.match(/[\u4e00-\u9fff]/g) || []).length * 5 + (text.match(/https?:\/\//g) || []).length * 30 + text.length * .02;
        return score(utf16Runs) >= score(latinRuns) ? utf16Runs : latinRuns;
      }

      async function extract(file, { allowLegacyDoc = false, maxLength = Number.POSITIVE_INFINITY } = {}) {
        const kind = fileKind(file);
        if (!kind || (kind === "doc" && !allowLegacyDoc)) throw new Error(allowLegacyDoc ? "请选择 DOCX、DOC 或 TXT 文档" : "请选择 DOCX 或 TXT 文档");
        let text;
        if (kind === "docx") text = await extractDocx(file);
        else {
          const bytes = new Uint8Array(await file.arrayBuffer());
          text = kind === "doc" ? extractLegacyDoc(bytes) : decodeBytes(bytes);
        }
        const normalized = String(text ?? "").replace(/\r\n?/g, "\n").trim();
        const finiteLimit = Number(maxLength);
        const result = Number.isFinite(finiteLimit) && finiteLimit > 0 ? normalized.slice(0, finiteLimit) : normalized;
        if (!result) throw new Error("文档中没有可导入的文本");
        return result;
      }

      return Object.freeze({ DOCX_MIME, fileKind, decodeBytes, extract });
    })();
    window.QWQDocumentText = QWQDocumentText;

    if (!QWQPersistenceContext.crossVersionGuaranteed) {
      console.warn(
        "[清柳 persistence] 当前页面不是稳定 HTTP(S) Origin。IndexedDB 按 Origin 隔离；直接打开不同本地 HTML 文件时，新版无法保证读取上一文件的数据库。请让连续版本始终运行在相同 scheme / host / port。",
        QWQPersistenceContext
      );
    }

    // Viewport contract: one measured layout viewport owns every full-screen boundary.
    // CSS vh/dvh is only a no-JS fallback; runtime geometry is published as px from
    // window.innerHeight/innerWidth. This removes the previous browser-vs-standalone
    // split that could place the bottom edge below the real screen on some phones.
    const QWQViewport = (() => {
      const root = document.documentElement;
      const visualViewport = window.visualViewport || null;
      let frame = 0;
      let width = 0;
      let height = 0;

      function finite(value, fallback = 1) {
        const number = Number(value);
        return Number.isFinite(number) && number > 0 ? number : fallback;
      }

      function rounded(value) {
        return Math.round(finite(value) * 100) / 100;
      }

      function readRuntimeViewport() {
        const innerWidth = finite(window.innerWidth, root.clientWidth || 1);
        const innerHeight = finite(window.innerHeight, root.clientHeight || 1);

        // interactive-widget=resizes-content makes innerHeight follow the keyboard on
        // supporting browsers. On engines that resize only VisualViewport, use its visible
        // bottom only for a keyboard-sized contraction; ordinary toolbar movement must not
        // create a second competing shell height.
        let runtimeHeight = innerHeight;
        if (visualViewport) {
          const vvHeight = finite(visualViewport.height, innerHeight);
          const vvTop = Math.max(0, Number(visualViewport.offsetTop) || 0);
          const visibleBottom = vvTop + vvHeight;
          const contraction = innerHeight - vvHeight;
          if (contraction > 120 && visibleBottom > 0) {
            runtimeHeight = Math.min(innerHeight, visibleBottom);
          }
        }

        return {
          width: rounded(innerWidth),
          height: rounded(runtimeHeight)
        };
      }

      function publish(next) {
        // These are authoritative runtime facts. Always republish them, even when the
        // measured size did not change: imported historical theme data may have written an
        // obsolete inline custom property after the previous measurement. Equality of the
        // numeric measurement is therefore not sufficient to skip the DOM write.
        width = next.width;
        height = next.height;
        root.style.setProperty("--qwq-viewport-width", `${width}px`);
        root.style.setProperty("--qwq-shell-height", `${height}px`);
        root.style.setProperty("--qwq-viewport-height", `${height}px`);
      }

      function syncNow() {
        frame = 0;
        publish(readRuntimeViewport());
      }

      function sync() {
        if (frame) return;
        frame = requestAnimationFrame(syncNow);
      }

      function settle() {
        syncNow();
        requestAnimationFrame(() => requestAnimationFrame(syncNow));
      }

      // Reuse the pre-CSS publisher once, then take over from a single runtime owner.
      if (typeof window.__QWQPublishRuntimeViewport === "function") {
        window.__QWQPublishRuntimeViewport();
      }
      settle();
      window.addEventListener("resize", sync, { passive: true });
      window.addEventListener("orientationchange", settle, { passive: true });
      window.addEventListener("pageshow", settle, { passive: true });
      window.addEventListener("load", settle, { passive: true, once: true });
      visualViewport?.addEventListener("resize", sync, { passive: true });
      document.addEventListener("visibilitychange", () => {
        if (!document.hidden) settle();
      });

      return Object.freeze({
        sync,
        settle,
        size: () => ({ width, height }),
        visualSize: () => visualViewport ? ({
          width: rounded(visualViewport.width),
          height: rounded(visualViewport.height),
          offsetTop: Number(visualViewport.offsetTop) || 0,
          offsetLeft: Number(visualViewport.offsetLeft) || 0
        }) : null
      });
    })();
    window.QWQViewport = QWQViewport;

    // Browser-zoom contract: 清柳 is an app-like fixed viewport. Native page pinch/gesture zoom
    // would scale the entire shell independently of the app's own display/icon scale variables.
    const QWQGestureLock = (() => {
      const stopGesture = (event) => event.preventDefault();
      document.addEventListener("gesturestart", stopGesture, { passive: false });
      document.addEventListener("gesturechange", stopGesture, { passive: false });
      document.addEventListener("gestureend", stopGesture, { passive: false });
      // viewport user-scalable=no + root touch-action 已经禁止页面级 pinch zoom。
      // 禁止再在 document 上挂 passive:false touchmove：即使回调只处理双指，浏览器仍会
      // 把每一帧普通单指滚动交给主线程等待是否 preventDefault，直接破坏合成线程滚动。
      return Object.freeze({ enabled: true });
    })();
    window.QWQGestureLock = QWQGestureLock;

    // iOS Safari auto-zooms focused form controls whose computed font size is below 16px.
    // Keep the app geometry unchanged by raising only the focused control's editing font temporarily;
    // the original inline value/priority is restored exactly on blur.
    const QWQIOSInputGuard = (() => {
      const ua = String(navigator.userAgent || "");
      const platform = String(navigator.platform || "");
      const isIOS = /iPad|iPhone|iPod/.test(ua)
        || (platform === "MacIntel" && Number(navigator.maxTouchPoints || 0) > 1);
      if (!isIOS) return Object.freeze({ enabled: false });

      const original = new WeakMap();
      const editableSelector = 'input:not([type="range"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="file"]):not([type="color"]), textarea, select';

      document.addEventListener("focusin", (event) => {
        const field = event.target instanceof Element ? event.target.closest(editableSelector) : null;
        if (!field || original.has(field)) return;
        const size = Number.parseFloat(getComputedStyle(field).fontSize) || 16;
        if (size >= 16) return;
        original.set(field, {
          value: field.style.getPropertyValue("font-size"),
          priority: field.style.getPropertyPriority("font-size")
        });
        field.style.setProperty("font-size", "16px", "important");
      }, { passive: true });

      document.addEventListener("focusout", (event) => {
        const field = event.target instanceof Element ? event.target.closest(editableSelector) : null;
        const previous = field ? original.get(field) : null;
        if (!field || !previous) return;
        original.delete(field);
        requestAnimationFrame(() => {
          if (previous.value) field.style.setProperty("font-size", previous.value, previous.priority || "");
          else field.style.removeProperty("font-size");
        });
      }, { passive: true });

      return Object.freeze({ enabled: true });
    })();
    window.QWQIOSInputGuard = QWQIOSInputGuard;


    const fontAwesomeInlineIcons = {
      "user-shield": {"width": 640, "height": 512, "path": "M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512l388.6 0c1.8 0 3.5-.2 5.3-.5c-76.3-55.1-99.8-141-103.1-200.2c-16.1-4.8-33.1-7.3-50.7-7.3l-91.4 0zm308.8-78.3l-120 48C358 277.4 352 286.2 352 296c0 63.3 25.9 168.8 134.8 214.2c5.9 2.5 12.6 2.5 18.5 0C614.1 464.8 640 359.3 640 296c0-9.8-6-18.6-15.1-22.3l-120-48c-5.7-2.3-12.1-2.3-17.8 0zM591.4 312c-3.9 50.7-27.2 116.7-95.4 149.7l0-187.8L591.4 312z"},
      "bell": {"width": 448, "height": 512, "path": "M224 0c-17.7 0-32 14.3-32 32l0 19.2C119 66 64 130.6 64 208l0 18.8c0 47-17.3 92.4-48.5 127.6l-7.4 8.3c-8.4 9.4-10.4 22.9-5.3 34.4S19.4 416 32 416l384 0c12.6 0 24-7.4 29.2-18.9s3.1-25-5.3-34.4l-7.4-8.3C401.3 319.2 384 273.9 384 226.8l0-18.8c0-77.4-55-142-128-156.8L256 32c0-17.7-14.3-32-32-32zm45.3 493.3c12-12 18.7-28.3 18.7-45.3l-64 0-64 0c0 17 6.7 33.3 18.7 45.3s28.3 18.7 45.3 18.7s33.3-6.7 45.3-18.7z"},
      "battery-full": {"width": 576, "height": 512, "path": "M464 160c8.8 0 16 7.2 16 16l0 160c0 8.8-7.2 16-16 16L80 352c-8.8 0-16-7.2-16-16l0-160c0-8.8 7.2-16 16-16l384 0zM80 96C35.8 96 0 131.8 0 176L0 336c0 44.2 35.8 80 80 80l384 0c44.2 0 80-35.8 80-80l0-16c17.7 0 32-14.3 32-32l0-64c0-17.7-14.3-32-32-32l0-16c0-44.2-35.8-80-80-80L80 96zm368 96L96 192l0 128 352 0 0-128z"},
      "server": {"width": 512, "height": 512, "path": "M64 32C28.7 32 0 60.7 0 96l0 64c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-64c0-35.3-28.7-64-64-64L64 32zm280 72a24 24 0 1 1 0 48 24 24 0 1 1 0-48zm48 24a24 24 0 1 1 48 0 24 24 0 1 1 -48 0zM64 288c-35.3 0-64 28.7-64 64l0 64c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-64c0-35.3-28.7-64-64-64L64 288zm280 72a24 24 0 1 1 0 48 24 24 0 1 1 0-48zm56 24a24 24 0 1 1 48 0 24 24 0 1 1 -48 0z"},
      "wand-magic-sparkles": {"width": 576, "height": 512, "path": "M234.7 42.7L197 56.8c-3 1.1-5 4-5 7.2s2 6.1 5 7.2l37.7 14.1L248.8 123c1.1 3 4 5 7.2 5s6.1-2 7.2-5l14.1-37.7L315 71.2c3-1.1 5-4 5-7.2s-2-6.1-5-7.2L277.3 42.7 263.2 5c-1.1-3-4-5-7.2-5s-6.1 2-7.2 5L234.7 42.7zM46.1 395.4c-18.7 18.7-18.7 49.1 0 67.9l34.6 34.6c18.7 18.7 49.1 18.7 67.9 0L529.9 116.5c18.7-18.7 18.7-49.1 0-67.9L495.3 14.1c-18.7-18.7-49.1-18.7-67.9 0L46.1 395.4zM484.6 82.6l-105 105-23.3-23.3 105-105 23.3 23.3zM7.5 117.2C3 118.9 0 123.2 0 128s3 9.1 7.5 10.8L64 160l21.2 56.5c1.7 4.5 6 7.5 10.8 7.5s9.1-3 10.8-7.5L128 160l56.5-21.2c4.5-1.7 7.5-6 7.5-10.8s-3-9.1-7.5-10.8L128 96 106.8 39.5C105.1 35 100.8 32 96 32s-9.1 3-10.8 7.5L64 96 7.5 117.2zm352 256c-4.5 1.7-7.5 6-7.5 10.8s3 9.1 7.5 10.8L416 416l21.2 56.5c1.7 4.5 6 7.5 10.8 7.5s9.1-3 10.8-7.5L480 416l56.5-21.2c4.5-1.7 7.5-6 7.5-10.8s-3-9.1-7.5-10.8L480 352l-21.2-56.5c-1.7-4.5-6-7.5-10.8-7.5s-9.1 3-10.8 7.5L416 352l-56.5 21.2z"},
      "volume-high": {"width": 640, "height": 512, "path": "M533.6 32.5C598.5 85.2 640 165.8 640 256s-41.5 170.7-106.4 223.5c-10.3 8.4-25.4 6.8-33.8-3.5s-6.8-25.4 3.5-33.8C557.5 398.2 592 331.2 592 256s-34.5-142.2-88.7-186.3c-10.3-8.4-11.8-23.5-3.5-33.8s23.5-11.8 33.8-3.5zM473.1 107c43.2 35.2 70.9 88.9 70.9 149s-27.7 113.8-70.9 149c-10.3 8.4-25.4 6.8-33.8-3.5s-6.8-25.4 3.5-33.8C475.3 341.3 496 301.1 496 256s-20.7-85.3-53.2-111.8c-10.3-8.4-11.8-23.5-3.5-33.8s23.5-11.8 33.8-3.5zm-60.5 74.5C434.1 199.1 448 225.9 448 256s-13.9 56.9-35.4 74.5c-10.3 8.4-25.4 6.8-33.8-3.5s-6.8-25.4 3.5-33.8C393.1 284.4 400 271 400 256s-6.9-28.4-17.7-37.3c-10.3-8.4-11.8-23.5-3.5-33.8s23.5-11.8 33.8-3.5zM301.1 34.8C312.6 40 320 51.4 320 64l0 384c0 12.6-7.4 24-18.9 29.2s-25 3.1-34.4-5.3L131.8 352 64 352c-35.3 0-64-28.7-64-64l0-64c0-35.3 28.7-64 64-64l67.8 0L266.7 40.1c9.4-8.4 22.9-10.4 34.4-5.3z"},
      "puzzle-piece": {"width": 512, "height": 512, "path": "M192 104.8c0-9.2-5.8-17.3-13.2-22.8C167.2 73.3 160 61.3 160 48c0-26.5 28.7-48 64-48s64 21.5 64 48c0 13.3-7.2 25.3-18.8 34c-7.4 5.5-13.2 13.6-13.2 22.8c0 12.8 10.4 23.2 23.2 23.2l56.8 0c26.5 0 48 21.5 48 48l0 56.8c0 12.8 10.4 23.2 23.2 23.2c9.2 0 17.3-5.8 22.8-13.2c8.7-11.6 20.7-18.8 34-18.8c26.5 0 48 28.7 48 64s-21.5 64-48 64c-13.3 0-25.3-7.2-34-18.8c-5.5-7.4-13.6-13.2-22.8-13.2c-12.8 0-23.2 10.4-23.2 23.2L384 464c0 26.5-21.5 48-48 48l-56.8 0c-12.8 0-23.2-10.4-23.2-23.2c0-9.2 5.8-17.3 13.2-22.8c11.6-8.7 18.8-20.7 18.8-34c0-26.5-28.7-48-64-48s-64 21.5-64 48c0 13.3 7.2 25.3 18.8 34c7.4 5.5 13.2 13.6 13.2 22.8c0 12.8-10.4 23.2-23.2 23.2L48 512c-26.5 0-48-21.5-48-48L0 343.2C0 330.4 10.4 320 23.2 320c9.2 0 17.3 5.8 22.8 13.2C54.7 344.8 66.7 352 80 352c26.5 0 48-28.7 48-64s-21.5-64-48-64c-13.3 0-25.3 7.2-34 18.8C40.5 250.2 32.4 256 23.2 256C10.4 256 0 245.6 0 232.8L0 176c0-26.5 21.5-48 48-48l120.8 0c12.8 0 23.2-10.4 23.2-23.2z"},
      "robot": {"width": 640, "height": 512, "path": "M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z"},
      "hard-drive": {"width": 512, "height": 512, "path": "M0 96C0 60.7 28.7 32 64 32l384 0c35.3 0 64 28.7 64 64l0 184.4c-17-15.2-39.4-24.4-64-24.4L64 256c-24.6 0-47 9.2-64 24.4L0 96zM64 288l384 0c35.3 0 64 28.7 64 64l0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64l0-64c0-35.3 28.7-64 64-64zM320 416a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm128-32a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"},
      "arrows-rotate": {"width": 512, "height": 512, "path": "M105.1 202.6c7.7-21.8 20.2-42.3 37.8-59.8c62.5-62.5 163.8-62.5 226.3 0L386.3 160 352 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l111.5 0c0 0 0 0 0 0l.4 0c17.7 0 32-14.3 32-32l0-112c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 35.2L414.4 97.6c-87.5-87.5-229.3-87.5-316.8 0C73.2 122 55.6 150.7 44.8 181.4c-5.9 16.7 2.9 34.9 19.5 40.8s34.9-2.9 40.8-19.5zM39 289.3c-5 1.5-9.8 4.2-13.7 8.2c-4 4-6.7 8.8-8.1 14c-.3 1.2-.6 2.5-.8 3.8c-.3 1.7-.4 3.4-.4 5.1L16 432c0 17.7 14.3 32 32 32s32-14.3 32-32l0-35.1 17.6 17.5c0 0 0 0 0 0c87.5 87.4 229.3 87.4 316.7 0c24.4-24.4 42.1-53.1 52.9-83.8c5.9-16.7-2.9-34.9-19.5-40.8s-34.9 2.9-40.8 19.5c-7.7 21.8-20.2 42.3-37.8 59.8c-62.5 62.5-163.8 62.5-226.3 0l-.1-.1L125.6 352l34.4 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L48.4 288c-1.6 0-3.2 .1-4.8 .3s-3.1 .5-4.6 1z"},
      "forward-step": {"width": 320, "height": 512, "path": "M52.5 440.6c-9.5 7.9-22.8 9.7-34.1 4.4S0 428.4 0 416L0 96C0 83.6 7.2 72.3 18.4 67s24.5-3.6 34.1 4.4l192 160L256 241l0-145c0-17.7 14.3-32 32-32s32 14.3 32 32l0 320c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-145-11.5 9.6-192 160z"},
      "circle-info": {"width": 512, "height": 512, "path": "M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"},
      "droplet": {"width": 384, "height": 512, "path": "M192 512C86 512 0 426 0 320C0 228.8 130.2 57.7 166.6 11.7C172.6 4.2 181.5 0 191.1 0l1.8 0c9.6 0 18.5 4.2 24.5 11.7C253.8 57.7 384 228.8 384 320c0 106-86 192-192 192zM96 336c0-8.8-7.2-16-16-16s-16 7.2-16 16c0 61.9 50.1 112 112 112c8.8 0 16-7.2 16-16s-7.2-16-16-16c-44.2 0-80-35.8-80-80z"},
      "image": {"width": 512, "height": 512, "path": "M0 96C0 60.7 28.7 32 64 32l384 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zM323.8 202.5c-4.5-6.6-11.9-10.5-19.8-10.5s-15.4 3.9-19.8 10.5l-87 127.6L170.7 297c-4.6-5.7-11.5-9-18.7-9s-14.2 3.3-18.7 9l-64 80c-5.8 7.2-6.9 17.1-2.9 25.4s12.4 13.6 21.6 13.6l96 0 32 0 208 0c8.9 0 17.1-4.9 21.2-12.8s3.6-17.4-1.4-24.7l-120-176zM112 192a48 48 0 1 0 0-96 48 48 0 1 0 0 96z"},
      "icons": {"width": 512, "height": 512, "path": "M500.3 7.3C507.7 13.3 512 22.4 512 32l0 144c0 26.5-28.7 48-64 48s-64-21.5-64-48s28.7-48 64-48l0-57L352 90.2 352 208c0 26.5-28.7 48-64 48s-64-21.5-64-48s28.7-48 64-48l0-96c0-15.3 10.8-28.4 25.7-31.4l160-32c9.4-1.9 19.1 .6 26.6 6.6zM74.7 304l11.8-17.8c5.9-8.9 15.9-14.2 26.6-14.2l61.7 0c10.7 0 20.7 5.3 26.6 14.2L213.3 304l26.7 0c26.5 0 48 21.5 48 48l0 112c0 26.5-21.5 48-48 48L48 512c-26.5 0-48-21.5-48-48L0 352c0-26.5 21.5-48 48-48l26.7 0zM192 408a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM478.7 278.3L440.3 368l55.7 0c6.7 0 12.6 4.1 15 10.4s.6 13.3-4.4 17.7l-128 112c-5.6 4.9-13.9 5.3-19.9 .9s-8.2-12.4-5.3-19.2L391.7 400 336 400c-6.7 0-12.6-4.1-15-10.4s-.6-13.3 4.4-17.7l128-112c5.6-4.9 13.9-5.3 19.9-.9s8.2 12.4 5.3 19.2zm-339-59.2c-6.5 6.5-17 6.5-23 0L19.9 119.2c-28-29-26.5-76.9 5-103.9c27-23.5 68.4-19 93.4 6.5l10 10.5 9.5-10.5c25-25.5 65.9-30 93.9-6.5c31 27 32.5 74.9 4.5 103.9l-96.4 99.9z"},
      "font": {"width": 448, "height": 512, "path": "M254 52.8C249.3 40.3 237.3 32 224 32s-25.3 8.3-30 20.8L57.8 416 32 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-1.8 0 18-48 159.6 0 18 48-1.8 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-25.8 0L254 52.8zM279.8 304l-111.6 0L224 155.1 279.8 304z"},
      "window-maximize": {"width": 512, "height": 512, "path": "M64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zM96 96l320 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L96 160c-17.7 0-32-14.3-32-32s14.3-32 32-32z"},
      "universal-access": {"width": 512, "height": 512, "path": "M0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm161.5-86.1c-12.2-5.2-26.3 .4-31.5 12.6s.4 26.3 12.6 31.5l11.9 5.1c17.3 7.4 35.2 12.9 53.6 16.3l0 50.1c0 4.3-.7 8.6-2.1 12.6l-28.7 86.1c-4.2 12.6 2.6 26.2 15.2 30.4s26.2-2.6 30.4-15.2l24.4-73.2c1.3-3.8 4.8-6.4 8.8-6.4s7.6 2.6 8.8 6.4l24.4 73.2c4.2 12.6 17.8 19.4 30.4 15.2s19.4-17.8 15.2-30.4l-28.7-86.1c-1.4-4.1-2.1-8.3-2.1-12.6l0-50.1c18.4-3.5 36.3-8.9 53.6-16.3l11.9-5.1c12.2-5.2 17.8-19.3 12.6-31.5s-19.3-17.8-31.5-12.6L338.7 175c-26.1 11.2-54.2 17-82.7 17s-56.5-5.8-82.7-17l-11.9-5.1zM256 160a40 40 0 1 0 0-80 40 40 0 1 0 0 80z"},
      "code": {"width": 640, "height": 512, "path": "M392.8 1.2c-17-4.9-34.7 5-39.6 22l-128 448c-4.9 17 5 34.7 22 39.6s34.7-5 39.6-22l128-448c4.9-17-5-34.7-22-39.6zm80.6 120.1c-12.5 12.5-12.5 32.8 0 45.3L562.7 256l-89.4 89.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l112-112c12.5-12.5 12.5-32.8 0-45.3l-112-112c-12.5-12.5-32.8-12.5-45.3 0zm-306.7 0c-12.5-12.5-32.8-12.5-45.3 0l-112 112c-12.5 12.5-12.5 32.8 0 45.3l112 112c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256l89.4-89.4c12.5-12.5 12.5-32.8 0-45.3z"},
      "box-archive": {"width": 512, "height": 512, "path": "M32 32l448 0c17.7 0 32 14.3 32 32l0 32c0 17.7-14.3 32-32 32L32 128C14.3 128 0 113.7 0 96L0 64C0 46.3 14.3 32 32 32zm0 128l448 0 0 256c0 35.3-28.7 64-64 64L96 480c-35.3 0-64-28.7-64-64l0-256zm128 80c0 8.8 7.2 16 16 16l160 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-160 0c-8.8 0-16 7.2-16 16z"},
      "copy": {"width": 448, "height": 512, "path": "M208 0L332.1 0c12.7 0 24.9 5.1 33.9 14.1l67.9 67.9c9 9 14.1 21.2 14.1 33.9L448 336c0 26.5-21.5 48-48 48l-192 0c-26.5 0-48-21.5-48-48l0-288c0-26.5 21.5-48 48-48zM48 128l80 0 0 64-64 0 0 256 192 0 0-32 64 0 0 48c0 26.5-21.5 48-48 48L48 512c-26.5 0-48-21.5-48-48L0 176c0-26.5 21.5-48 48-48z"},
      "folder-open": {"width": 576, "height": 512, "path": "M88.7 223.8L0 375.8 0 96C0 60.7 28.7 32 64 32l117.5 0c17 0 33.3 6.7 45.3 18.7l26.5 26.5c12 12 28.3 18.7 45.3 18.7L416 96c35.3 0 64 28.7 64 64l0 32-336 0c-22.8 0-43.8 12.1-55.3 31.8zm27.6 16.1C122.1 230 132.6 224 144 224l400 0c11.5 0 22 6.1 27.7 16.1s5.7 22.2-.1 32.1l-112 192C453.9 474 443.4 480 432 480L32 480c-11.5 0-22-6.1-27.7-16.1s-5.7-22.2 .1-32.1l112-192z"},
      "file-export": {"width": 576, "height": 512, "path": "M0 64C0 28.7 28.7 0 64 0L224 0l0 128c0 17.7 14.3 32 32 32l128 0 0 128-168 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l168 0 0 112c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zM384 336l0-48 110.1 0-39-39c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l80 80c9.4 9.4 9.4 24.6 0 33.9l-80 80c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l39-39L384 336zm0-208l-128 0L256 0 384 128z"},
      "file-import": {"width": 512, "height": 512, "path": "M128 64c0-35.3 28.7-64 64-64L352 0l0 128c0 17.7 14.3 32 32 32l128 0 0 288c0 35.3-28.7 64-64 64l-256 0c-35.3 0-64-28.7-64-64l0-112 174.1 0-39 39c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l80-80c9.4-9.4 9.4-24.6 0-33.9l-80-80c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l39 39L128 288l0-224zm0 224l0 48L24 336c-13.3 0-24-10.7-24-24s10.7-24 24-24l104 0zM512 128l-128 0L384 0 512 128z"},
      "plus": {"width": 448, "height": 512, "path": "M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"},
      "trash-can": {"width": 448, "height": 512, "path": "M135.2 17.7C140.6 6.8 151.7 0 163.8 0H284.2c12.1 0 23.2 6.8 28.6 17.7L320 32h96c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 96 0 81.7 0 64S14.3 32 32 32h96l7.2-14.3zM32 128H416V432c0 44.2-35.8 80-80 80H112c-44.2 0-80-35.8-80-80V128zm104 80c-8.8 0-16 7.2-16 16V416c0 8.8 7.2 16 16 16s16-7.2 16-16V224c0-8.8-7.2-16-16-16zm88 0c-8.8 0-16 7.2-16 16V416c0 8.8 7.2 16 16 16s16-7.2 16-16V224c0-8.8-7.2-16-16-16zm88 0c-8.8 0-16 7.2-16 16V416c0 8.8 7.2 16 16 16s16-7.2 16-16V224c0-8.8-7.2-16-16-16z"},
      "rotate-left": {"width": 512, "height": 512, "path": "M48.5 224L40 224c-13.3 0-24-10.7-24-24L16 72c0-9.7 5.8-18.5 14.8-22.2s19.3-1.7 26.2 5.2L98.6 96.6c87.6-86.5 228.7-86.2 315.8 1c87.5 87.5 87.5 229.3 0 316.8s-229.3 87.5-316.8 0c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0c62.5 62.5 163.8 62.5 226.3 0s62.5-163.8 0-226.3c-62.2-62.2-162.7-62.5-225.3-1L185 183c6.9 6.9 8.9 17.2 5.2 26.2s-12.5 14.8-22.2 14.8L48.5 224z"},
      "xmark": {"width": 384, "height": 512, "path": "M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"},
      "chevron-down": {"width": 512, "height": 512, "path": "M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"},
      "plug-circle-check": {"width": 576, "height": 512, "path": "M96 0C78.3 0 64 14.3 64 32l0 96 64 0 0-96c0-17.7-14.3-32-32-32zM288 0c-17.7 0-32 14.3-32 32l0 96 64 0 0-96c0-17.7-14.3-32-32-32zM32 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l0 32c0 77.4 55 142 128 156.8l0 67.2c0 17.7 14.3 32 32 32s32-14.3 32-32l0-67.2c12.3-2.5 24.1-6.4 35.1-11.5c-2.1-10.8-3.1-21.9-3.1-33.3c0-80.3 53.8-148 127.3-169.2c.5-2.2 .7-4.5 .7-6.8c0-17.7-14.3-32-32-32L32 160zM576 368a144 144 0 1 0 -288 0 144 144 0 1 0 288 0zm-76.7-43.3c6.2 6.2 6.2 16.4 0 22.6l-72 72c-6.2 6.2-16.4 6.2-22.6 0l-40-40c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0L416 385.4l60.7-60.7c6.2-6.2 16.4-6.2 22.6 0z"},
      "play": {"width": 384, "height": 512, "path": "M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"},
      "stop": {"width": 384, "height": 512, "path": "M0 128C0 92.7 28.7 64 64 64H320c35.3 0 64 28.7 64 64V384c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V128z"},
      "cloud-arrow-down": {"width": 640, "height": 512, "path": "M144 480C64.5 480 0 415.5 0 336c0-62.8 40.2-116.2 96.2-135.9c-.1-2.7-.2-5.4-.2-8.1c0-88.4 71.6-160 160-160c59.3 0 111 32.2 138.7 80.2C409.9 102 428.3 96 448 96c53 0 96 43 96 96c0 12.2-2.3 23.8-6.4 34.6C596 238.4 640 290.1 640 352c0 70.7-57.3 128-128 128l-368 0zm79-167l80 80c9.4 9.4 24.6 9.4 33.9 0l80-80c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-39 39L344 184c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 134.1-39-39c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9z"},
      "user": {"width": 448, "height": 512, "path": "M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512l388.6 0c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304l-91.4 0z"},
      "crown": {"width": 576, "height": 512, "path": "M309 106c11.4-7 19-19.7 19-34c0-22.1-17.9-40-40-40s-40 17.9-40 40c0 14.4 7.6 27 19 34L209.7 220.6c-9.1 18.2-32.7 23.4-48.6 10.7L72 160c5-6.7 8-15 8-24c0-22.1-17.9-40-40-40S0 113.9 0 136s17.9 40 40 40c.2 0 .5 0 .7 0L86.4 427.4c5.5 30.4 32 52.6 63 52.6l277.2 0c30.9 0 57.4-22.1 63-52.6L535.3 176c.2 0 .5 0 .7 0c22.1 0 40-17.9 40-40s-17.9-40-40-40s-40 17.9-40 40c0 9 3 17.3 8 24l-89.1 71.3c-15.9 12.7-39.5 7.5-48.6-10.7L309 106z"},
      "sun": {"width": 512, "height": 512, "path": "M361.5 1.2c5 2.1 8.6 6.6 9.6 11.9L391 121l107.9 19.8c5.3 1 9.8 4.6 11.9 9.6s1.5 10.7-1.6 15.2L446.9 256l62.3 90.3c3.1 4.5 3.7 10.2 1.6 15.2s-6.6 8.6-11.9 9.6L391 391 371.1 498.9c-1 5.3-4.6 9.8-9.6 11.9s-10.7 1.5-15.2-1.6L256 446.9l-90.3 62.3c-4.5 3.1-10.2 3.7-15.2 1.6s-8.6-6.6-9.6-11.9L121 391 13.1 371.1c-5.3-1-9.8-4.6-11.9-9.6s-1.5-10.7 1.6-15.2L65.1 256 2.8 165.7c-3.1-4.5-3.7-10.2-1.6-15.2s6.6-8.6 11.9-9.6L121 121 140.9 13.1c1-5.3 4.6-9.8 9.6-11.9s10.7-1.5 15.2 1.6L256 65.1 346.3 2.8c4.5-3.1 10.2-3.7 15.2-1.6zM160 256a96 96 0 1 1 192 0 96 96 0 1 1-192 0zm224 0a128 128 0 1 0-256 0 128 128 0 1 0 256 0z"},
      "moon": {"width": 384, "height": 512, "path": "M223.5 32C100 32 0 132.3 0 256S100 480 223.5 480c60.6 0 115.5-24.2 155.8-63.4c5-4.9 6.3-12.5 3.1-18.7s-10.1-9.7-17-8.5c-9.8 1.7-19.8 2.6-30.1 2.6c-96.9 0-175.5-78.8-175.5-176c0-65.8 36-123.1 89.3-153.3c6.1-3.5 9.2-10.5 7.7-17.3s-7.3-11.9-14.3-12.5c-6.3-.5-12.6-.8-19-.8z"},
      "star": {"width": 576, "height": 512, "path": "M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z"},
      "ellipsis": {"width": 448, "height": 512, "path": "M8 256a56 56 0 1 1 112 0A56 56 0 1 1 8 256zm160 0a56 56 0 1 1 112 0 56 56 0 1 1 -112 0zm216-56a56 56 0 1 1 0 112 56 56 0 1 1 0-112z"},
      "circle-plus": {"width": 512, "height": 512, "path": "M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM232 344l0-64-64 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l64 0 0-64c0-13.3 10.7-24 24-24s24 10.7 24 24l0 64 64 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-64 0 0 64c0 13.3-10.7 24-24 24s-24-10.7-24-24z"},
      "user-plus": {"width": 640, "height": 512, "path": "M96 128a128 128 0 1 1 256 0A128 128 0 1 1 96 128zM0 482.3C0 383.8 79.8 304 178.3 304l91.4 0C368.2 304 448 383.8 448 482.3c0 16.4-13.3 29.7-29.7 29.7L29.7 512C13.3 512 0 498.7 0 482.3zM504 312l0-64-64 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l64 0 0-64c0-13.3 10.7-24 24-24s24 10.7 24 24l0 64 64 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-64 0 0 64c0 13.3-10.7 24-24 24s-24-10.7-24-24z"},
      "chevron-right": {"width": 320, "height": 512, "path": "M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"},
      "comment": {"width": 512, "height": 512, "path": "M512 240c0 114.9-114.6 208-256 208c-37.1 0-72.3-6.4-104.1-17.9c-11.9 8.7-31.3 20.6-54.3 30.6C73.6 471.1 44.7 480 16 480c-6.5 0-12.3-3.9-14.8-9.9c-2.5-6-1.1-12.8 3.4-17.4c0 0 0 0 0 0s0 0 0 0s0 0 0 0c0 0 0 0 0 0l.3-.3c.3-.3 .7-.7 1.3-1.4c1.1-1.2 2.8-3.1 4.9-5.7c4.1-5 9.6-12.4 15.2-21.6c10-16.6 19.5-38.4 21.4-62.9C17.7 326.8 0 285.1 0 240C0 125.1 114.6 32 256 32s256 93.1 256 208z"},
      "square-check": {"width": 448, "height": 512, "path": "M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64zM337 209L209 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L303 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"},
      "quote-left": {"width": 448, "height": 512, "path": "M0 216C0 149.7 53.7 96 120 96h8c17.7 0 32 14.3 32 32s-14.3 32-32 32h-8c-30.9 0-56 25.1-56 56v8h64c35.3 0 64 28.7 64 64v64c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V216zm256 0c0-66.3 53.7-120 120-120h8c17.7 0 32 14.3 32 32s-14.3 32-32 32h-8c-30.9 0-56 25.1-56 56v8h64c35.3 0 64 28.7 64 64v64c0 35.3-28.7 64-64 64h-64c-35.3 0-64-28.7-64-64V216z"},
      "heart": {"width": 512, "height": 512, "path": "M47.6 300.4L228.3 469.1c7.5 7 17.4 10.9 27.7 10.9s20.2-3.9 27.7-10.9L464.4 300.4c30.4-28.3 47.6-68 47.6-109.5v-5.8c0-69.9-50.5-129.5-119.4-141C347 36.5 300.6 51.4 268 84L256 96 244 84c-32.6-32.6-79-47.5-124.6-39.9C50.5 55.6 0 115.2 0 185.1v5.8c0 41.5 17.2 81.2 47.6 109.5z"},
      "lightbulb": {"width": 384, "height": 512, "path": "M272 384c9.6-31.9 29.5-59.1 49.2-86.2c0 0 0 0 0 0c5.2-7.1 10.4-14.2 15.4-21.4c19.8-28.5 31.4-63 31.4-100.3C368 78.8 289.2 0 192 0S16 78.8 16 176c0 37.3 11.6 71.9 31.4 100.3c5 7.2 10.2 14.3 15.4 21.4c0 0 0 0 0 0c19.8 27.1 39.7 54.4 49.2 86.2l160 0zM192 512c44.2 0 80-35.8 80-80l0-16-160 0 0 16c0 44.2 35.8 80 80 80zM112 176c0 8.8-7.2 16-16 16s-16-7.2-16-16c0-61.9 50.1-112 112-112c8.8 0 16 7.2 16 16s-7.2 16-16 16c-44.2 0-80 35.8-80 80z"},
      "link": {"width": 640, "height": 512, "path": "M579.8 267.7c56.5-56.5 56.5-148 0-204.5c-50-50-128.8-56.5-186.3-15.4l-1.6 1.1c-14.4 10.3-17.7 30.3-7.4 44.6s30.3 17.7 44.6 7.4l1.6-1.1c32.1-22.9 76-19.3 103.8 8.6c31.5 31.5 31.5 82.5 0 114L422.3 334.8c-31.5 31.5-82.5 31.5-114 0c-27.9-27.9-31.5-71.8-8.6-103.8l1.1-1.6c10.3-14.4 6.9-34.4-7.4-44.6s-34.4-6.9-44.6 7.4l-1.1 1.6C206.5 251.2 213 330 263 380c56.5 56.5 148 56.5 204.5 0L579.8 267.7zM60.2 244.3c-56.5 56.5-56.5 148 0 204.5c50 50 128.8 56.5 186.3 15.4l1.6-1.1c14.4-10.3 17.7-30.3 7.4-44.6s-30.3-17.7-44.6-7.4l-1.6 1.1c-32.1 22.9-76 19.3-103.8-8.6C74 372 74 321 105.5 289.5L217.7 177.2c31.5-31.5 82.5-31.5 114 0c27.9 27.9 31.5 71.8 8.6 103.9l-1.1 1.6c-10.3 14.4-6.9 34.4 7.4 44.6s34.4 6.9 44.6-7.4l1.1-1.6C433.5 260.8 427 182 377 132c-56.5-56.5-148-56.5-204.5 0L60.2 244.3z"},
      "share-nodes": {"width": 448, "height": 512, "path": "M352 224c53 0 96-43 96-96s-43-96-96-96s-96 43-96 96c0 4 .2 8 .7 11.9l-94.1 47C145.4 170.2 121.9 160 96 160c-53 0-96 43-96 96s43 96 96 96c25.9 0 49.4-10.2 66.6-26.9l94.1 47c-.5 3.9-.7 7.8-.7 11.9c0 53 43 96 96 96s96-43 96-96s-43-96-96-96c-25.9 0-49.4 10.2-66.6 26.9l-94.1-47c.5-3.9 .7-7.8 .7-11.9s-.2-8-.7-11.9l94.1-47C302.6 213.8 326.1 224 352 224z"},
      "circle-play": {"width": 512, "height": 512, "path": "M0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zM188.3 147.1c-7.6 4.2-12.3 12.3-12.3 20.9l0 176c0 8.7 4.7 16.7 12.3 20.9s16.8 4.1 24.3-.5l144-88c7.1-4.4 11.5-12.1 11.5-20.5s-4.4-16.1-11.5-20.5l-144-88c-7.4-4.5-16.7-4.7-24.3-.5z"},
      "book-open": {"width": 576, "height": 512, "path": "M249.6 471.5c10.8 3.8 22.4-4.1 22.4-15.5l0-377.4c0-4.2-1.6-8.4-5-11C247.4 52 202.4 32 144 32C93.5 32 46.3 45.3 18.1 56.1C6.8 60.5 0 71.7 0 83.8L0 454.1c0 11.9 12.8 20.2 24.1 16.5C55.6 460.1 105.5 448 144 448c33.9 0 79 14 105.6 23.5zm76.8 0C353 462 398.1 448 432 448c38.5 0 88.4 12.1 119.9 22.6c11.3 3.8 24.1-4.6 24.1-16.5l0-370.3c0-12.1-6.8-23.3-18.1-27.6C529.7 45.3 482.5 32 432 32c-58.4 0-103.4 20-123 35.6c-3.3 2.6-5 6.8-5 11L304 456c0 11.4 11.7 19.3 22.4 15.5z"},
      "calendar-check": {"width": 448, "height": 512, "path": "M128 0c17.7 0 32 14.3 32 32l0 32 128 0 0-32c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 48 0c26.5 0 48 21.5 48 48l0 48L0 160l0-48C0 85.5 21.5 64 48 64l48 0 0-32c0-17.7 14.3-32 32-32zM0 192l448 0 0 272c0 26.5-21.5 48-48 48L48 512c-26.5 0-48-21.5-48-48L0 192zM329 305c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-95 95-47-47c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l64 64c9.4 9.4 24.6 9.4 33.9 0L329 305z"},
      "pen": {"width": 512, "height": 512, "path": "M362.7 19.3L314.3 67.7 444.3 197.7l48.4-48.4c25-25 25-65.5 0-90.5L453.3 19.3c-25-25-65.5-25-90.5 0zm-71 71L58.6 323.5c-10.4 10.4-18 23.3-22.2 37.4L1 481.2C-1.5 489.7 .8 498.8 7 505s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L421.7 220.3 291.7 90.3z"},
      "thumbs-up": {"width": 512, "height": 512, "path": "M313.4 32.9c26 5.2 42.9 30.5 37.7 56.5l-2.3 11.4c-5.3 26.7-15.1 52.1-28.8 75.2l144 0c26.5 0 48 21.5 48 48c0 18.5-10.5 34.6-25.9 42.6C497 275.4 504 288.9 504 304c0 23.4-16.8 42.9-38.9 47.1c4.4 7.3 6.9 15.8 6.9 24.9c0 21.3-13.9 39.4-33.1 45.6c.7 3.3 1.1 6.8 1.1 10.4c0 26.5-21.5 48-48 48l-97.5 0c-19 0-37.5-5.6-53.3-16.1l-38.5-25.7C176 420.4 160 390.4 160 358.3l0-38.3 0-48 0-24.9c0-29.2 13.3-56.7 36-75l7.4-5.9c26.5-21.2 44.6-51 51.2-84.2l2.3-11.4c5.2-26 30.5-42.9 56.5-37.7zM32 192l64 0c17.7 0 32 14.3 32 32l0 224c0 17.7-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32L0 224c0-17.7 14.3-32 32-32z"},
      "bars": {"width": 448, "height": 512, "path": "M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 288 0 273.7 0 256zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z"},
      "location-dot": {"width": 750, "height": 1000, "path": "M336 980C355 1007 395 1007 414 980C698 569 750 526 750 375C750 168 582 0 375 0C168 0 0 168 0 375C0 526 52 569 336 980ZM375 531C289 531 219 461 219 375C219 289 289 219 375 219C461 219 531 289 531 375C531 461 461 531 375 531Z"},
      "envelope": {"width": 1000, "height": 1000, "path": "M981 373C937 407 879 450 680 595C640 624 570 689 500 688C431 688 361 625 320 595C121 450 63 407 19 373C11 367 0 372 0 382V781C0 833 42 875 94 875H906C958 875 1000 833 1000 781V382C1000 372 989 367 981 373ZM500 625C545 626 610 568 643 544C902 356 922 340 982 293C993 284 1000 270 1000 256V219C1000 167 958 125 906 125H94C42 125 0 167 0 219V256C0 270 7 284 18 293C78 340 98 356 357 544C390 568 455 626 500 625Z"},
      "money-bill-wave": {"width": 1250, "height": 1000, "path": "M1213 106C1137 74 1062 63 986 63C745 63 505 184 264 184C204 184 143 176 83 157C76 155 70 154 63 154C29 154 0 180 0 216V836C0 861 14 885 37 894C113 926 188 937 264 937C505 937 745 816 986 816C1046 816 1107 824 1167 843C1174 845 1180 846 1187 846C1221 846 1250 820 1250 784V164C1250 139 1236 116 1213 106ZM94 258C133 268 174 273 216 276C205 333 155 376 94 376ZM94 815V722C161 722 215 774 218 841C174 837 133 829 94 815ZM625 687C539 687 469 604 469 500C469 396 539 313 625 313C711 313 781 396 781 500C781 604 711 687 625 687ZM1156 742C1122 733 1086 728 1050 725C1061 674 1104 636 1156 629ZM1156 281C1096 273 1049 222 1047 160C1085 164 1121 172 1156 185Z"},
      "id-card": {"width": 1125, "height": 1000, "path": "M1031 63H94C42 63 0 104 0 156V187H1125V156C1125 104 1083 63 1031 63ZM0 844C0 896 42 937 94 937H1031C1083 937 1125 896 1125 844V250H0ZM688 391C688 382 694 375 703 375H984C993 375 1000 382 1000 391V422C1000 431 993 437 984 437H703C694 437 688 431 688 422ZM688 516C688 507 694 500 703 500H984C993 500 1000 507 1000 516V547C1000 556 993 563 984 563H703C694 563 688 556 688 547ZM688 641C688 632 694 625 703 625H984C993 625 1000 632 1000 641V672C1000 681 993 687 984 687H703C694 687 688 681 688 672ZM344 375C413 375 469 431 469 500C469 569 413 625 344 625C275 625 219 569 219 500C219 431 275 375 344 375ZM131 774C147 724 195 687 250 687H266C290 697 316 703 344 703C372 703 397 697 421 687H438C493 687 540 724 556 774C562 793 546 813 526 813H162C142 813 125 793 131 774Z"},
      "gift": {"width": 1000, "height": 1000, "path": "M62 875C62 910 90 937 125 937H438V625H62ZM562 937H875C910 937 938 910 938 875V625H562ZM938 313H855C867 289 875 262 875 234C875 139 798 63 703 63C622 63 569 104 502 196C435 104 382 63 301 63C206 63 129 139 129 234C129 262 137 289 149 313H62C27 313 0 340 0 375V531C0 548 14 563 31 563H969C986 563 1000 548 1000 531V375C1000 340 973 313 938 313ZM301 313C258 313 222 277 222 234C222 191 258 156 301 156C340 156 368 163 469 313ZM703 313H535C635 164 663 156 703 156C746 156 781 191 781 234C781 277 746 313 703 313Z"},
      "desktop": {"width": 1125, "height": 1000, "path": "M1031 0H94C42 0 0 42 0 94V719C0 771 42 813 94 813H469L438 906H297C271 906 250 927 250 953C250 979 271 1000 297 1000H828C854 1000 875 979 875 953C875 927 854 906 828 906H688L656 813H1031C1083 813 1125 771 1125 719V94C1125 42 1083 0 1031 0ZM1000 687H125V125H1000Z"},
      "music": {"width": 1000, "height": 1000, "path": "M919 3 294 187C269 195 250 219 250 247V758C230 753 210 750 188 750C84 750 0 806 0 875C0 944 84 1000 188 1000C292 1000 375 944 375 875V419L875 272V633C855 628 834 625 812 625C708 625 625 681 625 750C625 819 708 875 812 875C916 875 1000 819 1000 750V63C1000 29 972 0 938 0C931 0 925 1 919 3Z"},
      "palette": {"width": 512, "height": 512, "path": "M512 256c0 .9 0 1.8 0 2.7c-.4 36.5-33.6 61.3-70.1 61.3L344 320c-26.5 0-48 21.5-48 48c0 3.4 .4 6.7 1 9.9c2.1 10.2 6.5 20 10.8 29.9c6.1 13.8 12.1 27.5 12.1 42c0 31.8-21.6 60.7-53.4 62c-3.5 .1-7 .2-10.6 .2C114.6 512 0 397.4 0 256S114.6 0 256 0S512 114.6 512 256zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm0-96a32 32 0 1 0 0-64 32 32 0 1 0 0 64zM288 96a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm96 96a32 32 0 1 0 0-64 32 32 0 1 0 0 64z"},
      "gear": {"width": 512, "height": 512, "path": "M495.9 166.6c3.2 8.7 .5 18.4-6.4 24.6l-43.3 39.4c1.1 8.3 1.7 16.8 1.7 25.4s-.6 17.1-1.7 25.4l43.3 39.4c6.9 6.2 9.6 15.9 6.4 24.6c-4.4 11.9-9.7 23.3-15.8 34.3l-4.7 8.1c-6.6 11-14 21.4-22.1 31.2c-5.9 7.2-15.7 9.6-24.5 6.8l-55.7-17.7c-13.4 10.3-28.2 18.9-44 25.4l-12.5 57.1c-2 9.1-9 16.3-18.2 17.8c-13.8 2.3-28 3.5-42.5 3.5s-28.7-1.2-42.5-3.5c-9.2-1.5-16.2-8.7-18.2-17.8l-12.5-57.1c-15.8-6.5-30.6-15.1-44-25.4L83.1 425.9c-8.8 2.8-18.6 .3-24.5-6.8c-8.1-9.8-15.5-20.2-22.1-31.2l-4.7-8.1c-6.1-11-11.4-22.4-15.8-34.3c-3.2-8.7-.5-18.4 6.4-24.6l43.3-39.4C64.6 273.1 64 264.6 64 256s.6-17.1 1.7-25.4L22.4 191.2c-6.9-6.2-9.6-15.9-6.4-24.6c4.4-11.9 9.7-23.3 15.8-34.3l4.7-8.1c6.6-11 14-21.4 22.1-31.2c5.9-7.2 15.7-9.6 24.5-6.8l55.7 17.7c13.4-10.3 28.2-18.9 44-25.4l12.5-57.1c2-9.1 9-16.3 18.2-17.8C227.3 1.2 241.5 0 256 0s28.7 1.2 42.5 3.5c9.2 1.5 16.2 8.7 18.2 17.8l12.5 57.1c15.8 6.5 30.6 15.1 44 25.4l55.7-17.7c8.8-2.8 18.6-.3 24.5 6.8c8.1 9.8 15.5 20.2 22.1 31.2l4.7 8.1c6.1 11 11.4 22.4 15.8 34.3zM256 336a80 80 0 1 0 0-160 80 80 0 1 0 0 160z"},
      "paper-plane": {"width": 512, "height": 512, "path": "M498.1 5.6c10.1 7 15.4 19.1 13.5 31.2l-64 416c-1.5 9.7-7.4 18.2-16 23s-18.9 5.4-28 1.6L284 427.7l-68.5 74.1c-8.9 9.7-22.9 12.9-35.2 8.1S160 493.2 160 480l0-83.6c0-4 1.5-7.8 4.2-10.8L331.8 202.8c5.8-6.3 5.6-16-.4-22s-15.7-6.4-22-.7L106 360.8 17.7 316.6C7.1 311.3 .3 300.7 0 288.9s5.9-22.8 16.1-28.7l448-256c10.7-6.1 23.8-5.5 34 1.4z"},
      "bookmark": {"width": 384, "height": 512, "path": "M0 48V487.7C0 501.1 10.9 512 24.3 512c5 0 9.9-1.5 14-4.4L192 400 345.7 507.6c4.1 2.9 9 4.4 14 4.4c13.4 0 24.3-10.9 24.3-24.3V48c0-26.5-21.5-48-48-48H48C21.5 0 0 21.5 0 48z"},
      "folder": {"width": 512, "height": 512, "path": "M64 480H448c35.3 0 64-28.7 64-64V160c0-35.3-28.7-64-64-64H288c-10.1 0-19.6-4.7-25.6-12.8L243.2 57.6C231.1 41.5 212.1 32 192 32H64C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64z"},
      "credit-card": {"width": 576, "height": 512, "path": "M64 32C28.7 32 0 60.7 0 96l0 32 576 0 0-32c0-35.3-28.7-64-64-64L64 32zM576 224L0 224 0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-192zM112 352l64 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-64 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm112 16c0-8.8 7.2-16 16-16l128 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-128 0c-8.8 0-16-7.2-16-16z"},
      "shirt": {"width": 640, "height": 512, "path": "M211.8 0c7.8 0 14.3 5.7 16.7 13.2C240.8 51.9 277.1 80 320 80s79.2-28.1 91.5-66.8C413.9 5.7 420.4 0 428.2 0l12.6 0c22.5 0 44.2 7.9 61.5 22.3L628.5 127.4c6.6 5.5 10.7 13.5 11.4 22.1s-2.1 17.1-7.8 23.6l-56 64c-11.4 13.1-31.2 14.6-44.6 3.5L480 197.7 480 448c0 35.3-28.7 64-64 64l-192 0c-35.3 0-64-28.7-64-64l0-250.3-51.5 42.9c-13.3 11.1-33.1 9.6-44.6-3.5l-56-64c-5.7-6.5-8.5-15-7.8-23.6s4.8-16.6 11.4-22.1L137.7 22.3C155 7.9 176.7 0 199.2 0l12.6 0z"},
      "cloud-sun": {"width": 640, "height": 512, "path": "M294 1Q302 5 304 13L318 98L403 112Q411 114 415 122Q418 130 413 137L375 192Q371 192 368 192Q333 192 304 209V208Q303 167 276 140Q249 113 208 112Q167 113 140 140Q113 167 112 208Q113 249 140 276Q167 303 208 304Q220 304 231 301Q204 315 185 340Q167 364 162 396L137 413Q130 418 122 415Q114 411 112 402L98 318L13 304Q5 302 1 294Q-2 286 3 279L53 208L3 137Q-2 130 1 122Q5 114 13 112L98 98L112 13Q114 5 122 1Q130 -2 137 3L208 53L279 3Q286 -2 294 1ZM144 208Q145 172 176 153Q208 135 240 153Q271 172 272 208Q271 244 240 263Q208 281 176 263Q145 244 144 208ZM640 432Q639 466 616 488Q594 511 560 512H288Q247 511 220 484Q193 457 192 416Q193 379 215 354Q237 328 272 321V320Q273 279 300 252Q327 225 368 224Q394 224 416 237Q437 249 450 270Q470 256 496 256Q530 257 553 279Q575 302 576 336Q576 345 574 353Q603 359 621 380Q639 402 640 432Z"},
      "cloud": {"width": 640, "height": 512, "path": "M0 336c0 79.5 64.5 144 144 144l368 0c70.7 0 128-57.3 128-128c0-61.9-44-113.6-102.4-125.4c4.1-10.7 6.4-22.4 6.4-34.6c0-53-43-96-96-96c-19.7 0-38.1 6-53.3 16.2C367 64.2 315.3 32 256 32C167.6 32 96 103.6 96 192c0 2.7 .1 5.4 .2 8.1C40.2 219.8 0 273.2 0 336z"}
    };

    const createInlineFontAwesomeIcon = (iconConfig) => {
      if (!iconConfig || iconConfig.provider !== "fontawesome" || iconConfig.family !== "classic" || iconConfig.style !== "solid" || iconConfig.format !== "inline-svg") {
        return null;
      }

      const definition = fontAwesomeInlineIcons[iconConfig.name];
      if (!definition) return null;

      const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("viewBox", "0 0 " + definition.width + " " + definition.height);
      svg.setAttribute("aria-hidden", "true");
      svg.setAttribute("focusable", "false");
      svg.setAttribute("role", "img");
      svg.setAttribute("fill", "currentColor");
      svg.setAttribute("data-fa-family", "classic");
      svg.setAttribute("data-fa-style", "solid");
      svg.setAttribute("data-fa-inline", "true");

      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", definition.path);
      svg.appendChild(path);
      return svg;
    };


    // System-shell UI belongs to core. Lazy App modules must never own functions
    // needed by bootstrap or top-level navigation. This namespace makes the
    // dependency graph explicit instead of relying on classic-script globals.
    const QWQSystemUI = (() => {
      function renderParentMenu(groups, dataKey, onOpen) {
        const list = document.getElementById("theme-parent-list");
        if (!list || !Array.isArray(groups)) return false;
        const fragment = document.createDocumentFragment();

        groups.forEach((group) => {
          const groupElement = document.createElement("div");
          groupElement.className = "parent-menu-group";

          (group?.items || []).forEach((item) => {
            const row = document.createElement("button");
            row.className = "parent-row";
            row.type = "button";
            row.dataset[dataKey] = item.id;
            row.setAttribute("aria-label", item.name);
            row.disabled = item.enabled === false;
            if (item.enabled !== false) row.addEventListener("click", () => onOpen(item));

            const left = document.createElement("span");
            left.className = "parent-row-left";

            const logo = document.createElement("span");
            logo.className = "parent-row-logo";
            logo.setAttribute("aria-hidden", "true");
            const icon = createInlineFontAwesomeIcon({
              provider: "fontawesome", family: "classic", style: "solid", name: item.icon, format: "inline-svg"
            });
            if (icon) logo.appendChild(icon);

            const name = document.createElement("span");
            name.className = "parent-row-name";
            name.textContent = item.name;

            const chevron = document.createElement("span");
            chevron.className = "parent-row-chevron";
            chevron.setAttribute("aria-hidden", "true");
            const chevronIcon = createInlineFontAwesomeIcon({
              provider: "fontawesome", family: "classic", style: "solid", name: "chevron-right", format: "inline-svg"
            });
            if (chevronIcon) chevron.appendChild(chevronIcon);

            left.append(logo, name);
            row.append(left, chevron);
            groupElement.appendChild(row);
          });
          fragment.appendChild(groupElement);
        });

        list.replaceChildren(fragment);
        list.scrollTop = 0;
        return true;
      }

      function renderThemeParentMenu() {
        return renderParentMenu(myPhoneConfig.themeParentMenu, "themeItemId", (item) => {
          ThemeCustomization.openItem(item.id, item.name);
        });
      }

      function renderSettingsParentMenu() {
        return renderParentMenu(myPhoneConfig.settingsParentMenu, "settingsItemId", (item) => {
          window.QWQModuleLoader.ensureApp("settings")
            .then(() => window.SettingsApp.openItem(item.id, item.name))
            .catch((error) => console.error("settings module load failed", error));
        });
      }

      function renderParentAppPage(appId) {
        const appConfig = myPhoneConfig.apps[appId];
        if (!appConfig) return false;
        const page = document.getElementById(appConfig.route);
        const title = document.getElementById("theme-parent-title");
        if (!page || !title) return false;
        page.dataset.appPage = appId;
        page.setAttribute("aria-label", myPhoneConfig.appNames[appId] || appId);
        title.textContent = appConfig.pageTitle;
        if (appId === "theme") return renderThemeParentMenu();
        if (appId === "settings") return renderSettingsParentMenu();
        return true;
      }

      return Object.freeze({ createIcon: createInlineFontAwesomeIcon, renderParentMenu, renderThemeParentMenu, renderSettingsParentMenu, renderParentAppPage });
    })();
    window.QWQSystemUI = QWQSystemUI;

    /*
     * 清柳 Global Scroll Indicator
     * ---------------------------
     * Native browser scrollbars are hidden globally in core.css. One overlay
     * thumb is reused for both vertical and horizontal scrolling and reads only
     * the global --global-scrollbar-* variables. Apps must not create local skins.
     */
    const QWQGlobalScrollIndicator = (() => {
      const indicator = document.createElement("div");
      indicator.className = "global-scroll-indicator";
      indicator.setAttribute("aria-hidden", "true");
      const indicatorHost = document.getElementById("qwq-app-shell") || document.body;
      indicatorHost.appendChild(indicator);

      let activeTarget = null;
      let activeAxis = "vertical";
      let hideTimer = 0;
      let rafId = 0;
      const lastScrollLeft = new WeakMap();

      function normalizeScrollTarget(target) {
        if (target instanceof Element) return target;
        if (target === document || target === document.documentElement) return document.scrollingElement || document.documentElement;
        return null;
      }

      function indicatorHidden(target) {
        return target instanceof Element && Boolean(target.closest('[data-global-scroll-indicator="hidden"]'));
      }

      function axisEligibility(target) {
        if (!(target instanceof Element) || !target.isConnected || indicatorHidden(target)) return {vertical:false,horizontal:false};
        return {
          vertical: target.clientHeight > 0 && target.scrollHeight > target.clientHeight + 1,
          horizontal: target.clientWidth > 0 && target.scrollWidth > target.clientWidth + 1
        };
      }

      function findScroller(start) {
        let target = start instanceof Element ? start : null;
        if (indicatorHidden(target)) return null;
        while (target && target !== document.documentElement) {
          const eligible = axisEligibility(target);
          if (eligible.vertical || eligible.horizontal) return target;
          target = target.parentElement;
        }
        return null;
      }

      function cssNumber(styles, name, fallback) {
        const value = Number.parseFloat(styles.getPropertyValue(name));
        return Number.isFinite(value) ? value : fallback;
      }

      function hide(immediate = false) {
        window.clearTimeout(hideTimer);
        hideTimer = 0;
        if (immediate) indicator.style.transition = "none";
        indicator.classList.remove("is-visible");
        if (immediate) requestAnimationFrame(() => { indicator.style.transition = ""; });
      }

      function render(target = activeTarget, axis = activeAxis, { reveal = true } = {}) {
        if (axis === "vertical") {
          hide();
          return;
        }
        const eligible = axisEligibility(target);
        if (!target || !eligible[axis]) {
          activeTarget = null;
          hide();
          return;
        }
        activeTarget = target;
        activeAxis = axis;

        const rect = target.getBoundingClientRect();
        const viewportTop = Math.max(0, rect.top);
        const viewportBottom = Math.min(window.innerHeight, rect.bottom);
        const viewportLeft = Math.max(0, rect.left);
        const viewportRight = Math.min(window.innerWidth, rect.right);
        const visibleHeight = Math.max(0, viewportBottom - viewportTop);
        const visibleWidth = Math.max(0, viewportRight - viewportLeft);
        if (visibleHeight < 24 || visibleWidth < 24) {
          hide();
          return;
        }

        const styles = getComputedStyle(document.documentElement);
        const size = Math.max(2, cssNumber(styles, "--global-scrollbar-size", 4));
        const inset = Math.max(0, cssNumber(styles, "--global-scrollbar-inset", 4));
        const minThumb = Math.max(size * 2, cssNumber(styles, "--global-scrollbar-min-thumb", 28));
        const hideDelay = Math.max(120, cssNumber(styles, "--global-scrollbar-hide-delay", 720));

        let x;
        let y;
        let width;
        let height;

        if (axis === "horizontal") {
          const trackLength = Math.max(minThumb, visibleWidth - inset * 2);
          const ratio = Math.min(1, target.clientWidth / Math.max(target.scrollWidth, 1));
          const thumbLength = Math.max(minThumb, Math.min(trackLength, trackLength * ratio));
          const maxScroll = Math.max(1, target.scrollWidth - target.clientWidth);
          const progress = Math.max(0, Math.min(1, target.scrollLeft / maxScroll));
          width = thumbLength;
          height = size;
          x = viewportLeft + inset + Math.max(0, trackLength - thumbLength) * progress;
          y = Math.max(1, Math.min(window.innerHeight - size - 1, viewportBottom - size - inset));
        } else {
          const trackLength = Math.max(minThumb, visibleHeight - inset * 2);
          const ratio = Math.min(1, target.clientHeight / Math.max(target.scrollHeight, 1));
          const thumbLength = Math.max(minThumb, Math.min(trackLength, trackLength * ratio));
          const maxScroll = Math.max(1, target.scrollHeight - target.clientHeight);
          const progress = Math.max(0, Math.min(1, target.scrollTop / maxScroll));
          width = size;
          height = thumbLength;
          x = Math.max(1, Math.min(window.innerWidth - size - 1, viewportRight - size - inset));
          y = viewportTop + inset + Math.max(0, trackLength - thumbLength) * progress;
        }

        indicator.style.width = `${width}px`;
        indicator.style.height = `${height}px`;
        indicator.style.transform = `translate3d(${x}px, ${y}px, 0)`;

        if (reveal) {
          indicator.classList.add("is-visible");
          window.clearTimeout(hideTimer);
          hideTimer = window.setTimeout(() => indicator.classList.remove("is-visible"), hideDelay);
        }
      }

      function schedule(target, axis, reveal = true) {
        if (axis === "vertical") return;
        const eligible = axisEligibility(target);
        if (!eligible[axis]) return;
        activeTarget = target;
        activeAxis = axis;
        if (rafId) return;
        rafId = requestAnimationFrame(() => {
          rafId = 0;
          render(activeTarget, activeAxis, { reveal });
        });
      }

      document.addEventListener("scroll", (event) => {
        const target = normalizeScrollTarget(event.target);
        if (!target) return;

        // 纵向指示器全局隐藏，因此普通纵向滚动路径只能读取 scrollLeft/scrollTop。
        // 先用纯滚动偏移判断方向；只有横向位置真的变化时才做 closest()、尺寸读取、
        // getBoundingClientRect() 等资格/几何工作，避免纵向列表每帧遍历祖先链。
        const currentLeft = target.scrollLeft;
        const previousLeft = lastScrollLeft.get(target);
        if (previousLeft === currentLeft) return;
        lastScrollLeft.set(target, currentLeft);
        // The first event only establishes the horizontal baseline. Vertical-only scrollers then
        // stay on a WeakMap get + scrollLeft read path with no per-frame object allocation/write.
        if (previousLeft === undefined) return;
        if (indicatorHidden(target)) {
          activeTarget = null;
          hide(true);
          return;
        }
        if (target.scrollWidth <= target.clientWidth + 1) return;
        schedule(target, "horizontal", true);
      }, { capture: true, passive: true });

      document.addEventListener("pointerdown", (event) => {
        if (indicatorHidden(event.target)) {
          activeTarget = null;
          hide(true);
          return;
        }
        const target = findScroller(event.target);
        if (!target) return;
        lastScrollLeft.set(target, target.scrollLeft);
      }, true);

      // Horizontal indicator updates from the native scroll event. Avoid a document-level
      // touchmove ancestor walk on every mobile frame; that listener competed with home drag/swipe.

      window.addEventListener("resize", () => activeTarget ? schedule(activeTarget, activeAxis, false) : hide(true), { passive: true });
      document.addEventListener("visibilitychange", () => { if (document.hidden) hide(true); });

      return Object.freeze({
        refresh(target) {
          const eligible = axisEligibility(target);
          if (eligible.horizontal) schedule(target, "horizontal", false);
          else hide();
        },
        hide() { activeTarget = null; hide(true); }
      });
    })();
    window.QWQGlobalScrollIndicator = QWQGlobalScrollIndicator;

    /*
     * 清柳 Icon Hydrator
     * -----------------
     * Lucide 由模块加载器按需加载，但图标水合的作用域属于系统层。
     * 业务模块只能把包含 data-lucide 的宿主交给这里，禁止各自扫描 document
     * 或只扫描 App 根节点，否则全局抽屉 / 全局弹窗中的图标会因 portal 脱离业务根节点而失效。
     */
    const QWQIcons = (() => {
      const pendingScopes = new Set();
      let frame = 0;

      function normalizeScope(scope) {
        if (scope instanceof Element || scope instanceof Document) return scope;
        return null;
      }

      function flush() {
        frame = 0;
        const createIcons = window.lucide?.createIcons;
        if (typeof createIcons !== "function") {
          pendingScopes.clear();
          return false;
        }

        const scopes = Array.from(pendingScopes);
        pendingScopes.clear();
        scopes.forEach((scope) => {
          if (!scope?.querySelector?.("[data-lucide]")) return;
          createIcons({
            attrs: { "aria-hidden": "true", focusable: "false" },
            root: scope
          });
        });
        return true;
      }

      function hydrate(...scopes) {
        scopes.forEach((scope) => {
          const normalized = normalizeScope(scope);
          if (normalized) pendingScopes.add(normalized);
        });
        if (!pendingScopes.size || frame) return pendingScopes.size > 0;
        frame = requestAnimationFrame(flush);
        return true;
      }

      return Object.freeze({ hydrate, flush });
    })();
    window.QWQIcons = QWQIcons;

    // 标准 ZIP 工具：使用 PKZIP Store 方法，不依赖“改后缀”或第二套持久化。
    const ZipArchive = (() => {
      const encoder = new TextEncoder();
      const decoder = new TextDecoder("utf-8");
      const crcTable = new Uint32Array(256);
      for (let n = 0; n < 256; n += 1) {
        let c = n;
        for (let k = 0; k < 8; k += 1) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        crcTable[n] = c >>> 0;
      }

      function crc32(bytes) {
        let crc = 0xFFFFFFFF;
        for (const byte of bytes) crc = crcTable[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
        return (crc ^ 0xFFFFFFFF) >>> 0;
      }

      function dosDateTime(date = new Date()) {
        const year = Math.max(1980, date.getFullYear());
        const time = ((date.getHours() & 31) << 11) | ((date.getMinutes() & 63) << 5) | ((Math.floor(date.getSeconds() / 2)) & 31);
        const day = ((year - 1980) << 9) | (((date.getMonth() + 1) & 15) << 5) | (date.getDate() & 31);
        return { time, day };
      }

      function header(size) {
        const bytes = new Uint8Array(size);
        return { bytes, view: new DataView(bytes.buffer) };
      }

      function normalizeData(value) {
        if (value instanceof Uint8Array) return value;
        if (value instanceof ArrayBuffer) return new Uint8Array(value);
        return encoder.encode(String(value));
      }

      function create(files) {
        const now = dosDateTime();
        const localParts = [];
        const centralParts = [];
        let localOffset = 0;

        Object.entries(files).forEach(([name, value]) => {
          const nameBytes = encoder.encode(name);
          const data = normalizeData(value);
          const crc = crc32(data);

          const local = header(30);
          local.view.setUint32(0, 0x04034B50, true);
          local.view.setUint16(4, 20, true);
          local.view.setUint16(6, 0x0800, true);
          local.view.setUint16(8, 0, true);
          local.view.setUint16(10, now.time, true);
          local.view.setUint16(12, now.day, true);
          local.view.setUint32(14, crc, true);
          local.view.setUint32(18, data.length, true);
          local.view.setUint32(22, data.length, true);
          local.view.setUint16(26, nameBytes.length, true);
          local.view.setUint16(28, 0, true);
          localParts.push(local.bytes, nameBytes, data);

          const central = header(46);
          central.view.setUint32(0, 0x02014B50, true);
          central.view.setUint16(4, 20, true);
          central.view.setUint16(6, 20, true);
          central.view.setUint16(8, 0x0800, true);
          central.view.setUint16(10, 0, true);
          central.view.setUint16(12, now.time, true);
          central.view.setUint16(14, now.day, true);
          central.view.setUint32(16, crc, true);
          central.view.setUint32(20, data.length, true);
          central.view.setUint32(24, data.length, true);
          central.view.setUint16(28, nameBytes.length, true);
          central.view.setUint16(30, 0, true);
          central.view.setUint16(32, 0, true);
          central.view.setUint16(34, 0, true);
          central.view.setUint16(36, 0, true);
          central.view.setUint32(38, 0, true);
          central.view.setUint32(42, localOffset, true);
          centralParts.push(central.bytes, nameBytes);

          localOffset += local.bytes.length + nameBytes.length + data.length;
        });

        const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
        const end = header(22);
        const count = Object.keys(files).length;
        end.view.setUint32(0, 0x06054B50, true);
        end.view.setUint16(4, 0, true);
        end.view.setUint16(6, 0, true);
        end.view.setUint16(8, count, true);
        end.view.setUint16(10, count, true);
        end.view.setUint32(12, centralSize, true);
        end.view.setUint32(16, localOffset, true);
        end.view.setUint16(20, 0, true);
        return new Blob([...localParts, ...centralParts, end.bytes], { type: "application/zip" });
      }

      async function read(file) {
        const bytes = new Uint8Array(await file.arrayBuffer());
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        const files = {};
        let offset = 0;
        while (offset + 4 <= bytes.length && view.getUint32(offset, true) === 0x04034B50) {
          if (offset + 30 > bytes.length) throw new Error("ZIP 文件头不完整");
          const flags = view.getUint16(offset + 6, true);
          const method = view.getUint16(offset + 8, true);
          const compressedSize = view.getUint32(offset + 18, true);
          const nameLength = view.getUint16(offset + 26, true);
          const extraLength = view.getUint16(offset + 28, true);
          if (flags & 0x0008) throw new Error("不支持数据描述符 ZIP");
          if (method !== 0) throw new Error("仅支持本页面导出的标准 Store ZIP");
          const nameStart = offset + 30;
          const dataStart = nameStart + nameLength + extraLength;
          const dataEnd = dataStart + compressedSize;
          if (dataEnd > bytes.length) throw new Error("ZIP 文件内容不完整");
          const name = decoder.decode(bytes.slice(nameStart, nameStart + nameLength));
          const data = bytes.slice(dataStart, dataEnd);
          const expectedCrc = view.getUint32(offset + 14, true);
          if (crc32(data) !== expectedCrc) throw new Error(`ZIP 文件校验失败：${name}`);
          files[name] = data;
          offset = dataEnd;
        }
        if (!Object.keys(files).length) throw new Error("不是可读取的 ZIP 备份");
        return files;
      }

      function text(files, name) {
        if (!files[name]) throw new Error(`ZIP 中缺少 ${name}`);
        return decoder.decode(files[name]);
      }

      return { create, read, text };
    })();


    const QWQLifecycle = (() => {
      function afterNextPaint() {
        return new Promise((resolve) => {
          requestAnimationFrame(() => window.setTimeout(resolve, 0));
        });
      }

      async function waitForImage(image) {
        if (!(image instanceof HTMLImageElement) || !image.currentSrc && !image.src) return false;
        if (image.complete) return image.naturalWidth > 0;
        if (typeof image.decode === "function") {
          try {
            await image.decode();
            return image.naturalWidth > 0;
          } catch (error) {
            console.error("image decode failed while waiting for render", error);
            if (image.complete) return image.naturalWidth > 0;
          }
        }
        return new Promise((resolve) => {
          const finish = () => resolve(image.naturalWidth > 0);
          image.addEventListener("load", finish, { once:true });
          image.addEventListener("error", finish, { once:true });
        });
      }

      async function waitForImages(scope) {
        if (!scope?.querySelectorAll) return true;
        const images = Array.from(scope.querySelectorAll("img"));
        if (!images.length) return true;
        await Promise.all(images.map((image) => waitForImage(image)));
        return true;
      }

      async function waitForLocalImages(scope) {
        if (!scope?.querySelectorAll) return true;
        const images = Array.from(scope.querySelectorAll("img")).filter((image) => {
          const src = String(image.currentSrc || image.src || "");
          return src.startsWith("blob:") || src.startsWith("data:");
        });
        if (!images.length) return true;
        await Promise.all(images.map((image) => waitForImage(image)));
        return true;
      }

      function localInlineImageSources(scope) {
        if (!scope?.querySelectorAll) return [];
        const urls = new Set();
        const nodes = [scope, ...scope.querySelectorAll('[style*="blob:"],[style*="data:image"]')];
        const matcher = /(?:blob:[^\s"'\)]+|data:image\/[^\s"'\)]+)/g;
        for (const node of nodes) {
          const styleText = String(node.getAttribute?.("style") || "");
          for (const match of styleText.matchAll(matcher)) urls.add(match[0]);
        }
        return Array.from(urls);
      }

      async function waitForLocalRenderImages(scope) {
        await waitForLocalImages(scope);
        const urls = localInlineImageSources(scope);
        if (!urls.length) return true;
        await Promise.all(urls.map(async (src) => {
          const image = new Image();
          image.src = src;
          return waitForImage(image);
        }));
        return true;
      }

      function idle(task, { timeout = 1200 } = {}) {
        if (typeof task !== "function") return 0;
        if (typeof window.requestIdleCallback === "function") {
          return window.requestIdleCallback(() => task(), { timeout });
        }
        // 没有 requestIdleCallback 时仍要给可见交互留出完整窗口，避免后台清理/自动化
        // 在返回主屏后 200ms 左右抢占主线程。
        return window.setTimeout(() => task(), Math.min(timeout, Math.max(450, timeout / 3)));
      }

      return Object.freeze({ afterNextPaint, waitForImage, waitForImages, waitForLocalImages, waitForLocalRenderImages, idle });
    })();
    window.QWQLifecycle = QWQLifecycle;

    // Global dynamic-image lifecycle. All user/runtime image surfaces should go through
    // this registry instead of creating and revoking blob: URLs independently.
    // The contract is intentionally slot-based: unchanged media keeps one decoded URL;
    // replacements keep the old frame alive until the new source has decoded and painted.
    const QWQMediaSurface = (() => {
      const objectUrls = new Map();
      const pendingBlobs = new Map();
      const slotEpochs = new Map();
      const nodeTokens = new WeakMap();

      function cssUrl(url) { return url ? `url(${JSON.stringify(url)})` : "none"; }
      function sourceKey(source, identity) {
        if (identity !== undefined && identity !== null && identity !== "") return identity;
        return source;
      }
      function nextNodeToken(node) {
        const next = (nodeTokens.get(node) || 0) + 1;
        nodeTokens.set(node, next);
        return next;
      }
      function tokenIsCurrent(node, token) { return nodeTokens.get(node) === token; }
      function nextSlotEpoch(slot) {
        const key = String(slot || "");
        const next = (slotEpochs.get(key) || 0) + 1;
        slotEpochs.set(key, next);
        return next;
      }
      function slotEpochIsCurrent(slot, epoch) { return slotEpochs.get(String(slot || "")) === epoch; }
      function delayedRevoke(url) {
        if (!url || !String(url).startsWith("blob:")) return;
        requestAnimationFrame(() => requestAnimationFrame(() => {
          try { URL.revokeObjectURL(url); } catch (_) {}
        }));
      }
      function revokeNow(url) {
        if (!url || !String(url).startsWith("blob:")) return;
        try { URL.revokeObjectURL(url); } catch (_) {}
      }
      function blobDescriptorMatches(entry, blob, stableIdentity) {
        return Boolean(entry?.url
          && entry.source === stableIdentity
          && entry.size === blob.size
          && entry.type === (blob.type || ""));
      }
      function cancelPending(slot) {
        const key = String(slot || "");
        const pending = pendingBlobs.get(key);
        if (!pending) return;
        pendingBlobs.delete(key);
        revokeNow(pending.url);
      }
      function release(slot, { immediate = false } = {}) {
        const key = String(slot || "");
        if (!key) return;
        nextSlotEpoch(key);
        cancelPending(key);
        const current = objectUrls.get(key);
        objectUrls.delete(key);
        if (!current?.url) return;
        if (immediate) revokeNow(current.url);
        else delayedRevoke(current.url);
      }
      function releasePrefix(prefix, options) {
        const value = String(prefix || "");
        const keys = new Set([...objectUrls.keys(), ...pendingBlobs.keys()]);
        for (const key of keys) if (key.startsWith(value)) release(key, options);
      }
      function stableBlobUrl(slot, blob, identity = blob) {
        const key = String(slot || "");
        if (!key || !(blob instanceof Blob) || !blob.size) { if (key) release(key); return ""; }
        const stableIdentity = sourceKey(blob, identity);
        const current = objectUrls.get(key);
        if (blobDescriptorMatches(current, blob, stableIdentity)) return current.url;
        nextSlotEpoch(key);
        cancelPending(key);
        const url = URL.createObjectURL(blob);
        objectUrls.set(key, { source: stableIdentity, url, size: blob.size, type: blob.type || "" });
        if (current?.url && current.url !== url) delayedRevoke(current.url);
        return url;
      }
      async function preload(url) {
        const source = String(url || "");
        if (!source) return false;
        const probe = new Image();
        probe.decoding = "async";
        probe.src = source;
        if (typeof probe.decode === "function") {
          try { await probe.decode(); return probe.naturalWidth > 0; } catch (_) {}
        }
        if (probe.complete) return probe.naturalWidth > 0;
        return new Promise((resolve) => {
          probe.addEventListener("load", () => resolve(true), { once:true });
          probe.addEventListener("error", () => resolve(false), { once:true });
        });
      }
      async function preloadBlob(blob) {
        if (!(blob instanceof Blob) || !blob.size) return false;
        const url = URL.createObjectURL(blob);
        try { return await preload(url); }
        finally { revokeNow(url); }
      }
      async function resolveBlobUrl(slot, blob, identity = blob) {
        const key = String(slot || "");
        if (!key || !(blob instanceof Blob) || !blob.size) return "";
        const stableIdentity = sourceKey(blob, identity);
        const current = objectUrls.get(key);
        if (blobDescriptorMatches(current, blob, stableIdentity)) return current.url;

        const existingPending = pendingBlobs.get(key);
        if (blobDescriptorMatches(existingPending, blob, stableIdentity)) return await existingPending.promise;

        const epoch = nextSlotEpoch(key);
        cancelPending(key);
        const url = URL.createObjectURL(blob);
        const pending = { source:stableIdentity, url, size:blob.size, type:blob.type || "", epoch, promise:null };
        pending.promise = (async () => {
          const ok = await preload(url);
          const active = pendingBlobs.get(key);
          if (!ok || active !== pending || !slotEpochIsCurrent(key, epoch)) {
            revokeNow(url);
            return "";
          }
          pendingBlobs.delete(key);
          const previous = objectUrls.get(key);
          objectUrls.set(key, { source:stableIdentity, url, size:blob.size, type:blob.type || "" });
          if (previous?.url && previous.url !== url) delayedRevoke(previous.url);
          return url;
        })();
        pendingBlobs.set(key, pending);
        return await pending.promise;
      }
      async function prepareSource(slot, source, identity, tokenNode, token) {
        const key = String(slot || "");
        if (source instanceof Blob) {
          if (!source.size) return { ok:false, url:"", kind:"blob" };
          const url = await resolveBlobUrl(key, source, identity);
          if (!url || (tokenNode && !tokenIsCurrent(tokenNode, token))) return { ok:false, url:"", kind:"blob" };
          return { ok:true, url, kind:"blob" };
        }
        const url = String(source || "").trim();
        if (!url) return { ok:false, url:"", kind:"direct" };
        const epoch = key ? nextSlotEpoch(key) : 0;
        if (key) cancelPending(key);
        const ok = await preload(url);
        if (!ok || (tokenNode && !tokenIsCurrent(tokenNode, token)) || (key && !slotEpochIsCurrent(key, epoch))) {
          return { ok:false, url:"", kind:"direct", epoch };
        }
        return { ok:true, url, kind:"direct", epoch };
      }
      function commitPrepared(slot, prepared) {
        const key = String(slot || "");
        if (!key || prepared?.kind !== "direct") return true;
        if (!slotEpochIsCurrent(key, prepared.epoch)) return false;
        const previous = objectUrls.get(key);
        objectUrls.delete(key);
        if (previous?.url) delayedRevoke(previous.url);
        return true;
      }
      async function prepareBlobSlot(slot, blob, identity = blob) {
        const key = String(slot || "");
        if (!key) return "";
        if (!(blob instanceof Blob) || !blob.size) { release(key); return ""; }
        return await resolveBlobUrl(key, blob, identity);
      }
      async function setImage(image, slot, source, { identity = source, hiddenWhenEmpty = false, className = "", alt = "" } = {}) {
        if (!(image instanceof HTMLImageElement)) return false;
        if (source && !(source instanceof Blob)) {
          const direct = String(source).trim();
          if (direct && (image.getAttribute("src") === direct || image.currentSrc === direct)) {
            if (objectUrls.has(String(slot || "")) || pendingBlobs.has(String(slot || ""))) release(slot);
            image.alt = alt;
            if (hiddenWhenEmpty) image.hidden = false;
            if (className) image.classList.add(className);
            return true;
          }
        }
        const token = nextNodeToken(image);
        if (!source || source instanceof Blob && !source.size) {
          if (image.hasAttribute("src")) image.removeAttribute("src");
          if (hiddenWhenEmpty) image.hidden = true;
          if (className) image.classList.remove(className);
          release(slot);
          return true;
        }
        const prepared = await prepareSource(slot, source, identity, image, token);
        if (!prepared.ok || !tokenIsCurrent(image, token) || !commitPrepared(slot, prepared)) return false;
        if (image.getAttribute("src") !== prepared.url && image.currentSrc !== prepared.url) image.src = prepared.url;
        image.alt = alt;
        if (hiddenWhenEmpty) image.hidden = false;
        if (className) image.classList.add(className);
        return true;
      }
      async function setBackground(node, slot, source, { identity = source, className = "has-image", emptyValue = "none" } = {}) {
        if (!(node instanceof Element)) return false;
        if (source && !(source instanceof Blob)) {
          const direct = String(source).trim();
          if (direct && node.style.backgroundImage === cssUrl(direct)) {
            if (objectUrls.has(String(slot || "")) || pendingBlobs.has(String(slot || ""))) release(slot);
            if (className) node.classList.add(className);
            return true;
          }
        }
        const token = nextNodeToken(node);
        if (!source || source instanceof Blob && !source.size) {
          const next = String(emptyValue);
          if (node.style.backgroundImage !== next) node.style.backgroundImage = next;
          if (className) node.classList.remove(className);
          release(slot);
          return true;
        }
        const prepared = await prepareSource(slot, source, identity, node, token);
        if (!prepared.ok || !tokenIsCurrent(node, token) || !commitPrepared(slot, prepared)) return false;
        const next = cssUrl(prepared.url);
        if (node.style.backgroundImage !== next) node.style.backgroundImage = next;
        if (className) node.classList.add(className);
        return true;
      }
      async function setCssImageProperty(node, slot, propertyName, source, { identity = source, className = "", emptyValue = "none" } = {}) {
        if (!(node instanceof Element) || !propertyName) return false;
        if (source && !(source instanceof Blob)) {
          const direct = String(source).trim();
          if (direct && node.style.getPropertyValue(propertyName) === cssUrl(direct)) {
            if (objectUrls.has(String(slot || "")) || pendingBlobs.has(String(slot || ""))) release(slot);
            if (className) node.classList.add(className);
            return true;
          }
        }
        const token = nextNodeToken(node);
        if (!source || source instanceof Blob && !source.size) {
          const next = String(emptyValue);
          if (node.style.getPropertyValue(propertyName) !== next) node.style.setProperty(propertyName, next);
          if (className) node.classList.remove(className);
          release(slot);
          return true;
        }
        const prepared = await prepareSource(slot, source, identity, node, token);
        if (!prepared.ok || !tokenIsCurrent(node, token) || !commitPrepared(slot, prepared)) return false;
        const next = cssUrl(prepared.url);
        if (node.style.getPropertyValue(propertyName) !== next) node.style.setProperty(propertyName, next);
        if (className) node.classList.add(className);
        return true;
      }
      function applyBackgroundNow(node, slot, blob, { identity = blob, className = "has-image", emptyValue = "none" } = {}) {
        if (!(node instanceof Element)) return "";
        if (!(blob instanceof Blob) || !blob.size) {
          const next = String(emptyValue);
          if (node.style.backgroundImage !== next) node.style.backgroundImage = next;
          if (className) node.classList.remove(className);
          release(slot);
          return "";
        }
        const url = stableBlobUrl(slot, blob, identity);
        const next = cssUrl(url);
        if (node.style.backgroundImage !== next) node.style.backgroundImage = next;
        if (className) node.classList.add(className);
        return url;
      }
      function rebind(slot, identity) {
        const current = objectUrls.get(String(slot || ""));
        if (!current?.url) return false;
        current.source = identity;
        return true;
      }
      function get(slot) { return objectUrls.get(String(slot || ""))?.url || ""; }
      return Object.freeze({ cssUrl, stableBlobUrl, prepareBlobSlot, setImage, setBackground, setCssImageProperty, applyBackgroundNow, preload, preloadBlob, release, releasePrefix, rebind, get, afterNextPaint:QWQLifecycle.afterNextPaint });
    })();
    window.QWQMediaSurface = QWQMediaSurface;

    const Router = (() => {
      const stack = [];

      function getPage(routeId) {
        return document.getElementById(routeId);
      }

      function has(routeId) {
        return Boolean(getPage(routeId));
      }

      function activate(routeId) {
        const nextPage = getPage(routeId);
        if (!nextPage) return false;
        const activePage = document.querySelector(".route-page.is-active");
        if (activePage === nextPage) return true;
        document.dispatchEvent(new CustomEvent("qwq:route-will-change", {
          detail: { from: activePage?.id || null, to: routeId }
        }));
        activePage?.classList.remove("is-active");
        nextPage.classList.add("is-active");
        document.dispatchEvent(new CustomEvent("qwq:route-change", {
          detail: { from: activePage?.id || null, to: routeId }
        }));
        return true;
      }

      function current() {
        return document.querySelector(".route-page.is-active")?.id ?? null;
      }

      function push(routeId) {
        if (!has(routeId)) return false;
        const currentRoute = current();
        if (currentRoute && currentRoute !== routeId) stack.push(currentRoute);
        return activate(routeId);
      }

      function back(fallbackRoute = myPhoneConfig.navigation.entry.route) {
        const previousRoute = stack.pop() ?? fallbackRoute;
        return activate(previousRoute);
      }

      function reset(routeId) {
        if (!has(routeId)) return false;
        stack.length = 0;
        return activate(routeId);
      }

      // 顶层 APP 进入时重建一条干净的导航链：APP -> 主屏幕。
      // 子页面仍使用 push/back，不让上一个 APP 或旧子页面残留在返回栈中。
      function enter(routeId, returnRoute = myPhoneConfig.navigation.entry.route) {
        if (!has(routeId) || !has(returnRoute)) return false;
        stack.length = 0;
        if (routeId !== returnRoute) stack.push(returnRoute);
        return activate(routeId);
      }

      return { push, back, reset, enter, current, has };
    })();

    const QWQModuleLoader = (() => {
      const build = String(myPhoneConfig.version || "V0.0.312").replace(/^V/i, "") || "0.0.312";
      const memoryDataLifecycleScripts = Object.freeze([
        "./Apps/memory/memory-schema.js",
        "./Apps/memory/memory-integration.js",
        "./Apps/memory/memory-access.js",
        "./Apps/memory/memory-repository.js"
      ]);
      const memoryConsumerScripts = Object.freeze([
        "./Apps/memory/memory-lifecycle.js",
        "./Apps/memory/memory-embedding.js",
        "./Apps/memory/memory-retriever.js",
        "./Apps/memory/memory-ranker.js",
        "./Apps/memory/memory-core.js"
      ]);
      const memoryServiceScripts = Object.freeze([
        "./Apps/memory/memory-producers.js",
        "./Apps/memory/memory-generator.js",
        "./Apps/memory/memory-service.js"
      ]);
      const qqPrerequisiteScripts = Object.freeze([
        "./vendor/lucide.min.js",
        "./Apps/QQ/qq-data.js",
        "./Apps/QQ/stickers.js"
      ]);
      const appScripts = Object.freeze({
        settings: ["./Apps/settings/settings.js"],
        music: ["./vendor/lucide.min.js", "./Apps/music/music.js"],
        phone: ["./Apps/QQ/qq-data.js", "./Apps/phone/phone.js", "./Apps/phone/video-call.js"],
        sms: ["./Apps/QQ/qq-data.js", "./Apps/messages/messages.js"],
        qq: [...qqPrerequisiteScripts, "./Apps/QQ/qq.js"],
        memory: ["./Apps/settings/settings.js", "./vendor/lucide.min.js", "./Apps/QQ/qq-data.js", "./Apps/memory/memory-schema.js", "./Apps/memory/memory-integration.js", "./Apps/memory/memory-access.js", "./Apps/memory/memory-repository.js", "./Apps/memory/memory-lifecycle.js", "./Apps/memory/memory-embedding.js", "./Apps/memory/memory-retriever.js", "./Apps/memory/memory-ranker.js", "./Apps/memory/memory-core.js", "./Apps/memory/memory-producers.js", "./Apps/memory/memory-generator.js", "./Apps/memory/memory-service.js", "./Apps/memory/memory.js"],
        atlas: ["./Apps/worldbook/worldbook.js"],
        calendar: ["./vendor/lucide.min.js", "./Apps/calendar/calendar.js"],
        weather: ["./vendor/lucide.min.js", "./Apps/weather/weather.js"],
        weibo: ["./vendor/lucide.min.js", "./Apps/weibo/weibo.js"],
        appstore: ["./Apps/store/store.js"]
      });
      // App CSS is no longer part of the boot-critical stylesheet set. Hidden route shells are
      // already display:none from core.css, so each app can atomically activate its own styles
      // before route commit without exposing unstyled DOM. Once loaded, styles stay resident so
      // minimized call overlays / portals keep their appearance across app switches.
      const appStyles = Object.freeze({
        settings: [],
        music: ["./Apps/music/music.css"],
        phone: ["./Apps/phone/o3o-phone-context.css", "./Apps/phone/phone.css"],
        sms: ["./Apps/messages/messages.css"],
        qq: ["./Apps/QQ/qq.css", "./Apps/QQ/stickers.css", "./Apps/QQ/chat-settings.css"],
        memory: ["./Apps/memory/memory.css"],
        atlas: ["./Apps/worldbook/worldbook.css"],
        calendar: ["./Apps/calendar/calendar.css"],
        weather: ["./Apps/weather/weather.css"],
        weibo: ["./Apps/weibo/weibo.css"],
        appstore: ["./Apps/store/store.css"]
      });
      const pending = new Map();
      const pendingStyles = new Map();
      let qqAuthRuntimePromise = null;

      function loadScript(path) {
        const key = String(path || "");
        if (!key) return Promise.resolve(true);
        if (pending.has(key)) return pending.get(key);
        const existing = Array.from(document.scripts).find((script) => {
          const src = script.getAttribute("src") || "";
          return src === key || src.startsWith(`${key}?`);
        });
        if (existing?.dataset.qwqLoaded === "true") return Promise.resolve(true);

        const promise = new Promise((resolve, reject) => {
          const script = existing || document.createElement("script");
          const done = () => { script.dataset.qwqLoaded = "true"; resolve(true); };
          const fail = () => {
            pending.delete(key);
            if (!existing) script.remove();
            reject(new Error(`模块加载失败：${key}`));
          };
          script.addEventListener("load", done, { once: true });
          script.addEventListener("error", fail, { once: true });
          if (!existing) {
            script.src = `${key}?v=${encodeURIComponent(build)}`;
            script.async = false;
            script.dataset.qwqModule = key;
            document.body.appendChild(script);
          }
        });
        pending.set(key, promise);
        return promise;
      }

      function loadStyle(path) {
        const key = String(path || "");
        if (!key) return Promise.resolve(true);
        if (pendingStyles.has(key)) return pendingStyles.get(key);
        const existing = Array.from(document.styleSheets).map((sheet) => sheet.ownerNode).find((node) => {
          if (!(node instanceof HTMLLinkElement)) return false;
          const href = node.getAttribute("href") || "";
          return href === key || href.startsWith(`${key}?`);
        }) || Array.from(document.querySelectorAll('link[rel="stylesheet"]')).find((link) => {
          const href = link.getAttribute("href") || "";
          return href === key || href.startsWith(`${key}?`);
        });
        if (existing?.dataset.qwqLoaded === "true" || existing?.sheet) return Promise.resolve(true);

        const promise = new Promise((resolve, reject) => {
          const link = existing || document.createElement("link");
          const done = () => { link.dataset.qwqLoaded = "true"; resolve(true); };
          const fail = () => {
            pendingStyles.delete(key);
            if (!existing) link.remove();
            reject(new Error(`样式加载失败：${key}`));
          };
          link.addEventListener("load", done, { once:true });
          link.addEventListener("error", fail, { once:true });
          if (!existing) {
            link.rel = "stylesheet";
            link.href = `${key}?v=${encodeURIComponent(build)}`;
            link.dataset.qwqStyle = key;
            document.head.appendChild(link);
          }
        });
        pendingStyles.set(key, promise);
        return promise;
      }

      async function ensureStyles(appId) {
        const styles = appStyles[appId] || [];
        if (!styles.length) return true;
        await Promise.all(styles.map((style) => loadStyle(style)));
        return true;
      }

      async function ensureApp(appId) {
        // Styles and scripts are independent network/parse resources. Start both immediately;
        // route commit separately awaits ensureStyles() so no unstyled frame can become visible.
        const stylesReady = ensureStyles(appId);
        if (appId === "qq") {
          // QQ 首页只依赖图标、账号/聊天数据与表情协议。三者彼此独立，先并行
          // 取得并执行，再加载依赖它们的 qq.js。长期记忆运行时不属于 QQ 首屏。
          await Promise.all(qqPrerequisiteScripts.map((script) => loadScript(script)));
          await loadScript("./Apps/QQ/qq.js");
          await stylesReady;
          return true;
        }
        if (appId === "weather") {
          // Weather module construction does not depend on Lucide executing first; the icon
          // library is only consumed when the first view is committed. Fetch/parse both files
          // in parallel to remove the 419KB lucide -> weather.js cold-start waterfall.
          await Promise.all([
            loadScript("./vendor/lucide.min.js"),
            loadScript("./Apps/weather/weather.js")
          ]);
          await stylesReady;
          return true;
        }
        if (appId === "memory") {
          // Memory 冷启动过去把 16 个脚本做成一条网络瀑布。这里只并行真正独立的
          // 前置模块，并在依赖边界显式汇合；不改变任何持久化/召回协议。
          await Promise.all([
            loadScript("./Apps/settings/settings.js"),
            loadScript("./vendor/lucide.min.js"),
            loadScript("./Apps/QQ/qq-data.js")
          ]);
          await ensureMemoryServiceRuntime();
          await loadScript("./Apps/memory/memory.js");
          await stylesReady;
          return true;
        }
        const scripts = appScripts[appId] || [];
        for (const script of scripts) await loadScript(script);
        await stylesReady;
        return true;
      }

      async function ensureMemoryDataLifecycle() {
        await loadScript("./Apps/memory/memory-schema.js");
        // Repository 只依赖 schema；integration 同样只依赖 schema，因此可并行。
        await Promise.all([
          loadScript("./Apps/memory/memory-integration.js"),
          loadScript("./Apps/memory/memory-repository.js")
        ]);
        // AccessGuard 明确依赖 integration。
        await loadScript("./Apps/memory/memory-access.js");
        return true;
      }

      async function ensureMemoryConsumerRuntime() {
        await ensureMemoryDataLifecycle();
        // lifecycle / embedding / ranker 均只依赖 schema + repository；producer registry
        // 只依赖 schema + integration。并行执行后再加载会捕获 embedding 的 retriever。
        await Promise.all([
          loadScript("./Apps/memory/memory-lifecycle.js"),
          loadScript("./Apps/memory/memory-embedding.js"),
          loadScript("./Apps/memory/memory-ranker.js"),
          loadScript("./Apps/memory/memory-producers.js")
        ]);
        await loadScript("./Apps/memory/memory-retriever.js");
        await loadScript("./Apps/memory/memory-core.js");
        return true;
      }

      async function ensureMemoryServiceRuntime() {
        await ensureMemoryConsumerRuntime();
        await loadScript("./Apps/memory/memory-generator.js");
        await loadScript("./Apps/memory/memory-service.js");
        return true;
      }

      async function ensureSettingsRuntime() {
        await loadScript("./Apps/settings/settings.js");
        return true;
      }

      async function ensureWorldBookRuntime() {
        await loadScript("./Apps/worldbook/worldbook.js");
        if (!window.WorldBookRepository?.listEnabledEntriesForConversation) {
          throw new Error("世界书运行时未完成初始化");
        }
        return true;
      }

      // Cold-start QQ authentication is a data concern, not a page concern. Load only the
      // canonical account runtime and resolve its Dexie session/identity while the home
      // screen remains active. The same promise is shared with an immediate QQ launch, so
      // there is never a second concurrent session read or a visible auth-checking route.
      function ensureQqAuthRuntime() {
        if (qqAuthRuntimePromise) return qqAuthRuntimePromise;
        qqAuthRuntimePromise = (async () => {
          await loadScript("./Apps/QQ/qq-data.js");
          const store = window.QQAccountStore;
          const identityController = window.QQAccountIdentityController;
          if (!store?.ensureInitialized || !identityController?.refreshActive) {
            throw new Error("QQ账号认证运行时未完成初始化");
          }
          await store.ensureInitialized();
          const session = await store.getSession();
          // refreshActive consumes the already-resolved session cache and preloads the
          // active account/avatar into the document-level identity controller.
          await identityController.refreshActive();
          return Object.freeze({
            authenticated: Boolean(session?.accountId),
            accountId: session?.accountId || null
          });
        })().catch((error) => {
          qqAuthRuntimePromise = null;
          throw error;
        });
        return qqAuthRuntimePromise;
      }

      function prefetchApps(appIds = Object.keys(appScripts)) {
        const resources = new Map();
        for (const appId of appIds) {
          for (const path of appScripts[appId] || []) {
            if (!pending.has(path)) resources.set(path, "script");
          }
          for (const path of appStyles[appId] || []) {
            if (!pendingStyles.has(path)) resources.set(path, "style");
          }
        }
        for (const [path, as] of resources) {
          const href = `${path}?v=${encodeURIComponent(build)}`;
          if (document.querySelector(`link[data-qwq-prefetch="${CSS.escape(path)}"]`)) continue;
          const link = document.createElement("link");
          // Pointer-down is a high-confidence immediate navigation signal. preload fetches the
          // selected app bytes at navigation priority without executing scripts or activating CSS.
          link.rel = "preload";
          link.as = as;
          link.href = href;
          link.dataset.qwqPrefetch = path;
          document.head.appendChild(link);
        }
        return true;
      }


      return Object.freeze({
        ensureApp,
        ensureStyles,
        ensureMemoryDataLifecycle,
        ensureMemoryConsumerRuntime,
        ensureMemoryServiceRuntime,
        ensureSettingsRuntime,
        ensureWorldBookRuntime,
        ensureQqAuthRuntime,
        prefetchApps
      });
    })();
    window.QWQModuleLoader = QWQModuleLoader;

    const MyPhoneManager = (() => {
      const homeRoute = myPhoneConfig.navigation.entry.route;
      let currentContactId = null;
      let currentAppId = null;
      let navigationRevision = 0;
      let activeLaunch = null;

      function runCloseHook(appId) {
        if (appId === "music") return window.MusicApp?.close?.() ?? true;
        if (appId === "phone") return window.PhoneApp?.close?.() ?? true;
        if (appId === "sms") return window.MessagesApp?.close?.() ?? true;
        if (appId === "qq") return window.QQApp?.close?.() ?? true;
        if (appId === "memory") return window.MemoryApp?.close?.() ?? true;
        if (appId === "calendar") return window.CalendarApp?.close?.() ?? true;
        if (appId === "weather") return window.WeatherApp?.close?.() ?? true;
        if (appId === "weibo") return window.WeiboApp?.close?.() ?? true;
        if (appId === "atlas") return window.WorldBookApp?.close?.() ?? true;
        if (appId === "appstore") return window.AppleStoreApp?.close?.() ?? true;
        return true;
      }

      function scheduleCloseHook(appId) {
        if (!appId) return;
        // 电话的 close 会立即决定“最小化通话还是结束页面态”，必须保持同步语义。
        if (appId === "phone") {
          try { runCloseHook(appId); }
          catch (error) { console.error(`app close failed: ${appId}`, error); }
          return;
        }
        QWQLifecycle.afterNextPaint().then(() => {
          // 返回主屏先完成可见帧，再在真正空闲时做 QQ/Memory 等 DOM 与 Blob 清理。
          // 旧实现紧跟第二帧立刻清理，数据量大时仍会形成“已经回主屏但马上卡一下”。
          QWQLifecycle.idle(() => {
            if (currentAppId === appId) return;
            try { runCloseHook(appId); }
            catch (error) { console.error(`app close failed: ${appId}`, error); }
          }, { timeout: 900 });
        });
      }

      function prepareAppShell(appId, appConfig) {
        if (appConfig.pageTitle && !QWQSystemUI.renderParentAppPage(appId)) {
          throw new Error("应用页面不存在");
        }
      }

      async function preflightApp(appId, shouldContinue = () => true) {
        if (appId !== "qq") return true;

        // QQ is the only app whose first route depends on a persisted authentication
        // decision. Resolve that decision while the home screen still owns the route.
        // Only after QQApp has applied ready/login state may navigation commit to QQ.
        await QWQModuleLoader.ensureQqAuthRuntime();
        if (!shouldContinue()) return false;
        await QWQModuleLoader.ensureApp("qq");
        if (!shouldContinue()) return false;
        await window.ThemeCustomization.continuityReady;
        if (!shouldContinue()) return false;
        if (!window.QQApp?.primeAuthentication) throw new Error("QQ认证预提交接口未完成初始化");
        await window.QQApp.primeAuthentication();
        return shouldContinue();
      }

      async function prepareApp(appId, shouldContinue = () => true) {
        await QWQModuleLoader.ensureApp(appId);
        if (!shouldContinue()) return false;

        // 只有读取用户业务表的 App 才取得连续性迁移门闩；主题、设置、Store、微博与
        // 首屏不再被 QQ/聊天历史的大表迁移阻塞。门闩是单一 Promise，不存在并发迁移。
        // 只让真正依赖历史业务关系/音乐迁移的 App 等待全局连续性扫描。
        // 世界书目录只读取 worldBooks，日历只读取 calendarItems；把它们绑到聊天/账号/音乐
        // 的全表迁移会让 Edge 首次点击停留在主屏，看起来像“点击无反应”。
        if (["music", "phone", "qq"].includes(appId)) {
          await window.ThemeCustomization.continuityReady;
          if (!shouldContinue()) return false;
        }

        if (appId === "music") {
          if (!window.MusicApp) throw new Error("音乐模块未完成初始化");
          if (!await window.MusicApp.open("home")) throw new Error("音乐初始化失败");
        }

        if (appId === "atlas") {
          if (!window.WorldBookApp) throw new Error("世界书模块未完成初始化");
          await window.WorldBookApp.open();
        }

        if (appId === "phone") {
          if (!window.PhoneApp) throw new Error("电话模块未完成初始化");
          if (!await window.PhoneApp.open("calls")) throw new Error("电话初始化失败");
        }

        if (appId === "sms") {
          if (!window.MessagesApp) throw new Error("信息模块未完成初始化");
          if (!await window.MessagesApp.open()) throw new Error("信息初始化失败");
        }

        if (appId === "qq") {
          if (!window.QQApp) throw new Error("QQ 模块未完成初始化");
          if (!await window.QQApp.open("messages")) throw new Error("QQ 初始化失败");
        }

        if (appId === "memory") {
          if (!window.MemoryApp) throw new Error("记忆模块未完成初始化");
          if (!await window.MemoryApp.open()) throw new Error("记忆初始化失败");
        }

        if (appId === "calendar") {
          if (!window.CalendarApp) throw new Error("日历模块未完成初始化");
          if (!await window.CalendarApp.open()) throw new Error("日历初始化失败");
        }

        if (appId === "weather") {
          if (!window.WeatherApp) throw new Error("天气模块未完成初始化");
          if (!await window.WeatherApp.open()) throw new Error("天气初始化失败");
        }

        if (appId === "weibo") {
          if (!window.WeiboApp) throw new Error("微博模块未完成初始化");
          if (!window.WeiboApp.open("home")) throw new Error("微博初始化失败");
        }

        if (appId === "appstore") {
          if (!window.AppleStoreApp) throw new Error("Apple Store 模块未完成初始化");
          if (!window.AppleStoreApp.open()) throw new Error("Apple Store 初始化失败");
        }
        return true;
      }

      function open(contactId) {
        currentContactId = contactId ?? currentContactId;
        const closingAppId = currentAppId;
        navigationRevision += 1;
        currentAppId = null;
        const opened = Router.reset(homeRoute);
        if (opened) scheduleCloseHook(closingAppId);
        return opened;
      }

      async function openApp(appId) {
        const appConfig = myPhoneConfig.apps[appId];
        if (!appConfig) return false;
        const targetRoute = appConfig.route;
        if (!Router.has(targetRoute)) return false;

        if (currentAppId === appId) {
          if (activeLaunch?.appId === appId) return activeLaunch.promise;
          if (activeLaunch && activeLaunch.appId !== appId) {
            navigationRevision += 1;
            activeLaunch = null;
          }
          return true;
        }

        if (activeLaunch?.appId === appId) return activeLaunch.promise;

        // 导航和数据 hydration 必须拆开：页面壳本身已经随 index.html 同步解析，
        // 点击 App 时立即原子提交 route；脚本加载、Dexie 读取、头像/图片解码只决定
        // 页面何时从 hydrating 进入 ready，绝不能再阻塞“用户能否看到 App”。
        // revision 仍是唯一提交令牌，旧异步任务不能覆盖用户之后的导航。
        const revision = ++navigationRevision;
        const previousAppId = currentAppId;
        const page = document.getElementById(targetRoute);

        const launchPromise = (async () => {
          prepareAppShell(appId, appConfig);
          page?.setAttribute("aria-busy", "true");
          if (page) page.dataset.appPhase = "preparing";

          // App-specific CSS is the only resource allowed to gate route visibility. Hidden route
          // shells are already parsed, while scripts/data continue hydrating after navigation.
          // This removes ~630KB of app CSS from refresh-critical style matching without ever
          // exposing a naked/unstyled app page. Pointer-down prefetch normally makes this cache-hot.
          await QWQModuleLoader.ensureStyles(appId);
          if (revision !== navigationRevision) {
            page?.removeAttribute("aria-busy");
            if (page) delete page.dataset.appPhase;
            return false;
          }

          if (!Router.enter(targetRoute, homeRoute)) {
            page?.removeAttribute("aria-busy");
            if (page) delete page.dataset.appPhase;
            return false;
          }
          currentAppId = appId;
          if (previousAppId && previousAppId !== appId) scheduleCloseHook(previousAppId);
          if (page) page.dataset.appPhase = "hydrating";

          const preflighted = await preflightApp(
            appId,
            () => revision === navigationRevision && currentAppId === appId
          );
          if (!preflighted || revision !== navigationRevision || currentAppId !== appId) {
            runCloseHook(appId);
            page?.removeAttribute("aria-busy");
            if (page) delete page.dataset.appPhase;
            return false;
          }

          const prepared = await prepareApp(
            appId,
            () => revision === navigationRevision && currentAppId === appId
          );
          if (!prepared || revision !== navigationRevision || currentAppId !== appId) {
            runCloseHook(appId);
            page?.removeAttribute("aria-busy");
            if (page) delete page.dataset.appPhase;
            return false;
          }

          // 动态图片各自由 QWQMediaSurface 在自己的槽位内做原子预解码/替换。
          // 这里禁止再扫描整个 App DOM 并为每个 blob/data 背景额外创建 Image.decode()，
          // 否则打开任何 App 都会重复解码并与首帧争抢主线程/GPU 合成窗口。
          if (revision !== navigationRevision || currentAppId !== appId) return false;

          page?.removeAttribute("aria-busy");
          if (page) page.dataset.appPhase = "ready";
          return true;
        })();
        activeLaunch = { appId, revision, promise: launchPromise };

        try {
          return await launchPromise;
        } catch (error) {
          if (revision === navigationRevision && currentAppId === appId) {
            currentAppId = null;
            Router.reset(homeRoute);
          }
          page?.removeAttribute("aria-busy");
          if (page) page.dataset.appPhase = "error";
          runCloseHook(appId);
          throw error;
        } finally {
          if (activeLaunch?.revision === revision) activeLaunch = null;
        }
      }

      function closeApp(expectedAppId = currentAppId) {
        if (expectedAppId && currentAppId && expectedAppId !== currentAppId) return false;

        const closingAppId = currentAppId;
        // Home 是顶层强制导航：即使 App 仍处于 preflight / prepare 阶段，也必须立即作废其提交令牌，
        // 否则用户点击 Home 后，旧的异步启动仍可能在稍后把页面重新切回 App。
        navigationRevision += 1;
        activeLaunch = null;
        currentAppId = null;
        // Close is visually instantaneous; cleanup runs only after home has painted.
        const closed = Router.reset(homeRoute);
        if (closed && closingAppId) scheduleCloseHook(closingAppId);
        return closed;
      }

      function state() {
        return {
          currentContactId,
          currentAppId,
          currentRoute: Router.current()
        };
      }

      return { open, openApp, closeApp, state };
    })();

    const QWQGlobalHome = (() => {
      let area = null;

      function sync(routeId = Router.current()) {
        if (!area) return;
        area.dataset.route = routeId || "";
      }

      function goHome() {
        // 系统级 Home 先关闭文档级浮层，再退出当前 App / 子路由。
        // Home 层自身完全透明，底部安全区始终由当前业务表面真实绘制。
        try { window.ThemeCustomization?.GlobalModal?.close?.(); } catch {}
        try { window.ThemeCustomization?.GlobalDrawer?.close?.(); } catch {}
        const active = document.activeElement;
        if (active instanceof HTMLElement && active !== document.body) active.blur();
        return MyPhoneManager.closeApp();
      }

      function mount() {
        if (document.getElementById("qwq-global-home-area")) return;
        area = document.createElement("div");
        area.id = "qwq-global-home-area";
        area.setAttribute("aria-hidden", "false");

        const button = document.createElement("button");
        button.id = "qwq-global-home-button";
        button.type = "button";
        button.setAttribute("aria-label", "返回主屏幕");
        button.title = "返回主屏幕";
        button.addEventListener("click", goHome);
        area.append(button);
        const shell = document.getElementById("qwq-app-shell");
        (shell || document.body).append(area);

        document.addEventListener("qwq:route-change", (event) => sync(event.detail?.to));
        sync();
      }

      if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount, { once: true });
      else mount();

      return Object.freeze({ goHome, sync });
    })();

    window.Router = Router;
    window.MyPhoneManager = MyPhoneManager;
    window.QWQGlobalHome = QWQGlobalHome;