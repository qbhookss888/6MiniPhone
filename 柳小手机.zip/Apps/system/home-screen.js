const HomeScreenManager = (() => {
  "use strict";

  const GRID = Object.freeze({ columns: 4, rows: 6, dockCapacity: 4 });
  const SIZE_MAP = Object.freeze({
    "1x1": [1, 1], "2x1": [2, 1], "1x2": [1, 2], "2x2": [2, 2],
    "4x1": [4, 1], "4x2": [4, 2], "4x4": [4, 4]
  });
  const HOME_FORMAT = "QWQHomeLayout";
  const SCHEMA_VERSION = 3;
  // 单独的迁移凭据：schemaVersion 只表示布局结构版本，绝不能再被当成“天气 App 已真实落位”的成功凭据。
  const WEATHER_VISIBILITY_MIGRATION_KEY = "home.migration.weather-visible.v4";
  const LONG_PRESS_MS = 450;
  const PREVIEW_DWELL_MS = 48;
  const EDGE_DWELL_MS = 560;
  const EDGE_ZONE_PX = 34;
  const EDGE_REPEAT_COOLDOWN_MS = 520;
  const DRAG_THRESHOLD = 8;
  const SWIPE_THRESHOLD_RATIO = .47;
  const SAFE_COLLISION_LIMIT = 50;
  const RETIRED_REFERENCE_WIDGET_TYPES = new Set(["ref-date-message", "ref-clock-ring", "ref-profile-card", "ref-speech-bubble", "ref-album-disc", "ref-thought-composer", "ref-love-days", "ref-time-strip", "ref-account-banner", "ref-profile-player"]);

  // 唯一运行态母变量。主屏所有可变状态只允许挂在 HOME 下。
  const HOME = {
    initialized: false,
    hydrated: false,
    registry: new Map(),
    layout: null,
    preview: null,
    editMode: false,
    drag: null,
    gesture: null,
    geometry: null,
    refs: {},
    saveTimer: 0,
    dirty: false,
    clickSuppressUntil: 0,
    edgeTimer: 0,
    edgeCooldownUntil: 0,
    candidateTimer: 0,
    lastCandidateKey: "",
    objectUrls: new Map(),
    widgetMessageBound: false,
    suspendedWidgets: [],
    resizeRaf: 0,
    swipeRaf: 0,
    pendingSwipeOffset: null,
    dragMoveRaf: 0,
    pendingDragMove: null,
    desktopPositionKeys: new Map(),
    dockPositionKeys: new Map(),
    o3oClockTimer: 0,
    o3oBattery: null,
    o3oBatteryInit: null,
    o3oBatteryUnavailable: false
  };

  const clone = (value) => {
    if (typeof structuredClone === "function") return structuredClone(value);
    return JSON.parse(JSON.stringify(value));
  };
  const uid = (prefix) => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
  const widgetInstanceUid = () => {
    if (globalThis.crypto?.randomUUID) return `widget-instance-${globalThis.crypto.randomUUID()}`;
    if (globalThis.crypto?.getRandomValues) {
      const bytes = new Uint8Array(16);
      globalThis.crypto.getRandomValues(bytes);
      return `widget-instance-${Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
    }
    return `widget-instance-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
  };
  const legacyWidgetInstanceId = (itemId) => `widget-instance-legacy-${encodeURIComponent(String(itemId || "widget"))}`;
  const int = (value, fallback = 0) => Number.isFinite(Number(value)) ? Math.trunc(Number(value)) : fallback;
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const currentState = () => HOME.preview || HOME.layout;
  const pageId = (index) => `page-${index}`;
  const normalizeSizeKey = (size, width, height) => {
    if (SIZE_MAP[size]) return size;
    const hit = Object.entries(SIZE_MAP).find(([, dims]) => dims[0] === int(width, 1) && dims[1] === int(height, 1));
    return hit?.[0] || "1x1";
  };

  function extractRegistry() {
    const root = document.getElementById("page-my-phone-home");
    if (!root) throw new Error("主屏路由容器不存在");
    const appNames = myPhoneConfig.appNames || {};
    const appConfigs = myPhoneConfig.apps || {};
    const desktopNodes = Array.from(root.querySelectorAll(":scope > .top-grid > .app[data-app-id]"));
    const dockNodes = Array.from(root.querySelectorAll(":scope > .dock .dock-grid > [data-app-id]"));
    const all = [...desktopNodes, ...dockNodes];
    for (const node of all) {
      const appId = String(node.dataset.appId || "").trim();
      if (!appId || HOME.registry.has(appId)) continue;
      const shell = node.classList.contains("icon-shell") ? node : node.querySelector(".icon-shell");
      if (!shell) continue;
      const iconClass = Array.from(shell.classList).filter((name) => name !== "icon-shell").join(" ");
      const launchable = node.dataset.launchable === "true" || shell.dataset.launchable === "true";
      HOME.registry.set(appId, Object.freeze({
        appId,
        name: String(appNames[appId] || node.querySelector(".app-name")?.textContent || node.getAttribute("aria-label") || appId).replace(/^打开/, ""),
        launchable,
        routeAvailable: Boolean(appConfigs[appId]?.route),
        iconMarkup: shell.innerHTML,
        iconClass,
        defaultArea: dockNodes.includes(node) ? "dock" : "desktop"
      }));
    }
    if (!HOME.registry.size) throw new Error("主屏 App Registry 为空");
  }

  function makeDefaultLayout() {
    const desktopOrder = ["music", "theme", "calendar", "weather", "qq", "weibo", "memory", "appstore"].filter((id) => HOME.registry.has(id));
    const dockOrder = ["phone", "sms", "atlas", "settings"].filter((id) => HOME.registry.has(id));
    const desktopItems = desktopOrder.map((appId, index) => ({
      id: `desktop-app-${appId}`, kind: "app", appId, pageIndex: 0,
      gridX: index % GRID.columns, gridY: Math.floor(index / GRID.columns), width: 1, height: 1
    }));
    const dockItems = dockOrder.slice(0, GRID.dockCapacity).map((appId, order) => ({ appId, order }));
    return normalizeHomeLayout({
      schemaVersion: SCHEMA_VERSION,
      currentPageIndex: 0,
      pages: [{ id: pageId(0) }],
      desktopItems,
      dockItems,
      widgetTemplates: [],
      widgetRuntimeState: {},
      knownAppIds: Array.from(HOME.registry.keys())
    }, HOME.registry);
  }

  function getItemRect(item) {
    return { left: item.gridX, top: item.gridY, right: item.gridX + item.width, bottom: item.gridY + item.height };
  }
  function rectsOverlap(a, b) {
    const ra = a.left === undefined ? getItemRect(a) : a;
    const rb = b.left === undefined ? getItemRect(b) : b;
    return ra.left < rb.right && ra.right > rb.left && ra.top < rb.bottom && ra.bottom > rb.top;
  }
  function isWithinGrid(item) {
    return Number.isInteger(item.pageIndex) && item.pageIndex >= 0 && Number.isInteger(item.gridX) && Number.isInteger(item.gridY)
      && Number.isInteger(item.width) && Number.isInteger(item.height) && item.width > 0 && item.height > 0
      && item.gridX >= 0 && item.gridY >= 0 && item.gridX + item.width <= GRID.columns && item.gridY + item.height <= GRID.rows;
  }
  function pageItems(state, pageIndex, exceptId = null) {
    return state.desktopItems.filter((item) => item.pageIndex === pageIndex && item.id !== exceptId);
  }
  function positionFree(state, probe, exceptIds = new Set()) {
    if (!isWithinGrid(probe)) return false;
    return !state.desktopItems.some((item) => !exceptIds.has(item.id) && item.pageIndex === probe.pageIndex && rectsOverlap(item, probe));
  }
  function getOccupiedCells(items) {
    const cells = new Set();
    for (const item of items) for (let y = item.gridY; y < item.gridY + item.height; y += 1) for (let x = item.gridX; x < item.gridX + item.width; x += 1) cells.add(`${x}:${y}`);
    return cells;
  }
  function getLastOccupiedPage(state) {
    return Math.max(0, ...state.desktopItems.map((item) => int(item.pageIndex, 0)));
  }
  function ensurePages(state, lastIndex, { preserveExisting = false } = {}) {
    const requested = Math.max(0, int(lastIndex, 0));
    const existingLast = Math.max(0, (Array.isArray(state.pages) ? state.pages.length : 0) - 1);
    const next = preserveExisting ? Math.max(requested, existingLast) : requested;
    state.pages = Array.from({ length: next + 1 }, (_, index) => ({ id: pageId(index) }));
    return state;
  }
  function compactEmptyPages(state) {
    const occupied = Array.from(new Set(state.desktopItems.map((item) => Math.max(0, int(item.pageIndex, 0))))).sort((a, b) => a - b);
    if (!occupied.length) {
      state.pages = [{ id: pageId(0) }];
      state.currentPageIndex = 0;
      return state;
    }

    const oldCurrent = Math.max(0, int(state.currentPageIndex, 0));
    const pageMap = new Map(occupied.map((oldIndex, newIndex) => [oldIndex, newIndex]));
    for (const item of state.desktopItems) item.pageIndex = pageMap.get(Math.max(0, int(item.pageIndex, 0))) ?? 0;

    let nextCurrent = pageMap.get(oldCurrent);
    if (nextCurrent === undefined) {
      let nearestOld = occupied[0];
      let nearestDistance = Math.abs(nearestOld - oldCurrent);
      for (const candidate of occupied.slice(1)) {
        const distance = Math.abs(candidate - oldCurrent);
        if (distance < nearestDistance || (distance === nearestDistance && candidate < nearestOld)) {
          nearestOld = candidate;
          nearestDistance = distance;
        }
      }
      nextCurrent = pageMap.get(nearestOld) ?? 0;
    }

    ensurePages(state, occupied.length - 1);
    state.currentPageIndex = clamp(nextCurrent, 0, state.pages.length - 1);
    return state;
  }

  function findFirstFreeAppCell(startPageIndex, state, exceptIds = new Set()) {
    let pageIndex = Math.max(0, int(startPageIndex, 0));
    for (let safety = 0; safety < 1000; safety += 1, pageIndex += 1) {
      for (let y = 0; y < GRID.rows; y += 1) for (let x = 0; x < GRID.columns; x += 1) {
        const probe = { pageIndex, gridX: x, gridY: y, width: 1, height: 1 };
        if (positionFree(state, probe, exceptIds)) return probe;
      }
    }
    return null;
  }
  function findFirstFreeWidgetRect(size, startPageIndex, state, exceptIds = new Set()) {
    const dims = SIZE_MAP[size] || SIZE_MAP["1x1"];
    let pageIndex = Math.max(0, int(startPageIndex, 0));
    for (let safety = 0; safety < 1000; safety += 1, pageIndex += 1) {
      for (let y = 0; y <= GRID.rows - dims[1]; y += 1) for (let x = 0; x <= GRID.columns - dims[0]; x += 1) {
        const probe = { pageIndex, gridX: x, gridY: y, width: dims[0], height: dims[1] };
        if (positionFree(state, probe, exceptIds)) return probe;
      }
    }
    return null;
  }

  function repairCollisions(state) {
    const ordered = [...state.desktopItems].sort((a, b) => a.pageIndex - b.pageIndex || a.gridY - b.gridY || a.gridX - b.gridX || (a.kind === "widget" ? -1 : 1));
    const placed = [];
    state.desktopItems = [];
    for (const item of ordered) {
      const candidate = { ...item };
      const testState = { ...state, desktopItems: placed };
      if (!positionFree(testState, candidate)) {
        const location = item.kind === "widget"
          ? findFirstFreeWidgetRect(normalizeSizeKey(item.size, item.width, item.height), item.pageIndex, testState)
          : findFirstFreeAppCell(item.pageIndex, testState);
        if (!location) continue;
        Object.assign(candidate, location);
      }
      placed.push(candidate);
    }
    state.desktopItems = placed;
  }

  function normalizeHomeLayout(raw, registry = HOME.registry, { compactPages = true } = {}) {
    const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
    const result = {
      schemaVersion: SCHEMA_VERSION,
      currentPageIndex: Math.max(0, int(source.currentPageIndex, 0)),
      pages: [], desktopItems: [], dockItems: [], widgetTemplates: [], widgetRuntimeState: {}, knownAppIds: []
    };
    const ids = new Set();
    const usedApps = new Set();
    const widgetInstanceIds = new Set();
    const widgetInstanceByLegacyItemId = new Map();
    const rawDesktop = Array.isArray(source.desktopItems) ? source.desktopItems : [];
    for (const input of rawDesktop) {
      if (!input || typeof input !== "object") continue;
      const kind = input.kind === "widget" ? "widget" : "app";
      const id = String(input.id || "").trim() || uid(kind);
      if (ids.has(id)) continue;
      if (kind === "app") {
        const appId = String(input.appId || "").trim();
        if (!registry.has(appId) || usedApps.has(appId)) continue;
        const item = { id, kind: "app", appId, pageIndex: Math.max(0, int(input.pageIndex, 0)), gridX: int(input.gridX), gridY: int(input.gridY), width: 1, height: 1 };
        if (!isWithinGrid(item)) continue;
        ids.add(id); usedApps.add(appId); result.desktopItems.push(item);
      } else {
        let widgetType = String(input.widgetType || "basic");
        if (RETIRED_REFERENCE_WIDGET_TYPES.has(widgetType)) continue;
        if (widgetType === "os-status-control") continue;
        if (widgetType === "os-info-card") widgetType = "os-status-panel";
        let size = normalizeSizeKey(input.size, input.width, input.height);
        if (widgetType === "os-status-panel") size = "4x2";
        const dims = SIZE_MAP[size];
        let instanceId = String(input.instanceId || "").trim();
        if (!instanceId) instanceId = legacyWidgetInstanceId(id);
        if (widgetInstanceIds.has(instanceId)) instanceId = widgetInstanceUid();
        widgetInstanceIds.add(instanceId);
        widgetInstanceByLegacyItemId.set(id, instanceId);
        const item = {
          id, instanceId, kind: "widget", widgetType, templateId: input.templateId ? String(input.templateId) : null,
          templateSnapshot: input.templateSnapshot && typeof input.templateSnapshot === "object" ? clone(input.templateSnapshot) : null,
          size, pageIndex: Math.max(0, int(input.pageIndex, 0)), gridX: int(input.gridX), gridY: int(input.gridY), width: dims[0], height: dims[1],
          data: input.data && typeof input.data === "object" ? clone(input.data) : {}, overrides: input.overrides && typeof input.overrides === "object" ? clone(input.overrides) : {}
        };
        if (!isWithinGrid(item)) continue;
        ids.add(id); result.desktopItems.push(item);
      }
    }
    const rawDock = Array.isArray(source.dockItems) ? source.dockItems : [];
    for (const input of rawDock.sort((a, b) => int(a?.order) - int(b?.order))) {
      const appId = String(input?.appId || "").trim();
      if (!registry.has(appId) || usedApps.has(appId) || result.dockItems.some((row) => row.appId === appId)) continue;
      if (result.dockItems.length >= GRID.dockCapacity) break;
      usedApps.add(appId); result.dockItems.push({ appId, order: result.dockItems.length });
    }
    const templates = Array.isArray(source.widgetTemplates) ? source.widgetTemplates : [];
    const templateIds = new Set();
    for (const tpl of templates) {
      if (!tpl || typeof tpl !== "object") continue;
      const templateId = String(tpl.templateId || "").trim();
      const name = String(tpl.name || "").trim();
      if (!templateId || !name || templateIds.has(templateId)) continue;
      const defaultSize = SIZE_MAP[tpl.defaultSize] ? tpl.defaultSize : "2x2";
      const userFields = Array.isArray(tpl.userFields) ? tpl.userFields.filter((field, index, arr) => field && typeof field.key === "string" && field.key.trim() && arr.findIndex((other) => other?.key === field.key) === index).map((field) => ({
        key: String(field.key).trim(), label: String(field.label || field.key),
        type: ["text", "number", "date", "time", "color", "select"].includes(field.type) ? field.type : "text",
        defaultValue: field.defaultValue ?? "", options: Array.isArray(field.options) ? field.options.map(String).slice(0, 100) : []
      })) : [];
      const imageSlots = Array.isArray(tpl.imageSlots) ? tpl.imageSlots.filter((slot, index, arr) => slot && typeof slot.key === "string" && slot.key.trim() && arr.findIndex((other) => other?.key === slot.key) === index).map((slot) => ({ key: String(slot.key).trim(), label: String(slot.label || slot.key) })) : [];
      templateIds.add(templateId);
      result.widgetTemplates.push({
        templateId, name, defaultSize, html: String(tpl.html || ""), css: String(tpl.css || ""), imageSlots, userFields,
        createdAt: String(tpl.createdAt || new Date().toISOString()), updatedAt: String(tpl.updatedAt || new Date().toISOString())
      });
    }
    const rawWidgetRuntimeState = source.widgetRuntimeState && typeof source.widgetRuntimeState === "object" && !Array.isArray(source.widgetRuntimeState) ? source.widgetRuntimeState : {};
    result.widgetRuntimeState = {};
    for (const [rawKey, rawValue] of Object.entries(rawWidgetRuntimeState)) {
      if (!rawValue || typeof rawValue !== "object" || Array.isArray(rawValue)) continue;
      const instanceId = widgetInstanceIds.has(rawKey) ? rawKey : widgetInstanceByLegacyItemId.get(rawKey);
      if (!instanceId || result.widgetRuntimeState[instanceId]) continue;
      result.widgetRuntimeState[instanceId] = clone(rawValue);
    }
    result.knownAppIds = Array.from(new Set((Array.isArray(source.knownAppIds) ? source.knownAppIds : []).map(String).filter((id) => registry.has(id))));
    repairCollisions(result);
    const sourcePageLast = Math.max(0, (Array.isArray(source.pages) ? source.pages.length : 0) - 1);
    const requiredLast = Math.max(getLastOccupiedPage(result), result.currentPageIndex);
    ensurePages(result, compactPages ? requiredLast : Math.max(requiredLast, sourcePageLast));
    if (compactPages) compactEmptyPages(result);
    else result.currentPageIndex = clamp(result.currentPageIndex, 0, result.pages.length - 1);
    return result;
  }

  function addNewRegistryApps(state) {
    const known = new Set(state.knownAppIds);
    const occupied = new Set([...state.desktopItems.filter((item) => item.kind === "app").map((item) => item.appId), ...state.dockItems.map((item) => item.appId)]);
    for (const appId of HOME.registry.keys()) {
      if (known.has(appId)) continue;
      if (!occupied.has(appId)) {
        const location = findFirstFreeAppCell(0, state);
        if (location) {
          state.desktopItems.push({ id: `desktop-app-${appId}`, kind: "app", appId, ...location, width: 1, height: 1 });
          occupied.add(appId);
        } else {
          // 没有成功落位时禁止把 App 标为 known，否则后续启动将永久跳过该 App。
          continue;
        }
      }
      known.add(appId);
    }
    state.knownAppIds = Array.from(known);
    return compactEmptyPages(state);
  }

  function appPlacementExists(state, appId) {
    if (!state || !appId) return false;
    return state.desktopItems.some((item) => item.kind === "app" && item.appId === appId)
      || state.dockItems.some((item) => item.appId === appId);
  }

  function ensureRegistryAppPlacement(state, appId, { preferredPage = 0 } = {}) {
    const registryItem = HOME.registry.get(appId);
    if (!state || !registryItem) return { state, status: "registry-missing" };
    if (!registryItem.launchable || !registryItem.routeAvailable) return { state, status: "registry-incomplete" };
    if (appPlacementExists(state, appId)) {
      if (!state.knownAppIds.includes(appId)) state.knownAppIds.push(appId);
      return { state, status: "already-present" };
    }
    const location = findFirstFreeAppCell(preferredPage, state);
    if (!location) return { state, status: "no-space" };
    const baseId = `desktop-app-${appId}`;
    const ids = new Set(state.desktopItems.map((item) => item.id));
    let id = baseId;
    let suffix = 2;
    while (ids.has(id)) id = `${baseId}-${suffix++}`;
    state.desktopItems.push({ id, kind: "app", appId, ...location, width: 1, height: 1 });
    if (!state.knownAppIds.includes(appId)) state.knownAppIds.push(appId);
    compactEmptyPages(state);
    return { state, status: appPlacementExists(state, appId) ? "inserted" : "failed" };
  }

  // 天气是 V0.0.399 新增 App。旧实现把 knownAppIds/schemaVersion 当作迁移成功凭据，
  // 但它们都可能在“天气没有真实落位”的情况下被写入，导致后续永久跳过。
  // V4 改为：天气使用正式内联图标源，并重新执行一次真实落位迁移；旧 V3 凭据不能阻止本次修复。
  function prepareWeatherVisibilityMigration(state, marker) {
    if (marker?.value?.completed === true) return { state, pending: false, status: "completed" };
    const result = ensureRegistryAppPlacement(state, "weather", { preferredPage: 0 });
    const pending = result.status === "inserted" || result.status === "already-present";
    return { state: result.state, pending, status: result.status };
  }

  function weatherRuntimeNodeExists() {
    if (!HOME.refs?.root) return false;
    const node = HOME.refs.root.querySelector('.home-app[data-app-id="weather"]')
      || HOME.refs.root.querySelector('.home-dock-item[data-dock-app-id="weather"]');
    if (!node?.isConnected) return false;
    const style = getComputedStyle(node);
    const rect = node.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
  }

  async function finalizeWeatherVisibilityMigration(status) {
    if (!status?.pending) return false;
    const db = window.ThemeCustomization?.db;
    if (!db?.persistenceMeta || !HOME.layout) return false;
    const layoutPresent = appPlacementExists(HOME.layout, "weather");
    const domPresent = weatherRuntimeNodeExists();
    const weatherRegistry = HOME.registry.get("weather");
    const contractReady = Boolean(weatherRegistry?.launchable && weatherRegistry?.routeAvailable && document.getElementById(myPhoneConfig.apps?.weather?.route || ""));
    if (!contractReady || !layoutPresent || !domPresent) {
      if (status?.status !== "already-present") {
        console.error("[Home migration] 天气 App 迁移未通过运行态验证，保留未完成状态，下次启动继续重试。", {
          contractReady, layoutPresent, domPresent, status: status.status
        });
      }
      return false;
    }
    await db.persistenceMeta.put({
      key: WEATHER_VISIBILITY_MIGRATION_KEY,
      value: {
        completed: true,
        appId: "weather",
        completedAt: Date.now(),
        appVersion: String(myPhoneConfig.version || ""),
        layoutSchemaVersion: SCHEMA_VERSION
      },
      updatedAt: Date.now()
    });
    return true;
  }

  function createShell(registryItem, dock = false) {
    const shell = document.createElement("div");
    shell.className = `icon-shell${registryItem.iconClass ? ` ${registryItem.iconClass}` : ""}`;
    shell.dataset.appId = registryItem.appId;
    if (registryItem.launchable) shell.dataset.launchable = "true";
    if (dock) {
      shell.setAttribute("role", "button"); shell.tabIndex = 0; shell.setAttribute("aria-label", `打开${registryItem.name}`);
    } else shell.setAttribute("aria-hidden", "true");
    shell.innerHTML = registryItem.iconMarkup;
    // 运行时图标只装饰当前 shell；禁止每次主屏预览都全局重扫并重建所有图标 DOM。
    window.ThemeCustomization?.applyHomeIconToShell?.(registryItem.appId, shell);
    return shell;
  }

  function buildAppNode(item) {
    const reg = HOME.registry.get(item.appId); if (!reg) return null;
    const node = document.createElement("div");
    node.className = "app home-item home-app";
    node.dataset.itemId = item.id; node.dataset.appId = item.appId; node.dataset.appName = item.appId;
    if (reg.launchable) node.dataset.launchable = "true";
    node.setAttribute("role", "button"); node.tabIndex = 0; node.setAttribute("aria-label", `打开${reg.name}`);
    node.append(createShell(reg, false));
    const name = document.createElement("div"); name.className = "app-name"; name.textContent = reg.name; node.append(name);
    addEditControls(node, item);
    return node;
  }

  function sanitizeWidgetCss(css) { return String(css || "").replace(/<\/style/gi, "<\\/style"); }
  function sanitizeWidgetHtml(html) { return String(html || "").replace(/<\/script/gi, "<\\/script"); }
  function widgetTemplateFor(item, state) {
    return state.widgetTemplates.find((tpl) => tpl.templateId === item.templateId) || item.templateSnapshot || null;
  }
  function widgetObjectUrlKey(instanceId, scope, slot) {
    return `${String(instanceId || "")}::${String(scope || "media")}::${String(slot || "")}`;
  }

  function homeMediaSlot(key) { return `home:widget:${String(key || "")}`; }

  function releaseWidgetUrl(instanceId, scope, slot) {
    const key = widgetObjectUrlKey(instanceId, scope, slot);
    window.QWQMediaSurface?.release?.(homeMediaSlot(key));
    HOME.objectUrls.delete(key);
  }

  function releaseWidgetUrls(instanceId = null) {
    const prefix = instanceId ? `${String(instanceId)}::` : "";
    for (const [key] of Array.from(HOME.objectUrls.entries())) {
      if (prefix && !key.startsWith(prefix)) continue;
      window.QWQMediaSurface?.release?.(homeMediaSlot(key));
      HOME.objectUrls.delete(key);
    }
  }

  function stableWidgetBlobUrl(instanceId, scope, slot, blob) {
    if (!instanceId || !(blob instanceof Blob) || !blob.size) return "";
    const key = widgetObjectUrlKey(instanceId, scope, slot);
    // 组件图片以“实例 + 槽位”为稳定媒体身份。持久化 structuredClone 不再导致
    // 同内容 Blob 被当作新图片重建 URL；真正换图前上传事务会显式 releaseWidgetUrl。
    const url = window.QWQMediaSurface?.stableBlobUrl?.(homeMediaSlot(key), blob, `slot:${key}`) || "";
    HOME.objectUrls.set(key, { url, size: blob.size, type: blob.type || "" });
    return url;
  }

  function widgetImageUrls(item) {
    const out = {};
    const images = item.overrides?.images && typeof item.overrides.images === "object" ? item.overrides.images : {};
    for (const [key, value] of Object.entries(images)) {
      if (!(value instanceof Blob)) continue;
      out[key] = stableWidgetBlobUrl(item.instanceId, "custom", key, value);
    }
    return out;
  }

  function buildWidgetSrcdoc(item, state) {
    const tpl = widgetTemplateFor(item, state);
    if (!tpl) return `<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>html,body{margin:0;height:100%;display:grid;place-items:center;font:12px system-ui;color:#777;background:transparent}</style>Widget unavailable`;
    const fields = {};
    for (const field of tpl.userFields || []) fields[field.key] = item.overrides?.fields?.[field.key] ?? field.defaultValue ?? "";
    const images = widgetImageUrls(item);
    const materializedHtml = String(tpl.html || "")
      .replace(/\{\{field:([A-Za-z0-9_-]+)\}\}/g, (_, key) => escapeHtml(fields[key] ?? ""))
      .replace(/\{\{image:([A-Za-z0-9_-]+)\}\}/g, (_, key) => String(images[key] || ""));
    const bridge = `
<script>
(() => { const instanceId=${JSON.stringify(item.instanceId)}; const pending=new Map(); let seq=0;
const request=(op,key,value)=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});parent.postMessage({protocol:'QWQWidgetRuntimeV1',instanceId,id,op,key,value},'*');setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error('timeout'))}},4000)});
window.QWQWidget={getState:(k)=>request('get',k),getAllState:()=>request('getAll'),setState:(k,v)=>request('set',k,v),removeState:(k)=>request('remove',k),clearState:()=>request('clear'),onReady:(cb)=>{if(typeof cb==='function')queueMicrotask(cb)}};
addEventListener('message',(event)=>{const msg=event.data;if(!msg||msg.protocol!=='QWQWidgetRuntimeV1Result'||msg.instanceId!==instanceId)return;const p=pending.get(msg.id);if(!p)return;pending.delete(msg.id);msg.ok?p.resolve(msg.value):p.reject(new Error(msg.error||'failed'));});
window.QWQWidgetFields=${JSON.stringify(fields)};\nwindow.QWQWidgetImages=${JSON.stringify(images)};
})();
<\/script>`;
    return `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>html,body{width:100%;height:100%;margin:0;overflow:hidden;background:transparent;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;box-sizing:border-box}*,*:before,*:after{box-sizing:inherit}${sanitizeWidgetCss(tpl.css)}</style></head><body>${sanitizeWidgetHtml(materializedHtml)}${bridge}</body></html>`;
  }

  const UIIY_MUSIC_DEFAULT = Object.freeze({ title: "DorisWorld", artist: "Doris" });


  // O3O 主屏组件只提取视觉组件本体。布局、拖拽、持久化继续由 清柳 HomeScreenManager 统一负责。
  const O3O_COMPONENT_PRESETS = Object.freeze([
    Object.freeze({ widgetType: "o3o-profile", title: "个人资料", size: "4x4", displaySize: "4×4" }),
    Object.freeze({ widgetType: "o3o-music-battery", title: "音乐与电量", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "o3o-time-capsule", title: "时间与电量", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "o3o-duet-music", title: "双人音乐", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "o3o-duet-music-4x4", title: "双人音乐", size: "4x4", displaySize: "4×4" }),
    Object.freeze({ widgetType: "o3o-memory-gallery", title: "照片回忆", size: "4x2", displaySize: "4×2" })
  ]);

  // 初始小手机主屏：仅提取可复用组件本体。组件名称只存在于组件库元数据，不渲染到主屏实例。
  // 尺寸是 清柳 4×6 逻辑网格尺寸，像素宽高由运行时真实 cell / row / gap 决定。
  const OS_COMPONENT_PRESETS = Object.freeze([
    Object.freeze({ widgetType: "os-status-panel", title: "状态组件", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "os-image-card", title: "图片卡片", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "os-avatar-group", title: "头像组合", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "os-notification-card", title: "通知卡片", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "os-four-way-control", title: "四向控制", size: "4x2", displaySize: "4×2" })
  ]);

  // 参考截图组件：只提取布局结构与可编辑信息。截图中的人物、插画、头像、照片一律不复刻，
  // 所有媒体槽统一由 --home-widget-placeholder-bg 这一母变量占位。
  const REFERENCE_COMPONENT_PRESETS = Object.freeze([
    Object.freeze({ widgetType: "ref-social-thread", title: "动态卡片", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "ref-note-card", title: "便签", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "ref-week-calendar", title: "周历语录", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "ref-status-overview", title: "状态总栏", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "ref-status-overview-4x4", title: "状态总栏", size: "4x4", displaySize: "4×4" }),
    Object.freeze({ widgetType: "ref-camera-frame", title: "相机相框", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "ref-info-gallery", title: "资料卡片", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "ref-collection-profile", title: "收藏资料", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "ref-login-panel", title: "登录面板", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "ref-social-post", title: "动态帖子", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "ref-my-story", title: "主页数据卡", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "ref-imessage-chat", title: "iMessage 对话", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "ref-human-verification", title: "验证面板", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "ref-list-panel", title: "清单卡片", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "ref-circle-player", title: "圆形播放器", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "ref-robot-check", title: "人机验证", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "ref-photo-collage", title: "拼贴相册", size: "2x2", displaySize: "2×2" }),
    Object.freeze({ widgetType: "ref-month-calendar", title: "月历卡片", size: "4x2", displaySize: "4×2" }),
    Object.freeze({ widgetType: "ref-memory-board", title: "回忆文件夹", size: "2x2", displaySize: "2×2" }),
  ]);

  // 内置组件可编辑能力只从组件预设表派生，禁止再按家族前缀手写白名单；新增组件入库后自动继承图片/文本编辑能力。
  function isEditableBuiltinWidgetType(widgetType) {
    const type = String(widgetType || "");
    if (type === "uiiy-top-music") return true;
    return O3O_COMPONENT_PRESETS.some((preset) => preset.widgetType === type)
      || OS_COMPONENT_PRESETS.some((preset) => preset.widgetType === type)
      || REFERENCE_COMPONENT_PRESETS.some((preset) => preset.widgetType === type);
  }

  function homeWidgetAvatarPlaceholder(className = "") {
    const extra = String(className || "").trim();
    return `<svg aria-hidden="true" class="home-widget-avatar-placeholder${extra ? ` ${extra}` : ""}" preserveAspectRatio="xMidYMid meet" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg"><circle cx="300" cy="220" r="112" fill="#fff"></circle><path d="M72 600C86 463 180 384 300 384C420 384 514 463 528 600Z" fill="#fff"></path></svg>`;
  }

  function builtinWidgetText(item, key, fallback = "") {
    const value = item?.data?.text?.[key];
    return typeof value === "string" ? value : fallback;
  }

  function builtinWidgetMediaBlob(item, key) {
    const value = item?.data?.media?.[key];
    return value instanceof Blob ? value : null;
  }

  function trackBuiltinWidgetBlobUrl(instanceId, slot, blob) {
    return stableWidgetBlobUrl(instanceId, "builtin", slot, blob);
  }

  function applyBuiltinWidgetMediaNode(node, item, slot) {
    if (!node || !item?.instanceId || !slot) return false;
    const blob = builtinWidgetMediaBlob(item, slot);
    if (!(blob instanceof Blob) || !blob.size) return false;
    const url = window.QWQMediaSurface?.applyBackgroundNow?.(node, homeMediaSlot(widgetObjectUrlKey(item.instanceId, "builtin", slot)), blob, {identity:`slot:${widgetObjectUrlKey(item.instanceId, "builtin", slot)}`,className:"has-user-media",emptyValue:"none"})
      || trackBuiltinWidgetBlobUrl(item.instanceId, slot, blob);
    if (!url) return false;
    HOME.objectUrls.set(widgetObjectUrlKey(item.instanceId, "builtin", slot), { blob, url });
    node.dataset.homeCustomMediaUrl = url;
    return true;
  }

  function hydrateBuiltinWidgetMedia(root, item) {
    if (!root || !item?.instanceId) return root;
    root.querySelectorAll?.("[data-home-media-slot]").forEach((node) => {
      const key = String(node.dataset.homeMediaSlot || "").trim();
      if (key) applyBuiltinWidgetMediaNode(node, item, key);
    });
    return root;
  }

  async function waitForTrackedWidgetMedia() {
    const urls = Array.from(new Set(Array.from(HOME.objectUrls.values()).map((entry) => entry?.url).filter(Boolean)));
    if (!urls.length) return true;
    await Promise.all(urls.map(async (url) => {
      const image = new Image();
      image.src = url;
      return window.QWQLifecycle?.waitForImage?.(image) ?? true;
    }));
    return true;
  }

  function buildO3OProfileComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-o3o-preset home-o3o-profile";
    shell.setAttribute("aria-label", "个人资料");
    shell.innerHTML = `
      <div class="home-o3o-profile-cover" data-home-media-slot="profile.cover" aria-label="上传封面"></div>
      <div class="home-o3o-profile-avatar" data-home-media-slot="profile.avatar" aria-label="上传头像">${homeWidgetAvatarPlaceholder("home-o3o-avatar-placeholder")}</div>
      <div class="home-o3o-profile-info">
        <div class="home-o3o-profile-name" data-home-text-slot="profile.name">${escapeHtml(builtinWidgetText(item, "profile.name", "O3O"))}</div>
        <div class="home-o3o-profile-handle" data-home-text-slot="profile.handle">${escapeHtml(builtinWidgetText(item, "profile.handle", "oxo@O3O"))}</div>
        <div class="home-o3o-profile-bio" data-home-text-slot="profile.bio" data-home-text-multiline="true">${escapeHtml(builtinWidgetText(item, "profile.bio", '-ilove u"•ω<”♡u-'))}</div>
        <div class="home-o3o-profile-location"><i class="fa-solid fa-location-dot" aria-hidden="true"></i><span data-home-text-slot="profile.location">${escapeHtml(builtinWidgetText(item, "profile.location", "布吉岛"))}</span></div>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildO3OMusicBatteryComponent(item = null) {
    const shell = document.createElement("aside");
    shell.className = "home-o3o-preset home-o3o-music-battery";
    shell.setAttribute("aria-label", "音乐与电量");
    shell.innerHTML = `
      <div class="home-o3o-music-top"><div class="home-o3o-album" data-home-media-slot="music.cover" aria-label="上传音乐封面"></div><i class="fa-solid fa-music home-o3o-music-icon" aria-hidden="true"></i></div>
      <div class="home-o3o-music-copy"><div class="home-o3o-track-title" data-home-text-slot="music.title">${escapeHtml(builtinWidgetText(item, "music.title", "⁃ ⩊ ⁃ haengbok …"))}</div><div class="home-o3o-track-sub" data-home-text-slot="music.subtitle">${escapeHtml(builtinWidgetText(item, "music.subtitle", "✩⁺˚행복이 찾아오다‧˖˚"))}</div></div>
      <div class="home-o3o-power"><div class="home-o3o-power-label" data-home-text-slot="music.powerLabel">${escapeHtml(builtinWidgetText(item, "music.powerLabel", "< miss1u..."))}</div><div class="home-o3o-power-bar"><div class="home-o3o-power-fill" data-o3o-battery-fill></div><div class="home-o3o-power-value" data-o3o-battery-value>…</div></div></div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    syncO3OBattery(shell);
    applyO3OMusicBatteryPlayback(shell);
    return shell;
  }

  function buildO3OTimeCapsuleComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-o3o-preset home-o3o-time-capsule";
    shell.setAttribute("aria-label", "时间与电量");
    shell.innerHTML = `
      <div class="home-o3o-battery-row">
        <div class="home-o3o-battery-pill"><strong data-o3o-battery-value>…</strong><span data-home-text-slot="time.batteryLabel">${escapeHtml(builtinWidgetText(item, "time.batteryLabel", "Battery remaining"))}</span></div>
        <svg aria-hidden="true" class="home-o3o-battery-ring" viewBox="0 0 42 42"><circle class="home-o3o-battery-ring-track" cx="21" cy="21" r="16.5" pathLength="100"></circle><circle class="home-o3o-battery-ring-value" data-o3o-battery-ring cx="21" cy="21" r="16.5" pathLength="100"></circle></svg>
      </div>
      <div class="home-o3o-clock-stack">
        <div class="home-o3o-clock-capsule"><div class="home-o3o-clock-avatar" data-home-media-slot="time.avatar" aria-label="上传头像">${homeWidgetAvatarPlaceholder("home-o3o-avatar-placeholder")}</div><div class="home-o3o-clock-copy"><div class="home-o3o-clock-title" data-home-text-slot="time.title">${escapeHtml(builtinWidgetText(item, "time.title", "✦ · † Kitten Dreamland"))}</div><div class="home-o3o-clock-date" data-o3o-clock-date>Aug 06 · Thu</div></div><div class="home-o3o-clock-stats"><time class="home-o3o-clock-time" data-o3o-clock-time>15:30</time><span data-home-text-slot="time.steps">${escapeHtml(builtinWidgetText(item, "time.steps", "Steps  0"))}</span></div></div>
        <div class="home-o3o-clock-layer home-o3o-clock-layer-1"></div><div class="home-o3o-clock-layer home-o3o-clock-layer-2"></div><div class="home-o3o-clock-layer home-o3o-clock-layer-3"></div>
      </div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    syncO3OClock(shell);
    syncO3OBattery(shell);
    return shell;
  }

  function buildO3ODuetMusicComponent(item = null, variant = "2x2") {
    const shell = document.createElement("aside");
    const is4x4 = variant === "4x4";
    shell.className = `home-o3o-preset home-o3o-duet-music${is4x4 ? " home-o3o-duet-music-4x4" : ""}`;
    shell.setAttribute("aria-label", is4x4 ? "双人音乐 4×4" : "双人音乐");
    shell.innerHTML = `
      <div class="home-o3o-headphone-labels"><span data-home-text-slot="duet.leftLabel">${escapeHtml(builtinWidgetText(item, "duet.leftLabel", "You on left"))}</span><span data-home-text-slot="duet.rightLabel">${escapeHtml(builtinWidgetText(item, "duet.rightLabel", "Me on right"))}</span></div>
      <div class="home-o3o-headphone-stage">
        <div class="home-o3o-ear-disc is-left"><span class="home-o3o-ear-photo" data-home-media-slot="duet.leftAvatar" aria-label="上传左侧头像">${homeWidgetAvatarPlaceholder("home-o3o-ear-placeholder")}</span></div><div class="home-o3o-ear-disc is-right"><span class="home-o3o-ear-photo" data-home-media-slot="duet.rightAvatar" aria-label="上传右侧头像">${homeWidgetAvatarPlaceholder("home-o3o-ear-placeholder")}</span></div>
        <i class="home-o3o-ear-node is-left"></i><i class="home-o3o-ear-node is-right"></i>
        <svg aria-hidden="true" class="home-o3o-ear-cable is-left" preserveAspectRatio="xMidYMid meet" viewBox="0 0 64 84"><defs><linearGradient id="o3o-duet-wire-fade-left" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="76"><stop offset="0%" stop-color="#545454" stop-opacity="1"></stop><stop offset="38%" stop-color="#545454" stop-opacity="1"></stop><stop offset="56%" stop-color="#545454" stop-opacity=".62"></stop><stop offset="72%" stop-color="#545454" stop-opacity=".24"></stop><stop offset="84%" stop-color="#545454" stop-opacity="0"></stop></linearGradient></defs><path d="M4 0 C2 3 .8 9 1 16 C1.4 25 5 32 12 37 C20 43 28 48 34 55 C38 60 40 66 41 72" stroke="url(#o3o-duet-wire-fade-left)"></path></svg><svg aria-hidden="true" class="home-o3o-ear-cable is-right" preserveAspectRatio="xMidYMid meet" viewBox="0 0 64 84"><defs><linearGradient id="o3o-duet-wire-fade-right" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="76"><stop offset="0%" stop-color="#545454" stop-opacity="1"></stop><stop offset="38%" stop-color="#545454" stop-opacity="1"></stop><stop offset="56%" stop-color="#545454" stop-opacity=".62"></stop><stop offset="72%" stop-color="#545454" stop-opacity=".24"></stop><stop offset="84%" stop-color="#545454" stop-opacity="0"></stop></linearGradient></defs><path d="M60 0 C62 3 63.2 9 63 16 C62.6 25 59 32 52 37 C44 43 36 48 30 55 C26 60 24 66 23 72" stroke="url(#o3o-duet-wire-fade-right)"></path></svg>
      </div>
      <div class="home-o3o-mini-player"><div class="home-o3o-player-title"><span data-home-text-slot="duet.song">${escapeHtml(builtinWidgetText(item, "duet.song", "Pink Lavender"))}</span><i class="fa-solid fa-volume-high" data-o3o-duet-volume-icon aria-hidden="true"></i></div><div class="home-o3o-player-artist" data-home-text-slot="duet.artist">${escapeHtml(builtinWidgetText(item, "duet.artist", "Artist"))}</div><div class="home-o3o-player-progress"><span data-o3o-duet-progress></span></div><div class="home-o3o-player-times"><span data-home-text-slot="duet.elapsed">${escapeHtml(builtinWidgetText(item, "duet.elapsed", "1:26"))}</span><span data-home-text-slot="duet.duration">${escapeHtml(builtinWidgetText(item, "duet.duration", "3:48"))}</span></div><div class="home-o3o-player-controls"><button type="button" data-o3o-music-action="like" aria-label="喜欢"><i class="fa-solid fa-star" aria-hidden="true"></i></button><button type="button" data-o3o-music-action="prev" aria-label="上一首"><i class="fa-solid fa-backward" aria-hidden="true"></i></button><button type="button" data-o3o-music-action="toggle" aria-label="播放或暂停"><i class="fa-solid fa-pause" data-o3o-duet-play-icon aria-hidden="true"></i></button><button type="button" data-o3o-music-action="next" aria-label="下一首"><i class="fa-solid fa-forward" aria-hidden="true"></i></button><button type="button" data-o3o-music-action="like" aria-label="喜欢"><i class="fa-solid fa-heart" aria-hidden="true"></i></button></div></div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    applyO3ODuetMusicPlayback(shell);
    return shell;
  }

  function buildO3OMemoryGalleryComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-o3o-preset home-o3o-memory-gallery";
    shell.setAttribute("aria-label", "照片回忆");
    shell.innerHTML = `
      <div class="home-o3o-memory-progress"><div class="home-o3o-memory-avatar" data-home-media-slot="memory.avatar" aria-label="上传头像">${homeWidgetAvatarPlaceholder("home-o3o-avatar-placeholder")}</div><div class="home-o3o-progress-spacer"></div><div class="home-o3o-progress-line"><span class="home-o3o-progress-orbs"><i class="is-back"></i><i class="is-front"></i></span><strong data-o3o-day-percent>0.00%</strong></div><time data-o3o-memory-date>…</time></div>
      <div class="home-o3o-memory-gallery-inner">
        <article class="home-o3o-memory-card"><div class="home-o3o-memory-placeholder" data-home-media-slot="memory.photo1" aria-label="上传第一张照片"></div><div class="home-o3o-memory-meta"><span></span><b data-home-text-slot="memory.name1">${escapeHtml(builtinWidgetText(item, "memory.name1", "KiTiroll♡"))}</b></div><div class="home-o3o-memory-caption"><small data-home-text-slot="memory.caption1" data-home-text-multiline="true">${escapeHtml(builtinWidgetText(item, "memory.caption1", "点击添加文案"))}</small></div></article>
        <article class="home-o3o-memory-card"><div class="home-o3o-memory-placeholder is-alt" data-home-media-slot="memory.photo2" aria-label="上传第二张照片"></div><div class="home-o3o-memory-meta"><span></span><b data-home-text-slot="memory.name2">${escapeHtml(builtinWidgetText(item, "memory.name2", "Yuli_ieo♡"))}</b></div><div class="home-o3o-memory-caption"><small data-home-text-slot="memory.caption2" data-home-text-multiline="true">${escapeHtml(builtinWidgetText(item, "memory.caption2", "点击添加文案"))}</small></div></article>
      </div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    syncO3OClock(shell);
    return shell;
  }

  function buildO3OComponent(widgetType, item = null) {
    if (widgetType === "o3o-profile") return buildO3OProfileComponent(item);
    if (widgetType === "o3o-music-battery") return buildO3OMusicBatteryComponent(item);
    if (widgetType === "o3o-time-capsule") return buildO3OTimeCapsuleComponent(item);
    if (widgetType === "o3o-duet-music") return buildO3ODuetMusicComponent(item, "2x2");
    if (widgetType === "o3o-duet-music-4x4") return buildO3ODuetMusicComponent(item, "4x4");
    if (widgetType === "o3o-memory-gallery") return buildO3OMemoryGalleryComponent(item);
    return null;
  }

  function osMediaPlaceholder(icon = "image") {
    return "";
  }

  function buildOSStatusControlComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-os-preset home-os-status-control";
    shell.setAttribute("aria-label", "状态控制");
    shell.innerHTML = `
      <div class="home-os-battery-capsule home-os-glass">
        <strong data-o3o-battery-value>…</strong>
        <span data-home-text-slot="os.status.label">${escapeHtml(builtinWidgetText(item, "os.status.label", "剩余电量"))}</span>
      </div>
      <div class="home-os-circle-control home-os-glass" aria-hidden="true"><i class="fa-solid fa-heart"></i></div>`;
    syncO3OBattery(shell);
    return shell;
  }

  function buildOSInfoCardComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-os-preset home-os-info-card";
    shell.setAttribute("aria-label", "信息卡片");
    shell.innerHTML = `
      <div class="home-os-info-layer home-os-info-layer-2"></div>
      <div class="home-os-info-layer home-os-info-layer-1"></div>
      <div class="home-os-info-main home-os-glass">
        <div class="home-os-info-avatar" data-home-media-slot="os.info.avatar" aria-label="上传头像">${homeWidgetAvatarPlaceholder("home-o3o-avatar-placeholder")}</div>
        <div class="home-os-info-copy">
          <strong data-home-text-slot="os.info.title">${escapeHtml(builtinWidgetText(item, "os.info.title", "公主请好运"))}</strong>
          <span data-os-card-date>…</span>
        </div>
        <div class="home-os-info-weather">
          <div><b data-home-text-slot="os.info.temperature">${escapeHtml(builtinWidgetText(item, "os.info.temperature", "37"))}</b><em>°</em></div>
          <span><i class="fa-solid fa-sun" aria-hidden="true"></i><span data-home-text-slot="os.info.weather">${escapeHtml(builtinWidgetText(item, "os.info.weather", "中原区・晴"))}</span></span>
        </div>
      </div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    syncO3OClock(shell);
    return shell;
  }

  function buildOSStatusPanelComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-os-preset home-os-status-panel";
    shell.setAttribute("aria-label", "状态组件");
    shell.innerHTML = `
      <div class="home-os-status-top">
        <div class="home-os-battery-capsule home-os-glass">
          <strong data-o3o-battery-value>…</strong>
          <span data-home-text-slot="os.status.label">${escapeHtml(builtinWidgetText(item, "os.status.label", "剩余电量"))}</span>
        </div>
        <div class="home-os-circle-control home-os-glass" aria-hidden="true"><i class="fa-solid fa-heart"></i></div>
      </div>
      <div class="home-os-status-info">
        <div class="home-os-status-layer home-os-status-layer-2"></div>
        <div class="home-os-status-layer home-os-status-layer-1"></div>
        <div class="home-os-status-main home-os-glass">
          <div class="home-os-info-avatar" data-home-media-slot="os.info.avatar" aria-label="上传头像">${homeWidgetAvatarPlaceholder("home-o3o-avatar-placeholder")}</div>
          <div class="home-os-info-copy">
            <strong data-home-text-slot="os.info.title">${escapeHtml(builtinWidgetText(item, "os.info.title", "公主请好运"))}</strong>
            <span data-os-card-date>…</span>
          </div>
          <div class="home-os-info-weather">
            <div><b data-home-text-slot="os.info.temperature">${escapeHtml(builtinWidgetText(item, "os.info.temperature", "37"))}</b><em>°</em></div>
            <span><i class="fa-solid fa-sun" aria-hidden="true"></i><span data-home-text-slot="os.info.weather">${escapeHtml(builtinWidgetText(item, "os.info.weather", "中原区・晴"))}</span></span>
          </div>
        </div>
      </div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    syncO3OBattery(shell);
    syncO3OClock(shell);
    return shell;
  }

  function buildOSImageCardComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-os-preset home-os-image-card";
    shell.setAttribute("aria-label", "图片卡片");
    shell.innerHTML = `<div class="home-os-image-surface" data-home-media-slot="os.image.photo" aria-label="上传图片">${osMediaPlaceholder("image")}</div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildOSAvatarGroupComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-os-preset home-os-avatar-group";
    shell.setAttribute("aria-label", "头像组合");
    shell.innerHTML = `
      <div class="home-os-avatar-title" data-home-text-slot="os.avatar.title">${escapeHtml(builtinWidgetText(item, "os.avatar.title", "summer ☆₊⁺☆"))}</div>
      <div class="home-os-avatar-stage">
        <div class="home-os-avatar-frame home-os-glass"><div class="home-os-avatar-photo" data-home-media-slot="os.avatar.photo" aria-label="上传头像">${homeWidgetAvatarPlaceholder("home-o3o-avatar-placeholder")}</div></div>
        <div class="home-os-avatar-dots" aria-hidden="true">
          <span class="home-os-avatar-dot home-os-glass"><i class="fa-solid fa-paw"></i></span>
          <span class="home-os-avatar-dot home-os-glass"><i class="fa-solid fa-cookie"></i></span>
        </div>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildOSNotificationCardComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-os-preset home-os-notification-card";
    shell.setAttribute("aria-label", "通知卡片");
    shell.innerHTML = `
      <div class="home-os-notify-image" data-home-media-slot="os.notify.photo" aria-label="上传图片">${osMediaPlaceholder("image")}</div>
      <div class="home-os-notify-row">
        <strong data-home-text-slot="os.notify.title">${escapeHtml(builtinWidgetText(item, "os.notify.title", "小貓來信 ⁸¹⁶"))}</strong>
        <span class="home-os-notify-action home-os-glass" aria-hidden="true"><i class="fa-solid fa-phone"></i></span>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildOSFourWayControlComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-os-preset home-os-four-way-control";
    shell.setAttribute("aria-label", "四向控制");
    shell.innerHTML = `
      <div class="home-os-four-center" data-home-media-slot="os.four.center" aria-label="上传中心图片">${osMediaPlaceholder("image")}</div>
      <div class="home-os-four-pill is-top-left home-os-glass"><i class="fa-solid fa-headphones" aria-hidden="true"></i><span data-home-text-slot="os.four.topLeft">${escapeHtml(builtinWidgetText(item, "os.four.topLeft", "🐕✨🦴"))}</span></div>
      <div class="home-os-four-pill is-top-right home-os-glass"><i class="fa-solid fa-heart" aria-hidden="true"></i><span data-home-text-slot="os.four.topRight">${escapeHtml(builtinWidgetText(item, "os.four.topRight", "☆.*🐻°"))}</span></div>
      <div class="home-os-four-pill is-bottom-left home-os-glass"><i class="fa-solid fa-hashtag" aria-hidden="true"></i><span data-home-text-slot="os.four.bottomLeft">${escapeHtml(builtinWidgetText(item, "os.four.bottomLeft", "°//🐰🍋"))}</span></div>
      <div class="home-os-four-pill is-bottom-right home-os-glass"><i class="fa-solid fa-tag" aria-hidden="true"></i><span data-home-text-slot="os.four.bottomRight">${escapeHtml(builtinWidgetText(item, "os.four.bottomRight", "♪🤍 𝐿𝒪𝒱𝑒"))}</span></div>
      <div class="home-os-four-status" data-home-text-slot="os.four.status">${escapeHtml(builtinWidgetText(item, "os.four.status", "✨🎵.*..*...♪"))}</div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildOSComponent(widgetType, item = null) {
    if (widgetType === "os-status-panel") return buildOSStatusPanelComponent(item);
    if (widgetType === "os-status-control") return buildOSStatusControlComponent(item);
    if (widgetType === "os-info-card") return buildOSInfoCardComponent(item);
    if (widgetType === "os-image-card") return buildOSImageCardComponent(item);
    if (widgetType === "os-avatar-group") return buildOSAvatarGroupComponent(item);
    if (widgetType === "os-notification-card") return buildOSNotificationCardComponent(item);
    if (widgetType === "os-four-way-control") return buildOSFourWayControlComponent(item);
    return null;
  }


  function buildReferenceSocialThreadComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-social-thread";
    shell.setAttribute("aria-label", "动态卡片");
    shell.innerHTML = `
      <div class="home-ref-social-head">
        <div class="home-ref-social-avatar home-ref-media" data-home-media-slot="ref.social.avatar" aria-label="上传头像"></div>
        <div class="home-ref-social-identity"><strong data-home-text-slot="ref.social.name">${escapeHtml(builtinWidgetText(item, "ref.social.name", "Unable to view"))}</strong><span data-home-text-slot="ref.social.handle">${escapeHtml(builtinWidgetText(item, "ref.social.handle", "@奶芙熊熊"))}</span></div>
        <span class="home-ref-social-more" aria-hidden="true">•••</span>
      </div>
      <div class="home-ref-social-message" data-home-text-slot="ref.social.message" data-home-text-multiline="true">${escapeHtml(builtinWidgetText(item, "ref.social.message", "宇宙这么大，我该去哪里找你"))}</div>
      <div class="home-ref-social-replies">
        <div class="home-ref-social-reply"><div class="home-ref-social-reply-media home-ref-media" data-home-media-slot="ref.social.reply1" aria-label="上传回复头像"></div><div><strong data-home-text-slot="ref.social.reply1Name">${escapeHtml(builtinWidgetText(item, "ref.social.reply1Name", "@小雨呆咪"))}</strong><span data-home-text-slot="ref.social.reply1Text">${escapeHtml(builtinWidgetText(item, "ref.social.reply1Text", "永远 永远在一起吧"))}</span></div></div>
        <div class="home-ref-social-reply"><div class="home-ref-social-reply-media home-ref-media" data-home-media-slot="ref.social.reply2" aria-label="上传回复头像"></div><div><strong data-home-text-slot="ref.social.reply2Name">${escapeHtml(builtinWidgetText(item, "ref.social.reply2Name", "@流泪猫猫头_"))}</strong><span data-home-text-slot="ref.social.reply2Text">${escapeHtml(builtinWidgetText(item, "ref.social.reply2Text", "其实…我也是这么想的"))}</span></div></div>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceNoteCardComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-note-card";
    shell.setAttribute("aria-label", "便签");
    shell.innerHTML = `
      <header class="home-ref-note-head">
        <strong data-home-text-slot="ref.note.title">${escapeHtml(builtinWidgetText(item, "ref.note.title", "Notes"))}</strong>
      </header>
      <div class="home-ref-note-mint-line" aria-hidden="true"></div>
      <div class="home-ref-note-dash-line" aria-hidden="true"></div>
      <div class="home-ref-note-content">
        <div class="home-ref-note-kicker" data-home-text-slot="ref.note.kicker">${escapeHtml(builtinWidgetText(item, "ref.note.kicker", "9 · DESSERT SHOP · ♡"))}</div>
        <div class="home-ref-note-body" data-home-text-slot="ref.note.body" data-home-text-multiline="true">${escapeHtml(builtinWidgetText(item, "ref.note.body", "当有一天鱼板遇见了草莓\n· 就变成了：··鱼泥莓丸啦 ·\n· 主要配方 ·\n30鱼板♡ / 15奶油♡ / 99颗草莓♡"))}</div>
      </div>
      <footer class="home-ref-note-foot">
        <div class="home-ref-note-save"><span data-home-text-slot="ref.note.saveLabel">${escapeHtml(builtinWidgetText(item, "ref.note.saveLabel", "Save Time:"))}</span><time data-ref-time>…</time></div>
        <div class="home-ref-note-media home-ref-media" data-home-media-slot="ref.note.media" aria-label="上传图片"></div>
      </footer>`;
    hydrateBuiltinWidgetMedia(shell, item);
    syncO3OClock(shell);
    return shell;
  }

  function buildReferenceWeekCalendarComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-week-calendar";
    shell.setAttribute("aria-label", "周历语录");
    const week = Array.from({ length: 7 }, (_, index) => `<div class="home-ref-week-day" data-ref-week-index="${index}"><span data-ref-week-label>—</span><b data-ref-week-date></b></div>`).join("");
    shell.innerHTML = `
      <div class="home-ref-week-head">
        <div class="home-ref-week-avatar home-ref-media" data-home-media-slot="ref.week.avatar" aria-label="上传头像"></div>
        <div class="home-ref-week-copy"><strong data-home-text-slot="ref.week.title">${escapeHtml(builtinWidgetText(item, "ref.week.title", "Silverscar"))}</strong><span data-home-text-slot="ref.week.quote" data-home-text-multiline="true">${escapeHtml(builtinWidgetText(item, "ref.week.quote", "Tears are the only thing angels leave behind that weighs something."))}</span></div>
      </div>
      <div class="home-ref-week-grid">${week}</div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    syncO3OClock(shell);
    return shell;
  }


  function buildReferenceStatusOverviewComponent(item = null, variant = "4x2") {
    const shell = document.createElement("section");
    const is4x4 = variant === "4x4";
    shell.className = `home-ref-preset home-ref-status-overview ${is4x4 ? "is-large" : "is-compact"}`;
    shell.setAttribute("aria-label", is4x4 ? "状态总栏 4×4" : "状态总栏");
    const week = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((label, index) => `
      <div class="home-ref-status-day" data-ref-status-week-index="${index}">
        <span>${label}</span><b data-ref-status-date></b>
      </div>`).join("");
    shell.innerHTML = `
      <div class="home-ref-status-meta">
        <div class="home-ref-status-avatar-wrap">
          <div class="home-ref-status-avatar home-ref-media" data-home-media-slot="ref.status.avatar" aria-label="上传头像"></div>
          <span class="home-ref-status-avatar-badge" aria-hidden="true"><i class="fa-solid fa-camera"></i></span>
        </div>
        <div class="home-ref-status-profile-copy">
          <div class="home-ref-status-name-row"><strong data-home-text-slot="ref.status.name">${escapeHtml(builtinWidgetText(item, "ref.status.name", "DorisWorld"))}</strong><span aria-hidden="true">★</span></div>
          <div class="home-ref-status-week">${week}</div>
        </div>
      </div>
      <div class="home-ref-status-panel">
        <div class="home-ref-status-rail" aria-hidden="true">
          <div class="home-ref-status-rail-line"></div>
          <div class="home-ref-status-rail-button"><i class="fa-solid fa-headphones"></i></div>
          <div class="home-ref-status-rail-button"><i class="fa-solid fa-utensils"></i></div>
        </div>
        <div class="home-ref-status-content">
          <div class="home-ref-status-row is-listening">
            <div class="home-ref-status-copy"><span data-home-text-slot="ref.status.listeningLabel">${escapeHtml(builtinWidgetText(item, "ref.status.listeningLabel", "正在听"))}</span><strong data-home-text-slot="ref.status.track">${escapeHtml(builtinWidgetText(item, "ref.status.track", "WILDFLOWER-BillieEilish"))}</strong></div>
            <time data-ref-status-time>…</time><i class="fa-solid fa-circle-check home-ref-status-check" aria-hidden="true"></i>
          </div>
          <div class="home-ref-status-row is-weather">
            <div class="home-ref-status-weather-copy"><span><i class="fa-solid fa-cloud" aria-hidden="true"></i><b data-home-text-slot="ref.status.weather">${escapeHtml(builtinWidgetText(item, "ref.status.weather", "32°C 多云"))}</b></span><strong data-home-text-slot="ref.status.note">${escapeHtml(builtinWidgetText(item, "ref.status.note", "things^in*myphone"))}</strong></div>
            <div class="home-ref-status-media-strip">
              <div class="home-ref-status-media home-ref-media" data-home-media-slot="ref.status.tile1" aria-label="上传第一张图片"></div>
              <div class="home-ref-status-media home-ref-media" data-home-media-slot="ref.status.tile2" aria-label="上传第二张图片"></div>
              <div class="home-ref-status-media home-ref-media" data-home-media-slot="ref.status.tile3" aria-label="上传第三张图片"></div>
            </div>
            <div class="home-ref-status-now"><span data-home-text-slot="ref.status.now">${escapeHtml(builtinWidgetText(item, "ref.status.now", "Now"))}</span><i aria-hidden="true"></i></div>
          </div>
        </div>
      </div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    syncO3OClock(shell);
    applyReferenceStatusPlayback(shell);
    return shell;
  }

  function buildReferenceCameraFrameComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-camera-frame";
    shell.setAttribute("aria-label", "相机相框");
    shell.innerHTML = `
      <div class="home-ref-camera-stage">
        <div class="home-ref-camera-photo home-ref-media" data-home-media-slot="ref.camera.photo" aria-label="上传相机屏幕图片"></div>
        <img class="home-ref-camera-png-frame" src="./Apps/system/assets/camera-cybershot-frame.png?v=0.0.312" alt="" aria-hidden="true" draggable="false">
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceInfoGalleryComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-info-gallery";
    shell.setAttribute("aria-label", "资料卡片");
    shell.innerHTML = `
      <div class="home-ref-info-tabs"><button type="button" tabindex="-1" aria-hidden="true">×</button><strong data-home-text-slot="ref.info.tab1">${escapeHtml(builtinWidgetText(item, "ref.info.tab1", "Info"))}</strong><span data-home-text-slot="ref.info.tab2">${escapeHtml(builtinWidgetText(item, "ref.info.tab2", "Shared"))}</span><span data-home-text-slot="ref.info.tab3">${escapeHtml(builtinWidgetText(item, "ref.info.tab3", "Me"))}</span></div>
      <div class="home-ref-info-body">
        <div class="home-ref-info-media-grid"><div class="home-ref-info-media home-ref-media" data-home-media-slot="ref.info.photo1" aria-label="上传第一张图片"></div><div class="home-ref-info-media home-ref-media" data-home-media-slot="ref.info.photo2" aria-label="上传第二张图片"></div></div>
        <div class="home-ref-info-copy"><strong data-home-text-slot="ref.info.copy" data-home-text-multiline="true">${escapeHtml(builtinWidgetText(item, "ref.info.copy", "★ [ · Pink shirt (♡♡)\n· Cake skirt★/…\n· Diamond nail art ★/… ]"))}</strong><span data-home-text-slot="ref.info.stats">${escapeHtml(builtinWidgetText(item, "ref.info.stats", "99k replies · 520k likes"))}</span></div>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceCollectionProfileComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-collection-profile";
    shell.setAttribute("aria-label", "收藏资料");
    shell.innerHTML = `
      <div class="home-ref-collection-head">
        <div class="home-ref-collection-avatar-wrap">
          <div class="home-ref-collection-avatar home-ref-media" data-home-media-slot="ref.collection.avatar" aria-label="上传头像"></div>
          <span class="home-ref-collection-avatar-badge" aria-hidden="true"><i class="fa-solid fa-camera"></i></span>
        </div>
        <div class="home-ref-collection-copy"><strong data-home-text-slot="ref.collection.name">${escapeHtml(builtinWidgetText(item, "ref.collection.name", "Doris"))}</strong><span data-home-text-slot="ref.collection.subtitle">${escapeHtml(builtinWidgetText(item, "ref.collection.subtitle", "#收藏集"))}</span></div>
        <span class="home-ref-collection-follow" data-home-text-slot="ref.collection.follow">${escapeHtml(builtinWidgetText(item, "ref.collection.follow", "Follow"))}</span>
      </div>
      <div class="home-ref-collection-orbs">
        <div class="home-ref-collection-orb home-ref-media" data-home-media-slot="ref.collection.item1" aria-label="上传第一张收藏图片"></div>
        <div class="home-ref-collection-orb home-ref-media" data-home-media-slot="ref.collection.item2" aria-label="上传第二张收藏图片"></div>
        <div class="home-ref-collection-orb home-ref-media" data-home-media-slot="ref.collection.item3" aria-label="上传第三张收藏图片"></div>
        <div class="home-ref-collection-orb home-ref-media" data-home-media-slot="ref.collection.item4" aria-label="上传第四张收藏图片"></div>
        <div class="home-ref-collection-add" aria-hidden="true">＋</div>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceLoginPanelComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-login-panel";
    shell.setAttribute("aria-label", "登录面板");
    shell.innerHTML = `
      <div class="home-ref-login-top">
        <div class="home-ref-login-tabs"><strong data-home-text-slot="ref.login.tab1">${escapeHtml(builtinWidgetText(item, "ref.login.tab1", "Account"))}</strong><span data-home-text-slot="ref.login.tab2">${escapeHtml(builtinWidgetText(item, "ref.login.tab2", "Password"))}</span></div>
        <div class="home-ref-login-mini"><span data-home-text-slot="ref.login.badge">${escapeHtml(builtinWidgetText(item, "ref.login.badge", "Mell°o°^"))}</span><div class="home-ref-login-mini-media home-ref-media" data-home-media-slot="ref.login.avatar" aria-label="上传图片"></div></div>
      </div>
      <div class="home-ref-login-form">
        <strong data-home-text-slot="ref.login.label">${escapeHtml(builtinWidgetText(item, "ref.login.label", "Username"))}</strong>
        <div class="home-ref-login-field" data-home-text-slot="ref.login.username">${escapeHtml(builtinWidgetText(item, "ref.login.username", "@DorisWorld"))}</div>
        <span data-home-text-slot="ref.login.hint">${escapeHtml(builtinWidgetText(item, "ref.login.hint", "Enter your email address"))}</span>
        <b data-home-text-slot="ref.login.action">${escapeHtml(builtinWidgetText(item, "ref.login.action", "Continue"))}</b>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceSocialPostComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-social-post";
    shell.setAttribute("aria-label", "动态帖子");
    shell.innerHTML = `
      <div class="home-ref-post-head">
        <div class="home-ref-post-avatar home-ref-media" data-home-media-slot="ref.post.avatar" aria-label="上传头像"></div>
        <div class="home-ref-post-meta">
          <div class="home-ref-post-name-row">
            <strong data-home-text-slot="ref.post.name">${escapeHtml(builtinWidgetText(item, "ref.post.name", "流泪猫猫头"))}</strong>
            <img class="home-ref-post-verified" src="./Apps/system/assets/twitter-verified-badge.svg?v=0.0.315" alt="已认证" draggable="false">
          </div>
          <span class="home-ref-post-time"><b data-home-text-slot="ref.post.timeValue">${escapeHtml(builtinWidgetText(item, "ref.post.timeValue", "29"))}</b><em data-home-text-slot="ref.post.timeLabel">${escapeHtml(builtinWidgetText(item, "ref.post.timeLabel", "seconds ago"))}</em></span>
        </div>
        <button type="button" aria-label="更多选项">…</button>
      </div>
      <div class="home-ref-post-body">
        <strong data-home-text-slot="ref.post.content" data-home-text-multiline="true">${escapeHtml(builtinWidgetText(item, "ref.post.content", "Life has given me countless snow. And you are the first spring I have ever met."))}</strong>
        <span data-home-text-slot="ref.post.translation">${escapeHtml(builtinWidgetText(item, "ref.post.translation", "Translation from the internet"))}</span>
      </div>
      <div class="home-ref-post-actions">
        <div><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i><span data-home-text-slot="ref.post.action1">${escapeHtml(builtinWidgetText(item, "ref.post.action1", "Repost"))}</span></div>
        <div><i class="fa-regular fa-comment" aria-hidden="true"></i><span data-home-text-slot="ref.post.action2">${escapeHtml(builtinWidgetText(item, "ref.post.action2", "Comments"))}</span></div>
        <div><i class="fa-regular fa-thumbs-up" aria-hidden="true"></i><span data-home-text-slot="ref.post.action3">${escapeHtml(builtinWidgetText(item, "ref.post.action3", "Likes"))}</span></div>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceMyStoryComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-my-story";
    shell.setAttribute("aria-label", "主页数据卡");
    shell.innerHTML = `
      <div class="home-ref-story-head">
        <strong data-home-text-slot="ref.story.title">${escapeHtml(builtinWidgetText(item, "ref.story.title", "MyStory"))}</strong>
        <span class="home-ref-story-photo-button" aria-hidden="true"><i class="fa-solid fa-image-portrait"></i></span>
      </div>
      <div class="home-ref-story-body">
        <div class="home-ref-story-hero home-ref-media" data-home-media-slot="ref.story.hero" aria-label="上传主页图片"></div>
        <div class="home-ref-story-stat"><b data-home-text-slot="ref.story.stat1">${escapeHtml(builtinWidgetText(item, "ref.story.stat1", "52"))}</b><span data-home-text-slot="ref.story.label1">${escapeHtml(builtinWidgetText(item, "ref.story.label1", "posts"))}</span></div>
        <div class="home-ref-story-stat"><b data-home-text-slot="ref.story.stat2">${escapeHtml(builtinWidgetText(item, "ref.story.stat2", "2"))}</b><span data-home-text-slot="ref.story.label2">${escapeHtml(builtinWidgetText(item, "ref.story.label2", "following"))}</span></div>
        <div class="home-ref-story-stat"><b data-home-text-slot="ref.story.stat3">${escapeHtml(builtinWidgetText(item, "ref.story.stat3", "99M"))}</b><span data-home-text-slot="ref.story.label3">${escapeHtml(builtinWidgetText(item, "ref.story.label3", "followers"))}</span></div>
        <div class="home-ref-story-edit"><span data-home-text-slot="ref.story.edit">${escapeHtml(builtinWidgetText(item, "ref.story.edit", "Edit Your Profile"))}</span><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></div>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceIMessageChatComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-imessage-chat";
    shell.setAttribute("aria-label", "iMessage 对话");
    shell.innerHTML = `
      <div class="home-ref-imessage-top">
        <div class="home-ref-imessage-sticker home-ref-media" data-home-media-slot="ref.imessage.sticker" aria-label="上传贴纸"></div>
        <div class="home-ref-imessage-title"><strong data-home-text-slot="ref.imessage.title">${escapeHtml(builtinWidgetText(item, "ref.imessage.title", "iMessage"))}</strong><span data-home-text-slot="ref.imessage.time">${escapeHtml(builtinWidgetText(item, "ref.imessage.time", "Today 21:43"))}</span></div>
        <div class="home-ref-imessage-music">
          <div class="home-ref-imessage-cover home-ref-media" data-home-media-slot="ref.imessage.cover" aria-label="上传音乐封面"></div>
          <div class="home-ref-imessage-music-copy"><strong data-home-text-slot="ref.imessage.song">${escapeHtml(builtinWidgetText(item, "ref.imessage.song", "lovestory"))}</strong><span data-home-text-slot="ref.imessage.artist">${escapeHtml(builtinWidgetText(item, "ref.imessage.artist", "Taylor Swift"))}</span></div>
          <i class="fa-solid fa-pause" aria-hidden="true"></i>
        </div>
      </div>
      <div class="home-ref-imessage-bubble" data-home-text-slot="ref.imessage.message">${escapeHtml(builtinWidgetText(item, "ref.imessage.message", "oh I'm falling love"))}</div>
      <div class="home-ref-imessage-input">
        <i class="fa-solid fa-circle-plus" aria-hidden="true"></i>
        <span data-home-text-slot="ref.imessage.placeholder">${escapeHtml(builtinWidgetText(item, "ref.imessage.placeholder", "iMessage"))}</span>
        <i class="fa-solid fa-microphone" aria-hidden="true"></i>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceHumanVerificationComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-human-verification";
    shell.setAttribute("aria-label", "验证面板");
    shell.innerHTML = `
      <strong data-home-text-slot="ref.verify.title">${escapeHtml(builtinWidgetText(item, "ref.verify.title", "HumanVerification"))}</strong>
      <div class="home-ref-verify-links"><span data-home-text-slot="ref.verify.link1">${escapeHtml(builtinWidgetText(item, "ref.verify.link1", "Skip"))}</span><span data-home-text-slot="ref.verify.link2">${escapeHtml(builtinWidgetText(item, "ref.verify.link2", "Help"))}</span><span data-home-text-slot="ref.verify.link3">${escapeHtml(builtinWidgetText(item, "ref.verify.link3", "I ??? a robot"))}</span></div>
      <div class="home-ref-verify-media home-ref-media" data-home-media-slot="ref.verify.image" aria-label="上传验证码图片"></div>
      <div class="home-ref-verify-input"><span data-home-text-slot="ref.verify.placeholder">${escapeHtml(builtinWidgetText(item, "ref.verify.placeholder", "Enter the code"))}</span><i class="fa-solid fa-reply" aria-hidden="true"></i></div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }


  function buildReferenceListPanelComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-list-panel";
    shell.setAttribute("aria-label", "清单卡片");
    shell.innerHTML = `
      <div class="home-ref-list-tabs">
        <span data-home-text-slot="ref.list.tab1">${escapeHtml(builtinWidgetText(item, "ref.list.tab1", "New List"))}</span>
        <span data-home-text-slot="ref.list.tab2">${escapeHtml(builtinWidgetText(item, "ref.list.tab2", "Templates"))}</span>
      </div>
      <div class="home-ref-list-surface">
        <div class="home-ref-list-media home-ref-media" data-home-media-slot="ref.list.cover" aria-label="上传清单图片"></div>
        <div class="home-ref-list-id" data-home-text-slot="ref.list.id">${escapeHtml(builtinWidgetText(item, "ref.list.id", "@ID: ANuyoah-m7"))}</div>
      </div>
      <div class="home-ref-list-type"><i class="fa-solid fa-list" aria-hidden="true"></i><span data-home-text-slot="ref.list.type">${escapeHtml(builtinWidgetText(item, "ref.list.type", "List Type"))}</span><b aria-hidden="true">›</b></div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceCirclePlayerComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-circle-player";
    shell.setAttribute("aria-label", "圆形播放器");
    shell.innerHTML = `
      <div class="home-ref-circle-frame">
        <div class="home-ref-circle-media home-ref-media" data-home-media-slot="ref.circle.image" aria-label="上传圆形图片"></div>
        <span class="home-ref-circle-add" aria-hidden="true"><i class="fa-solid fa-plus"></i></span>
      </div>
      <span class="home-ref-circle-tag" data-home-text-slot="ref.circle.tag">${escapeHtml(builtinWidgetText(item, "ref.circle.tag", "困困糊"))}</span>
      <i class="fa-solid fa-music home-ref-circle-music-icon" aria-hidden="true"></i>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceRobotCheckComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-robot-check";
    shell.setAttribute("aria-label", "人机验证");
    shell.innerHTML = `
      <div class="home-ref-robot-head">
        <span class="home-ref-robot-box" aria-hidden="true"></span>
        <strong data-home-text-slot="ref.robot.title">${escapeHtml(builtinWidgetText(item, "ref.robot.title", "I’m not a robot"))}</strong>
      </div>
      <div class="home-ref-robot-panel">
        <span class="home-ref-robot-notch" aria-hidden="true"></span>
        <div class="home-ref-robot-input">
          <div class="home-ref-robot-field">
            <span data-home-text-slot="ref.robot.placeholder">${escapeHtml(builtinWidgetText(item, "ref.robot.placeholder", "Type what u see"))}</span>
          </div>
          <b data-home-text-slot="ref.robot.action">${escapeHtml(builtinWidgetText(item, "ref.robot.action", "Verify"))}</b>
        </div>
        <div class="home-ref-robot-body">
          <div class="home-ref-robot-media home-ref-media" data-home-media-slot="ref.robot.image" aria-label="上传验证图片"></div>
          <div class="home-ref-robot-tools" aria-hidden="true">
            <i class="fa-solid fa-rotate-right"></i>
            <i class="fa-solid fa-headphones"></i>
          </div>
        </div>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferencePhotoCollageComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-photo-collage";
    shell.setAttribute("aria-label", "拼贴相册");
    shell.innerHTML = `
      <div class="home-ref-collage-frame">
        <div class="home-ref-collage-media home-ref-media is-a" data-home-media-slot="ref.collage.photo1" aria-label="上传第一张拼贴图片"></div>
        <div class="home-ref-collage-media home-ref-media is-b" data-home-media-slot="ref.collage.photo2" aria-label="上传第二张拼贴图片"></div>
        <div class="home-ref-collage-media home-ref-media is-c" data-home-media-slot="ref.collage.photo3" aria-label="上传第三张拼贴图片"></div>
      </div>
      <span class="home-ref-collage-caption" data-home-text-slot="ref.collage.caption">${escapeHtml(builtinWidgetText(item, "ref.collage.caption", "Colorful Widget"))}</span>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceMonthCalendarComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-month-calendar";
    shell.setAttribute("aria-label", "月历卡片");
    const weekdays = ["S", "M", "T", "W", "T", "F", "S"].map((day) => `<span>${day}</span>`).join("");
    const days = Array.from({ length: 42 }, (_, index) => `<b data-ref-month-day="${index}"></b>`).join("");
    shell.innerHTML = `
      <div class="home-ref-month-search">
        <i class="fa-solid fa-face-smile" aria-hidden="true"></i>
        <span data-home-text-slot="ref.month.search">${escapeHtml(builtinWidgetText(item, "ref.month.search", "love you always.."))}</span>
        <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
      </div>
      <div class="home-ref-month-main">
        <div class="home-ref-month-date"><span data-ref-month-year></span><strong data-ref-month-name></strong><b data-ref-month-weekday></b></div>
        <div class="home-ref-month-photo home-ref-media" data-home-media-slot="ref.month.photo" aria-label="上传月历图片"></div>
        <div class="home-ref-month-calendar-body">
          <div class="home-ref-month-weekdays">${weekdays}</div>
          <div class="home-ref-month-days">${days}</div>
        </div>
      </div>
      <div class="home-ref-month-quote" data-home-text-slot="ref.month.quote">${escapeHtml(builtinWidgetText(item, "ref.month.quote", "˚. 9e * ·You deserve all the beauty in the world ·* 9e .˚"))}</div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    syncO3OClock(shell);
    return shell;
  }

  function buildReferenceMemoryBoardComponent(item = null) {
    const shell = document.createElement("section");
    shell.className = "home-ref-preset home-ref-memory-board";
    shell.setAttribute("aria-label", "回忆文件夹");
    shell.innerHTML = `
      <div class="home-ref-memory-folder">
        <div class="home-ref-memory-folder-tab" aria-hidden="true"></div>
        <div class="home-ref-memory-folder-grid">
          <div class="home-ref-memory-board-media home-ref-media is-a" data-home-media-slot="ref.memoryBoard.photo1" aria-label="上传第一张回忆图片"></div>
          <div class="home-ref-memory-board-media home-ref-media is-b" data-home-media-slot="ref.memoryBoard.photo2" aria-label="上传第二张回忆图片"></div>
          <div class="home-ref-memory-board-media home-ref-media is-c" data-home-media-slot="ref.memoryBoard.photo3" aria-label="上传第三张回忆图片"></div>
          <strong data-home-text-slot="ref.memoryBoard.title">${escapeHtml(builtinWidgetText(item, "ref.memoryBoard.title", "Memories"))}</strong>
        </div>
      </div>`;
    return hydrateBuiltinWidgetMedia(shell, item);
  }

  function buildReferenceComponent(widgetType, item = null) {
    if (widgetType === "ref-social-thread") return buildReferenceSocialThreadComponent(item);
    if (widgetType === "ref-note-card") return buildReferenceNoteCardComponent(item);
    if (widgetType === "ref-week-calendar") return buildReferenceWeekCalendarComponent(item);
    if (widgetType === "ref-status-overview") return buildReferenceStatusOverviewComponent(item, "4x2");
    if (widgetType === "ref-status-overview-4x4") return buildReferenceStatusOverviewComponent(item, "4x4");
    if (widgetType === "ref-camera-frame") return buildReferenceCameraFrameComponent(item);
    if (widgetType === "ref-info-gallery") return buildReferenceInfoGalleryComponent(item);
    if (widgetType === "ref-collection-profile") return buildReferenceCollectionProfileComponent(item);
    if (widgetType === "ref-login-panel") return buildReferenceLoginPanelComponent(item);
    if (widgetType === "ref-social-post") return buildReferenceSocialPostComponent(item);
    if (widgetType === "ref-my-story") return buildReferenceMyStoryComponent(item);
    if (widgetType === "ref-imessage-chat") return buildReferenceIMessageChatComponent(item);
    if (widgetType === "ref-human-verification") return buildReferenceHumanVerificationComponent(item);
    if (widgetType === "ref-list-panel") return buildReferenceListPanelComponent(item);
    if (widgetType === "ref-circle-player") return buildReferenceCirclePlayerComponent(item);
    if (widgetType === "ref-robot-check") return buildReferenceRobotCheckComponent(item);
    if (widgetType === "ref-photo-collage") return buildReferencePhotoCollageComponent(item);
    if (widgetType === "ref-month-calendar") return buildReferenceMonthCalendarComponent(item);
    if (widgetType === "ref-memory-board") return buildReferenceMemoryBoardComponent(item);
    return null;
  }

  const O3O_TIME_FORMATTER = new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit", hour12: false });
  const O3O_DATE_FORMATTER = new Intl.DateTimeFormat("en-US", { month: "short", day: "2-digit", weekday: "short" });
  const O3O_TIME12_FORMATTER = new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit", hour12: true });
  const O3O_MONTH_FORMATTER = new Intl.DateTimeFormat("en-US", { month: "long" });
  const O3O_WEEKDAY_FORMATTER = new Intl.DateTimeFormat("en-US", { weekday: "long" });

  function syncO3OClock(root = document) {
    const now = new Date();
    const time = O3O_TIME_FORMATTER.format(now);
    const date = O3O_DATE_FORMATTER.format(now).replace(",", " ·");
    const ymd = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, "0")}/${String(now.getDate()).padStart(2, "0")}`;
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const percent = clamp(((now.getTime() - start) / 86400000) * 100, 0, 100).toFixed(2) + "%";
    root.querySelectorAll?.("[data-o3o-clock-time]").forEach((node) => { node.textContent = time; });
    root.querySelectorAll?.("[data-o3o-clock-date]").forEach((node) => { node.textContent = date; });
    root.querySelectorAll?.("[data-o3o-memory-date]").forEach((node) => { node.textContent = ymd; });
    root.querySelectorAll?.("[data-o3o-day-percent]").forEach((node) => { node.textContent = percent; });
    const zhWeek = ["日", "一", "二", "三", "四", "五", "六"][now.getDay()];
    const osDate = `${now.getMonth() + 1}月${now.getDate()}日 周${zhWeek}`;
    root.querySelectorAll?.("[data-os-card-date]").forEach((node) => { node.textContent = osDate; });

    root.querySelectorAll?.("[data-ref-time]").forEach((node) => { node.textContent = time; });
    const time12 = O3O_TIME12_FORMATTER.format(now).replace(" ", "");
    root.querySelectorAll?.("[data-ref-status-time]").forEach((node) => { node.textContent = time12; });
    root.querySelectorAll?.(".home-ref-month-calendar").forEach((calendar) => {
      const yearNode = calendar.querySelector("[data-ref-month-year]");
      const monthNode = calendar.querySelector("[data-ref-month-name]");
      const weekdayNode = calendar.querySelector("[data-ref-month-weekday]");
      if (yearNode) yearNode.textContent = String(now.getFullYear());
      if (monthNode) monthNode.textContent = O3O_MONTH_FORMATTER.format(now);
      if (weekdayNode) weekdayNode.textContent = O3O_WEEKDAY_FORMATTER.format(now);
      const first = new Date(now.getFullYear(), now.getMonth(), 1);
      const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
      calendar.querySelectorAll("[data-ref-month-day]").forEach((node) => {
        const index = clamp(int(node.dataset.refMonthDay, 0), 0, 41);
        const dayNumber = index - first.getDay() + 1;
        const valid = dayNumber >= 1 && dayNumber <= daysInMonth;
        node.textContent = valid ? String(dayNumber) : "";
        node.classList.toggle("is-today", valid && dayNumber === now.getDate());
      });
    });

    root.querySelectorAll?.("[data-ref-status-week-index]").forEach((node) => {
      const index = clamp(int(node.dataset.refStatusWeekIndex, 0), 0, 6);
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay());
      const dateValue = new Date(start.getFullYear(), start.getMonth(), start.getDate() + index);
      const dateNode = node.querySelector("[data-ref-status-date]");
      if (dateNode) dateNode.textContent = String(dateValue.getDate());
      node.classList.toggle("is-today", dateValue.toDateString() === now.toDateString());
    });

    const day = now.getDay();
    const mondayOffset = day === 0 ? -6 : 1 - day;
    const monday = new Date(now.getFullYear(), now.getMonth(), now.getDate() + mondayOffset);
    const weekLabels = ["一", "二", "三", "四", "五", "六", "日"];
    root.querySelectorAll?.("[data-ref-week-index]").forEach((node) => {
      const index = clamp(int(node.dataset.refWeekIndex, 0), 0, 6);
      const dateValue = new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + index);
      const label = node.querySelector("[data-ref-week-label]");
      const dateNode = node.querySelector("[data-ref-week-date]");
      if (label) label.textContent = weekLabels[index];
      if (dateNode) dateNode.textContent = String(dateValue.getDate());
      node.classList.toggle("is-today", dateValue.toDateString() === now.toDateString());
    });
  }

  function syncO3OBattery(root = document) {
    const level = HOME.o3oBattery && Number.isFinite(HOME.o3oBattery.level) ? clamp(Math.round(HOME.o3oBattery.level * 100), 0, 100) : null;
    const label = level === null ? (HOME.o3oBatteryUnavailable ? "N/A" : "…") : `${level}%`;
    root.querySelectorAll?.("[data-o3o-battery-value]").forEach((node) => { node.textContent = label; });
    root.querySelectorAll?.("[data-o3o-battery-fill]").forEach((node) => { node.style.width = level === null ? "0%" : `${level}%`; });
    root.querySelectorAll?.("[data-o3o-battery-ring]").forEach((node) => { node.style.strokeDashoffset = level === null ? "100" : String(100 - level); });
  }

  function syncMountedRealtimeComponents() {
    // 组件库抽屉位于主屏 route 根节点之外，实时数据必须覆盖当前已挂载实例；
    // 但扫描只发生在渲染/回到主屏/低频时钟 tick，不再永久每秒扫描整个 document。
    syncO3OClock(document);
    syncO3OBattery(document);
  }

  function realtimeSurfaceVisible() {
    if (document.hidden) return false;
    if (HOME.refs?.root?.classList.contains("is-active")) return true;
    return Boolean(document.querySelector(
      '.global-drawer-overlay.is-open [data-o3o-clock-time], .global-drawer-overlay.is-open [data-ref-time], .global-drawer-overlay.is-open [data-ref-status-time], .global-drawer-overlay.is-open [data-o3o-day-percent]'
    ));
  }

  function scheduleO3OClockTick() {
    window.clearTimeout(HOME.o3oClockTimer);
    HOME.o3oClockTimer = 0;
    if (!realtimeSurfaceVisible()) return;
    const now = Date.now();
    // 百分比保留两位时约 8.64 秒才会产生一次可见变化；10 秒 tick 足够，
    // 同时把旧实现每分钟约 60 次全 document 扫描降为约 6 次。
    const delay = Math.max(250, 10000 - (now % 10000));
    HOME.o3oClockTimer = window.setTimeout(() => {
      HOME.o3oClockTimer = 0;
      if (realtimeSurfaceVisible()) syncMountedRealtimeComponents();
      scheduleO3OClockTick();
    }, delay);
  }

  function ensureO3ORuntime() {
    syncMountedRealtimeComponents();
    scheduleO3OClockTick();
    if (!HOME.o3oBatteryInit && typeof navigator.getBattery === "function") {
      HOME.o3oBatteryUnavailable = false;
      HOME.o3oBatteryInit = navigator.getBattery().then((battery) => {
        HOME.o3oBattery = battery;
        HOME.o3oBatteryUnavailable = false;
        const update = () => syncO3OBattery(document);
        battery.addEventListener?.("levelchange", update);
        battery.addEventListener?.("chargingchange", update);
        update();
        return battery;
      }).catch(() => {
        HOME.o3oBatteryUnavailable = true;
        syncO3OBattery(document);
        return null;
      });
    } else if (typeof navigator.getBattery !== "function") {
      HOME.o3oBatteryUnavailable = true;
      syncO3OBattery(document);
    } else {
      syncO3OBattery(document);
    }
  }

  function readCurrentMusicPlaybackState() {
    try {
      const state = window.MusicApp?.state?.();
      return state && typeof state === "object" ? state : null;
    } catch (_) {
      return null;
    }
  }

  function formatMiniDuration(totalSeconds) {
    const value = Math.max(0, Number(totalSeconds) || 0);
    const minutes = Math.floor(value / 60);
    const seconds = Math.floor(value % 60);
    return `${minutes}:${String(seconds).padStart(2, "0")}`;
  }

  function rememberBuiltinTextBaseline(node) {
    if (!node) return "";
    if (!Object.prototype.hasOwnProperty.call(node.dataset, "homeDefaultText")) {
      node.dataset.homeDefaultText = String(node.textContent ?? "");
    }
    return String(node.dataset.homeDefaultText ?? "");
  }

  function writeRealtimeText(node, value) {
    if (!node || node.dataset.homeInlineEditing === "true") return;
    node.textContent = String(value ?? "");
  }

  function applyO3ODuetMusicPlayback(shell, payload = null) {
    if (!shell) return;
    const state = payload && typeof payload === "object" ? payload : readCurrentMusicPlaybackState();
    const track = state?.track && typeof state.track === "object" ? state.track : null;
    const hasTrack = Boolean(track);
    const playing = Boolean(hasTrack && state?.playing);
    const currentTime = Math.max(0, Number(state?.currentTime) || 0);
    const duration = Math.max(0, Number(state?.duration) || Number(track?.durationMs || 0) / 1000 || 0);
    const progress = duration > 0 ? clamp((currentTime / duration) * 100, 0, 100) : 0;
    const titleNode = shell.querySelector('[data-home-text-slot="duet.song"]');
    const artistNode = shell.querySelector('[data-home-text-slot="duet.artist"]');
    const elapsedNode = shell.querySelector('[data-home-text-slot="duet.elapsed"]');
    const durationNode = shell.querySelector('[data-home-text-slot="duet.duration"]');
    const progressNode = shell.querySelector('[data-o3o-duet-progress]');
    const playIcon = shell.querySelector('[data-o3o-duet-play-icon]');
    const volumeIcon = shell.querySelector('[data-o3o-duet-volume-icon]');
    const titleBaseline = rememberBuiltinTextBaseline(titleNode);
    const artistBaseline = rememberBuiltinTextBaseline(artistNode);
    const elapsedBaseline = rememberBuiltinTextBaseline(elapsedNode);
    const durationBaseline = rememberBuiltinTextBaseline(durationNode);
    writeRealtimeText(titleNode, hasTrack ? String(track.title || "Pink Lavender") : titleBaseline);
    writeRealtimeText(artistNode, hasTrack ? String(track.artist || track.artistName || "Artist") : artistBaseline);
    writeRealtimeText(elapsedNode, hasTrack ? formatMiniDuration(currentTime) : elapsedBaseline);
    writeRealtimeText(durationNode, hasTrack && duration > 0 ? formatMiniDuration(duration) : durationBaseline);
    if (progressNode) progressNode.style.width = `${progress}%`;
    if (playIcon) {
      playIcon.className = playing ? "fa-solid fa-pause" : "fa-solid fa-play";
      playIcon.setAttribute("aria-hidden", "true");
    }
    if (volumeIcon) volumeIcon.className = playing ? "fa-solid fa-volume-high" : "fa-solid fa-volume-low";
    shell.classList.toggle("is-live-music", hasTrack);
    shell.classList.toggle("is-playing", playing);
  }

  function applyUiiyMusicPlayback(shell, payload = null) {
    if (!shell) return;
    const state = payload && typeof payload === "object" ? payload : readCurrentMusicPlaybackState();
    const track = state?.track && typeof state.track === "object" ? state.track : null;
    const active = Boolean(state?.playing && track);
    const cover = shell.querySelector("[data-uiiy-music-cover]");
    const title = shell.querySelector("[data-uiiy-music-title]");
    const artist = shell.querySelector("[data-uiiy-music-artist]");
    const titleBaseline = rememberBuiltinTextBaseline(title);
    const artistBaseline = rememberBuiltinTextBaseline(artist);

    writeRealtimeText(title, active ? String(track.title || UIIY_MUSIC_DEFAULT.title) : titleBaseline);
    writeRealtimeText(artist, active ? String(track.artist || UIIY_MUSIC_DEFAULT.artist) : artistBaseline);
    if (cover) {
      const customUrl = String(cover.dataset.homeCustomMediaUrl || "").trim();
      const url = active ? String(track.cover || "").trim() : customUrl;
      const instanceId = String(shell.closest?.(".home-widget")?.dataset.widgetInstanceId || shell.dataset.widgetInstanceId || "uiiy-music");
      void window.QWQMediaSurface?.setBackground?.(cover, `home:live-music:${instanceId}:uiiy-cover`, url, {identity:url,className:"has-cover",emptyValue:""});
    }
    shell.classList.toggle("is-live-music", active);
  }

  function applyO3OMusicBatteryPlayback(shell, payload = null) {
    if (!shell) return;
    const state = payload && typeof payload === "object" ? payload : readCurrentMusicPlaybackState();
    const track = state?.track && typeof state.track === "object" ? state.track : null;
    const active = Boolean(state?.playing && track);
    const title = shell.querySelector('[data-home-text-slot="music.title"]');
    const subtitle = shell.querySelector('[data-home-text-slot="music.subtitle"]');
    const cover = shell.querySelector('[data-home-media-slot="music.cover"]');
    const titleBaseline = rememberBuiltinTextBaseline(title);
    const subtitleBaseline = rememberBuiltinTextBaseline(subtitle);
    writeRealtimeText(title, active ? String(track.title || "Music") : titleBaseline);
    writeRealtimeText(subtitle, active ? String(track.artist || track.artistName || "Artist") : subtitleBaseline);
    const customUrl = String(cover?.dataset.homeCustomMediaUrl || "").trim();
    const coverUrl = active ? String(track.cover || "").trim() : customUrl;
    if (cover) {
      const instanceId = String(shell.closest?.(".home-widget")?.dataset.widgetInstanceId || shell.dataset.widgetInstanceId || "o3o-music");
      void window.QWQMediaSurface?.setBackground?.(cover, `home:live-music:${instanceId}:o3o-cover`, coverUrl, {identity:coverUrl,className:"has-user-media",emptyValue:""});
    }
  }

  function applyReferenceStatusPlayback(shell, payload = null) {
    if (!shell) return;
    const state = payload && typeof payload === "object" ? payload : readCurrentMusicPlaybackState();
    const track = state?.track && typeof state.track === "object" ? state.track : null;
    const active = Boolean(state?.playing && track);
    const node = shell.querySelector('[data-home-text-slot="ref.status.track"]');
    const baseline = rememberBuiltinTextBaseline(node);
    if (!active) {
      writeRealtimeText(node, baseline);
      return;
    }
    const artist = String(track.artist || track.artistName || "").trim();
    writeRealtimeText(node, artist ? `${String(track.title || "Music")}-${artist}` : String(track.title || "Music"));
  }

  function syncUiiyMusicPlayback(payload = null) {
    const root = HOME.refs?.root || document.getElementById("page-my-phone-home");
    if (!root) return;
    root.querySelectorAll?.(".home-uiiy-top-shell").forEach((shell) => applyUiiyMusicPlayback(shell, payload));
    root.querySelectorAll?.(".home-o3o-duet-music").forEach((shell) => applyO3ODuetMusicPlayback(shell, payload));
    root.querySelectorAll?.(".home-o3o-music-battery").forEach((shell) => applyO3OMusicBatteryPlayback(shell, payload));
    root.querySelectorAll?.(".home-ref-status-overview").forEach((shell) => applyReferenceStatusPlayback(shell, payload));
  }

  function buildUiiyTopMusicComponent(item = null) {
    // 直接提取 UIIY_v26 主屏 App 网格上方的完整组件区：
    // .controls + .music-card-wrap + .widget-area。清柳 仅按现有 4×4 网格尺寸缩放，不添加整体视觉外壳。
    const shell = document.createElement("div");
    shell.className = "home-uiiy-top-shell";
    shell.innerHTML = `
      <div class="uiiy-controls" aria-label="UIIY 顶部控制区">
        <button class="uiiy-mini-button" type="button" tabindex="-1" aria-label="上一页"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i></button>
        <div class="uiiy-control-cluster">
          <button class="uiiy-mini-button" type="button" tabindex="-1" aria-label="返回首页"><i class="fa-solid fa-house" aria-hidden="true"></i></button>
          <button class="uiiy-tag-button" type="button" tabindex="-1"><span data-home-text-slot="uiiy.tag">${escapeHtml(builtinWidgetText(item, "uiiy.tag", "#记录你有关的萌点"))}</span></button>
        </div>
      </div>

      <div class="uiiy-music-card-wrap" aria-label="UIIY 音乐卡片">
        <button class="uiiy-side-next" type="button" tabindex="-1" aria-label="下一页"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></button>
        <div class="uiiy-music-stack">
          <div class="uiiy-music-main">
            <div class="uiiy-album-placeholder uiiy-media-placeholder" data-uiiy-music-cover data-home-media-slot="uiiy.musicCover" aria-label="上传音乐封面"></div>
            <div class="uiiy-music-copy">
              <div class="uiiy-music-title" data-uiiy-music-title data-home-text-slot="uiiy.musicTitle">${escapeHtml(builtinWidgetText(item, "uiiy.musicTitle", UIIY_MUSIC_DEFAULT.title))}</div>
              <div class="uiiy-music-artist" data-uiiy-music-artist data-home-text-slot="uiiy.musicArtist">${escapeHtml(builtinWidgetText(item, "uiiy.musicArtist", UIIY_MUSIC_DEFAULT.artist))}</div>
              <div class="uiiy-music-meta"><i class="fa-solid fa-circle-play" aria-hidden="true"></i><span data-home-text-slot="uiiy.musicMeta">${escapeHtml(builtinWidgetText(item, "uiiy.musicMeta", "Music"))}</span></div>
            </div>
            <button class="uiiy-close-music" type="button" tabindex="-1" aria-label="关闭音乐卡片"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
          </div>
          <div class="uiiy-quote-row">
            <div class="uiiy-quote-text" aria-label="标题" data-home-text-slot="uiiy.quote">${escapeHtml(builtinWidgetText(item, "uiiy.quote", "索菲亚公主的午後芭蕾茶話會"))}</div>
            <button class="uiiy-send-button" type="button" tabindex="-1" aria-label="保存"><i class="fa-solid fa-arrow-up" aria-hidden="true"></i></button>
          </div>
        </div>
      </div>

      <div class="uiiy-widget-area" aria-label="UIIY 三图组件">
        <div class="uiiy-drag-handle" aria-hidden="true"></div>
        <div class="uiiy-widget-grid" aria-label="三张图片容器">
          <div class="uiiy-widget-placeholder uiiy-media-placeholder" data-home-media-slot="uiiy.photo1" aria-label="上传第一张照片"></div>
          <div class="uiiy-widget-placeholder uiiy-media-placeholder" data-home-media-slot="uiiy.photo2" aria-label="上传第二张照片"></div>
          <div class="uiiy-widget-placeholder uiiy-media-placeholder" data-home-media-slot="uiiy.photo3" aria-label="上传第三张照片"></div>
        </div>
        <div class="uiiy-widget-meta">
          <button class="uiiy-chip" type="button" tabindex="-1"><i class="fa-solid fa-photo-film" aria-hidden="true"></i><span data-home-text-slot="uiiy.picsLabel">${escapeHtml(builtinWidgetText(item, "uiiy.picsLabel", "3Pics"))}</span></button>
          <button class="uiiy-chip" type="button" tabindex="-1"><span data-home-text-slot="uiiy.day">${escapeHtml(builtinWidgetText(item, "uiiy.day", "・天。"))}</span></button>
        </div>
      </div>`;
    hydrateBuiltinWidgetMedia(shell, item);
    applyUiiyMusicPlayback(shell);
    return shell;
  }

  function buildWidgetNode(item, state) {
    const node = document.createElement("div");
    node.className = "home-item home-widget"; node.dataset.itemId = item.id; node.dataset.widgetInstanceId = item.instanceId; node.dataset.widget = item.widgetType || "basic";
    if (item.widgetType === "custom") {
      const iframe = document.createElement("iframe");
      iframe.className = "home-widget-frame"; iframe.sandbox = "allow-scripts"; iframe.srcdoc = buildWidgetSrcdoc(item, state); iframe.title = widgetTemplateFor(item, state)?.name || "Widget";
      node.append(iframe);
    } else if (item.widgetType === "uiiy-top-music") {
      node.append(buildUiiyTopMusicComponent(item));
    } else {
      const o3o = buildO3OComponent(item.widgetType, item);
      const osComponent = o3o ? null : buildOSComponent(item.widgetType, item);
      const referenceComponent = (o3o || osComponent) ? null : buildReferenceComponent(item.widgetType, item);
      if (o3o) {
        const visualShell = document.createElement("div");
        visualShell.className = "home-o3o-visual-shell";
        visualShell.append(o3o);
        node.append(visualShell);
      }
      else if (osComponent) node.append(osComponent);
      else if (referenceComponent) node.append(referenceComponent);
      else {
        const body = document.createElement("div"); body.className = "home-basic-widget";
        body.innerHTML = `<strong>${escapeHtml(item.data?.title || "Widget")}</strong><span>${escapeHtml(item.data?.text || "长按可移动")}</span>`; node.append(body);
      }
    }
    const cover = document.createElement("div"); cover.className = "home-widget-edit-cover"; cover.dataset.dragHandle = "true"; node.append(cover);
    addEditControls(node, item);
    return node;
  }
  function escapeHtml(value) { return String(value ?? "").replace(/[&<>"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[char])); }

  function addEditControls(node, item) {
    const remove = document.createElement("button"); remove.type = "button"; remove.className = "home-item-remove"; remove.dataset.removeItem = item.id; remove.setAttribute("aria-label", "从主屏移除"); const removeIcon = document.createElement("i"); removeIcon.className = "fa-solid fa-minus"; removeIcon.setAttribute("aria-hidden", "true"); remove.append(removeIcon); node.append(remove);
    if (item.kind === "widget" && item.widgetType === "custom") {
      const edit = document.createElement("button"); edit.type = "button"; edit.className = "home-item-edit"; edit.dataset.editWidget = item.id; edit.setAttribute("aria-label", "编辑 Widget"); edit.textContent = "⋯"; node.append(edit);
    }
  }

  function applyGridPosition(node, item) {
    node.style.gridColumn = `${item.gridX + 1} / span ${item.width}`;
    node.style.gridRow = `${item.gridY + 1} / span ${item.height}`;
  }

  function createPageNode(index) {
    const pageNode = document.createElement("section");
    pageNode.className = "home-page";
    pageNode.dataset.pageIndex = String(index);
    pageNode.setAttribute("aria-label", `主屏第 ${index + 1} 页`);
    const gridNode = document.createElement("div");
    gridNode.className = "home-page-grid";
    pageNode.append(gridNode);
    return { pageNode, gridNode };
  }

  function ensurePageDomCount(state) {
    const track = HOME.refs.track;
    while (track.children.length < state.pages.length) {
      const index = track.children.length;
      const { pageNode } = createPageNode(index);
      track.append(pageNode);
    }
    while (track.children.length > state.pages.length) track.lastElementChild.remove();
  }

  function captureRects(nodes) {
    const rects = new Map();
    nodes.forEach((node) => { if (node?.isConnected && !node.classList.contains("is-drag-source")) rects.set(node, node.getBoundingClientRect()); });
    return rects;
  }

  function playFlip(rects) {
    if (!rects?.size) return;
    for (const [node, before] of rects) {
      if (!node.isConnected || node.classList.contains("is-drag-source") || typeof node.animate !== "function") continue;
      const after = node.getBoundingClientRect();
      const dx = before.left - after.left, dy = before.top - after.top;
      if (Math.abs(dx) < .5 && Math.abs(dy) < .5) continue;
      node.animate([{ translate: `${dx}px ${dy}px` }, { translate: "0px 0px" }], { duration: 170, easing: "cubic-bezier(.2,.8,.2,1)" });
    }
  }

  function desktopPositionKey(item) {
    return `${item.pageIndex}:${item.gridX}:${item.gridY}:${item.width}:${item.height}`;
  }

  function syncDesktopPositionKeys(state) {
    HOME.desktopPositionKeys.clear();
    state.desktopItems.forEach((item) => HOME.desktopPositionKeys.set(item.id, desktopPositionKey(item)));
  }

  function syncDockPositionKeys(state) {
    HOME.dockPositionKeys.clear();
    [...state.dockItems].sort((a, b) => a.order - b.order).forEach((row, index) => {
      HOME.dockPositionKeys.set(row.appId, String(index));
    });
  }

  function isDraggedDesktopStateItem(item) {
    const drag = HOME.drag;
    if (!drag || !item) return false;
    if (drag.itemId && item.id === drag.itemId) return true;
    return drag.sourceType === "dock" && item.kind === "app" && item.appId === drag.appId;
  }

  function syncPreviewDom(state) {
    ensurePageDomCount(state);
    const existingById = new Map(Array.from(HOME.refs.track.querySelectorAll("[data-item-id]")).map((node) => [node.dataset.itemId, node]));
    const changed = [];
    for (const item of state.desktopItems) {
      const node = existingById.get(item.id);
      if (node && HOME.desktopPositionKeys.get(item.id) !== desktopPositionKey(item)) changed.push(node);
    }
    // FLIP 只读取真正换格/跨页的节点，避免每次候选预览对整页做两轮 getBoundingClientRect。
    const before = captureRects(changed);
    const wanted = new Set(state.desktopItems.map((item) => item.id));
    for (const item of state.desktopItems) {
      // 拖动中的项目只显示“原 DOM 本体”。它已被提升到 drag layer，
      // Preview 只负责其它项目让位，禁止再构造第二份节点形成克隆视觉。
      if (isDraggedDesktopStateItem(item)) continue;
      let node = existingById.get(item.id);
      if (!node) node = item.kind === "app" ? buildAppNode(item) : buildWidgetNode(item, state);
      const pageNode = HOME.refs.track.children[item.pageIndex];
      const gridNode = pageNode?.querySelector(":scope > .home-page-grid");
      if (node && gridNode && node.parentElement !== gridNode) gridNode.append(node);
      if (node) applyGridPosition(node, item);
    }
    HOME.refs.track.querySelectorAll("[data-item-id]").forEach((node) => {
      if (!wanted.has(node.dataset.itemId)) node.remove();
    });
    syncDesktopPositionKeys(state);
    playFlip(before);
  }

  function render({ committed = true } = {}) {
    // 启动期禁止渲染默认内存态。正式布局只有 Dexie active hydrate 完成后才允许进入 DOM。
    if (!HOME.hydrated || !HOME.refs.track || !HOME.layout) return;
    const state = currentState();
    HOME.refs.track.style.setProperty("--home-page-index", String(state.currentPageIndex));
    if (committed || !HOME.refs.track.children.length) {
      // DOM 可以重建，但 Blob URL 属于组件槽位资源生命周期，不能跟着 render 一起销毁。
      // 否则每次布局提交都会先撤销旧 URL，再重建新 URL，造成所有图片容器同时闪烁。
      HOME.refs.track.replaceChildren();
      state.pages.forEach((page, index) => {
        const { pageNode, gridNode } = createPageNode(index);
        for (const item of pageItems(state, index)) {
          const node = item.kind === "app" ? buildAppNode(item) : buildWidgetNode(item, state);
          if (!node) continue; applyGridPosition(node, item); gridNode.append(node);
        }
        HOME.refs.track.append(pageNode);
      });
      renderDock(state);
      syncDesktopPositionKeys(state);
      syncDockPositionKeys(state);
    } else {
      syncPreviewDom(state);
      syncDockDom(state);
    }
    renderIndicator(state); renderEditUi();
    syncMountedRealtimeComponents();
    if (committed) updateGeometry();
  }

  function buildDockNode(row) {
    const reg = HOME.registry.get(row.appId); if (!reg) return null;
    // Dock 的可拖拽几何外壳与可摇摆图标分层：减号固定在外壳，只有 icon-shell 摇摆。
    // 这样 Dock 与桌面 App 共用同一编辑控件坐标，不再因父级 rotate 被甩动。
    const node = document.createElement("div");
    node.className = "home-dock-item";
    node.dataset.dockAppId = row.appId;
    const shell = createShell(reg, true);
    const remove = document.createElement("button"); remove.type = "button"; remove.className = "home-item-remove home-dock-remove"; remove.dataset.removeDockApp = row.appId; remove.setAttribute("aria-label", "从主屏移除"); const removeIcon = document.createElement("i"); removeIcon.className = "fa-solid fa-minus"; removeIcon.setAttribute("aria-hidden", "true"); remove.append(removeIcon);
    node.append(shell, remove);
    return node;
  }

  function renderDock(state) {
    HOME.refs.dockGrid.replaceChildren();
    HOME.refs.dock.dataset.dockCount = String(Math.min(GRID.dockCapacity, state.dockItems.length));
    [...state.dockItems].sort((a, b) => a.order - b.order).forEach((row) => {
      const shell = buildDockNode(row); if (shell) HOME.refs.dockGrid.append(shell);
    });
  }

  function syncDockDom(state) {
    // 拖动会话内 Dock 保持开始拖动时的真实几何，不跟随 Preview 抽走/插入节点。
    // 最终顺序只在松手事务结束后一次性提交，避免 fit-content 外壳与其余图标来回位移。
    if (HOME.drag) {
      HOME.refs.dock.dataset.dockCount = String(Math.min(GRID.dockCapacity, HOME.layout?.dockItems?.length || 0));
      return;
    }
    HOME.refs.dock.dataset.dockCount = String(Math.min(GRID.dockCapacity, state.dockItems.length));
    const rows = [...state.dockItems].sort((a, b) => a.order - b.order);
    const existing = Array.from(HOME.refs.dockGrid.querySelectorAll(".home-dock-item[data-dock-app-id]"));
    const changed = existing.filter((shell) => {
      const index = rows.findIndex((row) => row.appId === shell.dataset.dockAppId);
      return index >= 0 && HOME.dockPositionKeys.get(shell.dataset.dockAppId) !== String(index);
    });
    const before = captureRects(changed);
    const wanted = new Set(rows.map((row) => row.appId));
    for (const row of rows) {
      // 同样禁止为正在拖动的 App 在 Dock 中生成第二份可见节点。
      if (HOME.drag?.appId === row.appId) continue;
      let shell = HOME.refs.dockGrid.querySelector(`[data-dock-app-id="${CSS.escape(row.appId)}"]`);
      if (!shell) shell = buildDockNode(row);
      if (shell) HOME.refs.dockGrid.append(shell);
    }
    HOME.refs.dockGrid.querySelectorAll(".home-dock-item[data-dock-app-id]").forEach((shell) => {
      if (!wanted.has(shell.dataset.dockAppId)) shell.remove();
    });
    syncDockPositionKeys(state);
    playFlip(before);
  }
  function renderIndicator(state) {
    const count = state.pages.length;
    HOME.refs.indicator.hidden = count < 2;
    while (HOME.refs.indicator.children.length < count) {
      const dot = document.createElement("span");
      dot.className = "home-page-dot";
      HOME.refs.indicator.append(dot);
    }
    while (HOME.refs.indicator.children.length > count) HOME.refs.indicator.lastElementChild.remove();
    Array.from(HOME.refs.indicator.children).forEach((dot, index) => dot.classList.toggle("is-active", index === state.currentPageIndex));
  }
  function renderEditUi() {
    HOME.refs.root.classList.toggle("is-home-editing", HOME.editMode);
    HOME.refs.editBar.hidden = !HOME.editMode;
  }
  function buildRuntimeDom() {
    const root = document.getElementById("page-my-phone-home");
    const top = root.querySelector(":scope > .top-grid");
    const dock = root.querySelector(":scope > .dock");
    const dockGrid = dock?.querySelector(".dock-grid");
    if (!top || !dock || !dockGrid) throw new Error("主屏初始 DOM 不完整");
    const viewport = document.createElement("section"); viewport.className = "home-screen-viewport"; viewport.setAttribute("aria-label", "主屏页面");
    // 静态 Registry 与运行时 viewport 都不得在正式布局 hydrate 前参与首帧绘制。
    viewport.hidden = true;
    const track = document.createElement("div"); track.className = "home-page-track"; viewport.append(track);
    const indicator = document.createElement("div"); indicator.className = "home-page-indicator"; indicator.setAttribute("aria-hidden", "true"); viewport.append(indicator);
    const editBar = document.createElement("div"); editBar.className = "home-edit-bar"; editBar.hidden = true;
    const editActions = document.createElement("div"); editActions.className = "home-edit-actions";
    const makeEditIconAction = (action, label, iconName) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "home-edit-icon-action";
      button.dataset.homeAction = action;
      button.setAttribute("aria-label", label);
      button.title = label;
      const icon = window.QWQSystemUI?.createIcon?.({ provider: "fontawesome", family: "classic", style: "solid", name: iconName, format: "inline-svg" });
      if (icon) button.append(icon);
      return button;
    };
    editActions.append(
      makeEditIconAction("add", "添加", "plus"),
      makeEditIconAction("restore", "还原默认布局", "rotate-left")
    );
    const done = document.createElement("button"); done.type = "button"; done.className = "home-edit-done"; done.dataset.homeAction = "done"; done.textContent = "完成";
    editBar.append(editActions, done);
    // top-grid 是 Registry 的启动锚点；编辑栏先插到该节点前，再由正式 viewport 原位接管。
    root.insertBefore(editBar, top);
    top.replaceWith(viewport);
    // Registry 提取完成后立即销毁静态默认 Dock 子节点；异步 hydrate 期间 DOM 中不保留第二套可渲染布局。
    dockGrid.replaceChildren();
    const dragLayer = document.createElement("div"); dragLayer.className = "home-drag-layer"; dragLayer.setAttribute("aria-hidden", "true"); root.append(dragLayer);
    HOME.refs = { root, viewport, track, indicator, dock, dockGrid, editBar, dragLayer };
  }

  async function hydrate() {
    // 主题正式态先完成 hydrate；这样运行时图标在创建时一次到位，不再靠渲染后全局刷新修补。
    if (window.ThemeCustomization?.ready) await window.ThemeCustomization.ready;
    else await window.ThemeCustomization?.databaseReady;
    const db = window.ThemeCustomization?.db;
    const table = db?.homeScreenState;
    const metaTable = db?.persistenceMeta;
    if (!table) throw new Error("homeScreenState 数据表不存在");
    if (!metaTable) throw new Error("persistenceMeta 数据表不存在");
    const [record, weatherMigrationMarker] = await Promise.all([
      table.get("active"),
      metaTable.get(WEATHER_VISIBILITY_MIGRATION_KEY)
    ]);
    let state;
    if (record?.value && typeof record.value === "object") state = normalizeHomeLayout(record.value, HOME.registry);
    else state = makeDefaultLayout();
    state = addNewRegistryApps(state);
    const weatherMigration = prepareWeatherVisibilityMigration(state, weatherMigrationMarker);
    state = weatherMigration.state;
    HOME.layout = state; HOME.preview = null; HOME.hydrated = true;
    // 同一个同步任务内先解除启动隐藏，再立刻用 Dexie 正式态重建 DOM；浏览器没有机会绘制静态/默认排列。
    HOME.refs.viewport.hidden = false;
    HOME.refs.dock.hidden = false;
    render();
    // paint gate 仍处于关闭状态：先把壁纸、自定义图标和所有组件 Blob URL 解码完成，
    // 再允许 bootstrap 解除 body visibility，刷新时不会先看到空图片容器/占位背景。
    await Promise.all([
      window.QWQLifecycle?.waitForLocalRenderImages?.(HOME.refs.root) || Promise.resolve(true),
      waitForTrackedWidgetMedia()
    ]);
    // hydrate 完成后把 normalize / 新 App 合并结果一次性收口回正式 active 记录。
    await persistNow();
    // migration marker 只有在“布局状态 + 实际 DOM”都确认存在天气 App 后才允许提交。
    // 如果发生混合版本、Registry 缺失或渲染失败，本次绝不宣告迁移完成，下次启动继续重试。
    await finalizeWeatherVisibilityMigration(weatherMigration);
  }

  async function persistNow({ preserveEmptyPages = HOME.editMode } = {}) {
    if (!HOME.hydrated || !HOME.layout) return false;
    window.clearTimeout(HOME.saveTimer); HOME.saveTimer = 0;
    const value = normalizeHomeLayout(HOME.layout, HOME.registry, { compactPages: !preserveEmptyPages });
    HOME.layout = value;
    try {
      await window.ThemeCustomization.db.homeScreenState.put({ key: "active", schemaVersion: SCHEMA_VERSION, value: clone(value), updatedAt: Date.now() });
      HOME.dirty = false;
      return true;
    } catch (error) {
      // 写入失败必须保留 dirty，下一次显式保存/生命周期 flush 仍可继续提交。
      HOME.dirty = true;
      throw error;
    }
  }
  function schedulePersist(delay = 140) {
    if (!HOME.hydrated) return;
    HOME.dirty = true;
    window.clearTimeout(HOME.saveTimer);
    HOME.saveTimer = window.setTimeout(() => persistNow().catch((error) => console.error("home layout save failed", error)), delay);
  }

  function setEditMode(enabled) {
    const next = Boolean(enabled);
    if (HOME.editMode === next) return;
    HOME.editMode = next;
    if (!next) {
      HOME.refs?.root?.querySelector?.('[data-home-inline-editing="true"]')?.blur?.();
      interruptInteraction(false);
      compactEmptyPages(HOME.layout);
      render({ committed: false });
      schedulePersist(0);
      return;
    }
    renderEditUi();
  }

  function updateGeometry() {
    if (!HOME.refs.viewport?.isConnected) return;
    const state = currentState();
    const pageIndex = state?.currentPageIndex || 0;
    const viewportRect = HOME.refs.viewport.getBoundingClientRect();
    const dockRect = HOME.refs.dock.getBoundingClientRect();
    const pageNode = HOME.refs.track.querySelector(`.home-page[data-page-index="${pageIndex}"]`);
    const gridNode = pageNode?.querySelector(":scope > .home-page-grid");
    const gridRect = gridNode?.getBoundingClientRect() || pageNode?.getBoundingClientRect() || viewportRect;
    const style = gridNode ? getComputedStyle(gridNode) : null;
    const columnGap = Math.max(0, Number.parseFloat(style?.columnGap || style?.gap || "0") || 0);
    const rowGap = Math.max(0, Number.parseFloat(style?.rowGap || style?.gap || "0") || 0);
    const paddingLeft = Math.max(0, Number.parseFloat(style?.paddingLeft || "0") || 0);
    const paddingRight = Math.max(0, Number.parseFloat(style?.paddingRight || "0") || 0);
    const paddingTop = Math.max(0, Number.parseFloat(style?.paddingTop || "0") || 0);
    // viewport 只负责扩大真实显示窗口；4×6 坐标只读取内部 grid 的原内容矩形。
    // 两套几何禁止互相反推，避免进入移动布局后发生整体位移。
    const contentWidth = Math.max(1, (gridNode?.clientWidth || gridRect.width) - paddingLeft - paddingRight);
    const cellWidth = Math.max(1, (contentWidth - columnGap * (GRID.columns - 1)) / GRID.columns);
    HOME.refs.root.style.setProperty("--home-grid-cell", `${cellWidth}px`);
    const resolvedStyle = gridNode ? getComputedStyle(gridNode) : style;
    const firstResolvedRow = String(resolvedStyle?.gridTemplateRows || "").trim().split(/\s+/)[0];
    const cellHeight = Math.max(1, Number.parseFloat(firstResolvedRow) || cellWidth);
    HOME.refs.root.style.setProperty("--home-grid-row-px", `${cellHeight}px`);
    HOME.geometry = {
      viewportRect, dockRect, pageRect: gridRect, pageNode, gridNode, columnGap, rowGap, paddingLeft, paddingRight, paddingTop,
      gridOriginLeft: gridRect.left + paddingLeft,
      gridOriginTop: gridRect.top + paddingTop,
      cellWidth, cellHeight,
      columnStep: cellWidth + columnGap, rowStep: cellHeight + rowGap
    };
  }

  function pointerToGrid(clientX, clientY, item, pageIndex = currentState().currentPageIndex) {
    if (!HOME.geometry || HOME.geometry.pageNode?.dataset.pageIndex !== String(pageIndex)) updateGeometry();
    // 使用拖拽抓取点换算原项目左上角，而不是直接拿手指中心落格；大 Widget 不再跳位。
    const ghostLeft = clientX - (HOME.drag?.offsetX || 0);
    const ghostTop = clientY - (HOME.drag?.offsetY || 0);
    // 候选格原点必须从真实 grid content box 起算；首行安全留白只影响视觉，不得把拖拽坐标整体错开一格。
    const localX = ghostLeft - HOME.geometry.gridOriginLeft;
    const localY = ghostTop - HOME.geometry.gridOriginTop + (HOME.geometry.pageNode?.scrollTop || 0);
    const x = clamp(Math.round(localX / Math.max(1, HOME.geometry.columnStep)), 0, GRID.columns - item.width);
    const y = clamp(Math.round(localY / Math.max(1, HOME.geometry.rowStep)), 0, GRID.rows - item.height);
    return { pageIndex, gridX: x, gridY: y, width: item.width, height: item.height };
  }


  function solveDesktopPlacement(sourceState, draggedId, candidate, movingOverride = null) {
    const state = clone(sourceState);
    let moving = state.desktopItems.find((item) => item.id === draggedId);
    if (!moving && movingOverride) {
      moving = { ...clone(movingOverride), id: draggedId };
      state.desktopItems.push(moving);
    }
    if (!moving) return null;

    const target = {
      pageIndex: Math.max(0, int(candidate?.pageIndex, 0)),
      gridX: int(candidate?.gridX, 0),
      gridY: int(candidate?.gridY, 0),
      width: moving.width,
      height: moving.height
    };
    if (!isWithinGrid(target)) return null;

    const origin = {
      pageIndex: int(moving.pageIndex, -1),
      gridX: int(moving.gridX, -99),
      gridY: int(moving.gridY, -99),
      width: moving.width,
      height: moving.height
    };
    const records = state.desktopItems.map((item) => ({ id: item.id, width: item.width, height: item.height }));
    const spots = new Map(state.desktopItems.map((item) => [item.id, {
      pageIndex: int(item.pageIndex, -1), gridX: int(item.gridX, -99), gridY: int(item.gridY, -99)
    }]));

    const rectAt = (spot, record) => ({
      left: spot.gridX, top: spot.gridY,
      right: spot.gridX + record.width, bottom: spot.gridY + record.height
    });
    const validSpot = (spot, record) => isWithinGrid({ ...spot, width: record.width, height: record.height });
    const intersections = (recordId, spot, record) => records.filter((other) => {
      if (other.id === recordId) return false;
      const otherSpot = spots.get(other.id);
      return otherSpot && otherSpot.pageIndex === spot.pageIndex
        && rectsOverlap(rectAt(spot, record), rectAt(otherSpot, other));
    }).sort((a, b) => {
      const as = spots.get(a.id), bs = spots.get(b.id);
      return as.pageIndex - bs.pageIndex || as.gridY - bs.gridY || as.gridX - bs.gridX || a.id.localeCompare(b.id);
    });

    spots.set(draggedId, { pageIndex: target.pageIndex, gridX: target.gridX, gridY: target.gridY });
    const movingRecord = records.find((record) => record.id === draggedId);
    const initialHits = intersections(draggedId, spots.get(draggedId), movingRecord);
    const initialHitIds = new Set(initialHits.map((record) => record.id));
    const isCrossPageMove = origin.pageIndex >= 0 && origin.pageIndex !== target.pageIndex;

    // 仅同页允许“覆盖对象回填拖拽物原占区”的交换语义。
    // 跨页拖动必须保留源页空位：目标页对象只在目标页/其它非源页寻找新位置，禁止交换回源页。
    // 吸收用户自有虚拟小手机的核心规则：先尝试把“真正被覆盖的对象”整体塞回拖拽物原占区。
    // 这样 2×2 Widget 覆盖多个 1×1 App 时，只交换这一条碰撞链，不会牵连整页重新压实。
    const tryOriginExchange = () => {
      if (isCrossPageMove || !initialHits.length || !isWithinGrid(origin)) return false;
      const movingTarget = { pageIndex: target.pageIndex, gridX: target.gridX, gridY: target.gridY };
      const movingTargetRect = rectAt(movingTarget, movingRecord);
      const fixedRecords = records.filter((record) => record.id !== draggedId && !initialHitIds.has(record.id));
      const orderedVictims = [...initialHits].sort((a, b) => {
        const areaA = a.width * a.height, areaB = b.width * b.height;
        return areaB - areaA || b.height - a.height || b.width - a.width || a.id.localeCompare(b.id);
      });
      const assigned = new Map();

      const candidatesInsideOrigin = (victim) => {
        const maxX = origin.gridX + movingRecord.width - victim.width;
        const maxY = origin.gridY + movingRecord.height - victim.height;
        if (maxX < origin.gridX || maxY < origin.gridY) return [];
        const victimSpot = spots.get(victim.id);
        const preferred = {
          gridX: origin.gridX + (victimSpot.gridX - target.gridX),
          gridY: origin.gridY + (victimSpot.gridY - target.gridY)
        };
        const list = [];
        for (let y = origin.gridY; y <= maxY; y += 1) for (let x = origin.gridX; x <= maxX; x += 1) {
          const spot = { pageIndex: origin.pageIndex, gridX: x, gridY: y };
          if (validSpot(spot, victim)) list.push(spot);
        }
        return list.sort((a, b) => {
          const da = Math.abs(a.gridX - preferred.gridX) + Math.abs(a.gridY - preferred.gridY);
          const db = Math.abs(b.gridX - preferred.gridX) + Math.abs(b.gridY - preferred.gridY);
          return da - db || a.gridY - b.gridY || a.gridX - b.gridX;
        });
      };

      const blocked = (victim, candidate) => {
        const rect = rectAt(candidate, victim);
        if (candidate.pageIndex === movingTarget.pageIndex && rectsOverlap(rect, movingTargetRect)) return true;
        for (const other of fixedRecords) {
          const otherSpot = spots.get(other.id);
          if (otherSpot?.pageIndex === candidate.pageIndex && rectsOverlap(rect, rectAt(otherSpot, other))) return true;
        }
        for (const other of orderedVictims) {
          const placed = assigned.get(other.id);
          if (placed?.pageIndex === candidate.pageIndex && rectsOverlap(rect, rectAt(placed, other))) return true;
        }
        return false;
      };

      const placeVictim = (index) => {
        if (index >= orderedVictims.length) return true;
        const victim = orderedVictims[index];
        for (const candidate of candidatesInsideOrigin(victim)) {
          if (blocked(victim, candidate)) continue;
          assigned.set(victim.id, candidate);
          if (placeVictim(index + 1)) return true;
          assigned.delete(victim.id);
        }
        return false;
      };

      if (!placeVictim(0)) return false;
      spots.set(draggedId, movingTarget);
      assigned.forEach((spot, id) => spots.set(id, { ...spot }));
      return true;
    };

    if (tryOriginExchange()) {
      const maxPage = Math.max(target.pageIndex, origin.pageIndex, ...Array.from(spots.values()).map((spot) => Math.max(0, spot.pageIndex)));
      for (const item of state.desktopItems) Object.assign(item, spots.get(item.id));
      ensurePages(state, maxPage, { preserveExisting: true });
      state.currentPageIndex = target.pageIndex;
      return state;
    }

    let operations = 0;
    const operationLimit = Math.max(640, records.length * GRID.columns * GRID.rows * 36);
    const maxSearchPage = Math.max(state.pages.length + records.length + 2, target.pageIndex + 2);
    const undo = [];
    const setSpot = (id, next) => { undo.push([id, { ...spots.get(id) }]); spots.set(id, { ...next }); };
    const rollback = (checkpoint) => { while (undo.length > checkpoint) { const [id, previous] = undo.pop(); spots.set(id, previous); } };

    const pageCandidates = (record, pageIndex, anchor = null) => {
      const list = [];
      for (let y = 0; y <= GRID.rows - record.height; y += 1) {
        for (let x = 0; x <= GRID.columns - record.width; x += 1) list.push({ pageIndex, gridX: x, gridY: y });
      }
      if (anchor?.pageIndex === pageIndex) {
        list.sort((a, b) => {
          const da = Math.abs(a.gridX - anchor.gridX) + Math.abs(a.gridY - anchor.gridY);
          const db = Math.abs(b.gridX - anchor.gridX) + Math.abs(b.gridY - anchor.gridY);
          return da - db || a.gridY - b.gridY || a.gridX - b.gridX;
        });
      }
      return list;
    };

    const relocationCandidates = (record, startSpot) => {
      const result = [];
      const seen = new Set();
      const push = (spot) => {
        const key = `${spot.pageIndex}:${spot.gridX}:${spot.gridY}`;
        if (!seen.has(key) && validSpot(spot, record)) { seen.add(key); result.push(spot); }
      };

      // 只有同页移动才允许初始被覆盖对象优先回填拖拽物原占区。
      // 跨页移动若也执行这一步，就会形成用户看到的“跨页互换”。
      if (!isCrossPageMove && initialHitIds.has(record.id) && isWithinGrid(origin)) {
        const maxX = origin.gridX + movingRecord.width - record.width;
        const maxY = origin.gridY + movingRecord.height - record.height;
        if (maxX >= origin.gridX && maxY >= origin.gridY) {
          const preferred = {
            gridX: origin.gridX + (startSpot.gridX - target.gridX),
            gridY: origin.gridY + (startSpot.gridY - target.gridY)
          };
          const originList = [];
          for (let y = origin.gridY; y <= maxY; y += 1) for (let x = origin.gridX; x <= maxX; x += 1) originList.push({ pageIndex: origin.pageIndex, gridX: x, gridY: y });
          originList.sort((a, b) => {
            const da = Math.abs(a.gridX - preferred.gridX) + Math.abs(a.gridY - preferred.gridY);
            const db = Math.abs(b.gridX - preferred.gridX) + Math.abs(b.gridY - preferred.gridY);
            return da - db || a.gridY - b.gridY || a.gridX - b.gridX;
          });
          originList.forEach(push);
        }
      }

      const pages = [];
      const startPage = Math.max(0, int(startSpot.pageIndex, target.pageIndex));
      const pushPage = (page) => {
        if (isCrossPageMove && page === origin.pageIndex) return;
        if (!pages.includes(page)) pages.push(page);
      };
      pushPage(startPage);
      for (let page = startPage + 1; page < state.pages.length; page += 1) pushPage(page);
      for (let page = 0; page < startPage && page < state.pages.length; page += 1) pushPage(page);
      for (let page = state.pages.length; page < maxSearchPage; page += 1) pushPage(page);
      for (const pageIndex of pages) {
        for (const spot of pageCandidates(record, pageIndex, pageIndex === startPage ? startSpot : null)) push(spot);
      }
      return result;
    };

    const relocate = (record, startSpot, locked) => {
      if (locked.has(record.id) || locked.size >= SAFE_COLLISION_LIMIT) return false;
      const nextLocked = new Set(locked); nextLocked.add(record.id);
      for (const next of relocationCandidates(record, startSpot)) {
        operations += 1;
        if (operations > operationLimit) return false;
        const hits = intersections(record.id, next, record);
        if (hits.some((hit) => nextLocked.has(hit.id))) continue;
        const checkpoint = undo.length;
        setSpot(record.id, next);
        let ok = true;
        for (const hit of hits) {
          if (!relocate(hit, { ...spots.get(hit.id) }, nextLocked)) { ok = false; break; }
        }
        if (ok) return true;
        rollback(checkpoint);
      }
      return false;
    };

    for (const victim of initialHits) {
      const current = spots.get(victim.id);
      if (!rectsOverlap(rectAt(current, victim), rectAt(spots.get(draggedId), movingRecord))) continue;
      if (!relocate(victim, { ...current }, new Set([draggedId]))) return null;
    }

    for (const record of records) {
      const spot = spots.get(record.id);
      if (!validSpot(spot, record) || intersections(record.id, spot, record).length) return null;
    }

    const maxPage = Math.max(target.pageIndex, ...Array.from(spots.values()).map((spot) => Math.max(0, spot.pageIndex)));
    for (const item of state.desktopItems) Object.assign(item, spots.get(item.id));
    ensurePages(state, maxPage, { preserveExisting: true });
    state.currentPageIndex = target.pageIndex;
    return state;
  }

  function resolveAppInsert(sourceState, draggedId, candidate) {
    const item = sourceState.desktopItems.find((row) => row.id === draggedId);
    if (!item || item.kind !== "app") return null;
    return solveDesktopPlacement(sourceState, draggedId, candidate);
  }

  function resolveWidgetPlacement(sourceState, draggedId, candidate) {
    const item = sourceState.desktopItems.find((row) => row.id === draggedId);
    if (!item || item.kind !== "widget") return null;
    return solveDesktopPlacement(sourceState, draggedId, candidate);
  }

  function startDrag(sourceEl, contact, sourceType = "desktop") {
    if (HOME.drag || !sourceEl || !contact) return false;
    const state = HOME.layout;
    let item = null;
    let dockAppId = null;
    if (sourceType === "dock") dockAppId = sourceEl.dataset.dockAppId;
    else item = state.desktopItems.find((row) => row.id === sourceEl.dataset.itemId);
    if (!item && !dockAppId) return false;

    setEditMode(true);
    updateGeometry();
    const rect = sourceEl.getBoundingClientRect();
    // Dock 使用 fit-content：真实节点被提升到 fixed 层前，先保留一个纯几何占位槽。
    // 占位不复制图标内容，只维持原列数，因此不会出现长按瞬间外壳缩短/其余 App 横移。
    let dockPlaceholder = null;
    if (sourceType === "dock") {
      dockPlaceholder = document.createElement("span");
      dockPlaceholder.className = "home-dock-drag-placeholder";
      dockPlaceholder.setAttribute("aria-hidden", "true");
      sourceEl.before(dockPlaceholder);
    }
    // 不再 cloneNode。拖动时直接把当前真实项目提升到 drag layer，
    // 整个拖拽会话始终只有一个可见实例。
    sourceEl.classList.add("is-drag-source", "home-drag-direct");
    sourceEl.style.width = `${rect.width}px`;
    sourceEl.style.height = `${rect.height}px`;
    HOME.refs.dragLayer.replaceChildren(sourceEl);
    HOME.refs.dragLayer.classList.add("is-active");

    HOME.drag = {
      pointerId: contact.id,
      inputType: contact.inputType || "touch",
      captureTarget: contact.captureTarget || null,
      sourceEl,
      sourceType,
      itemId: item?.id || null,
      appId: item?.appId || dockAppId,
      offsetX: contact.clientX - rect.left,
      offsetY: contact.clientY - rect.top,
      clientX: contact.clientX,
      clientY: contact.clientY,
      moved: false,
      edgeDirection: 0,
      originRect: { left: rect.left, top: rect.top, width: rect.width, height: rect.height },
      dockPlaceholder,
      original: clone(state)
    };

    if (HOME.drag.inputType === "mouse" && HOME.drag.captureTarget?.setPointerCapture) {
      try { HOME.drag.captureTarget.setPointerCapture(contact.id); } catch (_) {}
    }
    moveDraggedSource(contact.clientX, contact.clientY);
    updateDragContact(contact.clientX, contact.clientY, contact.id);
    return true;
  }

  function moveDraggedSource(clientX, clientY) {
    const source = HOME.drag?.sourceEl;
    if (!source || !HOME.drag) return;
    source.style.transform = `translate3d(${clientX - HOME.drag.offsetX}px, ${clientY - HOME.drag.offsetY}px, 0) scale(1.018)`;
  }

  function clearInvalidPreview() {
    window.clearTimeout(HOME.candidateTimer);
    HOME.candidateTimer = 0;
    HOME.lastCandidateKey = "";
    if (HOME.preview) {
      HOME.preview = null;
      render({ committed: false });
      updateGeometry();
    }
  }

  function dockOrderFromPoint(clientX) {
    const drag = HOME.drag;
    if (!drag?.appId || !HOME.geometry) return null;
    const existingSelf = HOME.layout.dockItems.some((row) => row.appId === drag.appId);
    const others = HOME.layout.dockItems.filter((row) => row.appId !== drag.appId).sort((a, b) => a.order - b.order);
    if (!existingSelf && others.length >= GRID.dockCapacity) return null;
    const rect = HOME.geometry.dockRect;
    const targetCount = Math.min(GRID.dockCapacity, others.length + 1);
    const ratio = clamp((clientX - rect.left) / Math.max(1, rect.width), 0, .999999);
    return clamp(Math.floor(ratio * Math.max(1, targetCount)), 0, Math.max(0, targetCount - 1));
  }

  // 松手提交不能依赖 145ms Preview dwell。Preview 只服务“拖动时其它项目让位”，
  // 最终落点必须直接按松手坐标同步解析为合法 Dock 槽位或 4×6 网格。
  function resolveFinalDropTarget(clientX, clientY) {
    const drag = HOME.drag;
    if (!drag) return null;
    if (!HOME.geometry) updateGeometry();
    if (!HOME.geometry) return null;

    const dockRect = HOME.geometry.dockRect;
    const overDock = clientX >= dockRect.left - 10 && clientX <= dockRect.right + 10
      && clientY >= dockRect.top - 12 && clientY <= dockRect.bottom + 12;
    if (overDock) {
      if (!drag.appId) return null;
      const order = dockOrderFromPoint(clientX);
      return order === null ? null : { type: "dock", order };
    }

    const viewportRect = HOME.geometry.viewportRect;
    if (clientY < viewportRect.top || clientY > viewportRect.bottom) return null;

    let item = drag.itemId ? HOME.layout.desktopItems.find((row) => row.id === drag.itemId) : null;
    if (!item && drag.sourceType === "dock") item = { kind: "app", appId: drag.appId, width: 1, height: 1 };
    if (!item) return null;

    const pageIndex = currentState().currentPageIndex;
    if (!HOME.geometry || HOME.geometry.pageNode?.dataset.pageIndex !== String(pageIndex)) updateGeometry();
    return { type: "desktop", candidate: pointerToGrid(clientX, clientY, item, pageIndex) };
  }

  function cancelDragMoveFrame() {
    if (HOME.dragMoveRaf) cancelAnimationFrame(HOME.dragMoveRaf);
    HOME.dragMoveRaf = 0;
    HOME.pendingDragMove = null;
  }

  function flushDragMoveFrame() {
    if (!HOME.pendingDragMove) return;
    if (HOME.dragMoveRaf) cancelAnimationFrame(HOME.dragMoveRaf);
    HOME.dragMoveRaf = 0;
    const pending = HOME.pendingDragMove;
    HOME.pendingDragMove = null;
    updateDragContact(pending.clientX, pending.clientY, pending.contactId);
  }

  function scheduleDragContact(clientX, clientY, contactId) {
    HOME.pendingDragMove = { clientX, clientY, contactId };
    if (HOME.dragMoveRaf) return;
    HOME.dragMoveRaf = requestAnimationFrame(() => {
      HOME.dragMoveRaf = 0;
      const pending = HOME.pendingDragMove;
      HOME.pendingDragMove = null;
      if (pending) updateDragContact(pending.clientX, pending.clientY, pending.contactId);
    });
  }

  function scheduleSwipePaint(offset) {
    HOME.pendingSwipeOffset = offset;
    if (HOME.swipeRaf) return;
    HOME.swipeRaf = requestAnimationFrame(() => {
      HOME.swipeRaf = 0;
      const value = HOME.pendingSwipeOffset;
      HOME.pendingSwipeOffset = null;
      if (value === null || !HOME.refs.track) return;
      HOME.refs.track.style.setProperty("--home-swipe-offset", `${value}px`);
    });
  }

  function cancelSwipePaint() {
    if (HOME.swipeRaf) cancelAnimationFrame(HOME.swipeRaf);
    HOME.swipeRaf = 0;
    HOME.pendingSwipeOffset = null;
  }

  function updateDragContact(clientX, clientY, contactId) {
    const drag = HOME.drag;
    if (!drag || drag.pointerId !== contactId) return;
    drag.clientX = clientX;
    drag.clientY = clientY;
    drag.moved = true;
    moveDraggedSource(clientX, clientY);
    if (!HOME.geometry) updateGeometry();

    const dockRect = HOME.geometry.dockRect;
    const overDock = clientX >= dockRect.left - 10 && clientX <= dockRect.right + 10
      && clientY >= dockRect.top - 12 && clientY <= dockRect.bottom + 12;
    if (overDock) {
      window.clearTimeout(HOME.edgeTimer);
      HOME.edgeTimer = 0;
      drag.edgeDirection = 0;
      if (!drag.appId) { clearInvalidPreview(); return; }
      const order = dockOrderFromPoint(clientX);
      if (order === null) { clearInvalidPreview(); return; }
      scheduleCandidate({ type: "dock", order });
      return;
    }

    updateEdgeDwell(clientX, clientY);
    const viewportRect = HOME.geometry.viewportRect;
    if (clientY < viewportRect.top || clientY > viewportRect.bottom) {
      clearInvalidPreview();
      return;
    }
    let item = drag.itemId ? HOME.layout.desktopItems.find((row) => row.id === drag.itemId) : null;
    if (!item && drag.sourceType === "dock") item = { kind: "app", appId: drag.appId, width: 1, height: 1 };
    if (!item) return;
    const candidate = pointerToGrid(clientX, clientY, item, currentState().currentPageIndex);
    scheduleCandidate({ type: "desktop", candidate });
  }

  function scheduleCandidate(candidate) {
    const key = JSON.stringify(candidate);
    if (key === HOME.lastCandidateKey) return;
    HOME.lastCandidateKey = key;
    window.clearTimeout(HOME.candidateTimer);
    HOME.candidateTimer = window.setTimeout(() => {
      if (!HOME.drag || HOME.lastCandidateKey !== key) return;
      applyDragCandidate(candidate);
    }, PREVIEW_DWELL_MS);
  }

  function applyDragCandidate(target) {
    const drag = HOME.drag;
    if (!drag) return;
    if (target.type === "dock") {
      if (!drag.appId) return;
      const preview = clone(HOME.layout);
      const existingIndex = preview.dockItems.findIndex((row) => row.appId === drag.appId);
      const capacityWithoutSelf = preview.dockItems.length - (existingIndex >= 0 ? 1 : 0);
      if (capacityWithoutSelf >= GRID.dockCapacity) { clearInvalidPreview(); return; }
      preview.desktopItems = preview.desktopItems.filter((item) => !(item.kind === "app" && item.appId === drag.appId));
      preview.dockItems = preview.dockItems.filter((row) => row.appId !== drag.appId);
      preview.dockItems.splice(clamp(target.order, 0, preview.dockItems.length), 0, { appId: drag.appId, order: 0 });
      preview.dockItems.forEach((row, index) => { row.order = index; });
      HOME.preview = preview;
      render({ committed: false });
      return;
    }

    if (drag.sourceType === "dock") {
      const base = clone(HOME.layout);
      base.dockItems = base.dockItems.filter((row) => row.appId !== drag.appId).map((row, index) => ({ ...row, order: index }));
      const fakeId = `desktop-app-${drag.appId}`;
      const preview = solveDesktopPlacement(base, fakeId, target.candidate, {
        id: fakeId,
        kind: "app",
        appId: drag.appId,
        pageIndex: -1,
        gridX: -99,
        gridY: -99,
        width: 1,
        height: 1
      });
      if (!preview) { clearInvalidPreview(); return; }
      HOME.preview = preview;
      render({ committed: false });
      return;
    }

    const item = HOME.layout.desktopItems.find((row) => row.id === drag.itemId);
    if (!item) return;
    const preview = solveDesktopPlacement(HOME.layout, item.id, target.candidate);
    if (!preview) { clearInvalidPreview(); return; }
    HOME.preview = preview;
    render({ committed: false });
  }

  function updateEdgeDwell(clientX, clientY) {
    if (!HOME.drag || !HOME.geometry) return;
    const rect = HOME.geometry.viewportRect;
    if (performance.now() < HOME.edgeCooldownUntil) {
      window.clearTimeout(HOME.edgeTimer);
      HOME.edgeTimer = 0;
      HOME.drag.edgeDirection = 0;
      return;
    }
    if (clientY < rect.top || clientY > rect.bottom) {
      window.clearTimeout(HOME.edgeTimer);
      HOME.edgeTimer = 0;
      HOME.drag.edgeDirection = 0;
      return;
    }
    let direction = 0;
    if (clientX <= rect.left + EDGE_ZONE_PX) direction = -1;
    else if (clientX >= rect.right - EDGE_ZONE_PX) direction = 1;
    if (!direction) {
      window.clearTimeout(HOME.edgeTimer);
      HOME.edgeTimer = 0;
      HOME.drag.edgeDirection = 0;
      return;
    }
    if (HOME.drag.edgeDirection === direction && HOME.edgeTimer) return;
    HOME.drag.edgeDirection = direction;
    window.clearTimeout(HOME.edgeTimer);
    HOME.edgeTimer = window.setTimeout(() => {
      if (!HOME.drag || HOME.drag.edgeDirection !== direction) return;
      const state = HOME.preview || HOME.layout;
      const maxAllowed = getLastOccupiedPage(state) + 1;
      const next = clamp(state.currentPageIndex + direction, 0, maxAllowed);
      if (next === state.currentPageIndex) {
        HOME.edgeTimer = 0;
        HOME.drag.edgeDirection = 0;
        return;
      }
      const nextState = clone(state);
      ensurePages(nextState, Math.max(getLastOccupiedPage(nextState), next));
      nextState.currentPageIndex = next;
      HOME.preview = nextState;
      render({ committed: false });
      HOME.lastCandidateKey = "";
      HOME.edgeTimer = 0;
      HOME.drag.edgeDirection = 0;
      HOME.edgeCooldownUntil = performance.now() + EDGE_REPEAT_COOLDOWN_MS;
      // 跨页采用“窄边缘 + 长停留 + 翻页后冷却”，避免手指靠近边缘时连续误翻。
      // 先让 Page Track 完成大部分切页动画，再按新页真实 rect 重新命中，避免读取动画中的中间坐标。
      // 不能在 transform 动画刚启动时读取目标页 rect，否则跨页后候选格会偏一个屏幕宽。
      window.setTimeout(() => {
        if (!HOME.drag || currentState().currentPageIndex !== next) return;
        updateGeometry();
        updateDragContact(HOME.drag.clientX, HOME.drag.clientY, HOME.drag.pointerId);
      }, 230);
    }, EDGE_DWELL_MS);
  }

  async function animateInvalidDropBack(drag) {
    const source = drag?.sourceEl;
    const rect = drag?.originRect;
    if (!source || !rect || !source.isConnected || typeof source.animate !== "function") return;
    try {
      const animation = source.animate([
        { transform: source.style.transform, opacity: 1 },
        { transform: `translate3d(${rect.left}px, ${rect.top}px, 0) scale(1)`, opacity: .94 }
      ], { duration: 145, easing: "cubic-bezier(.2,.8,.2,1)", fill: "forwards" });
      await animation.finished;
    } catch (_) {}
  }

  function disposeDirectDragSource(drag) {
    const source = drag?.sourceEl;
    drag?.dockPlaceholder?.remove?.();
    if (!source) return;
    source.classList.remove("is-drag-source", "home-drag-direct");
    source.style.removeProperty("width");
    source.style.removeProperty("height");
    source.style.removeProperty("transform");
    // 正式 DOM 由 committed/preview state 重新归位；先移除拖动层中的原节点，
    // 防止它和最终位置节点同时存在。这里不是克隆，只是结束一次 DOM 提升。
    if (source.parentElement === HOME.refs.dragLayer) source.remove();
  }

  async function finishDrag(contactId = null, cancelled = false) {
    const drag = HOME.drag;
    if (!drag || drag.finishing || (contactId !== null && drag.pointerId !== contactId)) return;
    // document capture 与 root bubbling 可能同时观察到同一次结束；只允许一个结束事务。
    drag.finishing = true;

    flushDragMoveFrame();
    cancelDragMoveFrame();

    // 先按“最后一个真实接触点”同步计算最终落点，再销毁 dwell/edge 定时器。
    // 这样即使用户在 Preview dwell 触发前就松手，也不会把 fixed 拖拽 DOM 留在任意像素位置。
    const finalTarget = cancelled ? null : resolveFinalDropTarget(drag.clientX, drag.clientY);

    window.clearTimeout(HOME.edgeTimer);
    window.clearTimeout(HOME.candidateTimer);
    HOME.edgeTimer = 0;
    HOME.edgeCooldownUntil = 0;
    HOME.candidateTimer = 0;
    HOME.lastCandidateKey = "";

    if (drag.inputType === "mouse" && drag.captureTarget?.hasPointerCapture?.(drag.pointerId)) {
      try { drag.captureTarget.releasePointerCapture(drag.pointerId); } catch (_) {}
    }

    // 丢弃可能停留在上一个格子的旧 Preview，只允许“松手坐标”成为最终提交来源。
    HOME.preview = null;
    if (finalTarget) applyDragCandidate(finalTarget);

    let shouldPersist = false;
    if (!cancelled && HOME.preview) {
      HOME.layout = normalizeHomeLayout(HOME.preview, HOME.registry, { compactPages: !HOME.editMode });
      HOME.preview = null;
      shouldPersist = true;
    } else {
      HOME.preview = null;
      if (!cancelled) await animateInvalidDropBack(drag);
    }

    HOME.clickSuppressUntil = performance.now() + 360;
    disposeDirectDragSource(drag);
    HOME.refs.dragLayer.replaceChildren();
    HOME.refs.dragLayer.classList.remove("is-active");
    HOME.drag = null;
    HOME.lastCandidateKey = "";
    render({ committed: false });
    updateGeometry();
    // 视觉网格归位必须在松手事务内完成；IndexedDB 仍退出关键帧异步写入同一 active 记录。
    if (shouldPersist) schedulePersist(0);
  }

  function cancelDrag(rerender = true) {
    const drag = HOME.drag;
    cancelDragMoveFrame();
    window.clearTimeout(HOME.edgeTimer);
    window.clearTimeout(HOME.candidateTimer);
    HOME.edgeTimer = 0;
    HOME.edgeCooldownUntil = 0;
    HOME.candidateTimer = 0;
    if (drag) {
      if (drag.inputType === "mouse" && drag.captureTarget?.hasPointerCapture?.(drag.pointerId)) {
        try { drag.captureTarget.releasePointerCapture(drag.pointerId); } catch (_) {}
      }
      disposeDirectDragSource(drag);
    }
    HOME.preview = null;
    HOME.drag = null;
    HOME.lastCandidateKey = "";
    HOME.refs.dragLayer?.replaceChildren();
    HOME.refs.dragLayer?.classList.remove("is-active");
    if (rerender && HOME.layout) render({ committed: false });
  }

  function changePage(index, animate = true) {
    const state = HOME.layout;
    if (!state) return;
    const next = clamp(int(index, 0), 0, state.pages.length - 1);
    HOME.refs.track.classList.toggle("no-transition", !animate);
    state.currentPageIndex = next;
    HOME.refs.track.style.setProperty("--home-page-index", String(next));
    renderIndicator(state);
    // 页面内容没有变化时禁止触发 syncPreviewDom/FLIP；仅移动 Page Track。
    HOME.geometry = null;
    requestAnimationFrame(() => HOME.refs.track.classList.remove("no-transition"));
    schedulePersist();
  }

  function editableWidgetItemFromTarget(target) {
    const node = target?.closest?.(".home-item[data-item-id]");
    if (!node) return null;
    const instanceId = String(node.dataset.widgetInstanceId || "").trim();
    const item = HOME.layout?.desktopItems?.find?.((row) => row.kind === "widget" && (instanceId ? row.instanceId === instanceId : row.id === node.dataset.itemId)) || null;
    if (!item) return null;
    const widgetType = String(item.widgetType || "");
    if (!isEditableBuiltinWidgetType(widgetType)) return null;
    return item;
  }

  function ensureBuiltinWidgetDataBucket(item, bucketName) {
    if (!item.data || typeof item.data !== "object" || Array.isArray(item.data)) item.data = {};
    const current = item.data[bucketName];
    if (!current || typeof current !== "object" || Array.isArray(current)) item.data[bucketName] = {};
    return item.data[bucketName];
  }

  async function pickBuiltinWidgetImage(target) {
    if (!HOME.editMode || !target) return false;
    const item = editableWidgetItemFromTarget(target);
    const slot = String(target.dataset.homeMediaSlot || "").trim();
    if (!item || !slot) return false;

    const input = document.createElement("input");
    input.type = "file";
    input.accept = window.ThemeCustomization?.imageAccept || "image/jpeg,image/png,image/gif,image/webp";
    input.style.position = "fixed";
    input.style.left = "-9999px";
    input.style.width = "1px";
    input.style.height = "1px";
    input.setAttribute("aria-hidden", "true");
    document.body.append(input);

    input.addEventListener("change", async () => {
      const file = input.files?.[0] || null;
      input.remove();
      if (!file) return;
      try {
        const prepare = window.ThemeCustomization?.prepareImageBlob;
        if (typeof prepare !== "function") throw new Error("图片处理模块未加载");
        const imageBlob = await prepare(file, { maxSide: 2160, quality: .9 });
        const liveItem = HOME.layout?.desktopItems?.find?.((row) => row.instanceId === item.instanceId && row.kind === "widget") || null;
        if (!liveItem) return;

        // 单槽位原子替换统一走系统媒体生命周期：旧帧保持到新图完成 decode，
        // 持久化成功后再把运行时 Blob 身份重绑为稳定槽位身份。
        const objectUrlKey = widgetObjectUrlKey(liveItem.instanceId, "builtin", slot);
        const mediaSlotKey = homeMediaSlot(objectUrlKey);
        const currentItem = HOME.layout?.desktopItems?.find?.((row) => row.instanceId === liveItem.instanceId && row.kind === "widget") || null;
        if (!currentItem) return;
        const mediaBucket = ensureBuiltinWidgetDataBucket(currentItem, "media");
        const hadPreviousMedia = Object.prototype.hasOwnProperty.call(mediaBucket, slot);
        const previousMedia = mediaBucket[slot];
        const liveNode = HOME.refs.track?.querySelector?.(`[data-widget-instance-id="${CSS.escape(currentItem.instanceId)}"] [data-home-media-slot="${CSS.escape(slot)}"]`);
        if (liveNode) {
          const committed = await window.QWQMediaSurface?.setBackground?.(liveNode, mediaSlotKey, imageBlob, { identity:imageBlob, className:"has-user-media", emptyValue:"none" });
          if (committed === false) throw new Error("组件图片无法完成解码");
          liveNode.dataset.homeCustomMediaUrl = window.QWQMediaSurface?.get?.(mediaSlotKey) || "";
        } else {
          const nextUrl = await window.QWQMediaSurface?.prepareBlobSlot?.(mediaSlotKey, imageBlob, imageBlob);
          if (!nextUrl) throw new Error("组件图片无法完成解码");
        }
        mediaBucket[slot] = imageBlob;
        HOME.objectUrls.set(objectUrlKey, { url:window.QWQMediaSurface?.get?.(mediaSlotKey) || "", size:imageBlob.size, type:imageBlob.type || "" });
        try {
          await persistNow();
          window.QWQMediaSurface?.rebind?.(mediaSlotKey, `slot:${objectUrlKey}`);
          HOME.objectUrls.set(objectUrlKey, { url:window.QWQMediaSurface?.get?.(mediaSlotKey) || "", size:imageBlob.size, type:imageBlob.type || "" });
        } catch (error) {
          const rollbackItem = HOME.layout?.desktopItems?.find?.((row) => row.instanceId === currentItem.instanceId && row.kind === "widget") || currentItem;
          const rollbackBucket = ensureBuiltinWidgetDataBucket(rollbackItem, "media");
          if (hadPreviousMedia) rollbackBucket[slot] = previousMedia;
          else delete rollbackBucket[slot];
          if (previousMedia instanceof Blob && previousMedia.size) {
            if (liveNode) {
              await window.QWQMediaSurface?.setBackground?.(liveNode, mediaSlotKey, previousMedia, { identity:previousMedia, className:"has-user-media", emptyValue:"none" });
              liveNode.dataset.homeCustomMediaUrl = window.QWQMediaSurface?.get?.(mediaSlotKey) || "";
            } else {
              await window.QWQMediaSurface?.prepareBlobSlot?.(mediaSlotKey, previousMedia, previousMedia);
            }
            window.QWQMediaSurface?.rebind?.(mediaSlotKey, `slot:${objectUrlKey}`);
            HOME.objectUrls.set(objectUrlKey, { url:window.QWQMediaSurface?.get?.(mediaSlotKey) || "", size:previousMedia.size, type:previousMedia.type || "" });
          } else {
            window.QWQMediaSurface?.release?.(mediaSlotKey);
            HOME.objectUrls.delete(objectUrlKey);
            if (liveNode) { liveNode.style.backgroundImage = "none"; liveNode.classList.remove("has-user-media"); delete liveNode.dataset.homeCustomMediaUrl; }
          }
          throw error;
        }
      } catch (error) {
        console.error("home widget image upload failed", error);
        window.ThemeCustomization?.GlobalModal?.alert?.({
          title: "图片无法使用",
          message: error?.message || "图片处理失败，请换一张图片重试。",
          confirmLabel: "知道了",
          action: "dismiss"
        });
      }
    }, { once: true });
    input.click();
    return true;
  }

  function insertPlainTextAtSelection(text) {
    const selection = window.getSelection?.();
    if (!selection || !selection.rangeCount) return;
    const range = selection.getRangeAt(0);
    range.deleteContents();
    const node = document.createTextNode(text);
    range.insertNode(node);
    range.setStartAfter(node);
    range.collapse(true);
    selection.removeAllRanges();
    selection.addRange(range);
  }

  function normalizeInlineWidgetText(value, { multiline = false } = {}) {
    let next = String(value ?? "").replace(/\r/g, "").replace(/\u00a0/g, " ");
    if (multiline) next = next.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
    else next = next.replace(/\s+/g, " ").trim();
    return next;
  }

  function beginBuiltinWidgetTextEdit(target) {
    if (!HOME.editMode || !target || target.dataset.homeInlineEditing === "true") return false;
    const item = editableWidgetItemFromTarget(target);
    const slot = String(target.dataset.homeTextSlot || "").trim();
    if (!item || !slot) return false;

    const original = String(target.innerText ?? target.textContent ?? "");
    const multiline = target.dataset.homeTextMultiline === "true";
    let cancelled = false;
    target.dataset.homeInlineEditing = "true";
    target.setAttribute("contenteditable", "true");
    target.setAttribute("role", "textbox");
    target.setAttribute("aria-multiline", multiline ? "true" : "false");
    target.spellcheck = true;

    const onKeyDown = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        cancelled = true;
        target.blur();
        return;
      }
      if (event.key === "Enter" && (!multiline || event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        target.blur();
      }
    };
    const onPaste = (event) => {
      event.preventDefault();
      insertPlainTextAtSelection(event.clipboardData?.getData("text/plain") || "");
    };
    const cleanup = () => {
      target.removeEventListener("keydown", onKeyDown);
      target.removeEventListener("paste", onPaste);
      target.removeAttribute("contenteditable");
      target.removeAttribute("role");
      target.removeAttribute("aria-multiline");
      delete target.dataset.homeInlineEditing;
    };
    const commit = () => {
      const value = cancelled ? original : normalizeInlineWidgetText(target.innerText ?? target.textContent ?? "", { multiline });
      target.textContent = value;
      cleanup();
      if (cancelled) return;
      const liveItem = HOME.layout?.desktopItems?.find?.((row) => row.instanceId === item.instanceId && row.kind === "widget") || null;
      if (!liveItem) return;
      ensureBuiltinWidgetDataBucket(liveItem, "text")[slot] = value;
      // 实时组件会缓存“非播放态基线”。用户明确清空为 "" 也是合法值，
      // 提交时必须同步刷新基线，禁止后续 realtime sync 用旧默认文案复活已删除文本。
      target.dataset.homeDefaultText = value;
      schedulePersist(0);
    };

    target.addEventListener("keydown", onKeyDown);
    target.addEventListener("paste", onPaste);
    target.addEventListener("blur", commit, { once: true });

    target.focus({ preventScroll: true });
    const selection = window.getSelection?.();
    if (selection && document.createRange) {
      const range = document.createRange();
      // 进入组件文字编辑时默认全选现有文案；用户直接输入就是“替换”，
      // 不再把新文字追加到旧文字末尾造成定宽组件内视觉重叠。
      range.selectNodeContents(target);
      selection.removeAllRanges();
      selection.addRange(range);
    }
    return true;
  }

  function findGestureSource(target) {
    if (target.closest("[data-remove-item],[data-remove-dock-app],[data-edit-widget],[data-home-action]")) return null;
    if (HOME.editMode && target.closest("[data-home-media-slot],[data-home-text-slot],[data-home-inline-editing=\"true\"]")) return null;
    const dockItem = target.closest(".home-dock-item[data-dock-app-id]");
    const desktopItem = target.closest(".home-item[data-item-id]");
    return dockItem ? { source: dockItem, sourceType: "dock" } : desktopItem ? { source: desktopItem, sourceType: "desktop" } : { source: null, sourceType: "desktop" };
  }

  function beginGesture({ id, clientX, clientY, inputType, target, captureTarget = null }) {
    if (HOME.drag) return;
    const gestureSource = findGestureSource(target);
    if (!gestureSource) return;
    const { source, sourceType } = gestureSource;
    // 主屏长按用于进入移动布局，不允许浏览器先创建文本选区。
    // 真正点击文字进入 data-home-inline-editing 后，CSS/事件层才恢复原生文本选择。
    if (source && !target.closest('[data-home-inline-editing="true"]')) {
      window.getSelection?.()?.removeAllRanges?.();
    }
    const gesture = {
      pointerId: id,
      inputType,
      captureTarget,
      source,
      sourceType,
      startX: clientX,
      startY: clientY,
      lastX: clientX,
      lastY: clientY,
      axis: null,
      longTimer: 0,
      pageStart: HOME.layout?.currentPageIndex || 0,
      allowPage: sourceType !== "dock",
      time: performance.now(),
      lastTime: performance.now(),
      velocityX: 0,
      viewportWidth: Math.max(1, HOME.refs.viewport?.clientWidth || window.innerWidth || 1)
    };
    HOME.gesture = gesture;

    if (source && HOME.editMode) {
      startDrag(source, { id, clientX, clientY, inputType, captureTarget }, sourceType);
      return;
    }
    if (source) {
      gesture.longTimer = window.setTimeout(() => {
        if (HOME.gesture !== gesture || HOME.drag) return;
        startDrag(source, {
          id,
          clientX: gesture.lastX,
          clientY: gesture.lastY,
          inputType,
          captureTarget
        }, sourceType);
      }, LONG_PRESS_MS);
    }
  }

  function moveGesture(clientX, clientY, id, time = performance.now()) {
    if (HOME.drag) {
      if (HOME.drag.pointerId !== id) return false;
      // 高频 touchmove/pointermove 只保留最新坐标，每个显示帧最多执行一次碰撞与 DOM 位移。
      scheduleDragContact(clientX, clientY, id);
      return true;
    }
    const gesture = HOME.gesture;
    if (!gesture || gesture.pointerId !== id) return false;
    const dx = clientX - gesture.startX;
    const dy = clientY - gesture.startY;
    const dt = Math.max(6, time - gesture.lastTime);
    const instant = (clientX - gesture.lastX) / dt;
    gesture.velocityX = gesture.velocityX * .62 + instant * .38;
    gesture.lastX = clientX;
    gesture.lastY = clientY;
    gesture.lastTime = time;

    if (!gesture.axis && Math.hypot(dx, dy) >= DRAG_THRESHOLD) {
      gesture.axis = gesture.allowPage && Math.abs(dx) >= Math.abs(dy) * 1.12 ? "horizontal" : "vertical";
      window.clearTimeout(gesture.longTimer);
      gesture.longTimer = 0;
    }
    if (!gesture.allowPage || gesture.axis !== "horizontal") return false;

    const width = gesture.viewportWidth || 1;
    let visualDx = dx;
    const atFirst = gesture.pageStart === 0 && dx > 0;
    const atLast = gesture.pageStart === HOME.layout.pages.length - 1 && dx < 0;
    if (atFirst || atLast) visualDx *= .3;
    HOME.refs.track.classList.add("is-swiping");
    scheduleSwipePaint(visualDx);
    return true;
  }

  function endGesture(id, cancelled = false) {
    if (HOME.drag && HOME.drag.pointerId === id) {
      finishDrag(id, cancelled).catch((error) => console.error("home drag finish failed", error));
      HOME.gesture = null;
      return;
    }
    const gesture = HOME.gesture;
    if (!gesture || gesture.pointerId !== id) return;
    window.clearTimeout(gesture.longTimer);
    if (gesture.axis === "horizontal") {
      const dx = gesture.lastX - gesture.startX;
      const width = gesture.viewportWidth || 1;
      const projected = cancelled ? dx : dx + gesture.velocityX * 205;
      let next = gesture.pageStart;
      if (Math.abs(dx) >= width * SWIPE_THRESHOLD_RATIO || Math.abs(projected) >= width * .5 || (Math.abs(gesture.velocityX) > .55 && Math.abs(dx) > 30)) {
        next += projected < 0 ? 1 : -1;
      }
      cancelSwipePaint();
      HOME.refs.track.classList.remove("is-swiping");
      HOME.refs.track.style.removeProperty("--home-swipe-offset");
      // 横划结束后的兼容 click 不能再穿透启动 App。
      if (Math.abs(dx) >= DRAG_THRESHOLD) HOME.clickSuppressUntil = Math.max(HOME.clickSuppressUntil, performance.now() + 320);
      changePage(next, true);
    }
    HOME.gesture = null;
  }

  function handleTouchStart(event) {
    if (event.touches.length !== 1) return;
    const touch = event.touches[0];
    beginGesture({ id: touch.identifier, clientX: touch.clientX, clientY: touch.clientY, inputType: "touch", target: event.target });
  }

  function findTouchById(touchList, id) {
    for (let index = 0; index < (touchList?.length || 0); index += 1) {
      const touch = touchList[index];
      if (touch.identifier === id) return touch;
    }
    return null;
  }

  function handleTouchMove(event) {
    const id = HOME.drag?.inputType === "touch" ? HOME.drag.pointerId : HOME.gesture?.inputType === "touch" ? HOME.gesture.pointerId : null;
    if (id === null || id === undefined) return;
    const touch = findTouchById(event.touches, id);
    if (!touch) return;
    // 仅供不支持 Pointer Events 的旧浏览器。横向翻页/拖拽一旦由 清柳 接管，
    // 必须阻止浏览器自己的横向导航；纵向则完全交还原生滚动。
    const consumed = moveGesture(touch.clientX, touch.clientY, id, performance.now());
    if (consumed && event.cancelable) event.preventDefault();
  }

  function handleTouchEnd(event) {
    const id = HOME.drag?.inputType === "touch" ? HOME.drag.pointerId : HOME.gesture?.inputType === "touch" ? HOME.gesture.pointerId : null;
    if (id === null || id === undefined) return;
    const changed = findTouchById(event.changedTouches, id);
    // Edge/部分 WebView 在 DOM 被拖到 fixed layer 后可能给出不完整 changedTouches；
    // 当屏幕已无活动触点时，同样必须结束当前唯一触摸手势。
    if (changed || (event.touches?.length ?? 0) === 0) endGesture(id, false);
  }

  function handleTouchCancel(event) {
    const id = HOME.drag?.inputType === "touch" ? HOME.drag.pointerId : HOME.gesture?.inputType === "touch" ? HOME.gesture.pointerId : null;
    if (id === null || id === undefined) return;
    const changed = findTouchById(event.changedTouches, id);
    if (changed || (event.touches?.length ?? 0) === 0) endGesture(id, true);
  }

  function handlePointerDown(event) {
    const pointerType = event.pointerType || "mouse";
    if (pointerType === "mouse" && event.button !== 0) return;
    if (pointerType !== "mouse" && pointerType !== "touch" && pointerType !== "pen") return;
    beginGesture({
      id: event.pointerId,
      clientX: event.clientX,
      clientY: event.clientY,
      inputType: pointerType,
      target: event.target,
      captureTarget: pointerType === "mouse" ? HOME.refs.root : null
    });
    // 鼠标拖出主屏边界仍需持续收事件；触屏不主动 capture，避免破坏 pan-y 原生纵向滚动。
    if (pointerType === "mouse" && (HOME.drag || HOME.gesture)) {
      try { HOME.refs.root.setPointerCapture?.(event.pointerId); } catch (_) {}
    }
  }

  function handlePointerMove(event) {
    const pointerType = event.pointerType || "mouse";
    if (pointerType !== "mouse" && pointerType !== "touch" && pointerType !== "pen") return;
    if (moveGesture(event.clientX, event.clientY, event.pointerId, event.timeStamp || performance.now()) && event.cancelable) event.preventDefault();
  }

  function handlePointerUp(event) {
    endGesture(event.pointerId, false);
  }

  function handlePointerCancel(event) {
    endGesture(event.pointerId, true);
  }

  async function launchApp(appId) {
    if (!appId || HOME.editMode || performance.now() < HOME.clickSuppressUntil) return;
    const reg = HOME.registry.get(appId); if (!reg?.launchable) return;
    cancelDrag(false);
    try { await window.MyPhoneManager.openApp(appId); }
    catch (error) {
      console.error(`app open failed: ${appId}`, error);
      window.ThemeCustomization?.GlobalModal?.alert({ title: appId === "atlas" ? "世界书无法打开" : "应用无法打开", message: error?.message || "初始化失败", confirmLabel: "知道了", action: "dismiss" });
    }
  }

  function handleClick(event) {
    const duetAction = event.target.closest?.("[data-o3o-music-action]");
    if (duetAction) {
      event.preventDefault();
      event.stopPropagation();
      if (HOME.editMode) return;
      const action = String(duetAction.dataset.o3oMusicAction || "");
      if (action === "prev") void window.MusicApp?.previous?.();
      else if (action === "next") void window.MusicApp?.next?.();
      else if (action === "toggle") void window.MusicApp?.toggle?.();
      else if (action === "like") void window.MusicApp?.toggleLike?.();
      return;
    }
    const action = event.target.closest("[data-home-action]")?.dataset.homeAction;
    if (action === "done") { setEditMode(false); return; }
    if (action === "add") { openComponentLibrary(); return; }
    if (action === "restore") { confirmResetLayout(); return; }
    const removeItem = event.target.closest("[data-remove-item]")?.dataset.removeItem;
    if (removeItem) { removeDesktopItem(removeItem); return; }
    const removeDockApp = event.target.closest("[data-remove-dock-app]")?.dataset.removeDockApp;
    if (removeDockApp) { removeDockItem(removeDockApp); return; }
    const editWidget = event.target.closest("[data-edit-widget]")?.dataset.editWidget;
    if (editWidget) { openWidgetInstanceEditor(editWidget); return; }
    if (HOME.editMode) {
      const mediaTarget = event.target.closest("[data-home-media-slot]");
      if (mediaTarget) { event.preventDefault(); event.stopPropagation(); pickBuiltinWidgetImage(mediaTarget); return; }
      const textTarget = event.target.closest("[data-home-text-slot]");
      if (textTarget) { event.preventDefault(); event.stopPropagation(); beginBuiltinWidgetTextEdit(textTarget); return; }
    }
    if (HOME.editMode || performance.now() < HOME.clickSuppressUntil) { event.preventDefault(); return; }
    const app = event.target.closest("[data-launchable=\"true\"][data-app-id]");
    if (app) launchApp(app.dataset.appId);
  }

  function handleKeyDown(event) {
    if (![("Enter"), (" ")].includes(event.key)) return;
    const app = event.target.closest("[data-launchable=\"true\"][data-app-id]");
    if (!app || HOME.editMode) return;
    event.preventDefault(); launchApp(app.dataset.appId);
  }

  function removeDesktopItem(itemId) {
    if (!HOME.editMode) return;
    const item = HOME.layout.desktopItems.find((row) => row.id === itemId); if (!item) return;
    HOME.layout.desktopItems = HOME.layout.desktopItems.filter((row) => row.id !== itemId);
    if (item.kind === "widget") { delete HOME.layout.widgetRuntimeState[item.instanceId]; releaseWidgetUrls(item.instanceId); }
    render(); schedulePersist(0);
  }
  function removeDockItem(appId) {
    if (!HOME.editMode) return;
    HOME.layout.dockItems = HOME.layout.dockItems.filter((row) => row.appId !== appId).map((row, index) => ({ ...row, order: index })); render(); schedulePersist(0);
  }

  function makeDrawerSection(title) {
    const section = document.createElement("section"); section.className = "home-drawer-section";
    const heading = document.createElement("h3"); heading.textContent = title; section.append(heading); return section;
  }
  function makeActionRow(title, note, action, danger = false) {
    const button = document.createElement("button"); button.type = "button"; button.className = `home-drawer-row${danger ? " is-danger" : ""}`;
    button.innerHTML = `<span><strong>${escapeHtml(title)}</strong>${note ? `<small>${escapeHtml(note)}</small>` : ""}</span><b>›</b>`; button.addEventListener("click", action); return button;
  }

  function currentWidgetPixelSize(size) {
    const dims = SIZE_MAP[size] || [4, 4];
    const grid = HOME.refs?.track?.querySelector(".home-page-grid");
    if (!grid) return { width: 336, height: 390 };
    const style = getComputedStyle(grid);
    const columnGap = Number.parseFloat(style.columnGap || "0") || 0;
    const rowGap = Number.parseFloat(style.rowGap || "0") || 0;
    const paddingLeft = Number.parseFloat(style.paddingLeft || "0") || 0;
    const paddingRight = Number.parseFloat(style.paddingRight || "0") || 0;
    const gridWidth = grid.clientWidth || grid.getBoundingClientRect().width || 336;
    const contentWidth = Math.max(1, gridWidth - paddingLeft - paddingRight);
    const cellWidth = Math.max(1, (contentWidth - (columnGap * (GRID.columns - 1))) / GRID.columns);
    const firstTrack = String(style.gridTemplateRows || "").trim().split(/\s+/)[0];
    const rowHeight = Number.parseFloat(firstTrack) || cellWidth;
    return {
      width: (cellWidth * dims[0]) + (columnGap * Math.max(0, dims[0] - 1)),
      height: (rowHeight * dims[1]) + (rowGap * Math.max(0, dims[1] - 1))
    };
  }

  function fitComponentLibraryPreview(previewHost) {
    if (!previewHost?.isConnected) return;
    const stage = previewHost.querySelector(".home-component-library-render");
    const component = stage?.firstElementChild;
    if (!stage || !component) return;
    const size = currentWidgetPixelSize(previewHost.dataset.size || "4x4");
    stage.style.width = `${size.width}px`;
    component.style.width = `${size.width}px`;
    const usesLogicalGridRect = component.classList.contains("home-os-preset")
      || component.classList.contains("home-ref-preset")
      || component.classList.contains("home-o3o-duet-music");
    component.style.height = usesLogicalGridRect ? `${size.height}px` : "auto";
    component.style.minHeight = "0";
    const naturalHeight = usesLogicalGridRect ? size.height : Math.max(1, component.scrollHeight, component.getBoundingClientRect().height);
    stage.style.height = `${naturalHeight}px`;
    const availableWidth = Math.max(1, previewHost.clientWidth);
    const scale = Math.min(1, availableWidth / size.width);
    stage.style.transform = `scale(${scale})`;
    previewHost.style.height = `${Math.ceil(naturalHeight * scale)}px`;
  }

  function makeComponentLibraryButton({ title, size, preview, action }) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "home-component-library-card";

    const previewHost = document.createElement("span");
    previewHost.className = "home-component-library-preview";
    previewHost.dataset.size = String(size || "4x4").toLowerCase().replace("×", "x");
    const render = document.createElement("span");
    render.className = "home-component-library-render";
    preview.classList.add("is-library-preview");
    render.append(preview);
    previewHost.append(render);

    const copy = document.createElement("span");
    copy.className = "home-component-library-copy";
    copy.innerHTML = `<strong>${escapeHtml(title)}</strong><small>${escapeHtml(size)}</small>`;

    button.append(previewHost, copy);
    button.addEventListener("click", action);
    requestAnimationFrame(() => fitComponentLibraryPreview(previewHost));
    return button;
  }

  async function openComponentLibrary() {
    await window.ThemeCustomization.GlobalDrawer.open({
      type: "home-component-library",
      title: "组件库",
      render: async () => {
        const body = document.querySelector('[data-ui-template="global-drawer"] .global-drawer-body') || document.querySelector(".global-drawer-body");
        if (!body) return;

        const library = document.createElement("div");
        library.className = "home-component-library";

        const grouped = new Map();
        const appendPreset = (size, button) => {
          const key = String(size || "").trim();
          if (!grouped.has(key)) grouped.set(key, []);
          grouped.get(key).push(button);
        };

        appendPreset("4×4", makeComponentLibraryButton({
          title: "萌点记录",
          size: "4×4",
          preview: buildUiiyTopMusicComponent(),
          action: () => addUiiyTopMusicWidget()
        }));
        O3O_COMPONENT_PRESETS.forEach((preset) => {
          appendPreset(preset.displaySize, makeComponentLibraryButton({
            title: preset.title,
            size: preset.displaySize,
            preview: buildO3OComponent(preset.widgetType),
            action: () => addO3OComponentWidget(preset.widgetType)
          }));
        });
        OS_COMPONENT_PRESETS.forEach((preset) => {
          appendPreset(preset.displaySize, makeComponentLibraryButton({
            title: preset.title,
            size: preset.displaySize,
            preview: buildOSComponent(preset.widgetType),
            action: () => addOSComponentWidget(preset.widgetType)
          }));
        });
        REFERENCE_COMPONENT_PRESETS.forEach((preset) => {
          appendPreset(preset.displaySize, makeComponentLibraryButton({
            title: preset.title,
            size: preset.displaySize,
            preview: buildReferenceComponent(preset.widgetType),
            action: () => addReferenceComponentWidget(preset.widgetType)
          }));
        });

        const orderedSizes = ["2×1", "2×2", "4×1", "4×2", "4×4"];
        const availableSizes = orderedSizes.filter((sizeLabel) => grouped.get(sizeLabel)?.length);
        const tabs = document.createElement("div");
        tabs.className = "home-component-library-size-tabs";
        const groupMap = new Map();
        let activeSize = availableSizes[0] || "";

        const updateActiveSize = (sizeLabel) => {
          activeSize = sizeLabel;
          tabs.querySelectorAll(".home-component-library-size-tab").forEach((tab) => {
            tab.classList.toggle("is-active", tab.dataset.sizeLabel === sizeLabel);
          });
          groupMap.forEach((group, key) => {
            group.hidden = key !== sizeLabel;
          });
          requestAnimationFrame(() => body.querySelectorAll('.home-component-library-preview').forEach(fitComponentLibraryPreview));
        };

        availableSizes.forEach((sizeLabel) => {
          const tab = document.createElement("button");
          tab.type = "button";
          tab.className = "home-component-library-size-tab";
          tab.dataset.sizeLabel = sizeLabel;
          tab.textContent = sizeLabel;
          tab.addEventListener("click", () => updateActiveSize(sizeLabel));
          tabs.append(tab);

          const group = document.createElement("section");
          group.className = "home-component-library-size-group";
          group.dataset.size = sizeLabel.replace("×", "x");

          const grid = document.createElement("div");
          grid.className = "home-component-library-grid";
          grid.dataset.size = sizeLabel.replace("×", "x");
          (grouped.get(sizeLabel) || []).forEach((entry) => grid.append(entry));

          group.append(grid);
          group.hidden = sizeLabel !== activeSize;
          groupMap.set(sizeLabel, group);
          library.append(group);
        });

        if (availableSizes.length) library.prepend(tabs);
        updateActiveSize(activeSize);

        const more = makeDrawerSection("更多");
        more.append(
          makeActionRow("基础 Widget", "选择网格尺寸", () => openBasicWidgetPicker()),
          makeActionRow("自定义 Widget", "管理自定义组件", () => openCustomWidgetList()),
          makeActionRow("主屏管理", "添加 App、导入导出与恢复布局", () => openManageDrawer())
        );
        body.append(library, more);
        requestAnimationFrame(() => body.querySelectorAll(".home-component-library-preview").forEach(fitComponentLibraryPreview));
      }
    });
  }

  async function addUiiyTopMusicWidget() {
    const size = "4x4";
    const loc = findFirstFreeWidgetRect(size, HOME.layout.currentPageIndex, HOME.layout);
    if (!loc) return showError("没有可放置 4×4 组件的页面");
    const dims = SIZE_MAP[size];
    HOME.layout.desktopItems.push({
      id: uid("widget"), instanceId: widgetInstanceUid(), kind: "widget", widgetType: "uiiy-top-music", size,
      ...loc, width: dims[0], height: dims[1],
      data: { title: "萌点记录", source: "UIIY_v26", sourceSelector: ".controls + .music-card-wrap + .widget-area" }
    });
    ensurePages(HOME.layout, loc.pageIndex);
    HOME.layout.currentPageIndex = loc.pageIndex;
    await persistNow();
    render();
    window.ThemeCustomization.GlobalDrawer.close();
  }

  async function addO3OComponentWidget(widgetType) {
    const preset = O3O_COMPONENT_PRESETS.find((entry) => entry.widgetType === widgetType);
    if (!preset) return;
    const loc = findFirstFreeWidgetRect(preset.size, HOME.layout.currentPageIndex, HOME.layout);
    if (!loc) return showError(`没有可放置 ${preset.displaySize} 组件的页面`);
    const dims = SIZE_MAP[preset.size];
    HOME.layout.desktopItems.push({
      id: uid("widget"), instanceId: widgetInstanceUid(), kind: "widget", widgetType: preset.widgetType, size: preset.size,
      ...loc, width: dims[0], height: dims[1],
      data: { title: preset.title, source: "O3O" }
    });
    ensurePages(HOME.layout, loc.pageIndex);
    HOME.layout.currentPageIndex = loc.pageIndex;
    await persistNow();
    render();
    window.ThemeCustomization.GlobalDrawer.close();
  }

  async function addOSComponentWidget(widgetType) {
    const preset = OS_COMPONENT_PRESETS.find((entry) => entry.widgetType === widgetType);
    if (!preset) return;
    const loc = findFirstFreeWidgetRect(preset.size, HOME.layout.currentPageIndex, HOME.layout);
    if (!loc) return showError(`没有可放置 ${preset.displaySize} 组件的页面`);
    const dims = SIZE_MAP[preset.size];
    HOME.layout.desktopItems.push({
      id: uid("widget"), instanceId: widgetInstanceUid(), kind: "widget", widgetType: preset.widgetType, size: preset.size,
      ...loc, width: dims[0], height: dims[1],
      data: { title: preset.title, source: "initial-small-phone" }
    });
    ensurePages(HOME.layout, loc.pageIndex);
    HOME.layout.currentPageIndex = loc.pageIndex;
    await persistNow();
    render();
    window.ThemeCustomization.GlobalDrawer.close();
  }

  async function addReferenceComponentWidget(widgetType) {
    const preset = REFERENCE_COMPONENT_PRESETS.find((entry) => entry.widgetType === widgetType);
    if (!preset) return;
    const loc = findFirstFreeWidgetRect(preset.size, HOME.layout.currentPageIndex, HOME.layout);
    if (!loc) return showError(`没有可放置 ${preset.displaySize} 组件的页面`);
    const dims = SIZE_MAP[preset.size];
    HOME.layout.desktopItems.push({
      id: uid("widget"), instanceId: widgetInstanceUid(), kind: "widget", widgetType: preset.widgetType, size: preset.size,
      ...loc, width: dims[0], height: dims[1],
      data: { title: preset.title, source: "reference-screenshots" }
    });
    ensurePages(HOME.layout, loc.pageIndex);
    HOME.layout.currentPageIndex = loc.pageIndex;
    await persistNow();
    render();
    window.ThemeCustomization.GlobalDrawer.close();
  }

  async function openManageDrawer() {
    await window.ThemeCustomization.GlobalDrawer.open({ type: "home-screen-manage", title: "主屏编辑", render: async () => {
      const body = document.querySelector('[data-ui-template="global-drawer"] .global-drawer-body') || document.querySelector(".global-drawer-body");
      if (!body) return;
      const used = new Set([...HOME.layout.desktopItems.filter((item) => item.kind === "app").map((item) => item.appId), ...HOME.layout.dockItems.map((row) => row.appId)]);
      const apps = makeDrawerSection("添加 App");
      const availableApps = Array.from(HOME.registry.values()).filter((reg) => !used.has(reg.appId));
      if (!availableApps.length) apps.append(Object.assign(document.createElement("p"), { className: "home-drawer-empty", textContent: "所有 App 已在主屏中" }));
      availableApps.forEach((reg) => apps.append(makeActionRow(reg.name, reg.launchable ? "添加到当前页后的第一个空位" : "无独立路由，仅保留现有行为", () => addApp(reg.appId))));
      const widgets = makeDrawerSection("Widget");
      widgets.append(makeActionRow("基础 Widget", "支持 1×1 / 2×1 / 1×2 / 2×2 / 4×1 / 4×2 / 4×4", () => openBasicWidgetPicker()), makeActionRow("自定义 Widget", "创建 HTML / CSS 隔离 Widget", () => openCustomWidgetList()));
      const data = makeDrawerSection("布局数据");
      data.append(makeActionRow("导出主屏布局", "标准 JSON，仅包含主屏与 Widget 数据", exportLayout), makeActionRow("导入主屏布局", "先完整校验，再覆盖主屏", importLayout), makeActionRow("恢复默认布局", "仅重置 App / Dock 排列并保留模板", confirmResetLayout, true));
      body.append(apps, widgets, data);
    }});
  }

  async function addApp(appId) {
    if (!HOME.registry.has(appId)) return;
    const used = new Set([...HOME.layout.desktopItems.filter((item) => item.kind === "app").map((item) => item.appId), ...HOME.layout.dockItems.map((row) => row.appId)]); if (used.has(appId)) return;
    const location = findFirstFreeAppCell(HOME.layout.currentPageIndex, HOME.layout); if (!location) return;
    HOME.layout.desktopItems.push({ id: `desktop-app-${appId}`, kind: "app", appId, ...location, width: 1, height: 1 }); ensurePages(HOME.layout, location.pageIndex); HOME.layout.currentPageIndex = location.pageIndex;
    await persistNow(); render(); window.ThemeCustomization.GlobalDrawer.close();
  }

  function makeWidgetPickerRow(size) {
    const dims = SIZE_MAP[size];
    const button = makeActionRow(`基础 Widget · ${size}`, "基础类型 · 自动寻找完整合法矩形", () => addBasicWidget(size));
    button.classList.add("home-widget-picker-row");
    const preview = document.createElement("span"); preview.className = "home-widget-size-preview"; preview.style.setProperty("--preview-w", String(dims[0])); preview.style.setProperty("--preview-h", String(dims[1])); preview.setAttribute("aria-hidden", "true");
    button.insertBefore(preview, button.lastElementChild);
    return button;
  }

  async function openBasicWidgetPicker() {
    await window.ThemeCustomization.GlobalDrawer.open({ type: "home-widget-picker", title: "添加 Widget", render: async () => {
      const body = document.querySelector(".global-drawer-body"); if (!body) return;
      const section = makeDrawerSection("尺寸");
      Object.keys(SIZE_MAP).forEach((size) => section.append(makeWidgetPickerRow(size))); body.append(section);
    }});
  }
  async function addBasicWidget(size) {
    const loc = findFirstFreeWidgetRect(size, HOME.layout.currentPageIndex, HOME.layout); if (!loc) return;
    const dims = SIZE_MAP[size]; HOME.layout.desktopItems.push({ id: uid("widget"), instanceId: widgetInstanceUid(), kind: "widget", widgetType: "basic", size, ...loc, width: dims[0], height: dims[1], data: { title: "Widget", text: size } });
    ensurePages(HOME.layout, loc.pageIndex); HOME.layout.currentPageIndex = loc.pageIndex; await persistNow(); render(); window.ThemeCustomization.GlobalDrawer.close();
  }

  async function openCustomWidgetList() {
    await window.ThemeCustomization.GlobalDrawer.open({ type: "home-custom-widget-list", title: "自定义 Widget", render: async () => {
      const body = document.querySelector(".global-drawer-body"); if (!body) return;
      const section = makeDrawerSection("模板"); section.append(makeActionRow("新建模板", "HTML / CSS / 图片槽 / 用户字段", () => openCustomWidgetEditor(null)));
      HOME.layout.widgetTemplates.forEach((tpl) => section.append(makeActionRow(tpl.name, `默认 ${tpl.defaultSize}`, () => openTemplateActions(tpl.templateId)))); body.append(section);
    }});
  }

  function openTemplateActions(templateId) {
    const tpl = HOME.layout.widgetTemplates.find((row) => row.templateId === templateId); if (!tpl) return;
    window.ThemeCustomization.GlobalModal.open({ title: tpl.name, message: "选择操作", showCancel: true, confirmLabel: "添加到主屏", cancelLabel: "关闭", content(host) {
      const wrap = document.createElement("div"); wrap.className = "home-modal-actions";
      const edit = document.createElement("button"); edit.type = "button"; edit.textContent = "编辑模板"; edit.onclick = () => { window.ThemeCustomization.GlobalModal.close(); openCustomWidgetEditor(templateId); };
      const del = document.createElement("button"); del.type = "button"; del.textContent = "删除模板"; del.onclick = () => deleteTemplate(templateId);
      wrap.append(edit, del); host.append(wrap);
    }, action: async () => { await addCustomWidget(templateId, tpl.defaultSize); return true; } });
  }

  async function openCustomWidgetEditor(templateId) {
    const existing = HOME.layout.widgetTemplates.find((row) => row.templateId === templateId) || null;
    await window.ThemeCustomization.GlobalDrawer.open({ type: "home-custom-widget-editor", title: existing ? "编辑 Widget" : "新建 Widget", render: async () => {
      const body = document.querySelector(".global-drawer-body"); if (!body) return;
      const form = document.createElement("div"); form.className = "home-widget-editor";
      form.innerHTML = `
<label>名称<input data-field="name" value="${escapeHtml(existing?.name || "")}"></label>
<label>默认尺寸<select data-field="size">${Object.keys(SIZE_MAP).map((size) => `<option value="${size}"${existing?.defaultSize === size ? " selected" : ""}>${size}</option>`).join("")}</select></label>
<label>HTML<textarea data-field="html" rows="8">${escapeHtml(existing?.html || "<div class='card'>Hello Widget</div>")}</textarea></label>
<label>CSS<textarea data-field="css" rows="8">${escapeHtml(existing?.css || ".card{height:100%;display:grid;place-items:center;border-radius:20px;background:#fff;color:#111}")}</textarea></label>
<label>图片槽 <small>每行：key|名称</small><textarea data-field="images" rows="3">${escapeHtml((existing?.imageSlots || []).map((x) => `${x.key}|${x.label}`).join("\n"))}</textarea></label>
<label>用户字段 <small>每行：key|名称|text/number/date/time/color/select|默认值|选项1,选项2</small><textarea data-field="fields" rows="5">${escapeHtml((existing?.userFields || []).map((x) => `${x.key}|${x.label}|${x.type}|${x.defaultValue ?? ""}|${(x.options || []).join(",")}`).join("\n"))}</textarea></label>
<div class="home-widget-preview"><iframe sandbox="allow-scripts" title="实时预览"></iframe></div>
<button type="button" data-save-template>保存模板</button>`;
      body.append(form);
      const preview = () => {
        const fake = { id: "preview", widgetType: "custom", templateId: "preview", overrides: {} };
        const tempState = clone(HOME.layout); tempState.widgetTemplates = [{ templateId: "preview", name: form.querySelector('[data-field="name"]').value || "Preview", defaultSize: form.querySelector('[data-field="size"]').value, html: form.querySelector('[data-field="html"]').value, css: form.querySelector('[data-field="css"]').value, imageSlots: [], userFields: [] }];
        form.querySelector("iframe").srcdoc = buildWidgetSrcdoc(fake, tempState);
      };
      form.querySelectorAll("input,textarea,select").forEach((el) => el.addEventListener("input", preview)); preview();
      form.querySelector("[data-save-template]").addEventListener("click", async () => {
        const name = form.querySelector('[data-field="name"]').value.trim(); if (!name) return showError("Widget 名称不能为空");
        const parseLines = (text) => String(text).split(/\n+/).map((line) => line.trim()).filter(Boolean).map((line) => line.split("|"));
        const imageSlots = parseLines(form.querySelector('[data-field="images"]').value).map(([key, label]) => ({ key: String(key || "").trim(), label: String(label || key || "").trim() })).filter((row) => row.key);
        if (imageSlots.some((row) => !/^[A-Za-z][A-Za-z0-9_-]*$/.test(row.key))) return showError("图片槽 key 只能使用英文字母开头的字母、数字、_、-");
        const imageKeys = new Set(imageSlots.map((x) => x.key)); if (imageKeys.size !== imageSlots.length) return showError("图片槽 key 不能重复");
        const userFields = parseLines(form.querySelector('[data-field="fields"]').value).map(([key, label, type, defaultValue, options]) => ({ key: String(key || "").trim(), label: String(label || key || "").trim(), type: ["text","number","date","time","color","select"].includes(type) ? type : "text", defaultValue: defaultValue ?? "", options: String(options || "").split(",").map((x) => x.trim()).filter(Boolean) })).filter((row) => row.key);
        if (userFields.some((row) => !/^[A-Za-z][A-Za-z0-9_-]*$/.test(row.key))) return showError("用户字段 key 只能使用英文字母开头的字母、数字、_、-");
        const fieldKeys = new Set(userFields.map((x) => x.key)); if (fieldKeys.size !== userFields.length) return showError("用户字段 key 不能重复");
        if (userFields.some((row) => row.type === "select" && (!row.options.length || new Set(row.options).size !== row.options.length))) return showError("select 字段必须提供不重复的有效选项");
        const now = new Date().toISOString(); const next = { templateId: existing?.templateId || uid("template"), name, defaultSize: form.querySelector('[data-field="size"]').value, html: form.querySelector('[data-field="html"]').value, css: form.querySelector('[data-field="css"]').value, imageSlots, userFields, createdAt: existing?.createdAt || now, updatedAt: now };
        const index = HOME.layout.widgetTemplates.findIndex((row) => row.templateId === next.templateId); if (index >= 0) HOME.layout.widgetTemplates[index] = next; else HOME.layout.widgetTemplates.push(next);
        // 已有实例保留模板快照，避免模板后续删除导致空白。
        HOME.layout.desktopItems.filter((item) => item.kind === "widget" && item.templateId === next.templateId).forEach((item) => item.templateSnapshot = clone(next));
        await persistNow(); render(); openCustomWidgetList();
      });
    }});
  }

  async function addCustomWidget(templateId, size) {
    const tpl = HOME.layout.widgetTemplates.find((row) => row.templateId === templateId); if (!tpl) return;
    const chosen = SIZE_MAP[size] ? size : tpl.defaultSize; const loc = findFirstFreeWidgetRect(chosen, HOME.layout.currentPageIndex, HOME.layout); if (!loc) return;
    const dims = SIZE_MAP[chosen]; const fields = Object.fromEntries((tpl.userFields || []).map((field) => [field.key, field.defaultValue ?? ""]));
    HOME.layout.desktopItems.push({ id: uid("widget"), instanceId: widgetInstanceUid(), kind: "widget", widgetType: "custom", templateId, templateSnapshot: clone(tpl), size: chosen, ...loc, width: dims[0], height: dims[1], overrides: { fields, images: {} } });
    ensurePages(HOME.layout, loc.pageIndex); HOME.layout.currentPageIndex = loc.pageIndex; await persistNow(); render(); window.ThemeCustomization.GlobalModal.close(); window.ThemeCustomization.GlobalDrawer.close();
  }

  function deleteTemplate(templateId) {
    HOME.layout.widgetTemplates = HOME.layout.widgetTemplates.filter((row) => row.templateId !== templateId);
    // 实例已有 templateSnapshot，不删除实例。
    persistNow().then(() => { render(); window.ThemeCustomization.GlobalModal.close(); openCustomWidgetList(); });
  }

  async function openWidgetInstanceEditor(itemId) {
    const item = HOME.layout.desktopItems.find((row) => row.id === itemId && row.kind === "widget" && row.widgetType === "custom"); if (!item) return;
    const tpl = widgetTemplateFor(item, HOME.layout); if (!tpl) return showError("Widget 模板不可用");
    await window.ThemeCustomization.GlobalDrawer.open({ type: "home-widget-instance-editor", title: tpl.name, render: async () => {
      const body = document.querySelector(".global-drawer-body"); if (!body) return;
      const form = document.createElement("div"); form.className = "home-widget-editor";
      for (const field of tpl.userFields || []) {
        const label = document.createElement("label"); label.textContent = field.label;
        let input;
        if (field.type === "select") { input = document.createElement("select"); (field.options || []).forEach((opt) => input.append(new Option(opt, opt))); }
        else { input = document.createElement("input"); input.type = field.type; }
        input.dataset.userField = field.key; input.value = item.overrides?.fields?.[field.key] ?? field.defaultValue ?? ""; label.append(input); form.append(label);
      }
      for (const slot of tpl.imageSlots || []) {
        const label = document.createElement("label"); label.textContent = slot.label;
        const input = document.createElement("input"); input.type = "file"; input.accept = window.ThemeCustomization.imageAccept || "image/*"; input.dataset.imageSlot = slot.key; label.append(input); form.append(label);
      }
      const save = document.createElement("button"); save.type = "button"; save.textContent = "保存"; form.append(save); body.append(form);
      save.onclick = async () => {
        if (save.disabled) return;
        save.disabled = true;
        const previousOverrides = clone(item.overrides || {});
        const stagedImages = [];
        try {
          for (const input of form.querySelectorAll("[data-image-slot]")) if (input.files?.[0]) {
            const slot = input.dataset.imageSlot;
            const imageBlob = await window.ThemeCustomization.prepareImageBlob(input.files[0], { maxSide: 2160, quality: .9 });
            if (!(imageBlob instanceof Blob) || !imageBlob.size) throw new Error("组件图片处理结果为空");
            const decoded = await window.QWQMediaSurface?.preloadBlob?.(imageBlob);
            if (decoded === false) throw new Error("组件图片无法完成解码");
            const key = widgetObjectUrlKey(item.instanceId, "custom", slot);
            stagedImages.push({ slot, imageBlob, key });
          }

          item.overrides ||= {};
          item.overrides.fields ||= {};
          item.overrides.images ||= {};
          form.querySelectorAll("[data-user-field]").forEach((input) => {
            item.overrides.fields[input.dataset.userField] = input.value;
          });
          stagedImages.forEach((entry) => {
            item.overrides.images[entry.slot] = entry.imageBlob;
          });

          // 持久化成功前不动当前可见 URL；成功后先在原槽位完成新图解码，
          // 再提交 URL 与 DOM，禁止“先 revoke 旧图再等待新图”。
          await persistNow();
          for (const entry of stagedImages) {
            const slotKey = homeMediaSlot(entry.key);
            const nextUrl = await window.QWQMediaSurface?.prepareBlobSlot?.(slotKey, entry.imageBlob, entry.imageBlob);
            if(!nextUrl) throw new Error("组件图片无法完成解码");
            window.QWQMediaSurface?.rebind?.(slotKey, `slot:${entry.key}`);
            HOME.objectUrls.set(entry.key, {url:nextUrl,size:entry.imageBlob.size,type:entry.imageBlob.type || ""});
          }
          render();
          window.ThemeCustomization.GlobalDrawer.close();
        } catch (error) {
          item.overrides = previousOverrides;
          // 若持久化已经成功而后续媒体提交失败，必须把数据与媒体槽一并回滚；
          // 禁止留下“数据库是新图、当前页面仍是旧图”的半提交状态。
          for (const entry of stagedImages) {
            const slotKey = homeMediaSlot(entry.key);
            const previousImage = previousOverrides?.images?.[entry.slot];
            if(previousImage instanceof Blob && previousImage.size){
              const previousUrl = await window.QWQMediaSurface?.prepareBlobSlot?.(slotKey, previousImage, previousImage);
              if(previousUrl) {
                window.QWQMediaSurface?.rebind?.(slotKey, `slot:${entry.key}`);
                HOME.objectUrls.set(entry.key,{url:previousUrl,size:previousImage.size,type:previousImage.type || ""});
              }
            } else {
              window.QWQMediaSurface?.release?.(slotKey);
              HOME.objectUrls.delete(entry.key);
            }
          }
          try { await persistNow(); } catch (rollbackError) { console.error("custom widget rollback persist failed", rollbackError); }
          render();
          console.error("custom widget save failed", error);
          await window.ThemeCustomization?.GlobalModal?.alert?.({
            title: "组件保存失败",
            message: error?.message || "组件图片或文字无法保存。",
            confirmLabel: "知道了",
            action: "dismiss"
          });
        } finally {
          if (save.isConnected) save.disabled = false;
        }
      };
    }});
  }

  function bindWidgetRuntimeBridge() {
    if (HOME.widgetMessageBound) return; HOME.widgetMessageBound = true;
    window.addEventListener("message", async (event) => {
      const msg = event.data; if (!msg || msg.protocol !== "QWQWidgetRuntimeV1" || typeof msg.instanceId !== "string") return;
      const iframe = Array.from(document.querySelectorAll(".home-widget-frame")).find((frame) => frame.contentWindow === event.source); if (!iframe) return;
      const item = HOME.layout?.desktopItems.find((row) => row.instanceId === msg.instanceId && row.kind === "widget");
      const shell = iframe.closest("[data-widget-instance-id]");
      if (!item || shell?.dataset.widgetInstanceId !== item.instanceId || shell?.dataset.itemId !== item.id) return;
      const bucket = HOME.layout.widgetRuntimeState[item.instanceId] && typeof HOME.layout.widgetRuntimeState[item.instanceId] === "object" ? HOME.layout.widgetRuntimeState[item.instanceId] : (HOME.layout.widgetRuntimeState[item.instanceId] = {});
      let value; let ok = true; let error = "";
      try {
        if (msg.op === "get") value = clone(bucket[msg.key]);
        else if (msg.op === "getAll") value = clone(bucket);
        else if (msg.op === "set") {
          const encoded = JSON.stringify(msg.value); if (encoded.length > 65536) throw new Error("单个 Widget 状态值超过 64KB"); bucket[String(msg.key).slice(0, 128)] = clone(msg.value); value = true; schedulePersist(220);
        } else if (msg.op === "remove") { delete bucket[msg.key]; value = true; schedulePersist(220); }
        else if (msg.op === "clear") { HOME.layout.widgetRuntimeState[item.instanceId] = {}; value = true; schedulePersist(220); }
        else throw new Error("unsupported operation");
      } catch (err) { ok = false; error = String(err?.message || err); }
      event.source.postMessage({ protocol: "QWQWidgetRuntimeV1Result", instanceId: item.instanceId, id: msg.id, ok, value, error }, "*");
    });
  }

  async function binaryToJson(value) {
    if (value instanceof Blob) {
      const buffer = new Uint8Array(await value.arrayBuffer()); let binary = ""; const step = 0x8000; for (let i = 0; i < buffer.length; i += step) binary += String.fromCharCode(...buffer.subarray(i, i + step));
      return { __binary: "blob", type: value.type || "application/octet-stream", encoding: "base64", data: btoa(binary) };
    }
    if (Array.isArray(value)) return Promise.all(value.map(binaryToJson));
    if (value && typeof value === "object") { const out = {}; for (const [key, item] of Object.entries(value)) out[key] = await binaryToJson(item); return out; }
    return value;
  }
  async function jsonToBinary(value) {
    if (value && typeof value === "object" && !Array.isArray(value) && value.__binary === "blob") {
      if (value.encoding !== "base64" || typeof value.data !== "string" || typeof value.type !== "string") throw new Error("二进制标记无效");
      let raw; try { raw = atob(value.data); } catch (_) { throw new Error("Base64 解码失败"); }
      if (raw.length > 16 * 1024 * 1024) throw new Error("导入图片过大");
      const bytes = new Uint8Array(raw.length); for (let i = 0; i < raw.length; i += 1) bytes[i] = raw.charCodeAt(i); const blob = new Blob([bytes], { type: value.type });
      if (value.type.startsWith("image/")) return window.ThemeCustomization.prepareImageBlob(blob, { maxSide: 2160, quality: .9 });
      return blob;
    }
    if (Array.isArray(value)) return Promise.all(value.map(jsonToBinary));
    if (value && typeof value === "object") { const out = {}; for (const [key, item] of Object.entries(value)) out[key] = await jsonToBinary(item); return out; }
    return value;
  }

  async function exportLayout() {
    const layout = await binaryToJson(HOME.layout);
    const payload = { format: HOME_FORMAT, schemaVersion: SCHEMA_VERSION, appVersion: myPhoneConfig.version, exportedAt: new Date().toISOString(), grid: GRID, layout };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    window.QWQFileDownload.saveBlob(blob, `清柳-主屏布局-${new Date().toISOString().slice(0, 10)}.json`);
  }

  function validateImportedLayout(raw) {
    const ids = new Set(); const instanceIds = new Set(); const appIds = new Set(); const dockIds = new Set();
    if (raw.dockItems.length > GRID.dockCapacity) throw new Error("Dock 数量超过 4");
    const knownItems = [];
    for (const item of raw.desktopItems) {
      if (!item || typeof item !== "object") throw new Error("desktopItems 存在非法项目");
      const id = String(item.id || ""); if (!id || ids.has(id)) throw new Error("item id 缺失或重复"); ids.add(id);
      const kind = item.kind === "widget" ? "widget" : "app";
      if (kind === "app") {
        const appId = String(item.appId || ""); if (!appId) throw new Error("App appId 无效");
        if (!HOME.registry.has(appId)) continue;
        if (appIds.has(appId)) throw new Error(`App 重复：${appId}`); appIds.add(appId);
        if (int(item.width, 1) !== 1 || int(item.height, 1) !== 1) throw new Error(`App 必须为 1×1：${appId}`);
      } else {
        const instanceId = String(item.instanceId || "").trim();
        if (instanceId) {
          if (instanceId.length > 160 || instanceIds.has(instanceId)) throw new Error(`Widget instanceId 非法或重复：${id}`);
          instanceIds.add(instanceId);
        }
        const size = normalizeSizeKey(item.size, item.width, item.height); const dims = SIZE_MAP[size];
        if (int(item.width, dims[0]) !== dims[0] || int(item.height, dims[1]) !== dims[1]) throw new Error(`Widget 尺寸非法：${id}`);
      }
      const normalizedProbe = { pageIndex: int(item.pageIndex, -1), gridX: int(item.gridX, -1), gridY: int(item.gridY, -1), width: kind === "app" ? 1 : SIZE_MAP[normalizeSizeKey(item.size, item.width, item.height)][0], height: kind === "app" ? 1 : SIZE_MAP[normalizeSizeKey(item.size, item.width, item.height)][1] };
      if (!isWithinGrid(normalizedProbe)) throw new Error(`项目越出 4×6 网格：${id}`);
      knownItems.push({ ...normalizedProbe, id });
    }
    for (const row of raw.dockItems) {
      const appId = String(row?.appId || ""); if (!appId) throw new Error("Dock appId 无效");
      if (!HOME.registry.has(appId)) continue;
      if (dockIds.has(appId) || appIds.has(appId)) throw new Error(`App 同时重复出现在桌面或 Dock：${appId}`); dockIds.add(appId); appIds.add(appId);
    }
    for (let i = 0; i < knownItems.length; i += 1) for (let j = i + 1; j < knownItems.length; j += 1) if (knownItems[i].pageIndex === knownItems[j].pageIndex && rectsOverlap(knownItems[i], knownItems[j])) throw new Error(`布局存在非法重叠：${knownItems[i].id} / ${knownItems[j].id}`);
    const tplIds = new Set();
    for (const tpl of raw.widgetTemplates) {
      const id = String(tpl?.templateId || "");
      if (!id || tplIds.has(id)) throw new Error("Widget templateId 缺失或重复");
      tplIds.add(id);
      if (!String(tpl?.name || "").trim()) throw new Error(`Widget 模板名称为空：${id}`);
      if (!SIZE_MAP[tpl?.defaultSize]) throw new Error(`Widget 默认尺寸非法：${id}`);
      if (typeof tpl?.html !== "string" || typeof tpl?.css !== "string") throw new Error(`Widget HTML/CSS 类型无效：${id}`);
      if (!Array.isArray(tpl.imageSlots) || !Array.isArray(tpl.userFields)) throw new Error(`Widget 字段定义非法：${id}`);
      const imageKeys = new Set();
      for (const slot of tpl.imageSlots) {
        const key = String(slot?.key || "");
        if (!/^[A-Za-z][A-Za-z0-9_-]*$/.test(key) || imageKeys.has(key)) throw new Error(`Widget 图片槽 key 非法或重复：${id}`);
        imageKeys.add(key);
      }
      const fieldKeys = new Set();
      for (const field of tpl.userFields) {
        const key = String(field?.key || ""); const type = String(field?.type || "");
        if (!/^[A-Za-z][A-Za-z0-9_-]*$/.test(key) || fieldKeys.has(key)) throw new Error(`Widget 用户字段 key 非法或重复：${id}`);
        if (!["text","number","date","time","color","select"].includes(type)) throw new Error(`Widget 用户字段类型非法：${id}/${key}`);
        if (type === "select" && (!Array.isArray(field.options) || !field.options.length || field.options.some((option) => typeof option !== "string") || new Set(field.options).size !== field.options.length)) throw new Error(`Widget select 选项非法：${id}/${key}`);
        fieldKeys.add(key);
      }
    }
    for (const item of raw.desktopItems) {
      if (item?.kind !== "widget" || String(item?.widgetType || "basic") !== "custom") continue;
      const templateId = String(item?.templateId || "");
      const hasSnapshot = item?.templateSnapshot && typeof item.templateSnapshot === "object" && String(item.templateSnapshot.name || "").trim();
      if ((!templateId || !tplIds.has(templateId)) && !hasSnapshot) throw new Error(`自定义 Widget 缺少可恢复模板：${String(item?.id || "")}`);
    }
    return true;
  }

  function prepareImportedState(raw) {
    if (!raw || typeof raw !== "object") throw new Error("主屏状态缺失");
    for (const key of ["pages", "desktopItems", "dockItems", "widgetTemplates"]) {
      if (!Array.isArray(raw[key])) throw new Error(`${key} 必须是数组`);
    }
    validateImportedLayout(raw);
    const importedSchemaVersion = Math.max(0, int(raw.schemaVersion, 0));
    let normalized = normalizeHomeLayout(raw, HOME.registry);
    if (importedSchemaVersion < 3) {
      const weatherResult = ensureRegistryAppPlacement(normalized, "weather", { preferredPage: 0 });
      normalized = weatherResult.state;
      if (HOME.registry.has("weather") && !appPlacementExists(normalized, "weather")) {
        throw new Error("旧版布局迁移失败：天气 App 未能落位");
      }
    }
    normalized.knownAppIds = Array.from(HOME.registry.keys());
    const expectedKnownItems = (raw.desktopItems || []).filter((row) => row?.kind === "widget"
      ? !RETIRED_REFERENCE_WIDGET_TYPES.has(String(row?.widgetType || "basic")) && String(row?.widgetType || "basic") !== "os-status-control"
      : HOME.registry.has(String(row?.appId || ""))
    ).length;
    if (normalized.desktopItems.length < expectedKnownItems) throw new Error("布局存在重复、越界或非法重叠项目");
    return normalized;
  }

  async function importState(raw) {
    if (!HOME.hydrated) throw new Error("主屏尚未完成初始化");
    const normalized = prepareImportedState(raw);
    releaseWidgetUrls();
    HOME.layout = normalized;
    HOME.preview = null;
    await persistNow();
    render();
    await Promise.all([
      window.QWQLifecycle?.waitForLocalRenderImages?.(HOME.refs.root) || Promise.resolve(true),
      waitForTrackedWidgetMedia()
    ]);
    return getState();
  }

  function importLayout() {
    const input = document.createElement("input"); input.type = "file"; input.accept = "application/json,.json";
    input.onchange = async () => {
      const file = input.files?.[0]; if (!file) return;
      try {
        const parsed = JSON.parse(await file.text());
        if (!parsed || typeof parsed !== "object" || parsed.format !== HOME_FORMAT) throw new Error("不是 QWQHomeLayout 文件");
        const packageSchemaVersion = int(parsed.schemaVersion, -1);
        if (packageSchemaVersion > SCHEMA_VERSION) throw new Error("布局来自未来版本，当前版本不支持");
        if (packageSchemaVersion < 1) throw new Error("布局 schemaVersion 不受支持");
        if (parsed.grid && (int(parsed.grid.columns, -1) !== GRID.columns || int(parsed.grid.rows, -1) !== GRID.rows || int(parsed.grid.dockCapacity, -1) !== GRID.dockCapacity)) throw new Error("布局网格规格不是当前 4×6 / Dock 4 规范");
        if (!parsed.layout || typeof parsed.layout !== "object") throw new Error("layout 缺失");
        for (const key of ["pages", "desktopItems", "dockItems", "widgetTemplates"]) if (!Array.isArray(parsed.layout[key])) throw new Error(`${key} 必须是数组`);
        const decoded = await jsonToBinary(parsed.layout);
        prepareImportedState(decoded);
        const unknownApps = Array.from(new Set((decoded.desktopItems || []).filter((row) => row?.kind !== "widget").map((row) => String(row?.appId || "")).concat((decoded.dockItems || []).map((row) => String(row?.appId || ""))).filter((id) => id && !HOME.registry.has(id))));
        window.ThemeCustomization.GlobalModal.confirm({ title: "导入主屏布局", message: `导入后会替换当前主屏排列、Dock、Widget、自定义 Widget 模板和 Widget 状态，但不会修改其它应用数据。${unknownApps.length ? `\n\n已忽略当前版本未知 App：${unknownApps.join("、")}` : ""}`, confirmLabel: "导入", cancelLabel: "取消", danger: true, action: async () => { await importState(decoded); return true; } });
      } catch (error) { showError(`导入失败：${error?.message || error}`); }
    };
    input.click();
  }

  function confirmResetLayout() {
    window.ThemeCustomization.GlobalModal.confirm({ title: "恢复默认主屏", message: "仅恢复 App / Dock 默认排列，并移除桌面 Widget；自定义 Widget 模板会保留。主题、壁纸、自定义图标、聊天及其它业务数据不会被修改。", confirmLabel: "恢复", cancelLabel: "取消", danger: true, action: async () => {
      const templates = clone(HOME.layout.widgetTemplates); const next = makeDefaultLayout(); next.widgetTemplates = templates; releaseWidgetUrls(); HOME.layout = next; await persistNow(); render(); return true;
    }});
  }
  function showError(message) { window.ThemeCustomization?.GlobalModal?.alert({ title: "主屏布局", message: String(message), confirmLabel: "知道了", action: "dismiss" }); }

  function interruptInteraction(rerender = true) {
    if (HOME.gesture?.longTimer) window.clearTimeout(HOME.gesture.longTimer);
    HOME.gesture = null;
    cancelSwipePaint();
    HOME.refs.track?.classList.remove("is-swiping");
    HOME.refs.track?.style.removeProperty("--home-swipe-offset");
    cancelDrag(rerender);
  }

  function suspendWidgets() {
    if (HOME.suspendedWidgets.length) return;
    HOME.refs.root?.querySelectorAll(".home-widget").forEach((widget) => {
      const parent = widget.parentNode;
      if (!parent) return;
      const anchor = document.createComment(`qwq-widget:${widget.dataset.itemId || "unknown"}`);
      parent.replaceChild(anchor, widget);
      HOME.suspendedWidgets.push({ widget, anchor });
    });
  }

  function resumeWidgets() {
    const suspended = HOME.suspendedWidgets.splice(0);
    suspended.forEach(({ widget, anchor }) => {
      if (!anchor?.isConnected || !anchor.parentNode) return;
      anchor.parentNode.replaceChild(widget, anchor);
    });
    if (HOME.layout) render({ committed: false });
  }

  function flushHomeStateBeforeSuspension() {
    if (!HOME.hydrated || !HOME.layout) return;
    HOME.refs?.root?.querySelector?.('[data-home-inline-editing="true"]')?.blur?.();
    interruptInteraction(false);
    // 页面隐藏并不等于布局发生变化。只有存在未提交修改时才克隆并写 IndexedDB，
    // 避免每次切 App/锁屏都序列化整份 Widget + 图片状态抢占主线程。
    if (!HOME.dirty && !HOME.saveTimer) return;
    void persistNow({ preserveEmptyPages: HOME.editMode }).catch((error) => {
      console.error("home layout suspension flush failed", error);
    });
  }

  function onVisibilityChange() {
    if (document.visibilityState !== "visible") flushHomeStateBeforeSuspension();
  }
  function onRouteChange() { const active = HOME.refs.root?.classList.contains("is-active"); if (!active) interruptInteraction(); }

  function scheduleGeometryRefresh() {
    if (HOME.resizeRaf) return;
    HOME.resizeRaf = requestAnimationFrame(() => {
      HOME.resizeRaf = 0;
      // 其它 App 的布局视口变化不应读取隐藏主屏几何。
      if (!HOME.refs.root?.classList.contains("is-active") && !HOME.drag) {
        HOME.geometry = null;
        return;
      }
      // CSS Grid 会自行响应尺寸变化；resize 这里只刷新拖拽几何缓存，禁止重建整页 DOM/iframe。
      updateGeometry();
    });
  }

  function bindEvents() {
    const root = HOME.refs.root;
    // 只允许一套触控坐标链拥有一次手势事务。现代 Chromium / WebKit / Gecko
    // 统一由 Pointer Events 处理；Touch Events 仅作为旧内核 fallback。禁止二者同时竞争。
    if (typeof window.PointerEvent === "function") {
      root.addEventListener("pointerdown", handlePointerDown);
      root.addEventListener("pointermove", handlePointerMove, { passive: false });
      document.addEventListener("pointerup", handlePointerUp, { capture: true });
      document.addEventListener("pointercancel", handlePointerCancel, { capture: true });
    } else {
      root.addEventListener("touchstart", handleTouchStart, { passive: true });
      root.addEventListener("touchmove", handleTouchMove, { passive: false });
      // 结束事件放到 document capture：拖拽 DOM 被提升/重挂载、手指离开主屏可视边界时，
      // 仍能保证一次且仅一次结束事务。
      document.addEventListener("touchend", handleTouchEnd, { passive: true, capture: true });
      document.addEventListener("touchcancel", handleTouchCancel, { passive: true, capture: true });
    }
    root.addEventListener("pointerdown", (event) => {
      if (HOME.editMode) return;
      const app = event.target?.closest?.('[data-launchable="true"][data-app-id]');
      const appId = String(app?.dataset?.appId || "");
      if (appId) window.QWQModuleLoader?.prefetchApps?.([appId]);
    }, { passive: true });
    root.addEventListener("contextmenu", (event) => { if (event.target.closest(".home-item,.home-dock-item")) event.preventDefault(); });
    root.addEventListener("selectstart", (event) => {
      if (event.target?.closest?.('[data-home-inline-editing="true"]')) return;
      if (event.target?.closest?.(".home-item,.home-dock-item")) event.preventDefault();
    });
    root.addEventListener("dragstart", (event) => {
      if (event.target?.closest?.('[data-home-inline-editing="true"]')) return;
      if (event.target?.closest?.(".home-item,.home-dock-item")) event.preventDefault();
    });
    root.addEventListener("click", handleClick);
    root.addEventListener("keydown", handleKeyDown);
    window.addEventListener("resize", scheduleGeometryRefresh, { passive: true });
    window.addEventListener("blur", () => interruptInteraction());
    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("pagehide", flushHomeStateBeforeSuspension, { capture: true });
    // 自定义 Widget、其 iframe 与拖拽提升层共同构成一个渲染单元。离开主屏时整单元退出渲染树，
    // 返回时从 HOME 单一状态原位恢复；禁止只隐藏父路由或只拆 iframe 后保留旧合成快照。
    document.addEventListener("qwq:route-will-change", (event) => {
      if (event.detail?.from !== "page-my-phone-home") return;
      // 路由提交前先把仍在编辑中的文字触发 blur/commit，再把 active 布局写入 Dexie。
      // 这是主屏正式状态的离开事务，不依赖 140ms debounce 是否恰好来得及执行。
      HOME.refs?.root?.querySelector?.('[data-home-inline-editing="true"]')?.blur?.();
      interruptInteraction(false);
      if (HOME.dirty || HOME.saveTimer) {
        void persistNow({ preserveEmptyPages: HOME.editMode }).catch((error) => console.error("home layout route flush failed", error));
      }
      suspendWidgets();
      HOME.refs.dragLayer?.replaceChildren();
      HOME.refs.dragLayer?.classList.remove("is-active");
    });
    document.addEventListener("qwq:route-change", (event) => {
      if (event.detail?.to === "page-my-phone-home") {
        resumeWidgets();
        syncMountedRealtimeComponents();
        scheduleO3OClockTick();
      } else {
        onRouteChange();
        scheduleO3OClockTick();
      }
    });
    document.addEventListener("qwq:global-drawer-opened", () => {
      syncMountedRealtimeComponents();
      scheduleO3OClockTick();
    });
    document.addEventListener("qwq:global-drawer-closed", scheduleO3OClockTick);
    document.addEventListener("qwq:music-playback-state", (event) => syncUiiyMusicPlayback(event.detail));
    ensureO3ORuntime();
    bindWidgetRuntimeBridge();
  }

  async function init() {
    if (HOME.initialized) return; HOME.initialized = true;
    extractRegistry();
    buildRuntimeDom();
    bindEvents();
    // 唯一启动路径：先读 Dexie active，再首次 render。禁止默认布局预渲染、禁止刷新闪回旧坐标。
    try { await hydrate(); }
    catch (error) { console.error("HomeScreenManager 初始化失败", error); showError(`主屏布局初始化失败：${error?.message || error}`); }
  }

  function getState() { return HOME.layout ? clone(HOME.layout) : null; }
  function cancelActiveDrag() { cancelDrag(); }

  return Object.freeze({ init, getState, persistNow, importState, prepareImportedState, normalizeHomeLayout, getItemRect, rectsOverlap, isWithinGrid, getOccupiedCells, findFirstFreeAppCell, findFirstFreeWidgetRect, getLastOccupiedPage, compactEmptyPages, resolveAppInsert, resolveWidgetPlacement, cancelActiveDrag });
})();

window.HomeScreenManager = HomeScreenManager;