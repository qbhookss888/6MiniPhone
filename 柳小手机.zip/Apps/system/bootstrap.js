    QWQSystemUI.renderParentAppPage("theme");

    // 一次性进入页公告：只使用 清柳 的 Dexie persistenceMeta 保存展示凭据。
    // 公告凭据不属于主题状态，因此主题导入/还原不会让它重新出现。
    const QWQ_TRIAL_NOTICE_KEY = "ui.notice.qwq-paid-trial.2026-09-06";
    const QWQ_TRIAL_DEADLINE = Object.freeze({ year: 2026, month: 9, day: 7, hour: 0, minute: 0 });

    function formatQwqTrialDeadline() {
      const value = new Date(
        QWQ_TRIAL_DEADLINE.year,
        QWQ_TRIAL_DEADLINE.month - 1,
        QWQ_TRIAL_DEADLINE.day,
        QWQ_TRIAL_DEADLINE.hour,
        QWQ_TRIAL_DEADLINE.minute,
        0,
        0
      );
      const dateText = new Intl.DateTimeFormat("zh-CN", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
      }).format(value).replaceAll("/", ".");
      const weekday = new Intl.DateTimeFormat("zh-CN", { weekday: "short" }).format(value);
      const timeText = new Intl.DateTimeFormat("zh-CN", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
      }).format(value);
      return `${dateText} ${weekday} ${timeText}`;
    }

    function createQwqTrialNoticeContent(container) {
      const wrap = document.createElement("div");
      wrap.className = "qwq-trial-notice";

      const title = document.createElement("h3");
      title.className = "qwq-trial-notice-title";
      title.textContent = "免责声明";

      const body = document.createElement("div");
      body.className = "qwq-trial-notice-body";

      const p1 = document.createElement("p");
      p1.textContent = "本项目属于个人二创学习项目，仅作技术测试交流。";

      const p2 = document.createElement("p");
      p2.textContent = "服务不保障稳定性，请自行备份密钥与数据，使用风险由使用者自行承担。";

      const p3 = document.createElement("p");
      p3.textContent = "禁止商用与违规用途，如有侵权可联系作者处理。";

      body.append(p1, p2, p3);
      wrap.append(title, body);
      container.appendChild(wrap);
    }

    async function showQwqTrialNoticeOnce() {
      const theme = window.ThemeCustomization;
      if (!theme?.db || !theme?.GlobalModal) return false;
      try {
        await theme.ready;
        const db = theme.db;
        let shouldShow = false;
        await db.transaction("rw", db.persistenceMeta, async () => {
          const seen = await db.persistenceMeta.get(QWQ_TRIAL_NOTICE_KEY);
          if (seen?.value?.shown === true) return;
          await db.persistenceMeta.put({
            key: QWQ_TRIAL_NOTICE_KEY,
            value: {
              shown: true,
              shownAt: Date.now(),
              deadline: { ...QWQ_TRIAL_DEADLINE }
            },
            updatedAt: Date.now()
          });
          shouldShow = true;
        });
        if (!shouldShow) return false;
        theme.GlobalModal.alert({
          title: "免责声明",
          confirmLabel: "我已阅读并理解",
          size: "default",
          content: createQwqTrialNoticeContent,
          action: "dismiss"
        });
        return true;
      } catch (error) {
        // 不做 localStorage / 第二事实源兜底；持久化失败时宁可不弹，也不能违反“只显示一次”。
        console.error("[清柳 notice] 一次性公告状态提交失败，已取消展示以避免重复弹出。", error);
        return false;
      }
    }

    const entryButton = document.getElementById(myPhoneConfig.navigation.entry.buttonId);
    if (entryButton) {
      entryButton.addEventListener("click", () => MyPhoneManager.open(window.currentContactId ?? null));
    }

    // 动态主屏由 HomeScreenManager 统一接管。首帧保持 paint gate，直到 Dexie 正式布局 hydrate 完成，
    // 避免刷新时先绘制静态 HTML / 默认 Registry，再切换为运行时布局。
    void (async () => {
      try {
        await window.HomeScreenManager?.init?.();
      } catch (error) {
        console.error("主屏初始化失败", error);
      } finally {
        requestAnimationFrame(() => {
          document.documentElement.setAttribute("data-qwq-boot", "ready");
          // 公告在主屏首帧提交后打开；凭据会在打开前原子写入 Dexie，因此同一浏览器只展示一次。
          requestAnimationFrame(() => {
            void showQwqTrialNoticeOnce();
          });
          // 不再在首帧后自动预取全部 App，也不再自动预热 QQ/Dexie。
          // 移动端浏览器的 requestIdleCallback timeout 仍可能在主线程繁忙时强制执行，
          // 会把网络/脚本解析/IndexedDB 与用户首次滑动、点击争抢同一个窗口。
          // 主屏现在只在用户实际按下某个 App 时预取该 App 的资源。
        });
      }
    })();

    document.getElementById("theme-parent-title").addEventListener("click", () => MyPhoneManager.closeApp());

    function assertSingleGlobalUiTemplates() {
      const rules = [
        ["global drawer", "[data-ui-template=\"global-drawer\"]", 1],
        ["global modal", "[data-ui-template=\"global-modal\"]", 1],
        ["drawer overlay", "[data-ui-template=\"global-drawer-overlay\"]", 1],
        ["modal overlay", "[data-ui-template=\"global-modal-overlay\"]", 1]
      ];
      for (const [label, selector, expected] of rules) {
        const count = document.querySelectorAll(selector).length;
        if (count !== expected) console.warn(`[UI contract] ${label}: expected ${expected}, got ${count}`);
      }
    }
    assertSingleGlobalUiTemplates();

    if ("serviceWorker" in navigator && (location.protocol === "http:" || location.protocol === "https:")) {
      const runtimeBuild = String(window.__QWQ_CONFIG__?.version || "V0.0.312").replace(/^V/i, "") || "0.0.312";

      // 旧版本遗留的构建标记只清理 URL，不再通过 location.replace 触发第二次导航。
      try {
        const cleanUrl = new URL(window.location.href);
        const hadLegacyMarker = cleanUrl.searchParams.has("qwq-build") || cleanUrl.searchParams.has("qwq-reload");
        cleanUrl.searchParams.delete("qwq-build");
        cleanUrl.searchParams.delete("qwq-reload");
        if (hadLegacyMarker) history.replaceState(history.state, "", cleanUrl.toString());
      } catch (_) {}

      // 当前 worker 没有 fetch handler，不能影响本页已经加载的 bundle。
      // 因此更新 SW 只更新后台控制权，绝不为了“接管版本”刷新当前页面。
      void navigator.serviceWorker.register(`./sw.js?v=${encodeURIComponent(runtimeBuild)}`, { updateViaCache: "none" })
        .then((registration) => registration.update().catch(() => undefined))
        .catch((error) => console.warn("[清柳 PWA] service worker registration failed", error));
    }