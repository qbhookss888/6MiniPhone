/* ==========================================================================
 * 清柳 微博 App（经典脚本 / 无模块语法）
 * window.WeiboApp = { open(view), close }
 *
 * 基于 index.html 既有 DOM 绑定：
 *  - home 面板 关注/推荐 Tab（data-weibo-feed-tab）
 *  - 首页频道切换（data-weibo-channel）
 *  - 底部 5 个导航切换 .weibo-view 面板（data-weibo-nav）
 *  - 撰写面板 打开/关闭/发布（data-weibo-compose-open / compose-close / publish），
 *    发布后往当前信息流顶部插入新帖子；详情里则是写评论
 *  - 关注按钮文案切换（data-weibo-follow）
 *  - 帖子操作 分享/评论/点赞（data-weibo-post-action），计数 +1，点赞变实心
 *  - 帖子打开正文子页（data-weibo-detail-source / detail-*）
 *  - 搜索子页（search-*）、返回桌面（data-weibo-close）
 * 图标统一用 window.lucide?.createIcons?.() 注入（判空），激活/实心态用 FA solid。
 * ========================================================================== */
(() => {
  "use strict";
  const TAG = "[Weibo]";

  try {
    const root = document.getElementById("page-weibo-app");
    if (!root) return; // 页面不存在则静默退出

    const NAV_VIEWS = ["home", "super", "discover", "messages", "me"];
    const MOCK_COMMENTS = [
      "说得太对了，转发支持一下",
      "沙发！这个话题我也有同感",
      "路过点个赞，内容不错",
      "哈哈哈哈哈真实了",
      "蹲一个后续更新",
      "收藏了，慢慢看"
    ];

    const state = {
      page: root,
      bound: false,
      tab: "recommend",            // home 信息流：recommend / following
      channel: "热门",
      view: "home",
      pools: { recommend: [], following: [] },
      newPosts: [],
      followingNames: new Set(),
      detailSource: null,          // 当前正文子页对应的 feed 帖子节点
      compose: { open: false, mode: "post", target: null },
      searchOpen: false,
      history: ["微博热搜", "今日科技", "城市漫游"],
      toastTimer: 0,
      postSeq: 1
    };

    /* ---------------- 通用小工具 ---------------- */
    function escapeHTML(value) {
      return String(value).replace(/[&<>'"]/g, (char) => (
        { "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]
      ));
    }

    function formatTopics(text) {
      const safe = escapeHTML(text);
      return safe.replace(/#([^#\n]+)#/g, '<span class="weibo-topic">#$1#</span>');
    }

    function ensureIcons(scope) {
      if (!scope) return;
      try {
        const createIcons = window.lucide?.createIcons;
        if (typeof createIcons === "function") {
          createIcons({ root: scope, attrs: { "aria-hidden": "true", focusable: "false" } });
          return;
        }
      } catch (error) {
        console.warn(TAG, "图标注入失败", error);
      }
      window.QWQIcons?.hydrate?.(scope);
    }

    function toast(message) {
      const host = state.page.querySelector(".weibo-shell");
      if (!host) return;
      let el = host.querySelector(".weibo-toast");
      if (!el) {
        el = document.createElement("div");
        el.className = "weibo-toast";
        el.setAttribute("role", "status");
        host.appendChild(el);
      }
      el.textContent = String(message || "");
      el.classList.add("is-visible");
      window.clearTimeout(state.toastTimer);
      state.toastTimer = window.setTimeout(() => el.classList.remove("is-visible"), 1600);
    }

    /* 数字格式化：parseLabel("2.4万") -> 24000；formatCount(24001) -> "2.4万" */
    function parseLabel(text) {
      const raw = String(text || "").trim();
      const match = raw.match(/^([\d.]+)\s*(万|亿)?$/);
      if (!match) return 0;
      let value = Number(match[1]) || 0;
      if (match[2] === "万") value *= 10000;
      if (match[2] === "亿") value *= 100000000;
      return Math.round(value);
    }

    function formatCount(value) {
      const n = Number(value) || 0;
      if (n >= 100000000) return `${(n / 100000000).toFixed(1).replace(/\.0$/, "")}亿`;
      if (n >= 10000) return `${(n / 10000).toFixed(1).replace(/\.0$/, "")}万`;
      return String(n);
    }

    function readCount(button) {
      const stored = Number(button.dataset.weiboCount);
      if (Number.isFinite(stored) && stored > 0) return stored;
      const labelEl = button.querySelector("span:last-child") || button.querySelector("span");
      const parsed = parseLabel(labelEl?.textContent);
      button.dataset.weiboCount = String(parsed);
      return parsed;
    }

    function writeCount(button, value) {
      const next = Math.max(0, Number(value) || 0);
      button.dataset.weiboCount = String(next);
      const labelEl = button.querySelector("span:last-child") || button.querySelector("span");
      if (labelEl) labelEl.textContent = formatCount(next);
      return next;
    }

    function postNameOf(card) {
      if (!card) return "";
      const nameEl = card.querySelector("[data-weibo-detail-name], .weibo-post-name");
      return String(nameEl?.textContent || "").replace(/\s+/g, " ").trim();
    }

    /* ---------------- 初始数据采集 ---------------- */
    function captureStaticPosts() {
      const feed = state.page.querySelector("[data-weibo-feed]");
      if (!feed) return;
      const banner = feed.querySelector(".weibo-inline-banner");
      if (banner) state.banner = banner.cloneNode(true);
      const posts = Array.from(feed.querySelectorAll("article.weibo-post[data-weibo-post]"));
      posts.forEach((article) => {
        // 记录动作计数（惰性解析显示文本）
        article.querySelectorAll("[data-weibo-post-action]").forEach((button) => readCount(button));
        const name = postNameOf(article);
        const followed = Boolean(name && state.followingNames.has(name));
        const followBtn = article.querySelector("[data-weibo-follow]");
        if (followBtn) {
          followBtn.classList.toggle("is-followed", followed);
          followBtn.setAttribute("aria-pressed", followed ? "true" : "false");
          followBtn.textContent = followed ? "已关注" : "+ 关注";
        }
        const node = article.cloneNode(true);
        node.classList.remove("is-new");
        node.dataset.weiboId = `static-${state.postSeq++}`;
        state.pools.recommend.push(node);
        // “微博新鲜事”是未关注账号：只出现在推荐流；其余账号同时出现在关注流
        const isNews = name === "微博新鲜事";
        if (!isNews) {
          state.pools.following.push(node);
          state.followingNames.add(name);
        }
      });
    }

    function syncFollowButtons() {
      state.page.querySelectorAll("[data-weibo-follow]").forEach((button) => {
        const card = button.closest(".weibo-post, .weibo-detail-card");
        const name = postNameOf(card);
        const followed = Boolean(name && state.followingNames.has(name));
        button.classList.toggle("is-followed", followed);
        button.setAttribute("aria-pressed", followed ? "true" : "false");
        button.textContent = followed ? "已关注" : "+ 关注";
      });
    }

    /* ---------------- 面板 / 导航 ---------------- */
    function switchView(view) {
      if (!NAV_VIEWS.includes(view)) view = "home";
      state.view = view;
      state.page.dataset.weiboTab = view;
      state.page.querySelectorAll(".weibo-view").forEach((panel) => {
        const panelName = panel.dataset.weiboPanel;
        panel.classList.toggle("is-active", panelName === view);
        panel.setAttribute("aria-hidden", panelName === view ? "false" : "true");
      });
      state.page.querySelectorAll("[data-weibo-nav]").forEach((item) => {
        const active = item.dataset.weiboNav === view;
        item.classList.toggle("is-active", active);
        item.setAttribute("aria-current", active ? "page" : "false");
      });
      closeSearchPage(false);
      closeDetailPage(false);
      closeCompose(false);
      if (view === "home") renderFeed(state.tab);
    }

    function switchFeedTab(tab) {
      if (tab !== "following" && tab !== "recommend") return;
      state.tab = tab;
      state.page.querySelectorAll("[data-weibo-feed-tab]").forEach((item) => {
        const active = item.dataset.weiboFeedTab === tab;
        item.classList.toggle("is-active", active);
        item.setAttribute("aria-selected", active ? "true" : "false");
      });
      renderFeed(tab);
    }

    function renderFeed(tab) {
      const feed = state.page.querySelector("[data-weibo-feed]");
      if (!feed) return;
      const list = tab === "following" ? state.pools.following : state.pools.recommend;
      const nodes = list.slice();
      // 首页“实时热点”横幅保留在第一张帖子之后
      if (state.banner && nodes.length > 1) nodes.splice(1, 0, state.banner);
      feed.replaceChildren(...nodes);
      ensureIcons(feed);
    }

    function switchChannel(channel) {
      if (channel === "更多") {
        toast("更多频道正在路上，敬请期待");
        // 保持上一个频道高亮
        state.page.querySelectorAll("[data-weibo-channel]").forEach((item) => {
          item.classList.toggle("is-active", item.dataset.weiboChannel === state.channel);
        });
        return;
      }
      state.channel = channel;
      state.page.querySelectorAll("[data-weibo-channel]").forEach((item) => {
        item.classList.toggle("is-active", item.dataset.weiboChannel === channel);
      });
      const banner = state.page.querySelector(".weibo-inline-banner span");
      if (banner) banner.textContent = `已切换频道 · ${channel}热榜实时更新中`;
    }

    /* ---------------- 构建帖子节点 ---------------- */
    function buildPostNode({ author = "清柳 用户", avatar = "Q", avatarClass = "is-orange", verified = false, meta = "刚刚 · 来自 清柳 客户端", text = "", share = 0, comment = 0, like = 0, liked = false, isNew = false } = {}) {
      const article = document.createElement("article");
      article.className = "weibo-post" + (isNew ? " is-new" : "");
      article.setAttribute("data-weibo-post", "");
      article.setAttribute("data-weibo-detail-source", "");
      const id = `post-${state.postSeq++}`;
      article.dataset.weiboId = id;

      const head = document.createElement("div");
      head.className = "weibo-post-head";
      const avatarBox = document.createElement("div");
      avatarBox.className = `weibo-avatar ${avatarClass}`;
      avatarBox.textContent = String(avatar).slice(0, 1);
      const authorBox = document.createElement("div");
      authorBox.className = "weibo-post-author";
      const nameRow = document.createElement("div");
      nameRow.className = "weibo-post-name";
      nameRow.textContent = author;
      if (verified) {
        const badge = document.createElement("i");
        badge.className = "fa-solid fa-circle-check weibo-v-badge";
        badge.setAttribute("aria-hidden", "true");
        nameRow.appendChild(badge);
      }
      const metaLine = document.createElement("div");
      metaLine.className = "weibo-post-meta";
      metaLine.textContent = meta;
      authorBox.append(nameRow, metaLine);
      const follow = document.createElement("button");
      follow.type = "button";
      follow.className = "weibo-follow-button";
      follow.setAttribute("data-weibo-follow", "");
      const followed = state.followingNames.has(author);
      follow.classList.toggle("is-followed", followed);
      follow.setAttribute("aria-pressed", followed ? "true" : "false");
      follow.textContent = followed ? "已关注" : "+ 关注";
      head.append(avatarBox, authorBox, follow);

      const body = document.createElement("div");
      body.className = "weibo-post-body";
      const textEl = document.createElement("p");
      textEl.className = "weibo-post-text";
      textEl.innerHTML = formatTopics(text);
      body.appendChild(textEl);

      const actions = document.createElement("div");
      actions.className = "weibo-post-actions";
      actions.appendChild(buildActionButton("share", "square-arrow-out-up-right", share));
      actions.appendChild(buildActionButton("comment", "message-circle-more", comment));
      actions.appendChild(buildLikeButton(like, liked));

      article.append(head, body, actions);
      return article;
    }

    function buildActionButton(kind, iconName, count) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "weibo-post-action";
      button.setAttribute("data-weibo-post-action", kind);
      const icon = document.createElement("span");
      icon.className = "weibo-action-icon";
      const lucideIcon = document.createElement("i");
      lucideIcon.className = "weibo-lucide";
      lucideIcon.setAttribute("data-lucide", iconName);
      lucideIcon.setAttribute("aria-hidden", "true");
      icon.appendChild(lucideIcon);
      const label = document.createElement("span");
      label.textContent = formatCount(count);
      button.dataset.weiboCount = String(Number(count) || 0);
      button.append(icon, label);
      return button;
    }

    function buildLikeButton(count, liked) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "weibo-post-action";
      button.setAttribute("data-weibo-post-action", "like");
      button.setAttribute("data-weibo-like", "");
      button.setAttribute("aria-pressed", liked ? "true" : "false");
      if (liked) button.classList.add("is-liked");
      const icon = document.createElement("span");
      icon.className = "weibo-action-icon";
      icon.setAttribute("data-weibo-like-icon", "");
      if (liked) {
        const fa = document.createElement("i");
        fa.className = "fa-solid fa-thumbs-up";
        fa.setAttribute("aria-hidden", "true");
        icon.appendChild(fa);
      } else {
        const lucideIcon = document.createElement("i");
        lucideIcon.className = "weibo-lucide";
        lucideIcon.setAttribute("data-lucide", "thumbs-up");
        lucideIcon.setAttribute("aria-hidden", "true");
        icon.appendChild(lucideIcon);
      }
      const label = document.createElement("span");
      label.setAttribute("data-weibo-like-count", "");
      label.textContent = formatCount(count);
      button.dataset.weiboCount = String(Number(count) || 0);
      button.append(icon, label);
      return button;
    }

    /* ---------------- 操作：关注 / 转发 / 评论 / 点赞 ---------------- */
    function toggleFollow(button) {
      const card = button.closest(".weibo-post, .weibo-detail-card");
      const name = postNameOf(card);
      if (!name) {
        toast("无法识别关注对象");
        return;
      }
      if (state.followingNames.has(name)) state.followingNames.delete(name);
      else state.followingNames.add(name);
      syncFollowButtons();
      toast(state.followingNames.has(name) ? `已关注 ${name}` : `已取消关注 ${name}`);
    }

    function actionLike(button) {
      const post = button.closest(".weibo-post");
      if (!post) return;
      const liked = button.getAttribute("aria-pressed") === "true";
      const base = readCount(button);
      writeCount(button, liked ? base - 1 : base + 1);
      const nextLiked = !liked;
      button.setAttribute("aria-pressed", nextLiked ? "true" : "false");
      button.classList.toggle("is-liked", nextLiked);
      const iconBox = button.querySelector("[data-weibo-like-icon]");
      if (iconBox) {
        iconBox.replaceChildren();
        if (nextLiked) {
          const fa = document.createElement("i");
          fa.className = "fa-solid fa-thumbs-up";
          fa.setAttribute("aria-hidden", "true");
          iconBox.appendChild(fa);
        } else {
          const li = document.createElement("i");
          li.className = "weibo-lucide";
          li.setAttribute("data-lucide", "thumbs-up");
          li.setAttribute("aria-hidden", "true");
          iconBox.appendChild(li);
          ensureIcons(iconBox);
        }
      }
      syncDetailLikeState(post, nextLiked);
    }

    function syncDetailLikeState(post, liked) {
      if (state.detailSource !== post) return;
      const detailIcon = state.page.querySelector("[data-weibo-detail-like-icon]");
      const action = state.page.querySelector("[data-weibo-detail-like-action]");
      if (action) {
        action.classList.toggle("is-liked", liked);
        action.setAttribute("aria-pressed", liked ? "true" : "false");
      }
      if (detailIcon) {
        detailIcon.replaceChildren();
        if (liked) {
          const fa = document.createElement("i");
          fa.className = "fa-solid fa-thumbs-up";
          fa.setAttribute("aria-hidden", "true");
          detailIcon.appendChild(fa);
        } else {
          const li = document.createElement("i");
          li.className = "weibo-lucide";
          li.setAttribute("data-lucide", "thumbs-up");
          li.setAttribute("aria-hidden", "true");
          detailIcon.appendChild(li);
          ensureIcons(detailIcon);
        }
      }
    }

    function bumpCount(post, kind) {
      const button = post?.querySelector(`[data-weibo-post-action="${kind}"]`);
      if (!button) return 0;
      const next = readCount(button) + 1;
      writeCount(button, next);
      return next;
    }

    /* ---------------- 正文子页 ---------------- */
    function openDetail(post) {
      if (!post) return;
      const detailPage = state.page.querySelector("[data-weibo-detail-page]");
      const feedPost = post.closest(".weibo-post") || post;
      state.detailSource = feedPost;

      const avatarEl = state.page.querySelector("[data-weibo-detail-avatar]");
      const avatarSource = feedPost.querySelector(".weibo-avatar");
      const sourceClass = Array.from(avatarSource?.classList || []).find((cls) => cls.startsWith("is-"));
      if (avatarEl) {
        avatarEl.classList.remove("is-orange", "is-blue", "is-pink", "is-green", "is-purple");
        if (sourceClass) avatarEl.classList.add(sourceClass);
        avatarEl.textContent = avatarSource?.textContent?.slice(0, 1) || "微";
      }
      const nameEl = state.page.querySelector("[data-weibo-detail-name]");
      if (nameEl) nameEl.textContent = postNameOf(feedPost) || "微博用户";
      const metaEl = state.page.querySelector("[data-weibo-detail-meta]");
      const metaSource = feedPost.querySelector(".weibo-post-meta");
      if (metaEl) metaEl.textContent = metaSource?.textContent || "刚刚 · 来自微博客户端";

      const textEl = state.page.querySelector("[data-weibo-detail-text]");
      const textSource = feedPost.querySelector(".weibo-post-text");
      if (textEl) textEl.innerHTML = textSource?.innerHTML || "";

      const mediaEl = state.page.querySelector("[data-weibo-detail-media]");
      const mediaSource = feedPost.querySelector(".weibo-media-grid");
      if (mediaEl) {
        if (mediaSource) {
          const clone = mediaSource.cloneNode(true);
          mediaEl.replaceChildren(...clone.childNodes);
          mediaEl.hidden = false;
        } else {
          mediaEl.replaceChildren();
          mediaEl.hidden = true;
        }
      }

      const feedShare = readCount(feedPost.querySelector('[data-weibo-post-action="share"]'));
      const feedComment = readCount(feedPost.querySelector('[data-weibo-post-action="comment"]'));
      const feedLikeBtn = feedPost.querySelector('[data-weibo-post-action="like"]');
      const feedLike = readCount(feedLikeBtn);
      const likePressed = feedLikeBtn?.getAttribute("aria-pressed") === "true";

      const shareEl = state.page.querySelector("[data-weibo-detail-share]");
      const commentEl = state.page.querySelector("[data-weibo-detail-comment]");
      const likeEl = state.page.querySelector("[data-weibo-detail-like]");
      if (shareEl) shareEl.textContent = String(feedShare);
      if (commentEl) commentEl.textContent = String(feedComment);
      if (likeEl) likeEl.textContent = String(feedLike);
      syncDetailLikeState(feedPost, likePressed);

      // 重置互动 Tab 到评论
      setDetailTab("comment");
      renderDetailList("comment");

      detailPage.setAttribute("aria-hidden", "false");
      const scroll = detailPage.querySelector(".weibo-detail-scroll");
      if (scroll) scroll.scrollTop = 0;
    }

    function closeDetailPage(shouldToast) {
      const page = state.page.querySelector("[data-weibo-detail-page]");
      if (page) page.setAttribute("aria-hidden", "true");
      state.detailSource = null;
      if (shouldToast) toast("已返回正文列表");
    }

    function setDetailTab(tab) {
      state.page.querySelectorAll("[data-weibo-detail-tab], [data-weibo-detail-count-tab]").forEach((item) => {
        const active = item.dataset.weiboDetailTab === tab || item.dataset.weiboDetailCountTab === tab;
        item.classList.toggle("is-active", active);
        item.setAttribute("aria-selected", active ? "true" : "false");
      });
      if (["share", "comment", "like"].includes(tab)) renderDetailList(tab);
    }

    function renderDetailList(tab) {
      const list = state.page.querySelector("[data-weibo-detail-list]");
      if (!list) return;
      list.replaceChildren();
      const post = state.detailSource;
      if (tab === "comment") {
        if (post) {
          const name = postNameOf(post);
          const mock = MOCK_COMMENTS.filter((_, index) => ((name || "").length + index) % 2 === 0).slice(0, 2);
          mock.forEach((text, index) => {
            list.appendChild(buildCommentNode(`微博网友${(name.length + index) % 7 + 1}`, index % 2 ? "is-pink" : "is-blue", text));
          });
        }
        const empty = document.createElement("div");
        empty.className = "weibo-detail-empty";
        empty.textContent = "点击下方“写评论”参与讨论";
        list.appendChild(empty);
        return;
      }
      const empty = document.createElement("div");
      empty.className = "weibo-detail-empty";
      empty.textContent = tab === "share" ? "还没有人转发，点击“转发”分享给大家" : "还没有人赞过这条微博，来点个赞吧";
      list.appendChild(empty);
    }

    function buildCommentNode(name, avatarClass, text) {
      const row = document.createElement("div");
      row.className = "weibo-detail-comment";
      const avatar = document.createElement("div");
      avatar.className = `weibo-detail-comment-avatar ${avatarClass}`;
      avatar.textContent = String(name).slice(0, 1);
      const body = document.createElement("div");
      body.className = "weibo-detail-comment-body";
      const nameEl = document.createElement("div");
      nameEl.className = "weibo-detail-comment-name";
      nameEl.textContent = name;
      const textEl = document.createElement("div");
      textEl.className = "weibo-detail-comment-text";
      textEl.innerHTML = formatTopics(text);
      body.append(nameEl, textEl);
      row.append(avatar, body);
      return row;
    }

    function addMyComment(text) {
      const list = state.page.querySelector("[data-weibo-detail-list]");
      const commentTabActive = (state.page.querySelector('[data-weibo-detail-tab="comment"]') || {}).classList?.contains?.("is-active") !== false;
      if (list && commentTabActive) {
        const mock = list.querySelector(".weibo-detail-empty");
        if (mock) mock.remove();
        list.prepend(buildCommentNode("清柳 用户", "is-orange", text));
      }
      if (state.detailSource) {
        bumpCount(state.detailSource, "comment");
        const commentEl = state.page.querySelector("[data-weibo-detail-comment]");
        if (commentEl) commentEl.textContent = String(readCount(state.detailSource.querySelector('[data-weibo-post-action="comment"]')));
        setDetailTab("comment");
      }
    }

    /* ---------------- 撰写面板 ---------------- */
    function openCompose(mode, target) {
      state.compose.mode = mode === "comment" ? "comment" : "post";
      state.compose.target = mode === "comment" ? target : null;
      state.compose.open = true;
      const overlay = state.page.querySelector("[data-weibo-compose]");
      overlay.setAttribute("aria-hidden", "false");
      const textarea = overlay.querySelector("[data-weibo-compose-text]");
      if (textarea) {
        textarea.value = "";
        textarea.placeholder = state.compose.mode === "comment" ? "写评论..." : "分享新鲜事...";
        window.setTimeout(() => {
          try { textarea.focus(); } catch (error) { /* 无需处理 */ }
        }, 60);
      }
      const publish = overlay.querySelector("[data-weibo-publish]");
      if (publish) publish.disabled = true;
      const title = overlay.querySelector(".weibo-compose-title");
      if (title) title.textContent = state.compose.mode === "comment" ? "写评论" : "发微博";
    }

    function closeCompose(shouldReset) {
      state.compose.open = false;
      state.compose.mode = "post";
      state.compose.target = null;
      const overlay = state.page.querySelector("[data-weibo-compose]");
      if (overlay) overlay.setAttribute("aria-hidden", "true");
      if (shouldReset) {
        const textarea = overlay?.querySelector("[data-weibo-compose-text]");
        if (textarea) textarea.value = "";
      }
    }

    function onComposeInput() {
      const overlay = state.page.querySelector("[data-weibo-compose]");
      const textarea = overlay?.querySelector("[data-weibo-compose-text]");
      const publish = overlay?.querySelector("[data-weibo-publish]");
      if (publish) publish.disabled = !String(textarea?.value || "").trim();
    }

    function publishNow() {
      const overlay = state.page.querySelector("[data-weibo-compose]");
      const textarea = overlay?.querySelector("[data-weibo-compose-text]");
      const text = String(textarea?.value || "").trim();
      if (!text) {
        toast("先写点什么再发布吧");
        return false;
      }
      if (state.compose.mode === "comment") {
        addMyComment(text);
        closeCompose(true);
        toast("评论已发布");
        return true;
      }
      const meta = "刚刚 · 来自 清柳 客户端";
      const node = buildPostNode({
        author: "清柳 用户",
        avatar: "Q",
        avatarClass: "is-orange",
        meta,
        text,
        share: 0,
        comment: 0,
        like: 0,
        liked: false,
        isNew: true
      });
      node.querySelectorAll("[data-weibo-post-action]").forEach((button) => readCount(button));
      state.newPosts.unshift(node);
      state.pools.recommend.unshift(node);
      state.pools.following.unshift(node);
      renderFeed(state.tab);
      ensureIcons(state.page.querySelector("[data-weibo-feed]"));
      closeCompose(true);
      toast("发布成功");
      return true;
    }

    /* ---------------- 搜索子页 ---------------- */
    function openSearchPage() {
      state.searchOpen = true;
      const page = state.page.querySelector("[data-weibo-search-page]");
      page.setAttribute("aria-hidden", "false");
      state.page.querySelector("[data-weibo-search-home]").classList.remove("is-hidden");
      state.page.querySelector("[data-weibo-search-suggestions]")?.classList.add("is-hidden");
      state.page.querySelector("[data-weibo-search-results]").classList.remove("is-active");
      const input = state.page.querySelector("[data-weibo-search-page-input]");
      if (input) input.value = "";
      renderHistory();
      window.setTimeout(() => {
        try { input?.focus(); } catch (error) { /* 无需处理 */ }
      }, 60);
    }

    function closeSearchPage(shouldToast) {
      state.searchOpen = false;
      const page = state.page.querySelector("[data-weibo-search-page]");
      if (page) page.setAttribute("aria-hidden", "true");
      const results = state.page.querySelector("[data-weibo-search-results]");
      if (results) results.classList.remove("is-active");
      const home = state.page.querySelector("[data-weibo-search-home]");
      if (home) home.classList.remove("is-hidden");
      const suggestions = state.page.querySelector("[data-weibo-search-suggestions]");
      if (suggestions) suggestions.classList.add("is-hidden");
      const filterPanel = state.page.querySelector("[data-weibo-search-filter-panel]");
      if (filterPanel) filterPanel.classList.remove("is-open");
      if (shouldToast) toast("已退出搜索");
    }

    function renderHistory() {
      const wrap = state.page.querySelector("[data-weibo-search-history]");
      if (!wrap) return;
      wrap.replaceChildren();
      state.history.slice(0, 8).forEach((term) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "weibo-search-chip";
        chip.setAttribute("data-weibo-search-chip", "");
        chip.textContent = term;
        wrap.appendChild(chip);
      });
      if (!state.history.length) {
        const hint = document.createElement("span");
        hint.className = "weibo-search-chip";
        hint.textContent = "暂无搜索历史";
        wrap.appendChild(hint);
      }
    }

    function rememberHistory(term) {
      const value = String(term || "").trim();
      if (!value) return;
      state.history = [value, ...state.history.filter((item) => item !== value)].slice(0, 8);
      renderHistory();
    }

    function renderSuggestions(query) {
      const box = state.page.querySelector("[data-weibo-search-suggestions]");
      if (!box) return;
      const q = String(query || "").trim();
      box.replaceChildren();
      if (!q) {
        box.classList.add("is-hidden");
        return;
      }
      const hotSources = Array.from(state.page.querySelectorAll(".weibo-hot-item span:first-child, [data-weibo-search-topic] .weibo-search-trend-label"))
        .map((el) => String(el.textContent || "").trim())
        .filter(Boolean);
      const seeds = [...new Set([q, ...hotSources])].filter((text) => text.includes(q)).slice(0, 4);
      if (!seeds.length) seeds.push(q, q + " 最新", q + " 相关讨论");
      seeds.slice(0, 4).forEach((text) => {
        const row = document.createElement("button");
        row.type = "button";
        row.className = "weibo-search-suggestion";
        row.setAttribute("data-weibo-search-suggestion", "");
        const icon = document.createElement("i");
        icon.className = "weibo-lucide";
        icon.setAttribute("data-lucide", "search");
        icon.setAttribute("aria-hidden", "true");
        const label = document.createElement("span");
        const idx = text.indexOf(q);
        if (idx >= 0) {
          const before = document.createTextNode(text.slice(0, idx));
          const strong = document.createElement("strong");
          strong.textContent = q;
          const after = document.createTextNode(text.slice(idx + q.length));
          label.append(before, strong, after);
        } else {
          label.textContent = text;
        }
        row.append(icon, label);
        row.addEventListener("click", () => runSearch(text));
        box.appendChild(row);
      });
      box.classList.remove("is-hidden");
      ensureIcons(box);
    }

    function runSearch(query) {
      const q = String(query || "").trim();
      rememberHistory(q);
      const page = state.page.querySelector("[data-weibo-search-page]");
      const input = state.page.querySelector("[data-weibo-search-page-input]");
      if (input) input.value = q;
      const home = state.page.querySelector("[data-weibo-search-home]");
      if (home) home.classList.add("is-hidden");
      const suggestions = state.page.querySelector("[data-weibo-search-suggestions]");
      if (suggestions) suggestions.classList.add("is-hidden");
      const results = state.page.querySelector("[data-weibo-search-results]");
      results.classList.add("is-active");

      const content = state.page.querySelector("[data-weibo-search-result-content]");
      if (!content) return;
      content.replaceChildren();
      if (!q) {
        const empty = document.createElement("div");
        empty.className = "weibo-search-empty";
        empty.textContent = "请输入搜索内容";
        content.appendChild(empty);
        return;
      }
      const now = new Date();
      const meta = `${now.getHours()}:${String(now.getMinutes()).padStart(2, "0")} · 搜索结果`;
      const resultPost = buildPostNode({
        author: "微博搜索",
        avatar: "搜",
        avatarClass: "is-purple",
        verified: true,
        meta,
        text: `关于「${q}」的微博内容整理如下，点击任意帖子查看详情。\n#${q}# 讨论进行中，快来说说你的看法吧。`,
        share: 128,
        comment: 64,
        like: 521,
        liked: false
      });
      const resultPost2 = buildPostNode({
        author: "热门话题君",
        avatar: "热",
        avatarClass: "is-pink",
        meta: "10分钟前 · 来自微博搜索",
        text: `#${q}# 上榜啦！当前热度持续上升，大家正在围绕这个话题分享新鲜观点。`,
        share: 24,
        comment: 13,
        like: 96
      });
      content.append(resultPost, resultPost2);
      ensureIcons(content);
      toast(`搜索「${q}」完成`);
    }

    /* ---------------- 事件委托 ---------------- */
    function onPageClick(event) {
      const target = event.target;
      if (!(target instanceof Element)) return;

      const nav = target.closest("[data-weibo-nav]");
      if (nav) {
        switchView(nav.dataset.weiboNav);
        return;
      }
      const feedTab = target.closest("[data-weibo-feed-tab]");
      if (feedTab) {
        switchFeedTab(feedTab.dataset.weiboFeedTab);
        return;
      }
      const channel = target.closest("[data-weibo-channel]");
      if (channel) {
        switchChannel(channel.dataset.weiboChannel);
        return;
      }
      const composeOpen = target.closest("[data-weibo-compose-open]");
      if (composeOpen) {
        openCompose("post", null);
        return;
      }
      const composeClose = target.closest("[data-weibo-compose-close]");
      if (composeClose) {
        closeCompose(true);
        return;
      }
      const publish = target.closest("[data-weibo-publish]");
      if (publish) {
        publishNow();
        return;
      }
      const follow = target.closest("[data-weibo-follow]");
      if (follow) {
        toggleFollow(follow);
        return;
      }
      const postAction = target.closest("[data-weibo-post-action]");
      if (postAction) {
        const kind = postAction.dataset.weiboPostAction;
        const post = postAction.closest(".weibo-post");
        if (kind === "like") {
          actionLike(postAction);
          return;
        }
        if (kind === "share") {
          const next = bumpCount(post, "share");
          if (state.detailSource === post) {
            const el = state.page.querySelector("[data-weibo-detail-share]");
            if (el) el.textContent = String(next);
          }
          toast("转发 +1（模拟）");
          return;
        }
        if (kind === "comment") {
          bumpCount(post, "comment");
          toast("评论 +1（模拟）");
          return;
        }
        return;
      }

      const detailOpen = target.closest("[data-weibo-detail-source]");
      if (detailOpen) {
        const post = detailOpen.closest(".weibo-post");
        if (post) {
          openDetail(post);
          return;
        }
      }
      const detailClose = target.closest("[data-weibo-detail-close]");
      if (detailClose) {
        closeDetailPage(true);
        return;
      }
      const detailTabBtn = target.closest("[data-weibo-detail-tab], [data-weibo-detail-count-tab]");
      if (detailTabBtn) {
        const tab = detailTabBtn.dataset.weiboDetailTab || detailTabBtn.dataset.weiboDetailCountTab;
        setDetailTab(tab);
        return;
      }
      const detailLikeAction = target.closest("[data-weibo-detail-like-action]");
      if (detailLikeAction) {
        if (!state.detailSource) return;
        const feedBtn = state.detailSource.querySelector('[data-weibo-post-action="like"]');
        if (feedBtn) {
          // 直接复用 feed 按钮的切换逻辑，再同步回详情
          actionLike(feedBtn);
        }
        return;
      }
      const detailReply = target.closest(".weibo-detail-reply");
      if (detailReply) {
        if (!state.detailSource) {
          toast("请先打开一条微博");
          return;
        }
        openCompose("comment", state.detailSource);
        return;
      }
      const detailShareIcon = target.closest('.weibo-detail-bottom .weibo-detail-action[aria-label="转发"]');
      if (detailShareIcon) {
        if (state.detailSource) {
          const next = bumpCount(state.detailSource, "share");
          const el = state.page.querySelector("[data-weibo-detail-share]");
          if (el) el.textContent = String(next);
        }
        setDetailTab("share");
        return;
      }
      const detailCommentIcon = target.closest('.weibo-detail-bottom .weibo-detail-action[aria-label="评论"]');
      if (detailCommentIcon) {
        if (state.detailSource) openCompose("comment", state.detailSource);
        return;
      }

      const weiboClose = target.closest("[data-weibo-close]");
      if (weiboClose) {
        try {
          if (window.MyPhoneManager?.closeApp) window.MyPhoneManager.closeApp("weibo");
        } catch (error) {
          console.warn(TAG, "closeApp 调用失败", error);
        }
        return;
      }

      /* 搜索子页 */
      const searchOpen = target.closest("[data-weibo-search-open], [data-weibo-search-submit]");
      if (searchOpen) {
        const input = state.page.querySelector("[data-weibo-search-input]");
        openSearchPage();
        const pageInput = state.page.querySelector("[data-weibo-search-page-input]");
        if (input?.value && pageInput) pageInput.value = input.value;
        return;
      }
      const searchClose = target.closest("[data-weibo-search-close]");
      if (searchClose) {
        closeSearchPage(true);
        return;
      }
      const searchGo = target.closest("[data-weibo-search-go]");
      if (searchGo) {
        const input = state.page.querySelector("[data-weibo-search-page-input]");
        runSearch(input?.value);
        return;
      }
      const searchClear = target.closest("[data-weibo-search-clear]");
      if (searchClear) {
        const input = state.page.querySelector("[data-weibo-search-page-input]");
        if (input) {
          input.value = "";
          input.focus();
          renderSuggestions("");
        }
        return;
      }
      const searchHistoryClear = target.closest("[data-weibo-search-history-clear]");
      if (searchHistoryClear) {
        state.history = [];
        renderHistory();
        toast("搜索历史已清空");
        return;
      }
      const searchChip = target.closest("[data-weibo-search-chip]");
      if (searchChip) {
        runSearch(String(searchChip.textContent || "").trim());
        return;
      }
      const searchTopic = target.closest("[data-weibo-search-topic]");
      if (searchTopic) {
        const text = searchTopic.querySelector("span")?.textContent || searchTopic.textContent;
        if (!state.searchOpen) openSearchPage();
        runSearch(String(text || "").trim());
        return;
      }
      const suggestion = target.closest("[data-weibo-search-suggestion]");
      if (suggestion) {
        runSearch(suggestion.querySelector("span")?.textContent || "");
        return;
      }
      const filterToggle = target.closest("[data-weibo-search-filter-toggle]");
      if (filterToggle) {
        const panel = state.page.querySelector("[data-weibo-search-filter-panel]");
        panel?.classList.toggle("is-open");
        const open = panel?.classList.contains("is-open");
        filterToggle.setAttribute("aria-expanded", open ? "true" : "false");
        return;
      }
      const filterOption = target.closest(".weibo-search-filter-option");
      if (filterOption) {
        state.page.querySelectorAll(".weibo-search-filter-option").forEach((option) => option.classList.toggle("is-active", option === filterOption));
        toast(`筛选：${filterOption.textContent}`);
        return;
      }
      const resultTab = target.closest("[data-weibo-search-result-tab]");
      if (resultTab) {
        state.page.querySelectorAll("[data-weibo-search-result-tab]").forEach((tab) => {
          const active = tab === resultTab;
          tab.classList.toggle("is-active", active);
          tab.setAttribute("aria-selected", active ? "true" : "false");
        });
        toast(`搜索结果分类：${resultTab.textContent}`);
        return;
      }
      /* 顶部装饰性动作给出轻提示，避免“死按钮” */
      const homeTopAction = target.closest('.weibo-topbar [aria-label="签到日历"], .weibo-topbar [aria-label="活动"]');
      if (homeTopAction) {
        toast(homeTopAction.getAttribute("aria-label") === "签到日历" ? "签到日历（模拟）" : "热点活动（模拟）");
        return;
      }
    }

    function onPageInput(event) {
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (target.matches("[data-weibo-search-page-input]")) {
        if (!state.searchOpen) return;
        const query = target.value;
        if (String(query || "").trim()) renderSuggestions(query);
        else renderSuggestions("");
        return;
      }
      if (target.matches("[data-weibo-compose-text]")) {
        onComposeInput();
        return;
      }
    }

    function onPageKeydown(event) {
      const target = event.target;
      if (target instanceof Element && target.matches("[data-weibo-search-page-input]") && event.key === "Enter") {
        runSearch(target.value);
        event.preventDefault();
        return;
      }
      if (target instanceof Element && target.matches("[data-weibo-search-input]") && event.key === "Enter") {
        const value = target.value;
        openSearchPage();
        const pageInput = state.page.querySelector("[data-weibo-search-page-input]");
        if (pageInput) pageInput.value = value;
        event.preventDefault();
        return;
      }
      if (target instanceof Element && target.matches("[data-weibo-compose-text]")) {
        const publish = state.page.querySelector("[data-weibo-publish]");
        if ((event.key === "Enter" && (event.ctrlKey || event.metaKey)) && publish && !publish.disabled) {
          publishNow();
          event.preventDefault();
        }
      }
    }

    /* ---------------- 公开 API ---------------- */
    function open(view) {
      try {
        if (!state.bound) bind();
        view = String(view || "home");
        if (!NAV_VIEWS.includes(view)) view = "home";
        // 关闭可能的残留浮层，回到干净状态
        closeCompose(false);
        closeDetailPage(false);
        closeSearchPage(false);
        switchView(view);
        ensureIcons(state.page);
        console.log(TAG, "已打开", view);
        return true;
      } catch (error) {
        console.error(TAG, "打开失败", error);
        return false;
      }
    }

    function close() {
      try {
        closeCompose(false);
        closeDetailPage(false);
        closeSearchPage(false);
        return true;
      } catch (error) {
        console.error(TAG, "关闭失败", error);
        return true;
      }
    }

    function bind() {
      if (state.bound) return;
      state.bound = true;
      captureStaticPosts();
      renderFeed("recommend");
      syncFollowButtons();
      ensureIcons(state.page);
      state.page.addEventListener("click", onPageClick);
      state.page.addEventListener("input", onPageInput);
      state.page.addEventListener("keydown", onPageKeydown);
      // 从“更多”等占位按钮进入时保持可点
      console.log(TAG, "事件绑定完成");
    }

    /* ---------- 初始化 ---------- */
    // index.html 脚本均位于 body 末尾，DOM 已就绪：立即绑定一次。
    bind();

    const WeiboApp = Object.freeze({ open, close });

    if (!window.WeiboApp) {
      window.WeiboApp = WeiboApp;
    } else {
      window.WeiboApp.open = open;
      window.WeiboApp.close = close;
    }
    console.log(TAG, "模块就绪");
  } catch (error) {
    console.error("[Weibo] 初始化失败", error);
    if (!window.WeiboApp) {
      window.WeiboApp = Object.freeze({ open: () => false, close: () => true });
    }
  }
})();
