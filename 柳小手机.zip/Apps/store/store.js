/* ==========================================================================
 * 清柳 Apple Store（经典浏览器脚本 / 无模块语法 / 纯 DOM 渲染）
 *
 * window.AppleStoreApp = {
 *   open()        -> boolean  同步契约：open 时不依赖任何 async，立即渲染并返回 true
 *   close()       -> boolean  供 MyPhoneManager.runCloseHook 清理轻提示计时器
 *   openTab(tab)  -> boolean  切换 today / games / apps / arcade / search 并重渲染
 * }
 *
 * 页面 DOM 骨架来自 index.html #page-apple-store：
 *   - .apple-store-topbar：  #apple-store-title（返回主屏）、[data-apple-store-date]、
 *                            [data-apple-store-account]
 *   - [data-apple-store-content]：内容渲染目标（可滚动）
 *   - .apple-store-nav：     [data-apple-store-tab=today/games/apps/arcade] +
 *                            .apple-store-search-tab（tab=search）
 *
 * 内容：
 *   today   = 编辑精选 hero（渐变卡）+ 「今日专题」编辑行 + 「大家都在用」横向小卡
 *   games/apps/arcade = 网格卡片（首字母渐变方块模拟 icon；Arcade 另附品牌横幅）
 *   search  = 搜索框 + 热门搜索 chips + 结果列表（过滤内置演示 App 列表）
 * 所有 App 数据为下方常量数组；「获取」→「打开」切换并写入 localStorage 模拟安装。
 * ========================================================================== */
(() => {
  "use strict";
  const TAG = "[Apple Store]";

  // 契约：模块已存在且带 open 则整体跳过（避免重复初始化）
  if (window.AppleStoreApp && typeof window.AppleStoreApp.open === "function") return;

  try {
    const page = document.getElementById("page-apple-store");
    const content = page && page.querySelector("[data-apple-store-content]");
    if (!page || !content) {
      console.warn(TAG, "页面骨架缺失，模块跳过初始化");
      return;
    }

    /* ---------------- 内置演示 App 数据（14 款） ---------------- */
    const APPS = [
      { id: "note",    name: "流光笔记",   category: "效率",     rating: 4.9, price: "免费", kind: "app",    desc: "随手记录灵感，跨设备实时同步的轻量笔记。" },
      { id: "photo",   name: "云雀相册",   category: "摄影与录像", rating: 4.8, price: "免费", kind: "app",    desc: "智能整理本地相片，自动生成值得回看的回忆影集。" },
      { id: "letter",  name: "轻语信箱",   category: "社交",     rating: 4.7, price: "免费", kind: "app",    desc: "写给陌生人的一封信，慢慢等一封温柔的回音。" },
      { id: "wander",  name: "城市漫步",   category: "旅行",     rating: 4.6, price: "免费", kind: "app",    desc: "用双脚丈量街区，发现藏在小巷里的好店与故事。" },
      { id: "calm",    name: "每日冥想",   category: "健康健美", rating: 4.8, price: "免费", kind: "app",    desc: "三分钟正念练习，把呼吸还给忙碌的一天。",       tagline: "把焦虑调成静音" },
      { id: "sand",    name: "专注沙漏",   category: "工具",     rating: 4.5, price: "¥6",   kind: "app",    desc: "没有多余按钮的专注计时器，一沙一世界。" },
      { id: "dream",   name: "晚安电台",   category: "音乐",     rating: 4.5, price: "免费", kind: "app",    desc: "雨声、篝火与深夜爵士，陪你安稳入睡。" },
      { id: "stellar", name: "星穹探险",   category: "冒险",     rating: 4.8, price: "免费", kind: "game",   desc: "驾驶旧飞船穿过星云，在每个星球写下你的传说。", tagline: "向星海出发" },
      { id: "farm",    name: "像素牧场",   category: "模拟",     rating: 4.7, price: "¥18",  kind: "game",   desc: "种田、养宠、经营小镇，过像素风的慢生活。",     tagline: "把日子过成像素风" },
      { id: "cube",    name: "方块谜城",   category: "益智",     rating: 4.9, price: "免费", kind: "game",   desc: "一百道优雅谜题，一块不多，一块不少。" },
      { id: "drift",   name: "极速漂移",   category: "竞速",     rating: 4.6, price: "¥30",  kind: "game",   desc: "在霓虹城市里贴地飞行，轮胎冒烟才算转弯。" },
      { id: "paper",   name: "折纸王国",   category: "益智",     rating: 4.7, price: "免费", kind: "arcade", desc: "折一只纸鹤，就能飞过整片纸做的海洋。" },
      { id: "garage",  name: "银河修理厂", category: "模拟",     rating: 4.8, price: "免费", kind: "arcade", desc: "收集零件修理坠落的飞船，听听船员们的故事。", tagline: "宇宙第一修理员的日常" },
      { id: "tune",    name: "节奏星环",   category: "音游",     rating: 4.9, price: "免费", kind: "arcade", desc: "沿着光轨击打节拍，把整个星系重新混音。" }
    ];
    const APP_BY_ID = Object.create(null);
    APPS.forEach((app) => { APP_BY_ID[app.id] = app; });

    // 今日编辑配置
    const FEATURED_ID = "stellar";
    const TODAY_PICKS = [
      { id: "calm",   kicker: "编辑精选 · 健康健美" },
      { id: "farm",   kicker: "本周推荐 · 模拟" },
      { id: "garage", kicker: "Arcade · 原创" }
    ];
    const POPULAR_IDS = ["cube", "tune", "note", "garage", "photo", "calm"];

    // 渐变画板（图标 / hero / 小卡共用，全部深色渐变保证白字可读）
    const GRADIENTS = [
      ["#5E5CE6", "#3634A3"], ["#0A84FF", "#0045A8"], ["#FF375F", "#B8002E"],
      ["#248A3D", "#0F5C26"], ["#FF9F0A", "#C96400"], ["#BF5AF2", "#6B1FA3"],
      ["#32ADE6", "#0B5ED7"], ["#FF6482", "#A3002A"], ["#00C7BE", "#007A75"],
      ["#8E8E93", "#48484A"], ["#C99600", "#8A6500"], ["#AF52DE", "#5A1E8A"],
      ["#FF2D55", "#8E1E3B"], ["#64D2FF", "#0063D6"]
    ];

    const TABS = ["today", "games", "apps", "arcade", "search"];
    const TAB_TITLES = { today: "今日", games: "游戏", apps: "App", arcade: "Arcade", search: "搜索" };

    const STORE_KEY = "qwq.appstore.installed.v1";
    const WEEKDAYS = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];

    const state = {
      tab: "today",
      query: "",
      bound: false,
      installed: new Set(),
      toastTimer: 0
    };
    let openLogFlag = false;

    const els = {
      title: page.querySelector("#apple-store-title"),
      date: page.querySelector("[data-apple-store-date]"),
      account: page.querySelector("[data-apple-store-account]"),
      topbar: page.querySelector(".apple-store-topbar"),
      nav: page.querySelector(".apple-store-nav")
    };

    /* ---------------- 通用小工具 ---------------- */
    function log(...args) { console.log(TAG, ...args); }
    function warn(...args) { console.warn(TAG, ...args); }

    function escapeHTML(value) {
      return String(value ?? "").replace(/[&<>'"]/g, (ch) => (
        { "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[ch]
      ));
    }

    function getApp(id) { return APP_BY_ID[id] || null; }
    function isInstalled(id) { return state.installed.has(id); }
    function getLabel(app) { return isInstalled(app.id) ? "打开" : (app.price === "免费" ? "获取" : app.price); }

    function gradientOf(app) {
      let hash = 0;
      const seed = String(app.id || app.name);
      for (let i = 0; i < seed.length; i += 1) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
      const pair = GRADIENTS[hash % GRADIENTS.length];
      return `linear-gradient(145deg, ${pair[0]}, ${pair[1]})`;
    }

    function iconHTML(app, sizeClass) {
      const letter = escapeHTML(String(app.name).slice(0, 1) || "?");
      return `<span class="apple-store-icon ${sizeClass || "is-md"}" style="--icon-grad:${gradientOf(app)}" aria-hidden="true"><b>${letter}</b></span>`;
    }

    function ratingHTML(app) {
      return `<span class="apple-store-rating"><i class="fa-solid fa-star" aria-hidden="true"></i>${app.rating.toFixed(1)}</span>`;
    }

    function getButtonHTML(app, extraClass) {
      const installed = isInstalled(app.id);
      return `<button type="button" class="apple-store-get ${extraClass || ""}${installed ? " is-installed" : ""}" data-store-get="${app.id}" aria-label="${installed ? "打开" : "获取"} ${escapeHTML(app.name)}">${installed ? "打开" : escapeHTML(getLabel(app))}</button>`;
    }

    /* 存档：模拟“已获取”状态（localStorage 尽力而为） */
    function loadInstalled() {
      try {
        const raw = window.localStorage && window.localStorage.getItem(STORE_KEY);
        if (raw) {
          const list = JSON.parse(raw);
          if (Array.isArray(list)) list.forEach((id) => { if (APP_BY_ID[id]) state.installed.add(id); });
        }
      } catch (error) { warn("读取安装记录失败", error); }
    }
    function persistInstalled() {
      try {
        window.localStorage && window.localStorage.setItem(STORE_KEY, JSON.stringify(Array.from(state.installed)));
      } catch (error) { warn("保存安装记录失败", error); }
    }

    /* ---------------- 轻提示 ---------------- */
    function showToast(message) {
      const host = page.querySelector(".apple-store-toast") || (() => {
        const node = document.createElement("div");
        node.className = "apple-store-toast";
        node.setAttribute("role", "status");
        page.appendChild(node);
        return node;
      })();
      host.textContent = String(message || "");
      host.classList.add("is-visible");
      window.clearTimeout(state.toastTimer);
      state.toastTimer = window.setTimeout(() => host.classList.remove("is-visible"), 1700);
    }

    function notify(message) {
      const modal = window.ThemeCustomization && window.ThemeCustomization.GlobalModal;
      if (modal && typeof modal.alert === "function") {
        modal.alert({ title: "Apple Store", message: String(message), confirmLabel: "知道了", action: "dismiss" });
        return;
      }
      showToast(String(message));
    }

    /* ---------------- 日期（MM月dd日 EEEE） ---------------- */
    function todayText() {
      const now = new Date();
      const m = String(now.getMonth() + 1).padStart(2, "0");
      const d = String(now.getDate()).padStart(2, "0");
      return `${m}月${d}日 ${WEEKDAYS[now.getDay()]}`;
    }

    /* ---------------- 渲染：today ---------------- */
    function renderToday() {
      const featured = getApp(FEATURED_ID) || APPS[0];
      const heroLetter = escapeHTML(String(featured.name).slice(0, 1));
      const heroKicker = featured.kind === "arcade" ? "Arcade · 本周主打" : "今日专题 · 编辑精选";

      const sections = [];
      const hero = `<article class="apple-store-hero" style="--hero-grad:${gradientOf(featured)}" data-store-detail="${featured.id}" role="button" tabindex="0" aria-label="今日专题：${escapeHTML(featured.name)}">
        <span class="apple-store-hero-letter" aria-hidden="true">${heroLetter}</span>
        <div class="apple-store-hero-body">
          <span class="apple-store-hero-kicker">${heroKicker}</span>
          <h2 class="apple-store-hero-title">${escapeHTML(featured.tagline || featured.name)}</h2>
          <p class="apple-store-hero-sub">${escapeHTML(featured.desc)}</p>
          <div class="apple-store-hero-foot">
            ${iconHTML(featured, "is-xs apple-store-hero-appicon")}
            <span class="apple-store-hero-appname">${escapeHTML(featured.name)}</span>
            <span class="apple-store-hero-appmeta">${escapeHTML(featured.category)} · ${featured.rating.toFixed(1)}</span>
            <span class="apple-store-hero-arrow" aria-hidden="true"><i class="fa-solid fa-chevron-right"></i></span>
          </div>
        </div>
      </article>`;

      // 今日专题：编辑行
      const rows = TODAY_PICKS.map((pick) => {
        const app = getApp(pick.id);
        if (!app) return "";
        const line = app.tagline || app.desc;
        return `<div class="apple-store-editorial" data-store-detail="${app.id}" role="button" tabindex="0" aria-label="查看 ${escapeHTML(app.name)}">
          ${iconHTML(app, "is-md")}
          <span class="apple-store-editorial-copy">
            <span class="apple-store-editorial-kicker">${escapeHTML(pick.kicker)}</span>
            <strong class="apple-store-editorial-line">${escapeHTML(line)}</strong>
            <span class="apple-store-editorial-note">${escapeHTML(app.name)} · ${escapeHTML(app.desc)}</span>
          </span>
          <i class="fa-solid fa-chevron-right apple-store-editorial-chevron" aria-hidden="true"></i>
        </div>`;
      }).join("");

      // 大家都在用：横向小卡
      const railCards = POPULAR_IDS.map((id) => {
        const app = getApp(id);
        if (!app) return "";
        return `<div class="apple-store-rail-card" data-store-detail="${app.id}" role="button" tabindex="0" aria-label="查看 ${escapeHTML(app.name)}">
          <div class="apple-store-rail-art" style="--rail-grad:${gradientOf(app)}">
            <span class="apple-store-rail-art-letter" aria-hidden="true">${escapeHTML(String(app.name).slice(0, 1))}</span>
            <span class="apple-store-rail-tag">热门</span>
          </div>
          <div class="apple-store-rail-body">
            <span class="apple-store-rail-name">${escapeHTML(app.name)}</span>
            <span class="apple-store-rail-meta"><span>${escapeHTML(app.category)}</span>${ratingHTML(app)}</span>
            ${getButtonHTML(app, "apple-store-rail-get")}
          </div>
        </div>`;
      }).join("");

      sections.push(hero);
      if (rows) {
        sections.push(`<section class="apple-store-group" aria-label="今日专题">
          <h2 class="apple-store-group-label">今日专题<small>Editor's Picks</small></h2>
          <div class="apple-store-editorial-list">${rows}</div>
        </section>`);
      }
      sections.push(`<section class="apple-store-group" aria-label="大家都在用">
        <h2 class="apple-store-group-label">大家都在用<small>Top Charts</small></h2>
        <div class="apple-store-rail">${railCards}</div>
      </section>`);
      return sections.join("");
    }

    /* ---------------- 渲染：网格页（games / apps / arcade） ---------------- */
    function renderGrid(kind) {
      const pool = APPS.filter((app) => app.kind === kind);
      const titleMap = { games: "游戏", apps: "App", arcade: "Arcade" };
      const banner = kind === "arcade"
        ? `<section class="apple-store-arcade-banner" aria-label="Arcade 品牌横幅">
             <span class="apple-store-arcade-wordmark">Arcade</span>
             <span class="apple-store-arcade-sub">原创游戏合集 · 无广告 · 无内购 · 会员畅玩（模拟订阅）</span>
             <span class="apple-store-arcade-tags"><span>${pool.length} 款原创</span><span>全平台存档</span><span>离线可玩</span></span>
           </section>`
        : "";
      const cards = pool.map((app) => `
        <article class="apple-store-grid-card" data-store-detail="${app.id}" role="button" tabindex="0" aria-label="查看 ${escapeHTML(app.name)}">
          ${iconHTML(app, "is-lg")}
          <h3 class="apple-store-grid-name">${escapeHTML(app.name)}</h3>
          <p class="apple-store-grid-meta"><span>${escapeHTML(app.category)}</span>${ratingHTML(app)}${kind === "arcade" ? '<span class="apple-store-arcade-badge">Arcade</span>' : ""}</p>
          <p class="apple-store-grid-desc">${escapeHTML(app.desc)}</p>
          ${getButtonHTML(app)}
        </article>`).join("");
      const empty = pool.length ? "" : `<div class="apple-store-empty"><i class="fa-solid fa-box-open" aria-hidden="true"></i><span class="apple-store-empty-title">这个分类暂时空空如也</span><span class="apple-store-empty-note">稍后再来看看吧</span></div>`;
      return `${banner}<div class="apple-store-grid" aria-label="${titleMap[kind]}">${cards}</div>${empty}`;
    }

    /* ---------------- 渲染：search ---------------- */
    function searchApps(rawQuery) {
      const query = String(rawQuery || "").trim().toLowerCase();
      if (!query) return [];
      return APPS.filter((app) => {
        const hay = `${app.name} ${app.category} ${app.desc} ${app.tagline || ""} ${app.price} ${app.kind}`.toLowerCase();
        return hay.includes(query);
      });
    }

    function searchResultHTML(query) {
      const hits = searchApps(query);
      if (!hits.length) {
        return `<div class="apple-store-empty">
          <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
          <span class="apple-store-empty-title">没有找到相关 App</span>
          <span class="apple-store-empty-note">换个关键词试试：名称、分类或描述都行</span>
        </div>`;
      }
      const rows = hits.map((app) => `
        <div class="apple-store-search-row" data-store-detail="${app.id}" role="button" tabindex="0" aria-label="查看 ${escapeHTML(app.name)}">
          ${iconHTML(app, "is-sm")}
          <span class="apple-store-search-row-copy">
            <strong class="apple-store-search-row-name">${escapeHTML(app.name)}</strong>
            <span class="apple-store-search-row-meta"><span>${escapeHTML(app.category)}</span>${ratingHTML(app)}</span>
          </span>
          ${getButtonHTML(app)}
        </div>`).join("");
      return `<div class="apple-store-search-list" aria-label="搜索结果">${rows}</div>`;
    }

    const SEARCH_CHIPS = ["冥想", "星穹探险", "像素", "摄影", "音游", "效率", "Arcade", "免费"];
    const SEARCH_BROWSE = [
      { tab: "games", label: "游戏" },
      { tab: "apps", label: "App" },
      { tab: "arcade", label: "Arcade" }
    ];

    function renderSearch() {
      const chips = SEARCH_CHIPS.map((word) => `<button type="button" class="apple-store-chip" data-store-chip="${escapeHTML(word)}">${escapeHTML(word)}</button>`).join("");
      const browse = SEARCH_BROWSE.map((item) => `<button type="button" data-store-goto="${item.tab}">${item.label}</button>`).join("");
      const query = state.query;
      const hasQuery = Boolean(query.trim());
      return `
        <div class="apple-store-search-panel" data-store-search-panel>
          <label class="apple-store-search-box">
            <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
            <input class="apple-store-search-input" data-store-search-input type="search" autocomplete="off" enterkeyhint="search"
              placeholder="搜索名称、分类、描述…" value="${escapeHTML(query)}" aria-label="搜索 App Store">
            <button type="button" class="apple-store-search-clear" data-store-search-clear aria-label="清除搜索"${hasQuery ? "" : " hidden"}><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
          </label>
          <section class="apple-store-search-suggest" data-store-search-suggest${hasQuery ? " hidden" : ""} aria-label="搜索建议">
            <h2 class="apple-store-search-hint">热门搜索</h2>
            <div class="apple-store-chips">${chips}</div>
            <p class="apple-store-browse">没有灵感？去 ${browse} 逛逛</p>
          </section>
          <section data-store-search-result aria-live="polite">${hasQuery ? searchResultHTML(query) : ""}</section>
        </div>`;
    }

    /* ---------------- 顶部同步：日期 + 标题 + tab 态 + 占位测量 ---------------- */
    function refreshDate() {
      if (els.date) els.date.textContent = todayText();
    }

    function syncPadding() {
      window.requestAnimationFrame(() => {
        const barHeight = els.topbar ? els.topbar.offsetHeight : 0;
        if (barHeight > 0) content.style.setProperty("--apple-content-pad-top", `${barHeight + 4}px`);
        const navHeight = els.nav ? els.nav.offsetHeight : 0;
        if (navHeight > 0) content.style.setProperty("--apple-content-pad-bottom", `${navHeight + 28}px`);
      });
    }

    function applyTabUI(tab) {
      page.dataset.storeTab = tab;
      if (els.title) els.title.textContent = TAB_TITLES[tab] || "今日";
      page.querySelectorAll("[data-apple-store-tab]").forEach((node) => {
        const active = node.dataset.appleStoreTab === tab;
        node.classList.toggle("is-active", active);
        if (active) node.setAttribute("aria-current", "page");
        else node.removeAttribute("aria-current");
      });
    }

    /* ---------------- 内容渲染 ---------------- */
    function renderTab(tab) {
      const name = TABS.includes(tab) ? tab : "today";
      state.tab = name; // 立即固化当前页，供获取/详情后的局部重渲染使用
      let html = "";
      if (name === "today") html = renderToday();
      else if (name === "search") html = renderSearch();
      else html = renderGrid({ games: "game", apps: "app", arcade: "arcade" }[name]);
      content.innerHTML = html;
      applyTabUI(name);
      content.scrollTop = 0;
      syncPadding();
      return true;
    }

    /* ---------------- 交互 ---------------- */
    function goHome() {
      try {
        if (window.MyPhoneManager && typeof window.MyPhoneManager.closeApp === "function") {
          window.MyPhoneManager.closeApp("appstore");
          return true;
        }
      } catch (error) { warn("closeApp 调用失败", error); }
      try {
        if (window.MyPhoneManager && typeof window.MyPhoneManager.open === "function") {
          window.MyPhoneManager.open();
          return true;
        }
      } catch (error) { warn("返回主屏失败", error); }
      try {
        document.dispatchEvent(new CustomEvent("qwq:system:back", { detail: { app: "appstore" } }));
        return true;
      } catch (error) { warn("返回事件派发失败", error); }
      return false;
    }

    function handleGet(id) {
      const app = getApp(id);
      if (!app) return;
      if (isInstalled(id)) {
        showToast(`正在打开「${app.name}」…（模拟）`);
        return;
      }
      state.installed.add(id);
      persistInstalled();
      renderTab(state.tab);
      showToast(`已获取「${app.name}」${app.price === "免费" ? "" : `，价值 ${app.price}（模拟）`}`);
    }

    function openDetail(id) {
      const app = getApp(id);
      if (!app) return;
      const modal = window.ThemeCustomization && window.ThemeCustomization.GlobalModal;
      const status = isInstalled(id) ? "已获取，可直接打开（模拟）" : `${app.price === "免费" ? "免费获取（模拟）" : `${app.price} 获取（模拟）`}`;
      if (modal && typeof modal.alert === "function") {
        modal.alert({
          title: `${app.name}`,
          message: `${app.desc}\n\n分类：${app.category}\n评分：${app.rating.toFixed(1)} / 5 · ${status}`,
          confirmLabel: "知道了",
          action: "dismiss"
        });
        return;
      }
      showToast(`${app.name} · ${app.category} · ${app.rating.toFixed(1)} 分`);
    }

    function setQuery(value) {
      state.query = String(value || "");
      const panel = content.querySelector("[data-store-search-panel]");
      if (!panel) return;
      const suggest = panel.querySelector("[data-store-search-suggest]");
      const result = panel.querySelector("[data-store-search-result]");
      const clear = panel.querySelector("[data-store-search-clear]");
      const hasQuery = Boolean(state.query.trim());
      if (suggest) suggest.hidden = hasQuery;
      if (clear) clear.hidden = !hasQuery;
      if (result) result.innerHTML = hasQuery ? searchResultHTML(state.query) : "";
    }

    function bindEvents() {
      if (state.bound || !page) return;
      state.bound = true;

      page.querySelectorAll("[data-apple-store-tab]").forEach((tab) => {
        tab.addEventListener("click", () => openTab(tab.dataset.appleStoreTab));
      });
      if (els.title) els.title.addEventListener("click", goHome);
      if (els.account) els.account.addEventListener("click", () => notify("这里是模拟账户：无需登录，所有 App 免费畅玩（清柳 Listener）"));

      // 内容区事件委托（重渲染后依然有效）
      content.addEventListener("click", (event) => {
        const getEl = event.target.closest("[data-store-get]");
        if (getEl) {
          event.stopPropagation();
          handleGet(getEl.dataset.storeGet);
          return;
        }
        const chip = event.target.closest("[data-store-chip]");
        if (chip) {
          const input = content.querySelector("[data-store-search-input]");
          if (input) input.value = chip.dataset.storeChip || "";
          setQuery(input ? input.value : chip.dataset.storeChip);
          return;
        }
        const goto = event.target.closest("[data-store-goto]");
        if (goto) {
          openTab(goto.dataset.storeGoto);
          return;
        }
        if (event.target.closest("[data-store-search-clear]")) {
          const input = content.querySelector("[data-store-search-input]");
          if (input) input.value = "";
          setQuery("");
          return;
        }
        const detail = event.target.closest("[data-store-detail]");
        if (detail) openDetail(detail.dataset.storeDetail);
      });

      // 搜索输入（input 事件冒泡到内容区委托，避免重渲染打断焦点）
      content.addEventListener("input", (event) => {
        if (event.target && event.target.matches && event.target.matches("[data-store-search-input]")) {
          setQuery(event.target.value);
        }
      });

      // 键盘激活（Enter / Space 打开详情）
      content.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") return;
        const target = event.target;
        if (target && target.matches && target.matches("[data-store-detail]")) {
          event.preventDefault();
          openDetail(target.dataset.storeDetail);
        }
      });

      window.addEventListener("resize", syncPadding);
      refreshDate();
    }

    /* ---------------- 公共契约 ---------------- */
    function open() {
      if (!page) return false;
      bindEvents();
      renderTab(state.tab);
      if (!openLogFlag) {
        openLogFlag = true;
        log(`已打开（tab=${state.tab}）`);
      }
      return true;
    }

    function close() {
      window.clearTimeout(state.toastTimer);
      return true;
    }

    function openTab(tab) {
      if (!page) return false;
      renderTab(tab);
      return true;
    }

    loadInstalled();
    window.AppleStoreApp = Object.freeze({
      open,
      close,
      openTab,
      // 便于调试 / 其它模块读取
      getState: () => ({ tab: state.tab, installed: Array.from(state.installed), total: APPS.length })
    });
    log(`模块就绪 · 演示应用 ${APPS.length} 款 · tabs=${TABS.join("/")}`);
  } catch (error) {
    console.error("[Apple Store] 初始化失败", error);
  }
})();
