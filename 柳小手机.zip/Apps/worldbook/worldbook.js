/* =============================================================================
 * 世界书（World Book）App —— 经典浏览器脚本，无 import / export / top-level await。
 *
 * 对外契约：
 *   window.WorldBookApp        —— open() / close()，页面路由与 QQ 运行时共用。
 *   window.WorldBookRepository —— QQ 读提示词上下文的核心数据运行时：
 *       listEnabledEntriesForConversation(conversationId[, currentMessage])
 *       永不抛错、缺数据返回 []。
 *
 * 数据（window.ThemeCustomization.db, Dexie）：
 *   worldBooks          &worldBookId, &name, scope, createdAt, updatedAt
 *   worldBookEntries    &entryId, worldBookId, priority, injectionPosition, createdAt, updatedAt …
 *   worldBookBindings   &bindingId, conversationId, worldBookId, entryId, enabled, createdAt, updatedAt …
 *
 * 语义：
 *   scope === "global" 的世界书自动挂载全部条目到任意会话；
 *   局部书（local）需要整本绑定（entryId === null）或逐条绑定（entryId != null）。
 *   全部入口 try/catch，console 前缀 [World Book]。
 * ========================================================================== */
(function () {
  "use strict";

  var TAG = "[World Book]";
  var REPO_MARKER = "__qwqWorldBookRepository__";
  var APP_MARKER = "__qwqWorldBookApp__";
  var POSITIONS = ["before", "middle", "after"];
  var POSITION_LABELS = { before: "前置", middle: "中置", after: "后置" };

  /* ---------------- 基础工具 ---------------- */

  function uid(prefix) {
    var rand = "";
    try {
      if (globalThis.crypto && typeof globalThis.crypto.randomUUID === "function") {
        return prefix + "-" + globalThis.crypto.randomUUID();
      }
    } catch (_) { /* fallthrough */ }
    try {
      if (globalThis.crypto && typeof globalThis.crypto.getRandomValues === "function") {
        var bytes = new Uint8Array(8);
        globalThis.crypto.getRandomValues(bytes);
        for (var i = 0; i < bytes.length; i += 1) rand += bytes[i].toString(16).padStart(2, "0");
        return prefix + "-" + rand;
      }
    } catch (_) { /* fallthrough */ }
    return prefix + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
  }

  function normalizeScope(value) {
    return value === "global" ? "global" : "local";
  }

  function normalizePosition(value) {
    return POSITIONS.indexOf(value) >= 0 ? value : "before";
  }

  function toPriority(value) {
    var number = Number(value);
    return Number.isFinite(number) ? number : 0;
  }

  function toStringValue(value) {
    if (value === null || value === undefined) return "";
    return String(value);
  }

  function toIsoTimestamp() {
    return new Date().toISOString();
  }

  function cloneRow(row) {
    if (!row || typeof row !== "object") return null;
    return Object.assign({}, row);
  }

  function wrapError(error, fallback) {
    if (error instanceof Error) return error;
    return new Error(fallback || String(error || "未知错误"));
  }

  /* ---------------- 主题持久化运行时 ---------------- */

  var runtimePromise = null;

  function themeRuntime() {
    if (!runtimePromise) {
      runtimePromise = (async function () {
        var theme = window.ThemeCustomization;
        if (!theme || !theme.db || !theme.ready || typeof theme.ready.then !== "function") {
          throw new Error("主题持久化运行时尚未就绪");
        }
        await theme.ready;
        if (!theme.db) throw new Error("主题数据库不可用");
        return theme;
      })().catch(function (error) {
        runtimePromise = null;
        throw error;
      });
    }
    return runtimePromise;
  }

  function database() {
    return themeRuntime().then(function (theme) { return theme.db; });
  }

  function globalDrawer() {
    return themeRuntime().then(function (theme) {
      if (!theme.GlobalDrawer || typeof theme.GlobalDrawer.open !== "function") {
        throw new Error("全局抽屉运行时不可用");
      }
      return theme.GlobalDrawer;
    });
  }

  function globalModal() {
    return themeRuntime().then(function (theme) {
      if (!theme.GlobalModal || typeof theme.GlobalModal.open !== "function") {
        throw new Error("全局弹窗运行时不可用");
      }
      return theme.GlobalModal;
    });
  }

  function drawerUI() {
    return themeRuntime().then(function (theme) {
      return theme.DrawerUI || null;
    });
  }

  /* ---------------- WorldBookRepository（QQ 运行时依赖） ---------------- */

  // QQ worldBookBlock 需要的字段：content / injectionPosition / priority / enabled，
  // title 为可选项（缺失时 QQ 显示「未命名条目」）。列表顺序不要求按位置分组。
  function toEntryRecord(row) {
    var title = typeof row.title === "string" ? row.title.trim() : "";
    var record = {
      entryId: row.entryId,
      worldBookId: row.worldBookId,
      content: toStringValue(row.content),
      priority: toPriority(row.priority),
      injectionPosition: normalizePosition(row.injectionPosition),
      enabled: true
    };
    if (title) record.title = title;
    return record;
  }

  async function listEnabledEntriesForConversation(conversationId, currentMessage) {
    try {
      var cid = toStringValue(conversationId).trim();
      if (!cid) return [];
      var dbx = await database();

      var bindings = await dbx.worldBookBindings
        .where("conversationId").equals(cid).toArray();
      var books = await dbx.worldBooks.toArray();

      var bookById = new Map();
      books.forEach(function (book) { bookById.set(book.worldBookId, book); });

      // 1) 整本启用：全局书无条件 + 绑定行 entryId === null 且 enabled 的局部书。
      var mountIds = new Set();
      bookById.forEach(function (book, worldBookId) {
        if (book.scope === "global") mountIds.add(worldBookId);
      });
      bindings.forEach(function (binding) {
        if (binding.enabled !== true) return;
        var isWholeBook = binding.entryId === null || binding.entryId === undefined;
        if (isWholeBook && bookById.has(binding.worldBookId)) mountIds.add(binding.worldBookId);
      });

      // 2) 逐条绑定：绑定行 entryId != null 且 enabled，所在书必须仍存在。
      var boundEntryIds = new Set();
      bindings.forEach(function (binding) {
        if (binding.enabled !== true) return;
        if (binding.entryId === null || binding.entryId === undefined) return;
        if (!bookById.has(binding.worldBookId)) return;
        boundEntryIds.add(String(binding.entryId));
      });

      // 3) 汇总条目（按 entryId 去重），content 恒为字符串、priority 恒为数字。
      var collected = new Map();
      function collect(row) {
        if (!row || !row.entryId || collected.has(row.entryId)) return;
        collected.set(row.entryId, toEntryRecord(row));
      }
      for (var worldBookId of mountIds) {
        var rows = await dbx.worldBookEntries.where("worldBookId").equals(worldBookId).toArray();
        rows.forEach(collect);
      }
      if (boundEntryIds.size) {
        var direct = await dbx.worldBookEntries.bulkGet(Array.from(boundEntryIds));
        direct.forEach(collect);
      }

      var result = Array.from(collected.values());
      result.sort(function (a, b) {
        if (a.priority !== b.priority) return a.priority - b.priority;
        return a.entryId < b.entryId ? -1 : a.entryId > b.entryId ? 1 : 0;
      });
      return result;
    } catch (error) {
      console.warn(TAG, "listEnabledEntriesForConversation 失败，已返回空列表：", error && error.message ? error.message : error);
      return [];
    }
  }

  async function getBooks() {
    var dbx = await database();
    var rows = await dbx.worldBooks.toArray();
    rows.sort(function (a, b) {
      var at = Number(a.createdAt) || 0;
      var bt = Number(b.createdAt) || 0;
      if (at !== bt) return at - bt;
      return a.name < b.name ? -1 : a.name > b.name ? 1 : 0;
    });
    return rows.map(cloneRow);
  }

  async function getBook(worldBookId) {
    var dbx = await database();
    return cloneRow(await dbx.worldBooks.get(String(worldBookId || "")));
  }

  async function getEntries(worldBookId) {
    var dbx = await database();
    var rows = await dbx.worldBookEntries.where("worldBookId").equals(String(worldBookId || "")).toArray();
    rows.sort(function (a, b) {
      if (toPriority(a.priority) !== toPriority(b.priority)) return toPriority(a.priority) - toPriority(b.priority);
      return a.entryId < b.entryId ? -1 : a.entryId > b.entryId ? 1 : 0;
    });
    return rows.map(cloneRow);
  }

  async function getEntry(entryId) {
    var dbx = await database();
    return cloneRow(await dbx.worldBookEntries.get(String(entryId || "")));
  }

  // conversationId 传空则返回全部绑定，否则按会话过滤。
  async function getBindings(conversationId) {
    var dbx = await database();
    var cid = toStringValue(conversationId).trim();
    var rows = cid
      ? await dbx.worldBookBindings.where("conversationId").equals(cid).toArray()
      : await dbx.worldBookBindings.toArray();
    return rows.map(cloneRow);
  }

  async function createBook(input) {
    var dbx = await database();
    var name = toStringValue(input && input.name).trim();
    if (!name) throw new Error("请填写世界书名称");
    var scope = normalizeScope(input && input.scope);
    var now = Date.now();
    var row = {
      worldBookId: uid("worldbook"),
      name: name,
      scope: scope,
      createdAt: now,
      updatedAt: now
    };
    await dbx.worldBooks.add(row); // 重名会抛 ConstraintError，交由调用方展示
    return cloneRow(row);
  }

  async function updateBook(worldBookId, patch) {
    var dbx = await database();
    var id = String(worldBookId || "");
    var existing = await dbx.worldBooks.get(id);
    if (!existing) throw new Error("世界书不存在或已被删除");
    var next = {};
    if (patch && typeof patch.name !== "undefined") {
      var name = toStringValue(patch.name).trim();
      if (!name) throw new Error("世界书名称不能为空");
      next.name = name;
    }
    if (patch && typeof patch.scope !== "undefined") next.scope = normalizeScope(patch.scope);
    if (Object.keys(next).length) {
      next.updatedAt = Date.now();
      await dbx.worldBooks.update(id, next);
    }
    return cloneRow(await dbx.worldBooks.get(id));
  }

  async function createEntry(input) {
    var dbx = await database();
    var bookId = toStringValue(input && input.worldBookId);
    if (!bookId) throw new Error("请选择所属世界书");
    var book = await dbx.worldBooks.get(bookId);
    if (!book) throw new Error("所属世界书不存在或已被删除");
    var now = Date.now();
    var row = {
      entryId: uid("worldbook-entry"),
      worldBookId: bookId,
      title: toStringValue(input && input.title).trim(),
      content: toStringValue(input && input.content),
      priority: toPriority(input && input.priority),
      injectionPosition: normalizePosition(input && input.injectionPosition),
      createdAt: now,
      updatedAt: now
    };
    await dbx.worldBookEntries.add(row);
    return cloneRow(row);
  }

  async function updateEntry(entryId, patch) {
    var dbx = await database();
    var id = String(entryId || "");
    var existing = await dbx.worldBookEntries.get(id);
    if (!existing) throw new Error("条目不存在或已被删除");
    var next = {};
    var patchObject = patch && typeof patch === "object" ? patch : {};
    if (typeof patchObject.title !== "undefined") next.title = toStringValue(patchObject.title).trim();
    if (typeof patchObject.content !== "undefined") next.content = toStringValue(patchObject.content);
    if (typeof patchObject.priority !== "undefined") next.priority = toPriority(patchObject.priority);
    if (typeof patchObject.injectionPosition !== "undefined") {
      next.injectionPosition = normalizePosition(patchObject.injectionPosition);
    }
    if (typeof patchObject.worldBookId !== "undefined") {
      var targetBookId = toStringValue(patchObject.worldBookId);
      if (targetBookId && targetBookId !== existing.worldBookId) {
        var targetBook = await dbx.worldBooks.get(targetBookId);
        if (!targetBook) throw new Error("目标世界书不存在或已被删除");
        next.worldBookId = targetBookId;
      }
    }
    if (Object.keys(next).length) {
      next.updatedAt = Date.now();
      await dbx.worldBookEntries.update(id, next);
    }
    return cloneRow(await dbx.worldBookEntries.get(id));
  }

  // 删除书时级联删除其全部条目与绑定（整本 + 逐条）。
  async function deleteBook(worldBookId) {
    var dbx = await database();
    var id = String(worldBookId || "");
    if (!id) return false;
    var existing = await dbx.worldBooks.get(id);
    if (!existing) return false;
    await dbx.transaction("rw", dbx.worldBooks, dbx.worldBookEntries, dbx.worldBookBindings, async function () {
      await dbx.worldBookEntries.where("worldBookId").equals(id).delete();
      await dbx.worldBookBindings.where("worldBookId").equals(id).delete();
      await dbx.worldBooks.delete(id);
    });
    return true;
  }

  // 删除条目时顺带清理指向它的逐条绑定，避免孤儿绑定残留。
  async function deleteEntry(entryId) {
    var dbx = await database();
    var id = String(entryId || "");
    if (!id) return false;
    var existing = await dbx.worldBookEntries.get(id);
    if (!existing) return false;
    await dbx.transaction("rw", dbx.worldBookEntries, dbx.worldBookBindings, async function () {
      await dbx.worldBookBindings.where("entryId").equals(id).delete();
      await dbx.worldBookEntries.delete(id);
    });
    return true;
  }

  async function findWholeBookBinding(dbx, conversationId, worldBookId) {
    var rows = await dbx.worldBookBindings
      .where("[conversationId+worldBookId]").equals([conversationId, worldBookId]).toArray();
    for (var i = 0; i < rows.length; i += 1) {
      var row = rows[i];
      if (row.entryId === null || row.entryId === undefined) return row;
    }
    return null;
  }

  async function findEntryBinding(dbx, conversationId, worldBookId, entryId) {
    var rows = await dbx.worldBookBindings
      .where("[conversationId+worldBookId]").equals([conversationId, worldBookId]).toArray();
    for (var i = 0; i < rows.length; i += 1) {
      var row = rows[i];
      if (String(row.entryId || "") === String(entryId || "")) return row;
    }
    return null;
  }

  // 整本绑定会话：enabled 传 false 即解绑（更新 enabled 字段，保留痕迹便于再启用）。
  async function bindBookToConversation(conversationId, worldBookId, enabled) {
    var dbx = await database();
    var cid = toStringValue(conversationId).trim();
    if (!cid) throw new Error("缺少会话标识");
    var bookId = toStringValue(worldBookId);
    if (!bookId) throw new Error("缺少世界书标识");
    var wantEnabled = enabled !== false;
    var now = Date.now();
    var existing = await findWholeBookBinding(dbx, cid, bookId);
    if (existing) {
      await dbx.worldBookBindings.update(existing.bindingId, { enabled: wantEnabled, updatedAt: now });
      return cloneRow(Object.assign({}, existing, { enabled: wantEnabled, updatedAt: now }));
    }
    var row = {
      bindingId: uid("worldbook-binding"),
      conversationId: cid,
      worldBookId: bookId,
      entryId: null,
      enabled: wantEnabled,
      createdAt: now,
      updatedAt: now
    };
    await dbx.worldBookBindings.add(row);
    return cloneRow(row);
  }

  // 逐条绑定会话（局部书的单条目挂载）。
  async function bindEntryToConversation(conversationId, entryId, enabled) {
    var dbx = await database();
    var cid = toStringValue(conversationId).trim();
    if (!cid) throw new Error("缺少会话标识");
    var entry = await dbx.worldBookEntries.get(String(entryId || ""));
    if (!entry) throw new Error("条目不存在或已被删除");
    var wantEnabled = enabled !== false;
    var now = Date.now();
    var existing = await findEntryBinding(dbx, cid, entry.worldBookId, entry.entryId);
    if (existing) {
      await dbx.worldBookBindings.update(existing.bindingId, { enabled: wantEnabled, updatedAt: now });
      return cloneRow(Object.assign({}, existing, { enabled: wantEnabled, updatedAt: now }));
    }
    var row = {
      bindingId: uid("worldbook-binding"),
      conversationId: cid,
      worldBookId: entry.worldBookId,
      entryId: entry.entryId,
      enabled: wantEnabled,
      createdAt: now,
      updatedAt: now
    };
    await dbx.worldBookBindings.add(row);
    return cloneRow(row);
  }

  var Repository = {
    listEnabledEntriesForConversation: listEnabledEntriesForConversation,
    // 兼容旧占位脚本暴露的别名（与主方法同一实现，永不抛错）。
    getEntriesForConversation: function (conversationId) {
      return listEnabledEntriesForConversation(conversationId);
    },
    getBooks: getBooks,
    getBook: getBook,
    getEntries: getEntries,
    getEntry: getEntry,
    getBindings: getBindings,
    createBook: createBook,
    updateBook: updateBook,
    createEntry: createEntry,
    updateEntry: updateEntry,
    deleteBook: deleteBook,
    deleteEntry: deleteEntry,
    bindBookToConversation: bindBookToConversation,
    bindEntryToConversation: bindEntryToConversation
  }
  Object.defineProperty(Repository, REPO_MARKER, { value: true, enumerable: false });
  Object.freeze(Repository);

  var installedRepository = window.WorldBookRepository;
  if (!installedRepository || !installedRepository[REPO_MARKER]) {
    window.WorldBookRepository = Repository;
    console.log(TAG, "WorldBookRepository 已挂载（listEnabledEntriesForConversation 就绪）");
  }

  /* ================================================================
   * 以下为页面 UI。即使页面 DOM 缺失，Repository 仍然有效（QQ 场景）。
   * ================================================================ */

  var page = document.getElementById("page-worldbook-app");
  var listEl = page && page.querySelector("#worldbook-page-list");
  var addButton = page && page.querySelector("#worldbook-add-button");
  var titleButton = page && page.querySelector("#worldbook-page-title");
  var menuEl = page && page.querySelector("#worldbook-menu");

  var uiState = {
    bound: false,
    renderToken: 0,
    openBookId: null,
    menuBuilt: false
  };

  function iconElement(name) {
    try {
      var factory = window.QWQSystemUI && typeof window.QWQSystemUI.createIcon === "function"
        ? window.QWQSystemUI.createIcon
        : null;
      if (factory) {
        var svg = factory({
          provider: "fontawesome",
          family: "classic",
          style: "solid",
          name: name,
          format: "inline-svg"
        });
        if (svg) return svg;
      }
    } catch (_) { /* fallthrough */ }
    try {
      var icon = document.createElement("i");
      icon.className = "fa-solid fa-" + String(name || "");
      icon.setAttribute("aria-hidden", "true");
      return icon;
    } catch (_) {
      return null;
    }
  }

  function appendIcon(host, name) {
    var icon = iconElement(name);
    if (icon) host.appendChild(icon);
    return icon;
  }

  function node(tagName, className, children) {
    var element = document.createElement(tagName);
    if (className) element.className = className;
    if (children !== undefined && children !== null) {
      if (Array.isArray(children)) {
        children.forEach(function (child) { appendChildText(element, child); });
      } else {
        appendChildText(element, children);
      }
    }
    return element;
  }

  function appendChildText(host, child) {
    if (child === null || child === undefined) return;
    if (child instanceof Node) host.appendChild(child);
    else host.append(String(child));
  }

  function alertBox(title, message) {
    globalModal().then(function (modal) {
      try {
        modal.alert({
          title: title,
          message: message,
          confirmLabel: "知道了",
          action: "dismiss"
        });
      } catch (error) {
        console.warn(TAG, "弹窗失败：", error && error.message ? error.message : error);
      }
    }).catch(function (error) {
      console.warn(TAG, "弹窗运行时不可用：", error && error.message ? error.message : error);
    });
  }

  function confirmBox(config) {
    return globalModal().then(function (modal) {
      return modal.confirm({
        title: config.title,
        message: config.message,
        confirmLabel: config.confirmLabel || "确认",
        cancelLabel: config.cancelLabel || "取消",
        danger: config.danger === true,
        action: config.action || "dismiss"
      });
    });
  }

  function closeMenu() {
    if (menuEl) {
      menuEl.hidden = true;
      menuEl.setAttribute("aria-hidden", "true");
    }
  }

  function buildMenu() {
    if (!menuEl || uiState.menuBuilt) return;
    uiState.menuBuilt = true;
    menuEl.replaceChildren();

    var createBookItem = node("button", "wb-menu-item");
    createBookItem.type = "button";
    createBookItem.setAttribute("role", "menuitem");
    createBookItem.setAttribute("aria-label", "新建世界书");
    var createIconBox = node("span", "wb-menu-item-icon");
    appendIcon(createIconBox, "book-open");
    var createCopy = node("span", "wb-menu-item-copy");
    createCopy.appendChild(node("strong", "wb-menu-item-title", "新建世界书"));
    createCopy.appendChild(node("small", "wb-menu-item-desc", "创建一本新的设定集"));
    createBookItem.append(createIconBox, createCopy);
    createBookItem.addEventListener("click", function () {
      closeMenu();
      void openBookEditor(null);
    });

    var createEntryItem = node("button", "wb-menu-item");
    createEntryItem.type = "button";
    createEntryItem.setAttribute("role", "menuitem");
    createEntryItem.setAttribute("aria-label", "新增条目");
    var entryIconBox = node("span", "wb-menu-item-icon");
    appendIcon(entryIconBox, "circle-plus");
    var entryCopy = node("span", "wb-menu-item-copy");
    entryCopy.appendChild(node("strong", "wb-menu-item-title", "新增条目"));
    entryCopy.appendChild(node("small", "wb-menu-item-desc", "为某本世界书添加设定条目"));
    createEntryItem.append(entryIconBox, entryCopy);
    createEntryItem.addEventListener("click", function () {
      closeMenu();
      void openEntryEditor(null);
    });

    menuEl.append(createBookItem, createEntryItem);
  }

  function toggleMenu() {
    buildMenu();
    if (!menuEl) return;
    if (menuEl.hidden) {
      menuEl.hidden = false;
      menuEl.removeAttribute("aria-hidden");
    } else {
      closeMenu();
    }
  }

  function backHome() {
    // 多路容错：优先走系统导航，其次派发系统返回事件，最后 Router 兜底。
    var attempts = [
      function () {
        if (window.MyPhoneManager && typeof window.MyPhoneManager.closeApp === "function") {
          window.MyPhoneManager.closeApp();
          return true;
        }
        return false;
      },
      function () {
        if (window.MyPhoneManager && typeof window.MyPhoneManager.open === "function") {
          window.MyPhoneManager.open();
          return true;
        }
        return false;
      },
      function () {
        document.dispatchEvent(new CustomEvent("qwq:system:back", {
          bubbles: true,
          detail: { app: "atlas" }
        }));
        return true;
      },
      function () {
        if (window.Router && typeof window.Router.back === "function") {
          window.Router.back();
          return true;
        }
        return false;
      }
    ];
    for (var i = 0; i < attempts.length; i += 1) {
      try {
        if (attempts[i]()) return;
      } catch (error) {
        console.warn(TAG, "返回主屏路径失败（第 " + (i + 1) + " 路）：", error && error.message ? error.message : error);
      }
    }
  }

  /* ---------------- 列表渲染 ---------------- */

  function priorityTotal(entries) {
    return entries.reduce(function (sum, entry) { return sum + toPriority(entry.priority); }, 0);
  }

  function scopeBindingLabel(book, bindingCount) {
    if (book.scope === "global") return "全局 · 自动进入所有会话";
    return bindingCount > 0 ? ("局部 · 已绑定 " + bindingCount + " 个会话") : "局部 · 未绑定会话";
  }

  // 在卡片内收集该书的条目与绑定（单次查询，避免每本书重复 toArray）。
  async function collectPageData() {
    var dbx = await database();
    var books = await Repository.getBooks();
    var entries = await dbx.worldBookEntries.toArray();
    var bindings = await dbx.worldBookBindings.toArray();
    var entriesByBook = new Map();
    var bindingsByBook = new Map();
    books.forEach(function (book) {
      entriesByBook.set(book.worldBookId, []);
      bindingsByBook.set(book.worldBookId, 0);
    });
    entries.forEach(function (entry) {
      var group = entriesByBook.get(entry.worldBookId);
      if (group) group.push(entry);
    });
    bindings.forEach(function (binding) {
      if (binding.enabled !== true) return;
      if (!bindingsByBook.has(binding.worldBookId)) return;
      bindingsByBook.set(binding.worldBookId, bindingsByBook.get(binding.worldBookId) + 1);
    });
    entriesByBook.forEach(function (group) {
      group.sort(function (a, b) {
        if (toPriority(a.priority) !== toPriority(b.priority)) return toPriority(a.priority) - toPriority(b.priority);
        return a.entryId < b.entryId ? -1 : a.entryId > b.entryId ? 1 : 0;
      });
    });
    return { books: books, entriesByBook: entriesByBook, bindingsByBook: bindingsByBook };
  }

  function buildBookCard(book, entries, bindingCount) {
    var isOpen = uiState.openBookId === book.worldBookId;
    var card = node("article", "wb-book" + (isOpen ? " is-open" : ""));
    card.dataset.worldBookId = book.worldBookId;

    var head = node("button", "wb-book-head");
    head.type = "button";
    head.setAttribute("aria-expanded", isOpen ? "true" : "false");
    head.setAttribute("aria-label", (isOpen ? "收起" : "展开") + "世界书「" + book.name + "」");

    var logo = node("span", "wb-book-logo");
    appendIcon(logo, "book-open");

    var copy = node("span", "wb-book-copy");
    var nameRow = node("span", "wb-book-name-row");
    nameRow.appendChild(node("span", "wb-book-name", book.name || "未命名世界书"));
    var badge = node("span", "wb-scope-badge" + (book.scope === "global" ? " is-global" : ""),
      book.scope === "global" ? "全局" : "局部");
    nameRow.appendChild(badge);

    var meta = node("span", "wb-book-meta",
      entries.length + " 条条目 · 优先级小计 " + priorityTotal(entries) + " · " + scopeBindingLabel(book, bindingCount));
    copy.append(nameRow, meta);

    var chevron = node("span", "wb-book-chevron");
    appendIcon(chevron, "chevron-down");
    head.append(logo, copy, chevron);
    head.addEventListener("click", function () {
      uiState.openBookId = isOpen ? null : book.worldBookId;
      void rerender();
    });

    var body = node("div", "wb-book-body");
    body.hidden = !isOpen;
    if (isOpen) {
      body.appendChild(buildBookBody(book, entries, bindingCount));
    }

    card.append(head, body);
    return card;
  }

  function buildBookBody(book, entries, bindingCount) {
    var body = node("div", "wb-book-body-inner");

    if (book.scope !== "global" && bindingCount === 0) {
      body.appendChild(node("p", "wb-hint",
        "这是一本局部世界书：绑定到具体会话后才会注入。可在 QQ 会话资料 → 世界书 中挂载。" +
        "（挂载数据由会话侧管理，本目录不会自动生效。）"));
    }

    var entryList = node("div", "wb-entry-list");
    if (entries.length) {
      entries.forEach(function (entry) {
        entryList.appendChild(buildEntryRow(book, entry));
      });
    } else {
      entryList.appendChild(node("div", "wb-entry-empty", "这本书还没有条目。"));
    }
    body.appendChild(entryList);

    // 工具区：整行添加条目 + 编辑 / 删除
    var tools = node("div", "wb-book-tools");

    var addEntry = node("button", "ui-action-button wb-book-tools-add");
    addEntry.type = "button";
    appendIcon(addEntry, "circle-plus");
    addEntry.appendChild(node("span", null, "新增条目"));
    addEntry.addEventListener("click", function () {
      void openEntryEditor({ worldBookId: book.worldBookId });
    });

    var editBook = node("button", "ui-action-button");
    editBook.type = "button";
    appendIcon(editBook, "pen");
    editBook.appendChild(node("span", null, "编辑本书"));
    editBook.addEventListener("click", function () {
      void openBookEditor(book);
    });

    var deleteBookButton = node("button", "ui-action-button is-danger");
    deleteBookButton.type = "button";
    appendIcon(deleteBookButton, "trash-can");
    deleteBookButton.appendChild(node("span", null, "删除本书"));
    deleteBookButton.addEventListener("click", function () {
      void requestDeleteBook(book);
    });

    tools.append(addEntry, editBook, deleteBookButton);
    body.appendChild(tools);
    return body;
  }

  function buildEntryRow(book, entry) {
    var row = node("article", "wb-entry");
    row.dataset.entryId = entry.entryId;

    var title = node("span", "wb-entry-title", typeof entry.title === "string" && entry.title.trim()
      ? entry.title.trim()
      : "未命名条目");
    var pos = node("span", "wb-entry-pos is-" + normalizePosition(entry.injectionPosition),
      POSITION_LABELS[normalizePosition(entry.injectionPosition)] || normalizePosition(entry.injectionPosition));
    pos.title = "注入位置：" + String(entry.injectionPosition || "before");
    var head = node("div", "wb-entry-head");
    head.append(title, pos);

    var preview = node("p", "wb-entry-preview", null);
    var content = toStringValue(entry.content).replace(/\s+/g, " ").trim();
    preview.textContent = content || "（空内容）";
    if (!content) preview.classList.add("is-empty");

    var foot = node("div", "wb-entry-foot");
    foot.appendChild(node("span", "wb-entry-priority", "优先级 " + toPriority(entry.priority)));

    var actions = node("span", "wb-entry-actions");
    var editButton = node("button", "wb-mini-action");
    editButton.type = "button";
    appendIcon(editButton, "pen");
    editButton.appendChild(node("span", null, "编辑"));
    editButton.addEventListener("click", function () {
      void openEntryEditor({ entry: entry });
    });
    var deleteButton = node("button", "wb-mini-action is-danger");
    deleteButton.type = "button";
    appendIcon(deleteButton, "trash-can");
    deleteButton.appendChild(node("span", null, "删除"));
    deleteButton.addEventListener("click", function () {
      void requestDeleteEntry(book, entry);
    });
    actions.append(editButton, deleteButton);
    foot.appendChild(actions);

    row.append(head, preview, foot);
    return row;
  }

  function buildEmptyState() {
    var empty = node("div", "wb-empty");
    var iconShell = node("span", "wb-empty-icon");
    appendIcon(iconShell, "book-open");
    var inner = node("div", "wb-empty-copy");
    inner.appendChild(node("h3", "wb-empty-title", "还没有世界书"));
    inner.appendChild(node("p", "wb-empty-desc",
      "点右上角 ＋ 新建第一本世界书。\n全局书会进入所有会话的上下文；局部书需要绑定到具体会话后生效。"));
    var action = node("button", "ui-action-button is-primary wb-empty-action");
    action.type = "button";
    appendIcon(action, "circle-plus");
    action.appendChild(node("span", null, "新建世界书"));
    action.addEventListener("click", function () {
      void openBookEditor(null);
    });
    empty.append(iconShell, inner, action);
    return empty;
  }

  function buildBrokenState(message) {
    var broken = node("div", "wb-empty");
    var iconShell = node("span", "wb-empty-icon is-broken");
    appendIcon(iconShell, "xmark");
    var inner = node("div", "wb-empty-copy");
    inner.appendChild(node("h3", "wb-empty-title", "世界书暂时不可用"));
    inner.appendChild(node("p", "wb-empty-desc", String(message || "持久化运行时未就绪，请稍后重试。")));
    var retry = node("button", "ui-action-button wb-empty-action");
    retry.type = "button";
    retry.appendChild(node("span", null, "重试"));
    retry.addEventListener("click", function () { void rerender(); });
    broken.append(iconShell, inner, retry);
    return broken;
  }

  async function rerender() {
    if (!listEl) return;
    var token = ++uiState.renderToken;
    var loading = node("p", "wb-note", "正在读取世界书…");
    listEl.replaceChildren(loading);

    try {
      var data = await collectPageData();
      if (token !== uiState.renderToken) return;
      var fragment = document.createDocumentFragment();
      if (!data.books.length) {
        fragment.appendChild(buildEmptyState());
      } else {
        data.books.forEach(function (book) {
          fragment.appendChild(buildBookCard(
            book,
            data.entriesByBook.get(book.worldBookId) || [],
            data.bindingsByBook.get(book.worldBookId) || 0
          ));
        });
      }
      listEl.replaceChildren(fragment);
    } catch (error) {
      if (token !== uiState.renderToken) return;
      console.warn(TAG, "世界书目录渲染失败：", error && error.message ? error.message : error);
      listEl.replaceChildren(buildBrokenState(
        error && error.message ? error.message : "未知错误"
      ));
    }
  }

  /* ---------------- 抽屉表单：书 / 条目 ---------------- */

  function drawerBodyHost() {
    var host = document.getElementById("theme-drawer-body");
    if (!host) throw new Error("抽屉容器不存在");
    return host;
  }

  function formRow(labelText, control, hintText) {
    var row = node("div", "ui-form-row");
    var label = node("span", "ui-field-label", labelText);
    row.append(label, control);
    if (hintText) row.appendChild(node("p", "wb-field-hint", hintText));
    return row;
  }

  function buildSegmented(options, selected, onPick) {
    var group = node("div", "wb-segmented");
    group.setAttribute("role", "radiogroup");
    options.forEach(function (option) {
      var button = node("button", "wb-segmented-item" + (option.value === selected ? " is-active" : ""));
      button.type = "button";
      button.setAttribute("role", "radio");
      button.setAttribute("aria-checked", option.value === selected ? "true" : "false");
      button.textContent = option.label;
      button.addEventListener("click", function () {
        group.querySelectorAll(".wb-segmented-item").forEach(function (item) {
          var active = item === button;
          item.classList.toggle("is-active", active);
          item.setAttribute("aria-checked", active ? "true" : "false");
        });
        if (typeof onPick === "function") onPick(option.value);
      });
      group.appendChild(button);
    });
    return group;
  }

  function buildCharCounter() {
    var counter = node("span", "wb-char-count", "0 字");
    counter.dataset.role = "wb-char-count";
    return counter;
  }

  function syncCharCounter(counter, textarea) {
    var text = toStringValue(textarea && textarea.value);
    var count = 0;
    try { count = Array.from(text).length; } catch (_) { count = text.length; }
    counter.textContent = count + " 字";
  }

  // 打开抽屉并返回渲染好的抽屉 DOM 上下文；统一处理缺失运行时的降级。
  async function openDrawerPanel(type, title, renderBody) {
    var drawer = await globalDrawer();
    var DrawerUI = await drawerUI();
    return drawer.open({
      type: type,
      title: title,
      render: async function () {
        var host = drawerBodyHost();
        if (!DrawerUI) {
          host.replaceChildren();
          host.appendChild(node("p", "wb-drawer-fallback", "抽屉面板渲染运行时不可用。"));
          return;
        }
        host.replaceChildren();
        await renderBody(host, DrawerUI);
      }
    });
  }

  var SCOPE_OPTIONS = [
    { value: "global", label: "全局" },
    { value: "local", label: "局部" }
  ];
  var SCOPE_HINTS = {
    global: "所有会话都会自动挂载本书的全部条目，无需逐会话绑定。适合常驻设定、世界观基调。",
    local: "只在显式绑定到本书的会话中注入。适合单个角色的专属设定或实验性内容。"
  };
  var POSITION_HINTS = {
    before: "注入在人设设定之前，最先进入模型上下文。",
    middle: "注入在会话状态与记忆之后、核心协议之前。",
    after: "注入在提示词后段，紧邻核心协议前，适合收尾性约束。"
  };

  async function openBookEditor(book) {
    if (!page) return false;
    var isEdit = Boolean(book && book.worldBookId);
    try {
      var opened = await openDrawerPanel(
        "worldbook-book-editor",
        isEdit ? "编辑世界书" : "新建世界书",
        async function (host, DrawerUI) {
          var draft = {
            name: isEdit ? toStringValue(book.name) : "",
            scope: isEdit ? normalizeScope(book.scope) : "local"
          };

          var section = DrawerUI.createSection(isEdit ? "世界书资料" : "基础资料");

          var nameInput = node("input", "ui-field-input");
          nameInput.type = "text";
          nameInput.placeholder = "例如：星野小镇世界观";
          nameInput.value = draft.name;
          nameInput.setAttribute("aria-label", "世界书名称");
          section.appendChild(formRow("名称", nameInput));

          var scopeHint = node("p", "wb-segmented-hint", SCOPE_HINTS[draft.scope]);
          var scopeBox = node("div", "ui-form-row");
          scopeBox.appendChild(node("span", "ui-field-label", "作用范围"));
          var segmented = buildSegmented(SCOPE_OPTIONS, draft.scope, function (value) {
            draft.scope = value;
            scopeHint.textContent = SCOPE_HINTS[value] || "";
          });
          scopeBox.append(segmented, scopeHint);
          section.appendChild(scopeBox);

          var actions = node("div", "ui-action-row");
          var cancel = DrawerUI.createActionButton("取消", "xmark");
          var save = DrawerUI.createActionButton(isEdit ? "保存修改" : "创建", "square-check", "is-primary");
          actions.append(cancel, save);
          section.appendChild(actions);
          host.appendChild(section);

          if (isEdit) {
            var dangerSection = DrawerUI.createSection("危险操作");
            var deleteButton = DrawerUI.createActionButton("删除本书（含全部条目与绑定）", "trash-can", "is-danger is-wide");
            dangerSection.appendChild(deleteButton);
            host.appendChild(dangerSection);
            deleteButton.addEventListener("click", function () {
              void confirmDeleteBook(book);
            });
          }

          cancel.addEventListener("click", function () {
            try { window.ThemeCustomization?.GlobalDrawer?.close?.(); } catch (_) { }
          });

          save.addEventListener("click", async function () {
            var name = toStringValue(nameInput.value).trim();
            if (!name) {
              alertBox("名称不能为空", "请先填写世界书名称。");
              nameInput.focus();
              return;
            }
            save.disabled = true;
            try {
              if (isEdit) {
                await Repository.updateBook(book.worldBookId, { name: name, scope: draft.scope });
                uiState.openBookId = book.worldBookId;
              } else {
                var created = await Repository.createBook({ name: name, scope: draft.scope });
                uiState.openBookId = created.worldBookId; // 新建后展开，便于立刻添加条目
              }
              try { window.ThemeCustomization?.GlobalDrawer?.close?.(); } catch (_) { }
              void rerender();
            } catch (error) {
              save.disabled = false;
              var friendly = friendlyBookError(error);
              alertBox(isEdit ? "保存失败" : "创建失败", friendly);
            }
          });

          requestAnimationFrame(function () {
            if (nameInput.isConnected) nameInput.focus({ preventScroll: true });
          });
        }
      );
      return opened;
    } catch (error) {
      console.warn(TAG, "世界书编辑器无法打开：", error && error.message ? error.message : error);
      alertBox("编辑器无法打开", (error && error.message) || "抽屉运行时不可用，请稍后重试。");
      return false;
    }
  }

  function friendlyBookError(error) {
    var raw = error && error.message ? error.message : "";
    if (raw && /constraint/i.test(raw)) return "已存在同名世界书，请换一个名称。";
    return raw || "数据保存失败，请稍后重试。";
  }

  async function openEntryEditor(options) {
    var opts = options || {};
    var entry = opts.entry || null;
    var preselectedBookId = opts.worldBookId || (entry && entry.worldBookId) || null;
    if (!page) return false;

    try {
      var books = await Repository.getBooks();
      if (!entry && !books.length) {
        alertBox("还没有世界书", "请先通过右上角菜单创建一本世界书，再添加条目。");
        return false;
      }
      var isEdit = Boolean(entry && entry.entryId);
      var selectedBookId = preselectedBookId
        || (books.length === 1 ? books[0].worldBookId : "");

      var opened = await openDrawerPanel(
        "worldbook-entry-editor",
        isEdit ? "编辑条目" : "新增条目",
        async function (host, DrawerUI) {
          var draft = {
            bookId: selectedBookId,
            title: isEdit ? toStringValue(entry.title) : "",
            content: isEdit ? toStringValue(entry.content) : "",
            priority: isEdit ? toPriority(entry.priority) : 0,
            position: isEdit ? normalizePosition(entry.injectionPosition) : "before"
          };

          var section = DrawerUI.createSection(isEdit ? "条目资料" : "基本信息");

          var bookSelect = node("select", "native-select");
          bookSelect.setAttribute("aria-label", "所属世界书");
          if (!draft.bookId && books.length > 1) {
            var placeholder = node("option", null, "选择一本世界书…");
            placeholder.value = "";
            placeholder.disabled = true;
            bookSelect.appendChild(placeholder);
          }
          books.forEach(function (book) {
            var option = node("option", null, book.name + (book.scope === "global" ? "（全局）" : "（局部）"));
            option.value = book.worldBookId;
            bookSelect.appendChild(option);
          });
          if (!books.length) {
            var option = node("option", null, "（无可用世界书）");
            option.value = "";
            bookSelect.appendChild(option);
          }
          if (draft.bookId) bookSelect.value = draft.bookId;
          bookSelect.disabled = isEdit; // 编辑不允许搬书：先删后建更直观
          bookSelect.addEventListener("change", function () { draft.bookId = bookSelect.value; });
          if (isEdit) {
            section.appendChild(formRow("所属世界书", bookSelect, "条目已属于该书；如需移动请删除后重新添加。"));
          } else {
            section.appendChild(formRow("所属世界书", bookSelect));
          }

          var titleInput = node("input", "ui-field-input");
          titleInput.type = "text";
          titleInput.placeholder = "可选：例如「小镇禁忌」；留空显示为未命名条目";
          titleInput.value = draft.title;
          titleInput.setAttribute("aria-label", "条目名称");
          section.appendChild(formRow("名称", titleInput));
          var titleFocusTarget = titleInput;

          var positionHint = node("p", "wb-segmented-hint", POSITION_HINTS[draft.position]);
          var positionBox = node("div", "ui-form-row");
          positionBox.appendChild(node("span", "ui-field-label", "注入位置"));
          var positionSegmented = buildSegmented(
            [
              { value: "before", label: "前置" },
              { value: "middle", label: "中置" },
              { value: "after", label: "后置" }
            ],
            draft.position,
            function (value) {
              draft.position = value;
              positionHint.textContent = POSITION_HINTS[value] || "";
            }
          );
          positionBox.append(positionSegmented, positionHint);
          section.appendChild(positionBox);

          var priorityInput = node("input", "ui-field-input");
          priorityInput.type = "number";
          priorityInput.min = "0";
          priorityInput.max = "9999";
          priorityInput.step = "1";
          priorityInput.value = String(draft.priority);
          priorityInput.setAttribute("aria-label", "条目优先级");
          section.appendChild(formRow("优先级", priorityInput, "整数，仅作排序与管理参考。"));
          host.appendChild(section);

          // 内容区块（textarea 先建，供全屏编辑器回写）
          var contentTextarea = node("textarea", "ui-field-textarea");
          contentTextarea.rows = 9;
          contentTextarea.placeholder = "写下这条设定注入模型上下文的正文…（必填）";
          contentTextarea.value = draft.content;
          contentTextarea.setAttribute("aria-label", "条目正文");

          var contentSection = DrawerUI.createSection("条目内容");
          var contentHead = node("div", "wb-field-head");
          contentHead.appendChild(node("span", "ui-field-label", "注入正文"));
          var counter = buildCharCounter();
          var contentTools = node("span", "wb-field-tools");
          contentTools.appendChild(counter);
          try {
            var TextEntryUI = (await themeRuntime()).TextEntryUI;
            if (TextEntryUI && typeof TextEntryUI.createFullscreenButton === "function") {
              var fullscreenButton = TextEntryUI.createFullscreenButton(contentTextarea, "条目正文");
              if (fullscreenButton) contentTools.appendChild(fullscreenButton);
            }
          } catch (_) { /* 全屏按钮缺失不影响主流程 */ }
          contentHead.appendChild(contentTools);
          syncCharCounter(counter, contentTextarea);

          contentTextarea.addEventListener("input", function () {
            draft.content = contentTextarea.value;
            syncCharCounter(counter, contentTextarea);
          });

          var actions = node("div", "ui-action-row");
          var cancel = DrawerUI.createActionButton("取消", "xmark");
          var save = DrawerUI.createActionButton(isEdit ? "保存修改" : "添加条目", "square-check", "is-primary");
          actions.append(cancel, save);
          contentSection.append(contentHead, contentTextarea, actions);
          host.appendChild(contentSection);

          cancel.addEventListener("click", function () {
            try { window.ThemeCustomization?.GlobalDrawer?.close?.(); } catch (_) { }
          });

          save.addEventListener("click", async function () {
            var content = toStringValue(contentTextarea.value);
            if (!content.trim()) {
              alertBox("内容不能为空", "请填写条目正文后再保存。");
              contentTextarea.focus();
              return;
            }
            var bookId = isEdit ? entry.worldBookId : bookSelect.value;
            if (!bookId) {
              alertBox("未选择世界书", "请选择这本条目所属的世界书。");
              return;
            }
            save.disabled = true;
            try {
              if (isEdit) {
                await Repository.updateEntry(entry.entryId, {
                  title: titleInput.value,
                  content: content,
                  priority: priorityInput.value,
                  injectionPosition: draft.position
                });
              } else {
                await Repository.createEntry({
                  worldBookId: bookId,
                  title: titleInput.value,
                  content: content,
                  priority: priorityInput.value,
                  injectionPosition: draft.position
                });
              }
              try { window.ThemeCustomization?.GlobalDrawer?.close?.(); } catch (_) { }
              uiState.openBookId = isEdit ? entry.worldBookId : bookId;
              void rerender();
            } catch (error) {
              save.disabled = false;
              console.warn(TAG, "条目保存失败：", error && error.message ? error.message : error);
              alertBox(isEdit ? "保存失败" : "添加失败", (error && error.message) || "数据保存失败，请稍后重试。");
            }
          });

          requestAnimationFrame(function () {
            if (titleFocusTarget && titleFocusTarget.isConnected && !isEdit) {
              titleFocusTarget.focus({ preventScroll: true });
            }
          });
        }
      );
      return opened;
    } catch (error) {
      console.warn(TAG, "条目编辑器无法打开：", error && error.message ? error.message : error);
      alertBox("编辑器无法打开", (error && error.message) || "抽屉运行时不可用，请稍后重试。");
      return false;
    }
  }

  /* ---------------- 删除确认 ---------------- */

  function requestDeleteBook(book) {
    return confirmDeleteBook(book);
  }

  async function confirmDeleteBook(book) {
    try {
      await confirmBox({
        title: "删除世界书",
        message: "确定删除世界书「" + book.name + "」吗？其全部条目与会话绑定会被一并移除，且无法恢复。",
        confirmLabel: "删除",
        cancelLabel: "取消",
        danger: true,
        action: async function () {
          try {
            await Repository.deleteBook(book.worldBookId);
            try { window.ThemeCustomization?.GlobalDrawer?.close?.(); } catch (_) { }
            if (uiState.openBookId === book.worldBookId) uiState.openBookId = null;
            void rerender();
            return true;
          } catch (error) {
            console.warn(TAG, "删除世界书失败：", error && error.message ? error.message : error);
            alertBox("删除失败", (error && error.message) || "请稍后重试。");
            return false;
          }
        }
      });
    } catch (error) {
      console.warn(TAG, "删除确认弹窗不可用：", error && error.message ? error.message : error);
    }
  }

  async function requestDeleteEntry(book, entry) {
    try {
      await confirmBox({
        title: "删除条目",
        message: "确定删除「" + ((typeof entry.title === "string" && entry.title.trim()) ? entry.title.trim() : "未命名条目") + "」吗？该条目及其逐条绑定会被移除。",
        confirmLabel: "删除",
        cancelLabel: "取消",
        danger: true,
        action: async function () {
          try {
            await Repository.deleteEntry(entry.entryId);
            void rerender();
            return true;
          } catch (error) {
            console.warn(TAG, "删除条目失败：", error && error.message ? error.message : error);
            alertBox("删除失败", (error && error.message) || "请稍后重试。");
            return false;
          }
        }
      });
    } catch (error) {
      console.warn(TAG, "删除确认弹窗不可用：", error && error.message ? error.message : error);
    }
  }

  /* ---------------- WorldBookApp（open / close） ---------------- */

  async function open() {
    try {
      bindUI();
      closeMenu();
      uiState.openBookId = null;
      await rerender();
      console.log(TAG, "已打开（渲染世界书目录）");
    } catch (error) {
      console.warn(TAG, "打开世界书失败：", error && error.message ? error.message : error);
    }
    return true;
  }

  function close() {
    try {
      closeMenu();
      uiState.renderToken += 1;
      uiState.openBookId = null;
    } catch (_) { /* noop */ }
    return true;
  }

  function bindUI() {
    if (!page || uiState.bound) return;
    uiState.bound = true;

    if (addButton) {
      appendIcon(addButton, "plus");
      addButton.addEventListener("click", function (event) {
        event.stopPropagation();
        toggleMenu();
      });
    }

    if (titleButton) {
      titleButton.addEventListener("click", function () {
        closeMenu();
        backHome();
      });
    }

    // 点击菜单外任意位置时收起菜单
    document.addEventListener("pointerdown", function (event) {
      if (!menuEl || menuEl.hidden) return;
      var target = event.target;
      if (menuEl.contains(target)) return;
      if (addButton && addButton.contains(target)) return;
      closeMenu();
    }, true);

    // 路由切换时收起菜单，避免残影
    document.addEventListener("qwq:route-will-change", function () {
      closeMenu();
    });

    // Escape 关闭菜单
    document.addEventListener("keydown", function (event) {
      if (!menuEl || menuEl.hidden) return;
      if (event.key === "Escape") {
        closeMenu();
        if (addButton) addButton.focus({ preventScroll: true });
      }
    });

    // 页面失焦也收起菜单
    window.addEventListener("blur", function () {
      closeMenu();
    });
  }

  var App = {
    open: open,
    close: close
  }
  Object.defineProperty(App, APP_MARKER, { value: true, enumerable: false });
  Object.freeze(App);

  var installedApp = window.WorldBookApp;
  if (!installedApp || !installedApp[APP_MARKER] || typeof installedApp.open !== "function") {
    window.WorldBookApp = App;
    console.log(TAG, "WorldBookApp 已挂载");
  }
})();

console.log("[World Book] 世界书模块已加载");
