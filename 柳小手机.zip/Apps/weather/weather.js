/* ==========================================================================
 * 清柳 天气 App（经典脚本 / 无模块语法）
 * window.WeatherApp = { open, close }
 *
 * - 首屏在 #qwq-weather-root 内自建天气 UI（城市定位头部、当前温度大字、
 *   湿度/风/空气质量等详情格、24 小时横条、未来 7 天、数据源说明）。
 * - 「刷新」重新生成随机但内部稳定的一天数据并重新持久化。
 * - 以键 'weather.state.v2' 写入 db.persistenceMeta，结构与 QQ 的
 *   qwqWeatherBaseFromPersisted / qwqWeatherSubjectValues 读取协议一致：
 *   activeLocation / snapshots / subjects.user / settings.shareContext。
 * ========================================================================== */
(() => {
  "use strict";
  const TAG = "[Weather]";

  try {
    const STORAGE_KEY = "weather.state.v2";

    const CITIES = [
      { id: "shanghai", name: "上海", admin1: "上海市", country: "中国", lat: 31.2304, lon: 121.4737, mean: 17.2 },
      { id: "beijing", name: "北京", admin1: "北京市", country: "中国", lat: 39.9042, lon: 116.4074, mean: 13.4 },
      { id: "guangzhou", name: "广州", admin1: "广东省", country: "中国", lat: 23.1291, lon: 113.2644, mean: 22.6 },
      { id: "shenzhen", name: "深圳", admin1: "广东省", country: "中国", lat: 22.5431, lon: 114.0579, mean: 23.1 },
      { id: "hangzhou", name: "杭州", admin1: "浙江省", country: "中国", lat: 30.2741, lon: 120.1551, mean: 17.3 },
      { id: "chengdu", name: "成都", admin1: "四川省", country: "中国", lat: 30.5728, lon: 104.0668, mean: 16.5 }
    ];

    const WMO_INFO = {
      0: { label: "晴", hero: "is-clear", icon: "sun" },
      1: { label: "少云", hero: "is-partly", icon: "cloud-sun" },
      2: { label: "多云", hero: "is-cloud", icon: "cloud" },
      3: { label: "阴", hero: "is-overcast", icon: "cloudy" },
      45: { label: "雾", hero: "is-fog", icon: "cloud-fog" },
      48: { label: "冻雾", hero: "is-fog", icon: "cloud-fog" },
      51: { label: "毛毛雨", hero: "is-rain", icon: "cloud-drizzle" },
      53: { label: "毛毛雨", hero: "is-rain", icon: "cloud-drizzle" },
      55: { label: "毛毛雨", hero: "is-rain", icon: "cloud-drizzle" },
      56: { label: "冻毛毛雨", hero: "is-rain", icon: "cloud-drizzle" },
      57: { label: "冻毛毛雨", hero: "is-rain", icon: "cloud-drizzle" },
      61: { label: "小雨", hero: "is-rain", icon: "cloud-rain" },
      63: { label: "中雨", hero: "is-rain", icon: "cloud-rain" },
      65: { label: "大雨", hero: "is-rain", icon: "cloud-rain" },
      66: { label: "冻雨", hero: "is-rain", icon: "cloud-rain" },
      67: { label: "冻雨", hero: "is-rain", icon: "cloud-rain" },
      71: { label: "小雪", hero: "is-snow", icon: "cloud-snow" },
      73: { label: "中雪", hero: "is-snow", icon: "cloud-snow" },
      75: { label: "大雪", hero: "is-snow", icon: "cloud-snow" },
      77: { label: "雪粒", hero: "is-snow", icon: "cloud-snow" },
      80: { label: "阵雨", hero: "is-rain", icon: "cloud-rain" },
      81: { label: "强阵雨", hero: "is-rain", icon: "cloud-rain" },
      82: { label: "强阵雨", hero: "is-rain", icon: "cloud-rain" },
      85: { label: "阵雪", hero: "is-snow", icon: "cloud-snow" },
      86: { label: "阵雪", hero: "is-snow", icon: "cloud-snow" },
      95: { label: "雷阵雨", hero: "is-storm", icon: "cloud-lightning" },
      96: { label: "雷阵雨伴冰雹", hero: "is-storm", icon: "cloud-lightning" },
      99: { label: "雷阵雨伴冰雹", hero: "is-storm", icon: "cloud-lightning" }
    };

    const WEEKDAYS = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
    const WIND_DIRS = ["北风", "东北风", "东风", "东南风", "南风", "西南风", "西风", "西北风"];

    const state = {
      root: null,
      mounted: false,
      city: CITIES[0],
      shareContext: true,
      data: null,          // 结构化持久化 value（QQ 协议）
      display: null,       // 渲染辅助数据
      seedCounter: 0,
      generation: 0
    };

    /* ---------- 小工具 ---------- */
    function pad2(value) { return String(value).padStart(2, "0"); }

    function dateKey(date) {
      return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
    }

    function mulberry32(seed) {
      let a = seed >>> 0;
      return function next() {
        a |= 0; a = (a + 0x6D2B79F5) | 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };
    }

    function stableHash(text) {
      let hash = 2166136261;
      for (let i = 0; i < text.length; i += 1) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
      }
      return hash >>> 0;
    }

    function randBetween(rng, min, max) {
      return min + rng() * (max - min);
    }

    function randInt(rng, min, max) {
      return Math.floor(randBetween(rng, min, max + 1));
    }

    function clamp(value, min, max) {
      return Math.max(min, Math.min(max, value));
    }

    function round1(value) {
      return Number.isFinite(Number(value)) ? Math.round(Number(value) * 10) / 10 : null;
    }

    /* 平缓可辨的太阳高度温度曲线：凌晨 ~5 点最低、15 点最高 */
    function hourlyFactor(hour) {
      return Math.exp(-0.5 * Math.pow((hour - 15) / 5.2, 2));
    }

    function windDirectionLabel(degrees) {
      const index = Math.round((Number(degrees) % 360) / 45) % 8;
      return WIND_DIRS[index];
    }

    function moonPhaseForDate(date) {
      try {
        const synodic = 29.53058867;
        const knownNewMoon = Date.UTC(2000, 0, 6, 18, 14, 0);
        const days = (date.getTime() - knownNewMoon) / 86400000;
        const age = ((days % synodic) + synodic) % synodic;
        const illumination = Math.round((1 - Math.cos((2 * Math.PI * age) / synodic)) / 2 * 100);
        const name = age < 1.84566 ? "新月" : age < 5.53699 ? "娥眉月" : age < 9.22831 ? "上弦月"
          : age < 12.91963 ? "盈凸月" : age < 16.61096 ? "满月" : age < 20.30228 ? "亏凸月"
            : age < 23.99361 ? "下弦月" : age < 27.68493 ? "残月" : "新月";
        return { name, illumination };
      } catch (error) {
        return { name: "未知", illumination: 0 };
      }
    }

    function sunTimes(dayIndex) {
      // 模拟日出日落（仅供演示，含轻微逐日漂移）
      const baseSunrise = 348;  // 05:48 分钟
      const baseSunset = 1116;  // 18:36 分钟
      const drift = ((dayIndex * 37) % 11) - 5;
      const sunrise = clamp(baseSunrise + drift, 320, 390);
      const sunset = clamp(baseSunset - Math.floor(drift * 0.6), 1060, 1180);
      return {
        sunrise: `${pad2(Math.floor(sunrise / 60))}:${pad2(sunrise % 60)}`,
        sunset: `${pad2(Math.floor(sunset / 60))}:${pad2(sunset % 60)}`
      };
    }

    function aqiLabel(aqi) {
      if (aqi <= 50) return "优";
      if (aqi <= 100) return "良";
      if (aqi <= 150) return "轻度污染";
      if (aqi <= 200) return "中度污染";
      return "重度污染";
    }

    function uvLabel(uv) {
      if (uv < 3) return "弱";
      if (uv < 6) return "中等";
      if (uv < 8) return "强";
      if (uv < 11) return "很强";
      return "极强";
    }

    /* ---------- 一天天气描述 ---------- */
    function pickCode(rng, today) {
      const roll = rng();
      if (today) {
        if (roll < 0.18) return 0;
        if (roll < 0.37) return 1;
        if (roll < 0.60) return 2;
        if (roll < 0.72) return 3;
        if (roll < 0.77) return 45;
        if (roll < 0.84) return 61;
        if (roll < 0.90) return 63;
        if (roll < 0.94) return 71;
        if (roll < 0.97) return 80;
        return 95;
      }
      if (roll < 0.16) return 0;
      if (roll < 0.34) return 1;
      if (roll < 0.57) return 2;
      if (roll < 0.68) return 3;
      if (roll < 0.73) return 45;
      if (roll < 0.79) return 51;
      if (roll < 0.88) return 61;
      if (roll < 0.93) return 71;
      if (roll < 0.96) return 80;
      return 95;
    }

    function isRainCode(code) {
      return [51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82, 95, 96, 99].includes(Number(code));
    }
    function isSnowCode(code) {
      return [71, 73, 75, 77, 85, 86].includes(Number(code));
    }

    function generateDayWeather(rng, city, date, today) {
      const code = pickCode(rng, today);
      const month = date.getMonth();
      // 季节均值：7 月最热、1 月最冷
      const seasonal = 12.5 * Math.cos(((month - 6) / 12) * 2 * Math.PI);
      const dailyMean = city.mean + seasonal;
      let high = dailyMean + randBetween(rng, 3.2, 5.4) + (today ? 0 : randBetween(rng, -0.8, 0.8));
      let low = dailyMean - randBetween(rng, 3.4, 5.8);
      if (isRainCode(code)) { high -= randBetween(rng, 1.5, 3); low += randBetween(rng, 0, 1); }
      if (isSnowCode(code)) { high -= randBetween(rng, 3, 6); low -= randBetween(rng, 1, 2); }
      high = Math.round(high);
      low = Math.round(low);
      if (high <= low) high = low + randInt(rng, 2, 4);

      const humidity = isRainCode(code) ? randInt(rng, 72, 95)
        : isSnowCode(code) ? randInt(rng, 68, 90)
          : code === 3 || code === 45 ? randInt(rng, 62, 84)
            : randInt(rng, 38, 66);

      const precipitationProbability = isRainCode(code) ? randInt(rng, 55, 95)
        : isSnowCode(code) ? randInt(rng, 55, 90)
          : code === 2 || code === 3 ? randInt(rng, 18, 42)
            : randInt(rng, 3, 16);

      const uvMax = isRainCode(code) || isSnowCode(code) ? randInt(rng, 1, 3)
        : code === 2 ? randInt(rng, 3, 6)
          : code === 3 || code === 45 ? randInt(rng, 1, 3)
            : randInt(rng, 5, 9);

      const sun = sunTimes(date.getDate());
      const cloudCover = isRainCode(code) ? randInt(rng, 80, 100)
        : code === 2 ? randInt(rng, 45, 70)
          : code === 3 || code === 45 ? randInt(rng, 72, 96)
            : randInt(rng, 8, 34);

      return {
        date,
        code,
        high,
        low,
        humidity,
        precipitationProbability,
        precipitationMm: isRainCode(code) || isSnowCode(code) ? Math.round(randBetween(rng, 0.4, isSnowCode(code) ? 6 : 14) * 10) / 10 : 0,
        uvMax,
        sunrise: sun.sunrise,
        sunset: sun.sunset,
        cloudCover
      };
    }

    function generateSnapshot(city, seed) {
      const rng = mulberry32(seed);
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const dailyDays = [];
      for (let day = 0; day < 7; day += 1) {
        const date = new Date(today.getFullYear(), today.getMonth(), today.getDate() + day);
        dailyDays.push(generateDayWeather(rng, city, date, day === 0));
      }

      const currentDay = dailyDays[0];
      const hour = now.getHours();
      const currentCode = currentDay.code;
      const info = WMO_INFO[currentCode] || { label: "未知", hero: "is-cloud", icon: "cloud" };

      // 全天逐小时温度：与 high/low 同一条曲线，保证 15 点最热
      const dayTempsFor = (dayWeather) => {
        const temps = [];
        for (let h = 0; h < 24; h += 1) {
          const f = (hourlyFactor(h) - hourlyFactor(5)) / (1 - hourlyFactor(5));
          temps.push(Math.round(dayWeather.low + (dayWeather.high - dayWeather.low) * clamp(f, 0, 1)));
        }
        return temps;
      };

      const todayTemps = dayTempsFor(currentDay);
      const windKmh = Math.round(randBetween(rng, 5, 16));
      const windGustKmh = Math.round(windKmh + randBetween(rng, 4, 14));
      const windDirectionDeg = randInt(rng, 0, 359);
      const pressureHpa = Math.round(randBetween(rng, 1004, 1024));
      const visibilityM = currentDay.code === 45 || currentDay.code === 48
        ? randInt(rng, 800, 3200)
        : isRainCode(currentDay.code) ? randInt(rng, 5000, 12000)
          : randInt(rng, 18000, 30000);

      const aqi = randInt(rng, 22, 96);
      const pm25 = Math.max(3, Math.round(aqi * 0.62));
      const pm10 = Math.max(6, Math.round(aqi * 0.86));
      const ozone = randInt(rng, 42, 96);

      const currentTemp = todayTemps[hour];
      const humidityFactor = (currentDay.humidity - 50) * 0.035;
      const windFactor = windKmh > 24 ? -1.4 : windKmh > 15 ? -0.6 : 0;
      const feelsLike = Math.round(currentTemp + humidityFactor + windFactor);

      const hourlyTime = [];
      const hourlyCode = [];
      const hourlyTemp = [];
      const hourlyPop = [];
      const hourlyWind = [];
      const hourlyUv = [];
      for (let offset = 0; offset < 24; offset += 1) {
        const absoluteHour = hour + offset;
        const dayIndex = Math.floor(absoluteHour / 24);
        const dayWeather = dailyDays[Math.min(dayIndex, 6)] || currentDay;
        const h = absoluteHour % 24;
        const dayTemps = dayIndex === 0 ? todayTemps : dayTempsFor(dayWeather);
        const targetDate = new Date(today.getFullYear(), today.getMonth(), today.getDate() + dayIndex);
        hourlyTime.push(`${dateKey(targetDate)}T${pad2(h)}:00`);
        hourlyCode.push(dayWeather.code);
        hourlyTemp.push(dayTemps[h]);
        hourlyPop.push(dayWeather.precipitationProbability);
        hourlyWind.push(Math.max(2, Math.round(windKmh + (rng() - 0.5) * 6)));
        hourlyUv.push(h >= 7 && h <= 17 ? Math.max(0, Math.round(dayWeather.uvMax * Math.sin(Math.PI * (h - 7) / 10))) : 0);
      }

      const dateKeyToday = dateKey(today);
      const currentTime = `${dateKeyToday}T${pad2(hour)}:00`;
      const moon = moonPhaseForDate(now);

      const dayTimes = dailyDays.map((day) => dateKey(day.date));
      const sunriseArray = [];
      const sunsetArray = [];
      dailyDays.forEach((day) => {
        sunriseArray.push(`${dateKey(day.date)}T${day.sunrise}:00`);
        sunsetArray.push(`${dateKey(day.date)}T${day.sunset}:00`);
      });

      // 当前时刻的 UV（取就近整点）
      let uvIndex = 0;
      const idx = hourlyUv[0];
      if (hour >= 7 && hour <= 17) uvIndex = Math.max(1, idx);
      else uvIndex = Math.max(1, Math.round(currentDay.uvMax * 0.55));

      return {
        fetchedAt: Date.now(),
        location: {
          id: city.id,
          name: city.name,
          admin1: city.admin1,
          country: city.country,
          latitude: city.lat,
          longitude: city.lon
        },
        meta: { seed: seed >>> 0 },
        weather: {
          current: {
            time: currentTime,
            weather_code: currentCode,
            temperature_2m: currentTemp,
            apparent_temperature: feelsLike,
            relative_humidity_2m: currentDay.humidity,
            wind_speed_10m: windKmh,
            wind_direction_10m: windDirectionDeg,
            wind_gusts_10m: windGustKmh,
            visibility: visibilityM,
            surface_pressure: pressureHpa,
            precipitation: isRainCode(currentCode) ? Math.round(randBetween(rng, 0.1, 1.2) * 10) / 10 : 0,
            cloud_cover: currentDay.cloudCover
          },
          hourly: {
            time: hourlyTime,
            temperature_2m: hourlyTemp,
            weather_code: hourlyCode,
            precipitation_probability: hourlyPop,
            wind_speed_10m: hourlyWind,
            uv_index: hourlyUv
          },
          daily: {
            time: dayTimes,
            weather_code: dailyDays.map((day) => day.code),
            temperature_2m_max: dailyDays.map((day) => day.high),
            temperature_2m_min: dailyDays.map((day) => day.low),
            precipitation_sum: dailyDays.map((day) => day.precipitationMm),
            precipitation_probability_max: dailyDays.map((day) => day.precipitationProbability),
            uv_index_max: dailyDays.map((day) => day.uvMax),
            sunrise: sunriseArray,
            sunset: sunsetArray,
            sunshine_duration: dailyDays.map((day) => (day.code === 0 ? 36000 : day.code === 1 ? 26000 : day.code === 2 ? 16000 : 6000)),
            daylight_duration: dailyDays.map(() => 45900)
          }
        },
        air: {
          current: {
            us_aqi: aqi,
            pm2_5: pm25,
            pm10: pm10,
            ozone: ozone
          }
        },
        display: {
          conditionLabel: info.label,
          conditionIcon: info.icon,
          heroClass: info.hero,
          feelsLike,
          windKmh,
          windGustKmh,
          windDirectionDeg,
          windLabel: windDirectionLabel(windDirectionDeg),
          pressureHpa,
          visibilityM,
          aqi,
          aqiLabel: aqiLabel(aqi),
          pm25,
          uvIndex,
          uvMax: currentDay.uvMax,
          currentTemp,
          moonName: moon.name,
          moonIllumination: moon.illumination,
          updatedAt: Date.now(),
          hourlyView: hourlyTime.map((time, i) => ({
            time,
            hourLabel: i === 0 ? "现在" : `${pad2((hour + i) % 24)}时`,
            code: hourlyCode[i],
            temp: hourlyTemp[i],
            pop: hourlyPop[i]
          })),
          dailyView: dailyDays.map((day, index) => ({
            key: dateKey(day.date),
            weekday: index === 0 ? "今天" : index === 1 ? "明天" : WEEKDAYS[day.date.getDay()],
            code: day.code,
            high: day.high,
            low: day.low,
            pop: day.precipitationProbability
          }))
        }
      };
    }

    /* ---------- subjects / persistence 组装 ---------- */
    function buildSubjectValues(snapshot) {
      const now = new Date();
      const moon = moonPhaseForDate(now);
      const c = snapshot.weather.current;
      const daily = snapshot.weather.daily;
      const air = snapshot.air.current;
      const loc = snapshot.location;
      return {
        locationName: [loc.name, loc.admin1, loc.country].filter(Boolean).join(" · "),
        weatherCode: c.weather_code,
        temperatureC: round1(c.temperature_2m),
        feelsLikeC: round1(c.apparent_temperature),
        highC: round1(daily.temperature_2m_max[0]),
        lowC: round1(daily.temperature_2m_min[0]),
        humidity: round1(c.relative_humidity_2m),
        windKmh: round1(c.wind_speed_10m),
        windDirectionDeg: round1(c.wind_direction_10m),
        windGustKmh: round1(c.wind_gusts_10m),
        visibilityM: c.visibility,
        pressureHpa: round1(c.surface_pressure),
        precipitationMm: round1(c.precipitation),
        precipitationProbability: round1(daily.precipitation_probability_max[0]),
        cloudCover: round1(c.cloud_cover),
        aqi: round1(air.us_aqi),
        pm25: round1(air.pm2_5),
        pm10: round1(air.pm10),
        ozone: round1(air.ozone),
        uvIndex: round1(snapshot.display.uvIndex),
        uvMax: round1(daily.uv_index_max[0]),
        sunrise: daily.sunrise[0],
        sunset: daily.sunset[0],
        sunshineSeconds: daily.sunshine_duration[0],
        daylightSeconds: daily.daylight_duration[0],
        moonPhase: moon.name,
        moonIllumination: moon.illumination
      };
    }

    function assembleValue(city, snapshot, shareContext) {
      return {
        version: 2,
        activeLocation: {
          id: city.id,
          name: city.name,
          admin1: city.admin1,
          country: city.country,
          latitude: city.lat,
          longitude: city.lon
        },
        snapshots: {
          [city.id]: snapshot
        },
        subjects: {
          user: {
            type: "weather_subject",
            subjectType: "weather_subject",
            subjectId: "user",
            name: "我",
            values: buildSubjectValues(snapshot)
          }
        },
        settings: {
          shareContext: Boolean(shareContext),
          updatedAt: Date.now()
        }
      };
    }

    function generateAndAssemble(city, shareContext) {
      state.seedCounter += 1;
      const seed = (stableHash(city.id) + state.seedCounter * 7919 + Math.floor(Date.now() / 30000)) >>> 0;
      const snapshot = generateSnapshot(city, seed);
      snapshot.fetchedAt = Date.now();
      const value = assembleValue(city, snapshot, shareContext);
      state.data = value;
      state.display = snapshot.display;
      state.generation += 1;
      return value;
    }

    /* ---------- 持久化 ---------- */
    async function persistState() {
      const theme = window.ThemeCustomization;
      const db = theme?.db;
      if (!db?.persistenceMeta || !state.data) return false;
      try {
        await theme.ready;
        await db.persistenceMeta.put({
          key: STORAGE_KEY,
          value: state.data,
          updatedAt: Date.now()
        });
        return true;
      } catch (error) {
        console.warn(TAG, "weather.state.v2 持久化失败", error);
        return false;
      }
    }

    async function loadStateOrGenerate() {
      const theme = window.ThemeCustomization;
      const db = theme?.db;
      let loaded = null;
      if (db?.persistenceMeta) {
        try {
          await theme.ready;
          const row = await db.persistenceMeta.get(STORAGE_KEY);
          loaded = row?.value && typeof row.value === "object" ? row.value : null;
        } catch (error) {
          console.warn(TAG, "weather.state.v2 读取失败，将生成默认数据", error);
        }
      }
      if (loaded?.snapshots && typeof loaded.snapshots === "object") {
        const id = String(loaded.activeLocation?.id || "");
        const snap = id ? loaded.snapshots[id] : null;
        const firstSnap = snap || Object.values(loaded.snapshots).find((item) => item?.weather?.current);
        if (firstSnap?.weather?.current) {
          const city = CITIES.find((item) => item.id === id)
            || CITIES.find((item) => item.id === firstSnap.location?.id) || CITIES[0];
          state.city = city;
          state.shareContext = loaded.settings?.shareContext !== false;
          state.data = loaded;
          if (firstSnap.display) {
            state.display = firstSnap.display;
            return loaded;
          }
          // 旧结构（无 display 域）时按现有城市重建
          const rebuilt = generateAndAssemble(city, state.shareContext);
          await persistState();
          return rebuilt;
        }
      }
      const fresh = generateAndAssemble(CITIES[0], true);
      await persistState();
      return fresh;
    }

    /* ---------- DOM 构建 ---------- */
    function lucideElement(name, className) {
      const icon = document.createElement("i");
      icon.className = "qw-lucide";
      if (className) icon.classList.add(className);
      icon.setAttribute("data-lucide", name);
      icon.setAttribute("aria-hidden", "true");
      return icon;
    }

    function hydrateIcons(scope) {
      if (!scope) return;
      try {
        if (typeof window.lucide?.createIcons === "function") {
          window.lucide.createIcons({ root: scope, attrs: { "aria-hidden": "true", focusable: "false" } });
          return;
        }
      } catch (error) { /* 图标库失败时继续展示文本内容 */ }
      window.QWQIcons?.hydrate?.(scope);
    }

    function weatherClass(code) {
      const info = WMO_INFO[Number(code)] || WMO_INFO[2];
      return info.hero;
    }

    function buildFrame() {
      const app = document.createElement("div");
      app.className = "qw-weather-app";
      app.setAttribute("aria-label", "天气应用");

      const topbar = document.createElement("header");
      topbar.className = "qw-weather-topbar";
      const back = document.createElement("button");
      back.type = "button";
      back.className = "qw-weather-icon-button";
      back.setAttribute("aria-label", "返回主屏幕");
      back.dataset.qwWeatherAction = "back";
      back.appendChild(lucideElement("chevron-left"));
      const title = document.createElement("h2");
      title.className = "qw-weather-top-title";
      title.textContent = "天气";
      const refreshTop = document.createElement("button");
      refreshTop.type = "button";
      refreshTop.className = "qw-weather-icon-button";
      refreshTop.setAttribute("aria-label", "刷新天气");
      refreshTop.dataset.qwWeatherAction = "refresh";
      refreshTop.appendChild(lucideElement("rotate-cw"));
      topbar.append(back, title, refreshTop);

      const scroll = document.createElement("main");
      scroll.className = "qw-weather-scroll";

      app.append(topbar, scroll);
      return { app, scroll };
    }

    function renderAll() {
      const root = state.root;
      if (!root) return;
      const scroll = root.querySelector(".qw-weather-scroll");
      if (!scroll) return;
      const display = state.display;
      const data = state.data;
      if (!display || !data) return;

      const snapshot = data.snapshots[state.city.id] || data.snapshots[Object.keys(data.snapshots || {})[0]];
      if (!snapshot?.weather?.current) return;
      const current = snapshot.weather.current;
      const daily = snapshot.weather.daily;
      const heroClass = display.heroClass || weatherClass(current.weather_code);
      const info = WMO_INFO[current.weather_code] || WMO_INFO[2];
      const now = new Date();
      const fragments = [];

      /* --- Hero --- */
      const hero = document.createElement("section");
      hero.className = `qw-weather-card qw-weather-hero ${heroClass}`;

      const heroTop = document.createElement("div");
      heroTop.className = "qw-weather-hero-top";
      const cityBox = document.createElement("div");
      cityBox.className = "qw-weather-city";
      const cityButton = document.createElement("button");
      cityButton.type = "button";
      cityButton.className = "qw-weather-city-name";
      cityButton.setAttribute("aria-label", "切换城市，当前 " + state.city.name);
      cityButton.dataset.qwWeatherAction = "cycle-city";
      cityButton.textContent = state.city.name;
      const chevron = document.createElement("span");
      chevron.className = "qw-weather-city-toggle";
      chevron.appendChild(lucideElement("chevron-down"));
      cityBox.append(cityButton, chevron);

      const refreshPill = document.createElement("button");
      refreshPill.type = "button";
      refreshPill.className = "qw-weather-refresh-pill";
      refreshPill.dataset.qwWeatherAction = "refresh";
      refreshPill.appendChild(lucideElement("rotate-cw"));
      const pillLabel = document.createElement("span");
      pillLabel.textContent = "刷新";
      refreshPill.appendChild(pillLabel);
      const heroActions = document.createElement("div");
      heroActions.className = "qw-weather-hero-actions";
      const locatePill = document.createElement("button");
      locatePill.type = "button";
      locatePill.className = "qw-weather-refresh-pill";
      locatePill.dataset.qwWeatherAction = "locate";
      locatePill.setAttribute("aria-label", "使用当前定位");
      locatePill.appendChild(lucideElement("locate-fixed"));
      const locateLabel = document.createElement("span");
      locateLabel.textContent = "定位";
      locatePill.appendChild(locateLabel);
      heroActions.append(locatePill, refreshPill);
      heroTop.append(cityBox, heroActions);

      const dateLine = document.createElement("div");
      dateLine.className = "qw-weather-date-line";
      try {
        dateLine.textContent = new Intl.DateTimeFormat("zh-CN", { month: "long", day: "numeric", weekday: "long" }).format(now);
      } catch (error) {
        dateLine.textContent = `${now.getMonth() + 1}月${now.getDate()}日`;
      }

      const main = document.createElement("div");
      main.className = "qw-weather-main";
      const temp = document.createElement("div");
      temp.className = "qw-weather-temp";
      temp.textContent = `${current.temperature_2m}°`;
      const condSide = document.createElement("div");
      condSide.className = "qw-weather-condition-side";
      const cond = document.createElement("div");
      cond.className = "qw-weather-condition";
      cond.appendChild(lucideElement(info.icon));
      const condLabel = document.createElement("span");
      condLabel.textContent = info.label;
      cond.appendChild(condLabel);
      const hilo = document.createElement("div");
      hilo.className = "qw-weather-hilo";
      hilo.textContent = `${daily.temperature_2m_max[0]}° / ${daily.temperature_2m_min[0]}°`;
      const feels = document.createElement("div");
      feels.className = "qw-weather-feels";
      feels.textContent = `体感 ${current.apparent_temperature}°`;
      condSide.append(cond, hilo, feels);
      main.append(temp, condSide);
      hero.append(heroTop, dateLine, main);

      const divider = document.createElement("div");
      divider.className = "qw-weather-divider";
      hero.appendChild(divider);

      const miniRow = document.createElement("div");
      miniRow.className = "qw-weather-mini-row";
      const miniCells = [
        ["湿度", `${current.relative_humidity_2m}%`],
        ["风速", `${current.wind_speed_10m} km/h`],
        ["体感", `${current.apparent_temperature}°`],
        ["月相", display.moonName]
      ];
      miniCells.forEach(([label, value]) => {
        const cell = document.createElement("div");
        cell.className = "qw-weather-mini";
        const v = document.createElement("div");
        v.className = "qw-weather-mini-value";
        v.textContent = value;
        const l = document.createElement("div");
        l.className = "qw-weather-mini-label";
        l.textContent = label;
        cell.append(v, l);
        miniRow.appendChild(cell);
      });
      hero.appendChild(miniRow);
      fragments.push(hero);

      /* --- 详情格 --- */
      const detail = document.createElement("section");
      detail.className = "qw-weather-card qw-weather-detail-card";
      const detailTitle = document.createElement("h3");
      detailTitle.className = "qw-weather-section-title";
      detailTitle.textContent = "实时详情";
      detail.appendChild(detailTitle);
      const grid = document.createElement("div");
      grid.className = "qw-weather-grid";

      const airValue = display.aqi;
      const tileData = [
        { label: "湿度", icon: "droplets", value: `${current.relative_humidity_2m}%`, sub: "相对湿度" },
        { label: "风", icon: "wind", value: `${display.windLabel} ${current.wind_speed_10m}`, sub: `阵风 ${current.wind_gusts_10m} km/h` },
        { label: "空气质量", icon: "smog", value: `AQI ${airValue}`, sub: `PM2.5 ${display.pm25} · ${display.aqiLabel}` },
        { label: "能见度", icon: "eye", value: `${(current.visibility / 1000).toFixed(1)} km`, sub: "清晰视野" },
        { label: "气压", icon: "gauge", value: `${current.surface_pressure} hPa`, sub: "海平面气压" },
        { label: "紫外线", icon: "sun", value: `${display.uvIndex} ${uvLabel(display.uvIndex)}`, sub: `今日峰值 ${display.uvMax}` }
      ];
      tileData.forEach((tile) => {
        const box = document.createElement("div");
        box.className = "qw-weather-tile";
        const top = document.createElement("div");
        top.className = "qw-weather-tile-top";
        top.appendChild(lucideElement(tile.icon));
        const labelSpan = document.createElement("span");
        labelSpan.textContent = tile.label;
        top.appendChild(labelSpan);
        const value = document.createElement("div");
        value.className = "qw-weather-tile-value";
        value.textContent = tile.value;
        const sub = document.createElement("div");
        sub.className = "qw-weather-tile-sub";
        sub.textContent = tile.sub;
        box.append(top, value, sub);
        grid.appendChild(box);
      });
      detail.appendChild(grid);
      fragments.push(detail);

      /* --- 24 小时 --- */
      const hourlyCard = document.createElement("section");
      hourlyCard.className = "qw-weather-card qw-weather-hourly-wrap";
      const hourlyTitle = document.createElement("h3");
      hourlyTitle.className = "qw-weather-section-title";
      hourlyTitle.style.paddingTop = "14px";
      hourlyTitle.style.paddingLeft = "14px";
      hourlyTitle.style.marginBottom = "2px";
      hourlyTitle.textContent = "24 小时预报";
      hourlyCard.appendChild(hourlyTitle);
      const strip = document.createElement("div");
      strip.className = "qw-weather-hourly";
      display.hourlyView.forEach((item, index) => {
        const cell = document.createElement("div");
        cell.className = index === 0 ? "qw-weather-hour is-now" : "qw-weather-hour";
        const time = document.createElement("div");
        time.className = "qw-weather-hour-time";
        time.textContent = item.hourLabel;
        const icon = document.createElement("div");
        icon.className = "qw-weather-hour-icon";
        icon.appendChild(lucideElement((WMO_INFO[item.code] || WMO_INFO[2]).icon));
        const tempLabel = document.createElement("div");
        tempLabel.className = "qw-weather-hour-temp";
        tempLabel.textContent = `${item.temp}°`;
        cell.append(time, icon, tempLabel);
        strip.appendChild(cell);
      });
      hourlyCard.appendChild(strip);
      fragments.push(hourlyCard);

      /* --- 7 天 --- */
      const daysCard = document.createElement("section");
      daysCard.className = "qw-weather-card qw-weather-days";
      const daysTitle = document.createElement("h3");
      daysTitle.className = "qw-weather-section-title";
      daysTitle.textContent = "未来 7 天";
      daysCard.appendChild(daysTitle);
      const lows = display.dailyView.map((day) => day.low);
      const highs = display.dailyView.map((day) => day.high);
      const rangeMin = Math.min(...lows);
      const rangeMax = Math.max(...highs);

      display.dailyView.forEach((day, index) => {
        const row = document.createElement("button");
        row.type = "button";
        row.className = "qw-weather-day";
        const week = document.createElement("div");
        week.className = "qw-weather-day-week" + (index === 0 ? " is-today" : "");
        week.textContent = day.weekday;
        const cond = document.createElement("div");
        cond.className = "qw-weather-day-cond";
        cond.appendChild(lucideElement((WMO_INFO[day.code] || WMO_INFO[2]).icon));
        const condText = document.createElement("span");
        condText.textContent = (WMO_INFO[day.code] || WMO_INFO[2]).label;
        cond.appendChild(condText);
        const temps = document.createElement("div");
        temps.className = "qw-weather-day-temps";
        const low = document.createElement("span");
        low.className = "qw-weather-day-low";
        low.textContent = `${day.low}°`;
        const barWrap = document.createElement("span");
        barWrap.className = "qw-weather-temp-range";
        const bar = document.createElement("i");
        const spanRange = rangeMax - rangeMin;
        const startPercent = spanRange === 0 ? 0 : ((day.low - rangeMin) / spanRange) * 100;
        const widthPercent = spanRange === 0 ? 100 : Math.max(8, ((day.high - day.low) / spanRange) * 100);
        bar.style.left = `${Math.max(0, Math.min(92, startPercent))}%`;
        bar.style.width = `${Math.min(100, widthPercent)}%`;
        barWrap.appendChild(bar);
        const high = document.createElement("span");
        high.className = "qw-weather-day-high";
        high.textContent = `${day.high}°`;
        temps.append(low, barWrap, high);
        const pop = document.createElement("div");
        pop.className = "qw-weather-day-pop";
        pop.textContent = day.pop >= 55 ? `${day.pop}%` : "";
        row.append(week, cond, temps, pop);
        daysCard.appendChild(row);
      });
      fragments.push(daysCard);

      /* --- 数据源说明 --- */
      const source = document.createElement("section");
      source.className = "qw-weather-card qw-weather-source";
      const note = document.createElement("div");
      note.className = "qw-weather-source-note";
      note.appendChild(lucideElement("circle-info"));
      const noteText = document.createElement("span");
      noteText.textContent = "数据来源：清柳 天气模拟器（随机但自洽的一天）。仅供学习展示，不作为真实天气预报。";
      note.appendChild(noteText);

      const shareButton = document.createElement("button");
      shareButton.type = "button";
      shareButton.className = "qw-weather-share-toggle" + (state.shareContext ? "" : " is-off");
      shareButton.dataset.qwWeatherAction = "toggle-share";
      shareButton.setAttribute("role", "switch");
      shareButton.setAttribute("aria-checked", state.shareContext ? "true" : "false");
      const shareLeft = document.createElement("span");
      shareLeft.className = "qw-weather-share-left";
      shareLeft.appendChild(lucideElement(state.shareContext ? "share-2" : "share"));
      const shareCopy = document.createElement("span");
      shareCopy.textContent = "与 QQ 对话共享天气";
      shareLeft.appendChild(shareCopy);
      const status = document.createElement("span");
      status.className = "qw-weather-share-status";
      status.textContent = state.shareContext ? "已开启" : "已关闭";
      shareLeft.appendChild(status);
      const sw = document.createElement("button");
      sw.type = "button";
      sw.className = "ui-switch" + (state.shareContext ? " is-on" : "");
      sw.setAttribute("role", "switch");
      sw.setAttribute("aria-checked", state.shareContext ? "true" : "false");
      sw.setAttribute("aria-label", "与 QQ 共享天气");
      shareButton.append(shareLeft, sw);

      const updated = document.createElement("div");
      updated.className = "qw-weather-updated";
      const updatedTime = new Date(display.updatedAt);
      let timeText = "";
      try {
        timeText = updatedTime.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
      } catch (error) {
        timeText = updatedTime.getHours() + ":" + String(updatedTime.getMinutes()).padStart(2, "0");
      }
      const locationPart = state.city.lat ? ` · 定位 ${state.city.lat.toFixed(2)}N ${state.city.lon.toFixed(2)}E` : "";
      updated.textContent = `更新于 ${timeText} · 本地模拟数据${locationPart}`;
      source.append(note, shareButton, updated);
      fragments.push(source);

      scroll.replaceChildren(...fragments);
      hydrateIcons(scroll);
    }

    /* ---------- 交互 ---------- */
    function goHome() {
      try {
        if (window.MyPhoneManager?.closeApp) {
          window.MyPhoneManager.closeApp("weather");
          return;
        }
      } catch (error) {
        console.warn(TAG, "closeApp 调用失败", error);
      }
      try {
        document.dispatchEvent(new CustomEvent("qwq:system:back", { detail: { app: "weather" } }));
      } catch (error) {
        console.warn(TAG, "返回事件派发失败", error);
      }
    }

    async function refreshWeather(options) {
      try {
        const city = state.city;
        generateAndAssemble(city, state.shareContext);
        const shouldPersist = !(options && options.persist === false);
        if (shouldPersist) await persistState();
        renderAll();
        console.log(TAG, "已刷新", state.city.name);
        return true;
      } catch (error) {
        console.error(TAG, "刷新失败", error);
        return false;
      }
    }

    /* ---------- 当前定位 ---------- */
    const LOCATE_MATCH_KM = 120;

    function geoDistanceKm(lat1, lon1, lat2, lon2) {
      const toRad = (value) => (Number(value) * Math.PI) / 180;
      const R = 6371;
      const dLat = toRad(lat2 - lat1);
      const dLon = toRad(lon2 - lon1);
      const a = Math.sin(dLat / 2) ** 2
        + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
      return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
    }

    function meanTempFromLatitude(lat) {
      // 由纬度粗略推年均温：赤道约 27℃，每偏 1° 约降 0.45℃，收敛到合理区间。
      const value = 27 - Math.abs(Number(lat) || 0) * 0.45;
      return Math.round(Math.max(-8, Math.min(30, value)) * 10) / 10;
    }

    function buildLocatedCity(lat, lon) {
      const latText = `${Math.abs(lat).toFixed(2)}°${lat >= 0 ? "N" : "S"}`;
      const lonText = `${Math.abs(lon).toFixed(2)}°${lon >= 0 ? "E" : "W"}`;
      return {
        id: `located-${lat.toFixed(4)}-${lon.toFixed(4)}`,
        name: "当前定位",
        admin1: `${latText} ${lonText}`,
        country: "",
        lat,
        lon,
        mean: meanTempFromLatitude(lat),
        located: true
      };
    }

    function requestGeolocation() {
      return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
          reject(new Error("geolocation_unsupported"));
          return;
        }
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: false,
          timeout: 10000,
          maximumAge: 300000
        });
      });
    }

    async function locateWeather() {
      try {
        const position = await requestGeolocation();
        const lat = Number(position.coords.latitude);
        const lon = Number(position.coords.longitude);
        let nearest = null;
        let nearestKm = Infinity;
        CITIES.forEach((city) => {
          const km = geoDistanceKm(lat, lon, city.lat, city.lon);
          if (km < nearestKm) { nearestKm = km; nearest = city; }
        });
        const matched = Boolean(nearest) && nearestKm <= LOCATE_MATCH_KM;
        const city = matched ? nearest : buildLocatedCity(lat, lon);
        state.city = city;
        const refreshed = await refreshWeather({ persist: true });
        console.log(TAG, "定位完成", city.name, `${Math.round(nearestKm)}km`, refreshed);
        if (!refreshed) return { ok: false, reason: "refresh_failed" };
        return { ok: true, city, matched, distanceKm: nearestKm };
      } catch (error) {
        const denied = Number(error?.code) === 1;
        console.warn(TAG, "定位不可用", denied ? "用户拒绝授权" : (error?.message || error));
        return { ok: false, reason: denied ? "denied" : "unavailable" };
      }
    }

    function locateNotice(result) {
      const hero = document.querySelector(".qw-weather-hero");
      if (!hero) return;
      let node = hero.querySelector("[data-qw-weather-locate-note]");
      if (!node) {
        node = document.createElement("div");
        node.className = "qw-weather-locate-note";
        node.dataset.qwWeatherLocateNote = "";
        hero.appendChild(node);
      }
      const text = result?.reason === "denied"
        ? "已拒绝定位授权，保持原城市"
        : result?.reason === "refresh_failed"
          ? "定位成功但天气刷新失败"
          : "当前环境不支持定位，保持原城市";
      node.textContent = text;
      node.hidden = false;
      window.clearTimeout(locateWeather._noteTimer);
      locateWeather._noteTimer = window.setTimeout(() => { node.hidden = true; }, 3600);
    }

    function cycleCity() {
      const currentIndex = CITIES.findIndex((item) => item.id === state.city.id);
      const next = CITIES[(currentIndex + 1) % CITIES.length];
      state.city = next;
      void refreshWeather({ persist: true });
    }

    async function toggleShare() {
      state.shareContext = !state.shareContext;
      if (state.data) {
        state.data.settings = { shareContext: Boolean(state.shareContext), updatedAt: Date.now() };
        const snaps = state.data.snapshots;
        if (snaps && typeof snaps === "object") {
          Object.keys(snaps).forEach((key) => {
            const snap = snaps[key];
            if (snap && typeof snap === "object") snap.settings = { shareContext: Boolean(state.shareContext) };
          });
        }
      }
      await persistState();
      renderAll();
      return state.shareContext;
    }

    function onClick(event) {
      const target = event.target;
      const actionEl = target.closest?.("[data-qw-weather-action]");
      if (!actionEl) return;
      const action = actionEl.dataset.qwWeatherAction;
      if (!action) return;
      event.preventDefault();
      if (action === "back") goHome();
      else if (action === "refresh") {
        const pill = actionEl;
        pill.classList.add("is-busy");
        window.setTimeout(() => pill.classList.remove("is-busy"), 700);
        void refreshWeather({ persist: true });
      } else if (action === "cycle-city") cycleCity();
      else if (action === "locate") {
        const pill = actionEl;
        pill.classList.add("is-busy");
        void locateWeather().then((result) => {
          pill.classList.remove("is-busy");
          if (!result?.ok) locateNotice(result);
        });
      }
      else if (action === "toggle-share") void toggleShare();
    }

    /* ---------- open / close ---------- */
    async function ensureMount() {
      if (state.mounted || !state.root) return;
      const frame = buildFrame();
      state.root.replaceChildren(frame.app);
      state.mounted = true;
    }

    async function open() {
      try {
        const root = document.getElementById("qwq-weather-root");
        if (!root) return false;
        state.root = root;
        await loadStateOrGenerate();
        await ensureMount();
        renderAll();
        console.log(TAG, "已打开", state.city.name, state.display?.currentTemp !== undefined ? state.display.currentTemp + "°" : "");
        return true;
      } catch (error) {
        console.error(TAG, "打开失败", error);
        return false;
      }
    }

    function close() {
      // 轻量页面生命周期：路由隐藏已把页面移出渲染树，DOM/数据可复用。
      return true;
    }

    /* ---------- 初始化 ---------- */
    const root = document.getElementById("qwq-weather-root");
    if (root) {
      state.root = root;
      root.addEventListener("click", onClick);
    }

    const WeatherApp = Object.freeze({
      open,
      close,
      refreshWeather
    });

    if (!window.WeatherApp) {
      window.WeatherApp = WeatherApp;
    } else {
      window.WeatherApp.open = open;
      window.WeatherApp.close = close;
      window.WeatherApp.refreshWeather = refreshWeather;
    }
    console.log(TAG, "模块就绪");
  } catch (error) {
    console.error("[Weather] 初始化失败", error);
    if (!window.WeatherApp) {
      window.WeatherApp = Object.freeze({ open: () => false, close: () => true });
    }
  }
})();
