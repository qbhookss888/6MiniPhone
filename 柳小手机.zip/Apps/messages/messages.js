/* Messages App —— 信息（经典脚本，全局 MessagesApp）。 */
(function () {
  "use strict";
  if (window.MessagesApp) return;

  const page = document.getElementById("page-messages-app");
  const THREADS_KEY = "messages.threads.v1";

  const state = {
    threads: [],
    hydrated: false,
    selectedContact: null
  };

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
  }

  async function dbReady() {
    try { await window.ThemeCustomization?.ready; } catch (_) { }
    return window.ThemeCustomization?.db || null;
  }

  function nameOf(contact) {
    return String(contact?.displayName || contact?.name || contact?.nickname || "").trim() || "未知联系人";
  }

  async function loadContacts() {
    const db = await dbReady();
    if (!db?.contacts) return [];
    try {
      const all = await db.contacts.toArray();
      const seen = new Set();
      const rows = [];
      all.forEach((c) => {
        const key = c.contactId || nameOf(c);
        if (seen.has(key)) return;
        seen.add(key);
        rows.push(c);
      });
      return rows;
    } catch (_) { return []; }
  }

  async function hydrate() {
    if (state.hydrated) return;
    const db = await dbReady();
    if (db?.persistenceMeta) {
      try {
        const row = await db.persistenceMeta.get(THREADS_KEY);
        if (Array.isArray(row?.value)) state.threads = row.value;
      } catch (_) { }
    }
    state.hydrated = true;
  }

  async function persist() {
    const db = await dbReady();
    if (!db?.persistenceMeta) return;
    try {
      await db.persistenceMeta.put({ key: THREADS_KEY, value: state.threads.slice(0, 60), updatedAt: Date.now() });
    } catch (_) { }
  }

  function letterTime(at) {
    const time = Number(at) || Date.now();
    const date = new Date(time);
    const now = new Date();
    if (date.toDateString() === now.toDateString()) {
      return new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit", hour12: false }).format(date);
    }
    return new Intl.DateTimeFormat("zh-CN", { month: "numeric", day: "numeric" }).format(date);
  }

  async function renderThreads() {
    const host = page?.querySelector(".messages-list");
    if (!host) return;
    const contacts = await loadContacts();
    const contactMap = new Map(contacts.map((c) => [c.contactId, c]));

    // 聊天消息聚合（QQ 数据）
    let chatThreads = [];
    const db = await dbReady();
    if (db?.chatMessages) {
      try {
        const rows = await db.chatMessages.orderBy("[accountId+conversationId+createdAt+messageId]").reverse().limit(120).toArray().catch(() => []);
        if (!rows.length) {
          // 兼容旧索引
          const fallback = await db.chatMessages.orderBy("createdAt").reverse().limit(200).toArray().catch(() => []);
          rows.push(...fallback);
        }
        const byConv = new Map();
        rows.forEach((row) => {
          const key = row.conversationId;
          if (!byConv.has(key) || (row.createdAt || 0) > (byConv.get(key).createdAt || 0)) byConv.set(key, row);
        });
        byConv.forEach((row, conversationId) => {
          const contact = contactMap.get(conversationId) || null;
          chatThreads.push({
            key: conversationId,
            contactId: conversationId,
            name: contact ? nameOf(contact) : String(conversationId).slice(0, 12),
            preview: row.content ? String(row.content).slice(0, 60) : (row.type === "image" ? "[图片]" : "[消息]"),
            at: row.createdAt || Date.now()
          });
        });
      } catch (_) { }
    }

    // 短信线索
    const smsMap = new Map(state.threads.map((t) => [t.contactId, t]));
    chatThreads.forEach((t) => { if (!smsMap.has(t.contactId)) smsMap.set(t.contactId, t); });
    const merged = Array.from(smsMap.values()).sort((a, b) => (b.at || 0) - (a.at || 0));

    host.replaceChildren();
    const empty = page?.querySelector(".messages-new-empty");
    if (empty) empty.hidden = merged.length > 0;

    if (!merged.length) {
      const hint = document.createElement("div");
      hint.className = "messages-empty-hint";
      hint.textContent = "暂无信息，点右下角新建消息";
      host.appendChild(hint);
      return;
    }

    merged.forEach((thread) => {
      const contact = contactMap.get(thread.contactId) || null;
      const name = contact ? nameOf(contact) : thread.name;
      const row = document.createElement("button");
      row.type = "button";
      row.className = "messages-thread-row";
      const avatar = document.createElement("span");
      avatar.className = "messages-thread-avatar";
      avatar.textContent = (name[0] || "?").toUpperCase();
      const body = document.createElement("span");
      body.className = "messages-thread-body";
      const title = document.createElement("strong");
      title.textContent = name;
      const sub = document.createElement("small");
      sub.textContent = thread.preview || "";
      body.append(title, sub);
      const time = document.createElement("time");
      time.className = "messages-thread-time";
      time.textContent = letterTime(thread.at);
      row.append(avatar, body, time);
      row.addEventListener("click", () => openConversation(thread.contactId, name));
      host.appendChild(row);
    });
  }

  function openConversation(contactId, name) {
    document.dispatchEvent(new CustomEvent("qwq:contact-message", { detail: { contactId, name } }));
  }

  // ---------- 新建短信 ----------
  function openComposer() {
    const views = page ? page.querySelectorAll(".messages-view") : [];
    if (!views.length) return;
    showView("compose");
    void renderContactPicker();
  }

  async function renderContactPicker() {
    const picker = page?.querySelector('[data-messages-picker]');
    if (!picker) return;
    const contacts = await loadContacts();
    picker.replaceChildren();
    contacts.forEach((c) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "messages-pick-contact";
      btn.textContent = nameOf(c);
      btn.addEventListener("click", () => {
        state.selectedContact = c;
        const toLabel = page?.querySelector(".messages-to-label, [data-messages-to]");
        if (toLabel) toLabel.textContent = `发送给：${nameOf(c)}`;
        const input = page?.querySelector(".messages-input-shell textarea, [data-messages-input]");
        if (input) input.focus();
      });
      picker.appendChild(btn);
    });
    if (!contacts.length) {
      const empty = document.createElement("div");
      empty.className = "messages-empty-hint";
      empty.textContent = "先在 QQ 添加联系人";
      picker.appendChild(empty);
    }
  }

  async function sendSms() {
    const input = page?.querySelector(".messages-input-shell textarea, [data-messages-input]");
    const value = (input?.value || "").trim();
    const contact = state.selectedContact;
    if (!contact || !value) return;
    const db = await dbReady();
    const contactId = contact.contactId;
    state.threads = [
      { contactId, name: nameOf(contact), preview: value, at: Date.now(), lastText: value },
      ...state.threads.filter((t) => t.contactId !== contactId)
    ].slice(0, 60);
    void persist();
    if (input) input.value = "";
    document.dispatchEvent(new CustomEvent("qwq:contact-message", { detail: { contactId } }));
    showView("list");
  }

  function showView(name) {
    if (!page) return;
    const target = String(name || "list");
    page.querySelectorAll(".messages-view").forEach((v) => {
      v.classList.toggle("is-active", String(v.dataset.messagesView || "") === target);
    });
  }

  function bindEvents() {
    if (!page || page.dataset.messagesBound === "1") return;
    page.dataset.messagesBound = "1";

    const fab = page.querySelector(".messages-compose-fab, [data-messages-compose-open]");
    if (fab) fab.addEventListener("click", openComposer);

    const cancel = page.querySelector(".messages-compose-cancel, [data-messages-compose-cancel]");
    if (cancel) cancel.addEventListener("click", () => showView("list"));

    const send = page.querySelector(".messages-send, [data-messages-send]");
    if (send) send.addEventListener("click", () => void sendSms());

    const search = page.querySelector("[data-messages-search], .messages-search-shell input");
    if (search) {
      search.addEventListener("input", () => {
        const term = String(search.value || "").toLowerCase().trim();
        page.querySelectorAll(".messages-thread-row").forEach((row) => {
          row.hidden = term ? !(row.textContent || "").toLowerCase().includes(term) : false;
        });
      });
    }

    const title = page.querySelector(".messages-title");
    if (title && title.tagName === "BUTTON") {
      title.addEventListener("click", () => {
        try { window.MyPhoneManager?.open?.(); } catch (_) { }
      });
    }
  }

  // ---------- 契约 ----------
  function open() {
    if (!page) return false;
    bindEvents();
    void hydrate().then(() => renderThreads());
    return true;
  }

  function close() { return true; }

  function composeTo(contactId, name) {
    openConversation(contactId, name);
    return true;
  }

  function stateInfo() {
    return { threads: state.threads.length, selected: state.selectedContact ? nameOf(state.selectedContact) : null };
  }

  window.MessagesApp = Object.freeze({
    open,
    close,
    composeTo,
    state: stateInfo
  });
})();
console.log("[Messages] 信息模块已加载");
