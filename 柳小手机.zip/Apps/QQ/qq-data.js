const QQAccountStore = (() => {
      const db = ThemeCustomization.db;
      // v38 keeps the historical physical table name only so Dexie can upgrade existing databases in place.
      // Runtime semantics are a canonical QQ account entity, not a separate "profile" layer.
      const accounts = db.qqAccountProfiles;
      const state = db.qqAccountState;
      const assets = db.mediaAssets;
      const CONTINUITY_ACCOUNT_ID = "qwq-continuity-account-v33";
      let initialized = null;
      // Runtime session snapshot: IndexedDB is the canonical persistence source, but the
      // same document must not re-read and re-validate the login pointer on every QQ entry.
      // "unknown" is used only until the first authoritative read in this document.
      let sessionCacheState = "unknown";
      let sessionCache = null;

      function uid(prefix) {
        const raw = globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
        return `${prefix}-${raw}`;
      }

      function expectedBuild() {
        return String(window.__QWQ_CONFIG__?.version || "V0.0.308").replace(/^V/i, "");
      }

      function assertAccountRuntimeBuild() {
        const build = expectedBuild();
        const themeBuild = String(ThemeCustomization?.build || "").replace(/^V/i, "");
        if (themeBuild === build && typeof ThemeCustomization?.migrateQqAccounts === "function") return true;
        // 版本错配属于真实启动错误；禁止通过 location.replace 自行刷新，避免刷新链和裸 HTML 中间态。
        throw new Error(`清柳构建版本不一致：主题运行时 ${themeBuild || "未知"} / QQ运行时 ${build}`);
      }

      function normalizeText(value, maxLength = Number.POSITIVE_INFINITY) {
        const text = String(value ?? "").replace(/\r\n?/g, "\n").trim();
        return Number.isFinite(maxLength) ? text.slice(0, maxLength) : text;
      }

      function normalizeCredential(value) {
        if (!value || typeof value !== "object" || Array.isArray(value)) return null;
        const algorithm = normalizeText(value.algorithm, 40);
        const salt = normalizeText(value.salt, 400);
        const hash = normalizeText(value.hash, 400);
        const iterations = Number.parseInt(value.iterations, 10) || 0;
        if (!algorithm || !salt || !hash) return null;
        if (algorithm === "pbkdf2-sha256") {
          if (iterations < 1000) return null;
          return { algorithm, salt, hash, iterations };
        }
        if (algorithm === "local-fallback-v1") return { algorithm, salt, hash };
        return null;
      }

      function isLoginAccountRow(value) {
        if (!value || typeof value !== "object" || Array.isArray(value)) return false;
        if (value.status === "continuity-draft") return false;
        const accountId = normalizeText(value.accountId, 180);
        const qqNumber = normalizeText(value.qqNumber, 12).replace(/\D/g, "");
        return Boolean(accountId && /^\d{5,12}$/.test(qqNumber) && normalizeCredential(value.credential));
      }

      function isContinuityDraft(value) {
        return Boolean(value && value.accountId === CONTINUITY_ACCOUNT_ID && value.status === "continuity-draft");
      }

      function normalize(value = {}, accountId = null, { includeCredential = false } = {}) {
        const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
        const phoneNumber = normalizeText(source.phoneNumber);
        const record = {
          accountId: normalizeText(accountId || source.accountId, 180) || null,
          qqNumber: normalizeText(source.qqNumber, 12).replace(/\D/g, ""),
          nickname: normalizeText(source.nickname || source.displayName),
          name: normalizeText(source.name),
          persona: normalizeText(source.persona ?? source.settingContent),
          signature: normalizeText(source.signature || source.bio),
          gender: normalizeText(source.gender),
          birthday: normalizeText(source.birthday),
          constellation: normalizeText(source.constellation),
          location: normalizeText(source.location || source.current),
          origin: normalizeText(source.origin),
          tags: normalizeText(source.tags),
          likes: normalizeText(source.likes) || "0",
          level: Math.max(1, Math.min(4095, Number.parseInt(source.level, 10) || 1)),
          avatarAssetId: normalizeText(source.avatarAssetId, 180) || null,
          coverAssetId: normalizeText(source.coverAssetId, 180) || null,
          registeredAt: Number(source.registeredAt) || 0,
          createdAt: Number(source.createdAt) || 0,
          updatedAt: Number(source.updatedAt) || 0
        };
        if (phoneNumber) record.phoneNumber = phoneNumber;
        if (includeCredential) record.credential = normalizeCredential(source.credential);
        return record;
      }

      async function ensureInitialized() {
        if (initialized) return initialized;
        initialized = (async () => {
          if (!assertAccountRuntimeBuild()) {
            // Navigation has been committed. Keep this launch suspended until the old document is replaced;
            // do not continue a mixed-build migration and do not surface a false QQ initialization alert.
            await new Promise(() => {});
          }
          await ThemeCustomization.continuityReady;
          await ThemeCustomization.migrateQqAccounts();
          return true;
        })();
        initialized = initialized.catch((error) => {
          initialized = null;
          throw error;
        });
        return initialized;
      }

      async function mediaBlob(assetId) {
        if (!assetId) return null;
        const row = await assets.get(assetId);
        return row?.blob instanceof Blob && row.blob.size ? row.blob : null;
      }

      async function get(accountId, { withMedia = true, includeCredential = false } = {}) {
        await ensureInitialized();
        const id = normalizeText(accountId, 180);
        if (!id) return null;
        const row = await accounts.get(id);
        if (!isLoginAccountRow(row)) return null;
        const account = normalize(row, id, { includeCredential });
        const mediaScope = withMedia === false ? "none" : withMedia === "avatar" ? "avatar" : withMedia === "cover" ? "cover" : "all";
        if (mediaScope === "none") return account;
        if (mediaScope === "avatar") {
          const avatarBlob = await mediaBlob(account.avatarAssetId);
          return { ...account, avatarBlob };
        }
        if (mediaScope === "cover") {
          const coverBlob = await mediaBlob(account.coverAssetId);
          return { ...account, coverBlob };
        }
        const [avatarBlob, coverBlob] = await Promise.all([
          mediaBlob(account.avatarAssetId),
          mediaBlob(account.coverAssetId)
        ]);
        return { ...account, avatarBlob, coverBlob };
      }

      async function list(accountIds = null, options = {}) {
        await ensureInitialized();
        const ids = Array.isArray(accountIds)
          ? Array.from(new Set(accountIds.map((value) => normalizeText(value, 180)).filter(Boolean)))
          : null;
        const rows = ids ? (await accounts.bulkGet(ids)).filter(isLoginAccountRow) : (await accounts.toArray()).filter(isLoginAccountRow);
        const normalized = rows.map((row) => normalize(row, row.accountId, { includeCredential: options.includeCredential === true }));
        normalized.sort((a, b) => (Number(a.registeredAt) || Number(a.createdAt) || 0) - (Number(b.registeredAt) || Number(b.createdAt) || 0));
        if (options.withMedia === false) return normalized;
        return Promise.all(normalized.map((row) => get(row.accountId, options)));
      }

      async function identifierOwner(identifier) {
        const value = normalizeText(identifier);
        if (!value) return null;
        const [qqMatches, phoneMatches] = await Promise.all([
          /^\d{5,12}$/.test(value) ? accounts.where("qqNumber").equals(value).toArray() : [],
          accounts.where("phoneNumber").equals(value).toArray()
        ]);
        const owners = new Map();
        for (const row of [...qqMatches, ...phoneMatches]) {
          if (!isLoginAccountRow(row)) continue;
          owners.set(row.accountId, row);
        }
        if (owners.size > 1) throw new Error("QQ账号标识冲突，请先修复重复账号数据");
        return owners.values().next().value || null;
      }

      async function findByIdentifier(identifier, { includeCredential = true, withMedia = false } = {}) {
        await ensureInitialized();
        const row = await identifierOwner(identifier);
        if (!row) return null;
        return get(row.accountId, { includeCredential, withMedia });
      }

      function cloneSession(value) {
        if (!value) return null;
        return {
          key: "session",
          accountId: value.accountId,
          signedInAt: Number(value.signedInAt) || 0,
          updatedAt: Number(value.updatedAt) || 0
        };
      }

      function cacheSession(value) {
        sessionCache = cloneSession(value);
        sessionCacheState = "resolved";
        return cloneSession(sessionCache);
      }

      function invalidateSessionCache() {
        sessionCacheState = "unknown";
        sessionCache = null;
      }

      async function getSession({ fresh = false } = {}) {
        await ensureInitialized();
        if (!fresh && sessionCacheState === "resolved") return cloneSession(sessionCache);
        const row = await state.get("session");
        const accountId = normalizeText(row?.accountId, 180);
        if (!accountId) return cacheSession(null);
        const account = await accounts.get(accountId);
        if (!isLoginAccountRow(account)) {
          await state.delete("session");
          return cacheSession(null);
        }
        return cacheSession({ key: "session", accountId, signedInAt: Number(row?.signedInAt) || 0, updatedAt: Number(row?.updatedAt) || 0 });
      }

      async function getActiveAccountId(options = {}) {
        const session = await getSession(options);
        return session?.accountId || null;
      }

      async function getLastUsedAccountId() {
        await ensureInitialized();
        const row = await state.get("last-used");
        const accountId = normalizeText(row?.accountId, 180);
        if (!accountId) return null;
        if (isLoginAccountRow(await accounts.get(accountId))) return accountId;
        await state.delete("last-used");
        return null;
      }

      async function setSession(accountId) {
        await ensureInitialized();
        const id = normalizeText(accountId, 180);
        if (!id || !isLoginAccountRow(await accounts.get(id))) throw new Error("QQ账号不存在");
        const now = Date.now();
        await db.transaction("rw", state, async () => {
          await state.put({ key: "session", accountId: id, signedInAt: now, updatedAt: now });
          await state.put({ key: "last-used", accountId: id, updatedAt: now });
        });
        cacheSession({ key: "session", accountId: id, signedInAt: now, updatedAt: now });
        return id;
      }

      async function clearSession() {
        await ensureInitialized();
        await state.delete("session");
        cacheSession(null);
        return true;
      }

      async function countAssetReferences(assetId) {
        if (!assetId) return 0;
        const [contactRefs, templateRefs, characterRefs, accountAvatarRefs, accountCoverRefs] = await Promise.all([
          db.contacts.where("avatarAssetId").equals(assetId).count(),
          db.characterTemplates.where("avatarAssetId").equals(assetId).count(),
          db.characters.where("avatarAssetId").equals(assetId).count(),
          accounts.where("avatarAssetId").equals(assetId).count(),
          accounts.where("coverAssetId").equals(assetId).count()
        ]);
        return contactRefs + templateRefs + characterRefs + accountAvatarRefs + accountCoverRefs;
      }

      async function putPreparedMedia(accountId, kind, persistentBlob) {
        if (!(persistentBlob instanceof Blob) || !persistentBlob.size) return null;
        const now = Date.now();
        const assetId = uid("asset");
        // 这里只允许 Dexie/IndexedDB 请求。File/Blob 的 arrayBuffer、解码与重编码必须在
        // transaction 之前完成，否则浏览器可在等待非 IDB Promise 时自动提交事务。
        await assets.add({
          assetId,
          kind,
          ownerType: "qq-account",
          ownerId: accountId,
          mime: persistentBlob.type || "application/octet-stream",
          size: persistentBlob.size,
          blob: persistentBlob,
          createdAt: now,
          updatedAt: now
        });
        return assetId;
      }

      async function register(input = {}, { claimContinuity = true } = {}) {
        await ensureInitialized();
        const accountId = normalizeText(input.accountId, 180);
        const qqNumber = normalizeText(input.qqNumber, 12).replace(/\D/g, "");
        const phoneNumber = normalizeText(input.phoneNumber);
        const credential = normalizeCredential(input.credential);
        if (!accountId) throw new Error("QQ账号标识不存在");
        if (accountId === CONTINUITY_ACCOUNT_ID) throw new Error("QQ账号标识不可使用迁移保留值");
        if (!/^\d{5,12}$/.test(qqNumber)) throw new Error("QQ号需为 5-12 位数字");
        if (!credential) throw new Error("QQ账号登录凭据无效");
        const now = Date.now();
        const normalized = normalize(input, accountId, { includeCredential: true });
        const explicit = (field) => Object.prototype.hasOwnProperty.call(input, field);
        let createdRow = null;

        await db.transaction(
          "rw",
          accounts,
          state,
          assets,
          db.contacts,
          db.chatMessages,
          db.chatSettings,
          db.wallets,
          async () => {
            if (await accounts.get(accountId)) throw new Error("当前QQ账号已经存在");
            const qqOwner = await identifierOwner(qqNumber);
            if (qqOwner) throw new Error("该QQ号已被其他本机账号使用");
            if (phoneNumber) {
              const phoneOwner = await identifierOwner(phoneNumber);
              if (phoneOwner) throw new Error("该电话号码已被其他本机账号使用");
            }

            const realAccounts = (await accounts.toArray()).filter(isLoginAccountRow);
            const firstRealAccount = claimContinuity && realAccounts.length === 0;
            const draft = firstRealAccount ? await accounts.get(CONTINUITY_ACCOUNT_ID) : null;
            const continuity = isContinuityDraft(draft) ? normalize(draft, CONTINUITY_ACCOUNT_ID) : null;
            const row = {
              accountId,
              qqNumber,
              credential,
              nickname: (explicit("nickname") && normalized.nickname && normalized.nickname !== "^ω^")
                ? normalized.nickname
                : continuity?.nickname || normalized.nickname || "^ω^",
              name: explicit("name") && normalized.name ? normalized.name : continuity?.name || normalized.name,
              persona: explicit("persona") && normalized.persona ? normalized.persona : continuity?.persona || normalized.persona,
              signature: explicit("signature") && normalized.signature ? normalized.signature : continuity?.signature || normalized.signature,
              gender: explicit("gender") && normalized.gender ? normalized.gender : continuity?.gender || normalized.gender,
              birthday: explicit("birthday") && normalized.birthday ? normalized.birthday : continuity?.birthday || normalized.birthday,
              constellation: explicit("constellation") && normalized.constellation ? normalized.constellation : continuity?.constellation || normalized.constellation,
              location: explicit("location") && normalized.location ? normalized.location : continuity?.location || normalized.location,
              origin: explicit("origin") && normalized.origin ? normalized.origin : continuity?.origin || normalized.origin,
              tags: explicit("tags") && normalized.tags ? normalized.tags : continuity?.tags || normalized.tags,
              likes: explicit("likes") ? normalized.likes : continuity?.likes || normalized.likes || "0",
              level: explicit("level") ? normalized.level : continuity?.level || normalized.level,
              avatarAssetId: normalized.avatarAssetId || continuity?.avatarAssetId || null,
              coverAssetId: normalized.coverAssetId || continuity?.coverAssetId || null,
              registeredAt: Number(input.registeredAt) || now,
              createdAt: Number(input.createdAt) || now,
              updatedAt: now
            };
            if (phoneNumber) row.phoneNumber = phoneNumber;
            await accounts.add(row);
            createdRow = row;

            // Incomplete legacy identity is a lifecycle draft inside the canonical account table, not a second account layer.
            // The first real registration atomically adopts its profile/media and then deletes the draft permanently.
            if (firstRealAccount && continuity) {
              for (const assetId of [continuity.avatarAssetId, continuity.coverAssetId].filter(Boolean)) {
                const media = await assets.get(assetId);
                if (media && media.ownerType === "qq-account") {
                  await assets.update(assetId, { ownerId: accountId, updatedAt: now });
                }
              }
              await accounts.delete(CONTINUITY_ACCOUNT_ID);
            }

            // Historical unowned QQ business data may only be claimed from the explicit continuity sentinel,
            // and only by the first real account. Arbitrary orphan accountIds are never hijacked.
            if (firstRealAccount && accountId !== CONTINUITY_ACCOUNT_ID) {
              const [contactCount, messageCount, settingCount, wallet] = await Promise.all([
                db.contacts.where("accountId").equals(CONTINUITY_ACCOUNT_ID).count(),
                db.chatMessages.where("accountId").equals(CONTINUITY_ACCOUNT_ID).count(),
                db.chatSettings.where("accountId").equals(CONTINUITY_ACCOUNT_ID).count(),
                db.wallets.get(CONTINUITY_ACCOUNT_ID)
              ]);
              if (contactCount) await db.contacts.where("accountId").equals(CONTINUITY_ACCOUNT_ID).modify({ accountId, updatedAt: now });
              if (messageCount) await db.chatMessages.where("accountId").equals(CONTINUITY_ACCOUNT_ID).modify((item) => {
                item.accountId = accountId;
                item.updatedAt = Math.max(Number(item.updatedAt) || 0, now);
              });
              if (settingCount) await db.chatSettings.where("accountId").equals(CONTINUITY_ACCOUNT_ID).modify((item) => {
                item.accountId = accountId;
                item.updatedAt = Math.max(Number(item.updatedAt) || 0, now);
              });
              if (wallet) {
                await db.wallets.delete(CONTINUITY_ACCOUNT_ID);
                await db.wallets.put({ ...wallet, accountId, updatedAt: Math.max(Number(wallet.updatedAt) || 0, now) });
              }
            }

            await state.put({ key: "session", accountId, signedInAt: now, updatedAt: now });
            await state.put({ key: "last-used", accountId, updatedAt: now });
          }
        );
        cacheSession({ key: "session", accountId, signedInAt: now, updatedAt: now });
        return normalize(createdRow, accountId);
      }

      async function updateIdentifiers(accountId, qqNumberValue, phoneNumberValue) {
        await ensureInitialized();
        const id = normalizeText(accountId, 180);
        const qqNumber = normalizeText(qqNumberValue, 12).replace(/\D/g, "");
        const phoneNumber = normalizeText(phoneNumberValue);
        if (!id) throw new Error("QQ账号不存在");
        if (!/^\d{5,12}$/.test(qqNumber)) throw new Error("QQ号需为 5-12 位数字");
        await db.transaction("rw", accounts, async () => {
          const current = await accounts.get(id);
          if (!isLoginAccountRow(current)) throw new Error("QQ账号不存在");
          const qqOwner = await identifierOwner(qqNumber);
          if (qqOwner && qqOwner.accountId !== id) throw new Error("该QQ号已被其他本机账号使用");
          if (phoneNumber) {
            const phoneOwner = await identifierOwner(phoneNumber);
            if (phoneOwner && phoneOwner.accountId !== id) throw new Error("该电话号码已被其他本机账号使用");
          }
          const next = { ...current, qqNumber, updatedAt: Date.now() };
          if (phoneNumber) next.phoneNumber = phoneNumber;
          else delete next.phoneNumber;
          await accounts.put(next);
        });
        return get(id, { withMedia: false });
      }

      async function updateCredential(accountId, credentialValue) {
        await ensureInitialized();
        const id = normalizeText(accountId, 180);
        const credential = normalizeCredential(credentialValue);
        if (!id || !credential) throw new Error("QQ账号登录凭据无效");
        await db.transaction("rw", accounts, async () => {
          const current = await accounts.get(id);
          if (!isLoginAccountRow(current)) throw new Error("QQ账号不存在");
          await accounts.put({ ...current, credential, updatedAt: Date.now() });
        });
        return true;
      }

      async function save(accountId, input = {}, { avatarBlob = undefined, coverBlob = undefined } = {}) {
        await ensureInitialized();
        const id = normalizeText(accountId, 180);
        if (!id) throw new Error("QQ账号不存在");
        const current = await accounts.get(id);
        if (!isLoginAccountRow(current)) throw new Error("QQ账号不存在");
        const normalized = normalize({ ...current, ...input }, id, { includeCredential: true });
        if (!normalized.nickname && !normalized.name) throw new Error("请至少填写昵称或姓名");
        const now = Date.now();
        let nextAvatarAssetId = current.avatarAssetId || null;
        let nextCoverAssetId = current.coverAssetId || null;
        const previousAvatarAssetId = nextAvatarAssetId;
        const previousCoverAssetId = nextCoverAssetId;
        // Android Chromium 的 File 可能仍由临时 content URI 支撑。先在事务外读取为当前
        // 文档持有的 Blob；进入 Dexie 事务后不再等待任何非 IndexedDB 异步工作。
        const preparedAvatarBlob = avatarBlob instanceof Blob
          ? await ThemeCustomization.materializeBlobForPersistence(avatarBlob)
          : null;
        const preparedCoverBlob = coverBlob instanceof Blob
          ? await ThemeCustomization.materializeBlobForPersistence(coverBlob)
          : null;

        await db.transaction("rw", accounts, assets, async () => {
          if (preparedAvatarBlob) nextAvatarAssetId = await putPreparedMedia(id, "qq-account-avatar", preparedAvatarBlob);
          if (preparedCoverBlob) nextCoverAssetId = await putPreparedMedia(id, "qq-account-cover", preparedCoverBlob);
          const row = {
            ...current,
            nickname: normalized.nickname || "^ω^",
            name: normalized.name,
            persona: normalized.persona,
            signature: normalized.signature,
            gender: normalized.gender,
            birthday: normalized.birthday,
            constellation: normalized.constellation,
            location: normalized.location,
            origin: normalized.origin,
            tags: normalized.tags,
            likes: normalized.likes || "0",
            level: normalized.level,
            avatarAssetId: nextAvatarAssetId,
            coverAssetId: nextCoverAssetId,
            updatedAt: now
          };
          await accounts.put(row);
        });

        for (const assetId of [previousAvatarAssetId, previousCoverAssetId]) {
          if (!assetId || assetId === nextAvatarAssetId || assetId === nextCoverAssetId) continue;
          if ((await countAssetReferences(assetId)) === 0) await assets.delete(assetId);
        }
        const saved = await get(id);
        return saved;
      }

      async function saveCover(accountId, coverBlob) {
        return save(accountId, {}, { coverBlob });
      }

      return Object.freeze({
        normalize,
        ensureInitialized,
        get,
        list,
        findByIdentifier,
        getSession,
        getActiveAccountId,
        getLastUsedAccountId,
        invalidateSessionCache,
        setSession,
        clearSession,
        register,
        updateIdentifiers,
        updateCredential,
        save,
        saveCover,
        mediaBlob
      });
    })();
    window.QQAccountStore = QQAccountStore;

const QWQIdentityContext = (() => {
      function normalizeText(value, maxLength = Number.POSITIVE_INFINITY) {
        const text = String(value ?? "").replace(/\r\n?/g, "\n").trim();
        return Number.isFinite(maxLength) ? text.slice(0, maxLength) : text;
      }

      function normalizeAccountProfile(value = {}, accountId = null) {
        return QQAccountStore.normalize(value, accountId);
      }

      async function getActiveAccountId() {
        return QQAccountStore.getActiveAccountId();
      }

      async function getAccountProfile(accountId = null, options = {}) {
        const resolvedAccountId = normalizeText(accountId || await getActiveAccountId(), 180);
        if (!resolvedAccountId) return { accountId: null, profile: normalizeAccountProfile() };
        const stored = await QQAccountStore.get(resolvedAccountId, options);
        return {
          accountId: resolvedAccountId,
          profile: stored || normalizeAccountProfile({}, resolvedAccountId)
        };
      }

      async function getConversationIdentity(contactOrId) {
        await QQAccountStore.ensureInitialized();
        const contact = typeof contactOrId === "object" && contactOrId
          ? contactOrId
          : await ThemeCustomization.db.contacts.get(String(contactOrId || ""));
        if (!contact) throw new Error("当前聊天不存在");
        const currentAccountId = await getActiveAccountId();
        const accountId = normalizeText(contact.accountId, 180);
        if (!currentAccountId || !accountId || accountId !== currentAccountId) {
          throw new Error("该聊天不属于当前 QQ 账号");
        }
        const resolved = await getAccountProfile(accountId);
        return {
          kind: "account",
          accountId: resolved.accountId,
          ...resolved.profile,
          name: resolveName(resolved.profile)
        };
      }

      function resolveName(identity) {
        return normalizeText(identity?.nickname || identity?.name) || "^ω^";
      }

      return Object.freeze({
        getActiveAccountId,
        normalizeAccountProfile,
        getAccountProfile,
        getConversationIdentity,
        resolveName
      });
    })();
    window.QWQIdentityContext = QWQIdentityContext;

const QWQChatStore = (() => {
      const db = ThemeCustomization.db;
      let conversationCacheAccountId = null;
      let conversationCacheValue = null;
      let conversationCachePromise = null;

      function invalidateConversationCache() {
        conversationCacheAccountId = null;
        conversationCacheValue = null;
        conversationCachePromise = null;
      }

      function uid(prefix = "message") {
        const raw = globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
        return `${prefix}-${raw}`;
      }

      function normalizeText(value, maxLength = Number.POSITIVE_INFINITY) {
        const text = String(value ?? "").replace(/\r\n?/g, "\n").trim();
        return Number.isFinite(maxLength) ? text.slice(0, maxLength) : text;
      }

      function normalizeRole(role) {
        if (role === "system") return "system";
        return role === "assistant" || role === "incoming" ? "assistant" : "user";
      }

      function normalizeConversationMode(value) {
        return value === "offline-longform" ? "offline-longform" : "online-chat";
      }

      function requestedConversationMode(options = null) {
        const value = options && typeof options === "object" ? options.conversationMode : options;
        return value === "offline-longform" ? "offline-longform" : value === "online-chat" ? "online-chat" : "";
      }

      function recordConversationMode(record) {
        return normalizeConversationMode(record?.conversationMode || record?.payload?.conversationMode);
      }

      function isPhoneTimelineRecord(record) {
        const payload = record?.payload && typeof record.payload === "object" ? record.payload : null;
        if (String(payload?.source || "").trim() === "phone-call" || String(payload?.sourceSurface || "").trim() === "phone") return true;
        // Earlier builds dropped phone metadata from system_notice payloads while
        // normalizing storage. These exact lifecycle strings are unambiguously Phone-owned,
        // so hide them from QQ without guessing at ordinary user/assistant messages.
        if (String(record?.kind || "") === "system_notice") {
          const text = String(record?.text || "").trim();
          return /^语音通话已结束，通话时长 \d{2}:\d{2}(?::\d{2})?。$/.test(text)
            || /^对方已挂断语音通话，通话时长 \d{2}:\d{2}(?::\d{2})?。$/.test(text)
            || /^.+ 发起语音通话。$/.test(text)
            || /^发起语音通话：.+。$/.test(text)
            || text === "语音通话已接通。"
            || text === "语音通话已取消。"
            || text === "未接来电。"
            || text === "来电已拒绝。"
            || text === "来电已关闭并选择稍后提醒。"
            || text === "来电已关闭并选择以信息回复。";
        }
        return false;
      }

      function isMessagesTimelineRecord(record) {
        const payload = record?.payload && typeof record.payload === "object" ? record.payload : null;
        const source = String(payload?.source || "").trim().toLocaleLowerCase("en-US");
        const surface = String(payload?.sourceSurface || "").trim().toLocaleLowerCase("en-US");
        return source === "messages" || source === "information" || surface === "messages" || surface === "information";
      }

      function isExternalSurfaceTimelineRecord(record) {
        return isPhoneTimelineRecord(record) || isMessagesTimelineRecord(record);
      }

      function matchesRequestedConversationMode(record, mode) {
        if (!mode) return true;
        if (recordConversationMode(record) !== mode) return false;
        // Phone/Messages and QQ are independent rendering surfaces. External-surface turns stay in the canonical
        // account timeline for cross-app memory/context, but must never become visible QQ chat
        // rows, QQ conversation previews, exports, or QQ-mode clear operations.
        return mode !== "online-chat" || !isExternalSurfaceTimelineRecord(record);
      }

      function normalizeKind(kind) {
        return ["voice_message", "image", "video", "image_message", "polaroid", "location", "forward_bundle", "red_packet", "transfer", "sticker", "system_notice"].includes(kind) ? kind : "text";
      }

      function normalizeQuote(value) {
        const source = value && typeof value === "object" && !Array.isArray(value) ? value : null;
        if (!source) return null;
        const messageId = normalizeText(source.messageId, 160);
        const text = normalizeText(source.text);
        if (!messageId || !text) return null;
        const kind = normalizeKind(source.kind || source.type);
        return {
          messageId,
          role: normalizeRole(source.role),
          senderName: normalizeText(source.senderName) || (normalizeRole(source.role) === "system" ? "系统" : (normalizeRole(source.role) === "user" ? "你" : "对方")),
          kind,
          text,
          payload: normalizePayload(kind, source.payload, text)
        };
      }

      function normalizeMemoryRecallReceipt(value, role, replyGroupId = "") {
        if (normalizeRole(role) !== "assistant") return null;
        const source = value && typeof value === "object" && !Array.isArray(value) ? value : null;
        if (!source) return null;
        const memoryIds = [];
        const seen = new Set();
        for (const raw of Array.isArray(source.memoryIds) ? source.memoryIds : []) {
          const id = normalizeText(raw, 700);
          if (!id || seen.has(id)) continue;
          seen.add(id);
          memoryIds.push(id);
          if (memoryIds.length >= 64) break;
        }
        if (!memoryIds.length) return null;
        const turnId = normalizeText(source.turnId || replyGroupId, 180);
        if (!turnId) throw new Error("Recall Receipt 绑定缺少 turnId");
        const boundAt = Number(source.boundAt);
        return {
          revision: 1,
          turnId,
          memoryIds,
          boundAt: Number.isFinite(boundAt) && boundAt > 0 ? boundAt : Date.now()
        };
      }

      function emitChange(type, conversationId, messageIds = []) {
        invalidateConversationCache();
        document.dispatchEvent(new CustomEvent("qwq:chat-store-change", {
          detail: {
            type,
            conversationId: String(conversationId || ""),
            messageIds: Array.isArray(messageIds) ? messageIds.slice() : []
          }
        }));
      }

      function timelinePosition(record) {
        const messageId = normalizeText(record?.messageId, 220);
        return messageId ? { messageId, createdAt:Math.max(0, Number(record?.createdAt) || 0) } : null;
      }

      async function memoryTimelineRepository() {
        if (!window.QWQMemoryRepository?.runSourceTimelineMutation) {
          await window.QWQModuleLoader?.ensureMemoryDataLifecycle?.();
        }
        const repository = window.QWQMemoryRepository;
        if (!repository?.runSourceTimelineMutation) {
          throw new Error("聊天源变更被阻断：Memory Repository Source Mutation 协调器未加载");
        }
        return repository;
      }

      async function runTimelineMutation(context, mutation, task) {
        const repository = await memoryTimelineRepository();
        const outcome = await repository.runSourceTimelineMutation({
          accountId: context.accountId,
          conversationId: context.conversationId,
          mutationType: mutation.type,
          messageIds: mutation.messageIds || [],
          positions: mutation.positions || [],
          invalidateEvidence: mutation.invalidateEvidence !== false
        }, task);
        return outcome.result;
      }

      function normalizePayload(kind, payload, text, depth = 0) {
        const source = payload && typeof payload === "object" && !Array.isArray(payload) ? payload : {};
        if (kind === "location") {
          const name = normalizeText(source.name || text) || "位置";
          const address = normalizeText(source.address) || "地图位置";
          const seed = Number(source.mapSeed);
          return {
            name,
            address,
            mapSeed: Number.isFinite(seed) && seed ? Math.abs(Math.trunc(seed)) : Date.now()
          };
        }
        if (kind === "image" || kind === "video") {
          const fallback = kind === "video" ? "视频" : "图片";
          return {
            fileName: normalizeText(source.fileName || text) || fallback,
            mime: normalizeText(source.mime, 80) || (kind === "video" ? "video/mp4" : "image/*")
          };
        }
        if (kind === "sticker") {
          const stickerId = normalizeText(source.stickerId ?? source.sticker_id, 180);
          if (!stickerId) throw new Error("表情消息缺少 stickerId");
          return { stickerId };
        }
        if (kind === "polaroid" || kind === "image_message") {
          return { source: kind === "polaroid" ? "camera" : "assistant-image" };
        }
        if (kind === "text" || kind === "voice_message" || kind === "system_notice") {
          const sourceName = normalizeText(source.source, 80).toLocaleLowerCase("en-US");
          const sourceSurface = normalizeText(source.sourceSurface, 80).toLocaleLowerCase("en-US");
          const phoneSurface = sourceName === "phone-call" || sourceSurface === "phone";
          const messagesSurface = sourceName === "messages" || sourceName === "information" || sourceSurface === "messages" || sourceSurface === "information";
          const externalSurfacePayload = phoneSurface ? {
            source: "phone-call",
            sourceSurface: "phone",
            phoneSessionId: normalizeText(source.phoneSessionId, 180),
            event: normalizeText(source.event, 80),
            duration: normalizeText(source.duration, 40),
            endedBy: normalizeText(source.endedBy, 40),
            phoneReplyIndex: Number.isFinite(Number(source.phoneReplyIndex)) ? Math.max(0, Math.trunc(Number(source.phoneReplyIndex))) : null,
            phoneReplyCount: Number.isFinite(Number(source.phoneReplyCount)) ? Math.max(0, Math.trunc(Number(source.phoneReplyCount))) : null
          } : messagesSurface ? {
            source: "messages",
            sourceSurface: "messages",
            smsThreadId: normalizeText(source.smsThreadId, 180),
            event: normalizeText(source.event, 80) || "message"
          } : null;
          if (kind === "system_notice") return externalSurfacePayload;
          const translation = normalizeText(source.translation);
          const conversationMode = source.conversationMode === "offline-longform"
            ? "offline-longform"
            : source.conversationMode === "online-chat"
              ? "online-chat"
              : "";
          const durationSeconds = kind === "voice_message" ? Math.max(0, Math.min(600, Number(source.durationSeconds) || 0)) : 0;
          const mime = kind === "voice_message" ? normalizeText(source.mime, 100) : "";
          const transcriptStatus = kind === "voice_message" && ["recognized", "unavailable", "empty", "manual"].includes(String(source.transcriptStatus))
            ? String(source.transcriptStatus)
            : "";
          const contentSource = kind === "voice_message" && ["manual", "recognized", "unavailable"].includes(String(source.contentSource))
            ? String(source.contentSource)
            : "";
          if(!translation && !conversationMode && !durationSeconds && !mime && !transcriptStatus && !contentSource && !externalSurfacePayload) return null;
          return {
            translation,
            sourceLanguage: translation ? normalizeText(source.sourceLanguage, 40) : "",
            targetLanguage: translation ? normalizeText(source.targetLanguage, 40) : "",
            conversationMode,
            ...(kind === "voice_message" ? {durationSeconds, mime, transcriptStatus, contentSource} : {}),
            ...(externalSurfacePayload || {})
          };
        }
        if (kind === "red_packet" || kind === "transfer") {
          const amountCents = Math.max(1, Math.min(100000000, Math.trunc(Number(source.amountCents) || Math.round(Number(source.amount || 0) * 100) || 1)));
          const allowedStatus = kind === "red_packet"
            ? ["available", "sent", "claimed", "refunded"]
            : ["available", "pending", "paid", "accepted", "refunded"];
          const status = allowedStatus.includes(String(source.status)) ? String(source.status) : "available";
          return {
            amountCents,
            greeting: kind === "red_packet" ? (normalizeText(source.greeting) || "恭喜发财，大吉大利") : "",
            note: kind === "transfer" ? (normalizeText(source.note) || "转账") : "",
            status,
            senderName: normalizeText(source.senderName),
            walletTransactionId: normalizeText(source.walletTransactionId, 180),
            claimedAt: Number.isFinite(Number(source.claimedAt)) ? Number(source.claimedAt) : 0
          };
        }
        if (kind === "forward_bundle") {
          const participantMap = new Map();
          const rawParticipants = Array.isArray(source.participants) ? source.participants.slice(0, 24) : [];
          rawParticipants.forEach((item) => {
            const participantId = normalizeText(item?.participantId ?? item?.id, 160);
            if (!participantId || participantMap.has(participantId)) return;
            participantMap.set(participantId, {
              participantId,
              displayName: normalizeText(item?.displayName ?? item?.name) || "发言人",
              side: item?.side === "peer" ? "peer" : "self",
              avatarAssetId: normalizeText(item?.avatarAssetId, 160)
            });
          });
          const rawMessages = Array.isArray(source.messages) ? source.messages.slice(0, 100) : [];
          const messages = rawMessages.map((item) => {
            const legacyRole = normalizeRole(item?.role);
            const participantId = normalizeText(item?.participantId ?? item?.senderId, 160)
              || (legacyRole === "assistant" ? "source-peer" : "source-self");
            if (!participantMap.has(participantId)) {
              participantMap.set(participantId, {
                participantId,
                displayName: normalizeText(item?.senderName) || (legacyRole === "assistant" ? "对方" : "我方"),
                side: legacyRole === "assistant" ? "peer" : "self",
                avatarAssetId: ""
              });
            }
            const itemKind = normalizeKind(item?.kind);
            const embeddedPayload = depth < 2 && ["text", "voice_message", "location", "forward_bundle", "red_packet", "transfer", "sticker"].includes(itemKind)
              ? normalizePayload(itemKind, item?.payload, item?.text, depth + 1)
              : null;
            return {
              messageId: normalizeText(item?.messageId, 160),
              participantId,
              kind: itemKind,
              text: normalizeText(item?.text),
              payload: embeddedPayload,
              mediaBlob: ["image", "video", "voice_message"].includes(itemKind) && item?.mediaBlob instanceof Blob && item.mediaBlob.size ? item.mediaBlob : null,
              quote: normalizeQuote(item?.quote),
              thinking: normalizeText(item?.thinking, 20000) || null,
              recalled: item?.recalled === true,
              createdAt: Number.isFinite(Number(item?.createdAt)) && Number(item.createdAt) > 0 ? Number(item.createdAt) : 0
            };
          }).filter((item) => item.text);
          return {
            sourceConversationId: normalizeText(source.sourceConversationId, 160),
            sourceConversationName: normalizeText(source.sourceConversationName) || "聊天记录",
            participants: Array.from(participantMap.values()),
            messages
          };
        }
        return null;
      }

      async function resolveConversation(conversationId) {
        await ThemeCustomization.ready;
        const id = String(conversationId || "").trim();
        if (!id) throw new Error("聊天会话不存在");
        const contact = await db.contacts.get(id);
        if (!contact) throw new Error("聊天好友不存在");
        const activeAccountId = await QWQIdentityContext.getActiveAccountId();
        if (!activeAccountId || contact.accountId !== activeAccountId) {
          throw new Error("该聊天不属于当前 QQ 账号");
        }
        return { accountId: activeAccountId, conversationId: id };
      }

      async function list(conversationId, options = {}) {
        const context = await resolveConversation(conversationId);
        const mode = requestedConversationMode(options);
        const rows = await db.chatMessages
          .where("[accountId+conversationId]")
          .equals([context.accountId, context.conversationId])
          .sortBy("createdAt");
        const scoped = mode ? rows.filter((item) => matchesRequestedConversationMode(item, mode)) : rows;
        return scoped.map((item) => ({ ...item }));
      }

      async function listPage(conversationId, options = {}) {
        const context = await resolveConversation(conversationId);
        const count = Math.max(20, Math.min(300, Number.parseInt(options.limit, 10) || 80));
        const before = options.before && Number.isFinite(Number(options.before.createdAt)) && options.before.messageId
          ? { createdAt:Number(options.before.createdAt), messageId:String(options.before.messageId) }
          : null;
        const lowerKey = [context.accountId, context.conversationId, Dexie.minKey, Dexie.minKey];
        const upperKey = before
          ? [context.accountId, context.conversationId, before.createdAt, before.messageId]
          : [context.accountId, context.conversationId, Dexie.maxKey, Dexie.maxKey];
        const mode = requestedConversationMode(options);
        let collection = db.chatMessages
          .where("[accountId+conversationId+createdAt+messageId]")
          .between(lowerKey, upperKey, true, !before)
          .reverse();
        if(mode) collection = collection.filter((item) => matchesRequestedConversationMode(item, mode));
        const rows = await collection
          .limit(count + 1)
          .toArray();
        const hasMore = rows.length > count;
        if(hasMore) rows.length = count;
        rows.reverse();
        return {
          messages: rows.map((item) => ({ ...item })),
          hasMore
        };
      }

      async function listRecent(conversationId, limit = 20, options = {}) {
        const context = await resolveConversation(conversationId);
        const count = Math.max(1, Math.min(500, Number.parseInt(limit, 10) || 20));
        const mode = requestedConversationMode(options);
        let collection = db.chatMessages
          .where("[accountId+conversationId+createdAt+messageId]")
          .between(
            [context.accountId, context.conversationId, Dexie.minKey, Dexie.minKey],
            [context.accountId, context.conversationId, Dexie.maxKey, Dexie.maxKey],
            true,
            true
          )
          .reverse();
        if(mode) collection = collection.filter((item) => matchesRequestedConversationMode(item, mode));
        const rows = await collection.limit(count).toArray();
        rows.reverse();
        return rows.map((item) => ({ ...item }));
      }

      async function listConversations() {
        await ThemeCustomization.databaseReady;
        const accountId = await QWQIdentityContext.getActiveAccountId();
        if (!accountId) return [];
        if (conversationCacheAccountId === accountId && Array.isArray(conversationCacheValue)) {
          return conversationCacheValue;
        }
        if (conversationCacheAccountId === accountId && conversationCachePromise) {
          return conversationCachePromise;
        }

        conversationCacheAccountId = accountId;
        conversationCachePromise = (async () => {
          const contacts = await db.contacts.where("accountId").equals(accountId).toArray();
          // Each .last() is an indexed seek on the compound conversation timeline. Run all
          // independent seeks together instead of serial batches of 12, which amplified
          // latency on mobile IndexedDB implementations.
          const summaries = await Promise.all(contacts.map(async (contact) => {
            const lastMessage = await db.chatMessages
              .where("[accountId+conversationId+createdAt+messageId]")
              .between(
                [accountId, contact.contactId, Dexie.minKey, Dexie.minKey],
                [accountId, contact.contactId, Dexie.maxKey, Dexie.maxKey],
                true,
                true
              )
              .reverse()
              .filter((item) => matchesRequestedConversationMode(item, "online-chat"))
              .first();
            if (!lastMessage) return null;
            const { mediaBlob: _mediaBlob, ...lightMessage } = lastMessage;
            return {
              conversationId: contact.contactId,
              contact: { ...contact },
              lastMessage: lightMessage
            };
          }));
          const value = summaries
            .filter(Boolean)
            .sort((left, right) => Number(right.lastMessage.createdAt) - Number(left.lastMessage.createdAt));
          if (conversationCacheAccountId === accountId) conversationCacheValue = value;
          return value;
        })();

        try {
          return await conversationCachePromise;
        } finally {
          if (conversationCacheAccountId === accountId) conversationCachePromise = null;
        }
      }

      async function append(conversationId, role, text, options = {}) {
        const context = await resolveConversation(conversationId);
        const normalized = normalizeText(text);
        if (!normalized) throw new Error("消息内容不能为空");
        const createdAtValue = Number(options.createdAt);
        const createdAt = Number.isFinite(createdAtValue) && createdAtValue > 0 ? createdAtValue : Date.now();
        const kind = normalizeKind(options.kind);
        const sourceMediaBlob = ["image", "video", "voice_message"].includes(kind) && options.mediaBlob instanceof Blob && options.mediaBlob.size
          ? options.mediaBlob
          : null;
        if (["image", "video"].includes(kind) && !sourceMediaBlob) throw new Error(kind === "video" ? "视频内容不完整" : "图片内容不完整");
        const mediaBlob = sourceMediaBlob
          ? await ThemeCustomization.materializeBlobForPersistence(sourceMediaBlob)
          : null;
        const record = {
          messageId: typeof options.messageId === "string" && options.messageId ? options.messageId : uid(),
          accountId: context.accountId,
          conversationId: context.conversationId,
          role: normalizeRole(role),
          kind,
          text: normalized,
          mediaBlob,
          payload: normalizePayload(kind, options.payload, normalized),
          conversationMode: normalizeConversationMode(options.conversationMode || options.payload?.conversationMode),
          quote: normalizeQuote(options.quote),
          thinking: normalizeText(options.thinking, 20000) || null,
          replyGroupId: normalizeText(options.replyGroupId, 180) || null,
          memoryRecallReceipt: normalizeMemoryRecallReceipt(options.memoryRecallReceipt, role, options.replyGroupId),
          timeLabel: normalizeText(options.timeLabel, 40) || null,
          createdAt,
          updatedAt: Date.now()
        };
        await runTimelineMutation(context, {
          type:"append",
          messageIds:[record.messageId],
          positions:[timelinePosition(record)],
          invalidateEvidence:false
        }, async () => {
          await db.chatMessages.add(record);
          return true;
        });
        emitChange("append", context.conversationId, [record.messageId]);
        return { ...record };
      }

      async function appendMany(conversationId, role, texts, options = {}) {
        const source = Array.isArray(texts) ? texts : [];
        return appendBatch(
          conversationId,
          role,
          source.map((text) => ({ type: normalizeKind(options.kind), content: text })),
          options
        );
      }

      async function appendBatch(conversationId, role, messages, options = {}) {
        const context = await resolveConversation(conversationId);
        const source = Array.isArray(messages) ? messages : [];
        const normalizedMessages = source.map((message, index) => {
          if (!message || Array.isArray(message) || typeof message !== "object") {
            throw new Error(`messages[${index}] 必须是携带 type 字段的 JSON 对象`);
          }
          if (!Object.prototype.hasOwnProperty.call(message, "type") || typeof message.type !== "string" || !message.type.trim()) {
            throw new Error(`messages[${index}] 必须显式携带非空 type 字段`);
          }
          const declaredType = message.type.trim();
          const allowedTypes = ["text", "voice_message", "image", "image_message", "polaroid", "location", "forward_bundle", "red_packet", "transfer", "sticker", "system_notice"];
          if (!allowedTypes.includes(declaredType)) {
            throw new Error(`messages[${index}].type 不受支持：${declaredType}`);
          }
          const kind = normalizeKind(declaredType);
          const text = normalizeText(
            kind === "location"
              ? (message.name ?? message.content)
              : kind === "sticker"
                ? (message.content ?? "表情")
                : message.content
          );
          const payload = normalizePayload(kind, message.payload ?? message, text);
          const conversationMode = normalizeConversationMode(message.conversationMode || message.payload?.conversationMode || options.conversationMode);
          return { kind, text, payload, conversationMode, quote:normalizeQuote(message.quote) };
        });
        if (!normalizedMessages.length || normalizedMessages.some((message) => !message.text)) {
          throw new Error("消息内容不能为空");
        }
        const createdAtValue = Number(options.createdAt);
        const createdAt = Number.isFinite(createdAtValue) && createdAtValue > 0 ? createdAtValue : Date.now();
        const normalizedRole = normalizeRole(role);
        const thinking = normalizedRole === "assistant" ? (normalizeText(options.thinking, 20000) || null) : null;
        const replyGroupId = normalizedRole === "assistant" ? (normalizeText(options.replyGroupId, 180) || null) : null;
        const records = normalizedMessages.map((message, index) => ({
          messageId: uid(),
          accountId: context.accountId,
          conversationId: context.conversationId,
          role: normalizedRole,
          kind: message.kind,
          text: message.text,
          mediaBlob: null,
          payload: message.payload,
          conversationMode: message.conversationMode,
          quote: message.quote,
          thinking: index === 0 ? thinking : null,
          replyGroupId,
          memoryRecallReceipt: normalizeMemoryRecallReceipt(options.memoryRecallReceipt, normalizedRole, replyGroupId),
          timeLabel: null,
          createdAt: createdAt + index,
          updatedAt: Date.now()
        }));
        await runTimelineMutation(context, {
          type:"append-batch",
          messageIds:records.map((record) => record.messageId),
          positions:records.map(timelinePosition).filter(Boolean),
          invalidateEvidence:false
        }, async () => {
          await db.chatMessages.bulkAdd(records);
          return true;
        });
        emitChange("append-batch", context.conversationId, records.map((record) => record.messageId));
        return records.map((record) => ({ ...record }));
      }

      async function removeMessages(conversationId, messageIds) {
        const context = await resolveConversation(conversationId);
        const ids = Array.from(new Set((Array.isArray(messageIds) ? messageIds : [messageIds])
          .map((value)=>String(value || "").trim())
          .filter(Boolean)));
        if (!ids.length) return 0;
        const records = await db.chatMessages.bulkGet(ids);
        const existingIds = [];
        records.forEach((record, index) => {
          if (!record) return;
          if (record.accountId !== context.accountId || record.conversationId !== context.conversationId) {
            throw new Error("消息不属于当前聊天会话");
          }
          existingIds.push(ids[index]);
        });
        if (!existingIds.length) return 0;
        const existingRecords = records.filter(Boolean);
        await runTimelineMutation(context, {
          type:"delete",
          messageIds:existingIds,
          positions:existingRecords.map(timelinePosition).filter(Boolean)
        }, async () => {
          await db.chatMessages.bulkDelete(existingIds);
          return true;
        });
        emitChange("remove-batch", context.conversationId, existingIds);
        return existingIds.length;
      }

      async function removeMessage(conversationId, messageId) {
        return (await removeMessages(conversationId, [messageId])) > 0;
      }

      async function getMessages(conversationId, messageIds) {
        const context = await resolveConversation(conversationId);
        const ids = Array.from(new Set((Array.isArray(messageIds) ? messageIds : [messageIds])
          .map((value) => String(value || "").trim()).filter(Boolean)));
        const rows = await db.chatMessages.bulkGet(ids);
        return rows.map((record, index) => {
          if (!record) throw new Error(`消息不存在：${ids[index]}`);
          if (record.accountId !== context.accountId || record.conversationId !== context.conversationId) {
            throw new Error("消息不属于当前聊天会话");
          }
          return { ...record };
        });
      }

      async function updateMessageText(conversationId, messageId, text) {
        const context = await resolveConversation(conversationId);
        const normalized = normalizeText(text);
        if (!normalized) throw new Error("消息内容不能为空");
        const record = await db.chatMessages.get(String(messageId || ""));
        if (!record || record.accountId !== context.accountId || record.conversationId !== context.conversationId) {
          throw new Error("消息不属于当前聊天会话");
        }
        if (record.kind !== "text" || record.recalled === true) {
          throw new Error("只有未撤回的文字消息可以编辑");
        }
        const updatedAt = Date.now();
        const payload = (record.kind === "text" || record.kind === "voice_message") && record.payload && typeof record.payload === "object"
          ? { ...record.payload, translation:"", sourceLanguage:"", targetLanguage:"" }
          : record.payload;
        await runTimelineMutation(context, {
          type:"edit",
          messageIds:[record.messageId],
          positions:[timelinePosition(record)]
        }, async () => {
          await db.chatMessages.update(record.messageId, { text:normalized, payload, updatedAt });
          return true;
        });
        emitChange("update", context.conversationId, [record.messageId]);
        return { ...record, text:normalized, payload, updatedAt };
      }

      async function updateMessagePayload(conversationId, messageId, payload) {
        const context = await resolveConversation(conversationId);
        const id = String(messageId || "").trim();
        const record = await db.chatMessages.get(id);
        if (!record || record.accountId !== context.accountId || record.conversationId !== context.conversationId) {
          throw new Error("消息不属于当前聊天会话");
        }
        if (!["red_packet", "transfer"].includes(record.kind) || record.recalled === true) {
          throw new Error("该消息不支持更新交易状态");
        }
        const normalizedPayload = normalizePayload(record.kind, payload, record.text);
        const updatedAt = Date.now();
        await runTimelineMutation(context, {
          type:"payload-update",
          messageIds:[id],
          positions:[timelinePosition(record)]
        }, async () => {
          await db.chatMessages.update(id, { payload:normalizedPayload, updatedAt });
          return true;
        });
        emitChange("update-payload", context.conversationId, [id]);
        return { ...record, payload:normalizedPayload, updatedAt };
      }

      async function recallMessage(conversationId, messageId, requiredRole = null) {
        const context = await resolveConversation(conversationId);
        const id = String(messageId || "").trim();
        const record = await db.chatMessages.get(id);
        if (!record || record.accountId !== context.accountId || record.conversationId !== context.conversationId) {
          throw new Error("消息不属于当前聊天会话");
        }
        if (requiredRole && record.role !== normalizeRole(requiredRole)) throw new Error("不能撤回对方的消息");
        if (record.recalled === true) throw new Error("这条消息已经撤回");
        const recalledAt = Date.now();
        const recallAwareness = record.role === "user" ? (Math.random() < .5 ? "seen" : "unseen") : "self";
        await runTimelineMutation(context, {
          type:"recall",
          messageIds:[id],
          positions:[timelinePosition(record)]
        }, async () => {
          await db.chatMessages.update(id, { recalled:true, recalledAt, recallAwareness, updatedAt:recalledAt });
          return true;
        });
        emitChange("recall", context.conversationId, [id]);
        return { ...record, recalled:true, recalledAt, recallAwareness, updatedAt:recalledAt };
      }

      async function removeConversation(conversationId, options = {}) {
        const context = await resolveConversation(conversationId);
        const mode = requestedConversationMode(options);
        let records = await db.chatMessages
          .where("[accountId+conversationId]")
          .equals([context.accountId, context.conversationId])
          .toArray();
        if (mode) records = records.filter((item) => matchesRequestedConversationMode(item, mode));
        const ids = records.map((item) => item.messageId).filter(Boolean);
        if (!ids.length) return 0;
        await runTimelineMutation(context, {
          type:mode ? "overwrite-mode" : "overwrite-conversation",
          messageIds:ids,
          positions:records.map(timelinePosition).filter(Boolean)
        }, async () => {
          await db.chatMessages.bulkDelete(ids);
          return true;
        });
        emitChange("remove-conversation", context.conversationId, ids);
        return ids.length;
      }

      return Object.freeze({ list, listPage, listRecent, listConversations, invalidateConversationCache, append, appendMany, appendBatch, getMessages, updateMessageText, updateMessagePayload, recallMessage, removeMessage, removeMessages, removeConversation });
    })();
    window.QWQChatStore = QWQChatStore;

    const ContactApp = (() => {
      const db = ThemeCustomization.db;
      const { createSection, appendSectionContent, createActionButton } = ThemeCustomization.DrawerUI;
      const GROUPS = Object.freeze(["我的好友", "特别关心"]);
      const DEFAULT_GROUP = GROUPS[0];
      let contactSubscription = null;
      let contactActivation = null;
      let contactRenderPromise = null;
      let contactDirtyRevision = 1;
      let contactRenderedRevision = 0;
      let contactRenderRevision = 0;
      const contactsPanel = document.querySelector('[data-qq-panel="contacts"]');
      const friendsPane = document.querySelector('[data-qq-contact-pane="friends"]');
      const avatarObjectUrls = new Map();
      let memoryCascadeCapability = null;

      async function prepareMemoryContactCascade() {
        if (!window.QWQMemoryAccessGuard || !window.QWQMemoryRepository) {
          await window.QWQModuleLoader?.ensureMemoryDataLifecycle?.();
        }
        const guard = window.QWQMemoryAccessGuard;
        const repository = window.QWQMemoryRepository;
        if (!guard || !repository) {
          throw new Error("好友删除被阻断：记忆删除级联模块未加载");
        }
        await repository.ready();
        if (!memoryCascadeCapability) memoryCascadeCapability = guard.claim("qq-data");
        guard.authorize(memoryCascadeCapability, {
          operation: "purge",
          purpose: "contact-delete",
          surface: "data-cascade"
        });
        return { guard, repository };
      }

      function uid(prefix) {
        const raw = globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
        return `${prefix}-${raw}`;
      }

      function normalizeText(value, maxLength = Number.POSITIVE_INFINITY) {
        const text = String(value ?? "").replace(/\r\n?/g, "\n").trim();
        return Number.isFinite(maxLength) ? text.slice(0, maxLength) : text;
      }

      function normalizeOptionalId(value) {
        const id = String(value ?? "").trim();
        return id || null;
      }

      function normalizeWorldBookIds(value) {
        const source = Array.isArray(value) ? value : [];
        return Array.from(new Set(source.map((id) => normalizeOptionalId(id)).filter(Boolean)));
      }

      function contactDisplayToken(value) {
        return normalizeText(value).split("\n")[0].trim();
      }

      function resolveContactName(contact = {}, overrides = null, fallback = "") {
        const source = contact && typeof contact === "object" ? contact : {};
        const patch = overrides && typeof overrides === "object" ? overrides : {};
        const remarkSource = Object.prototype.hasOwnProperty.call(patch, "contactNote")
          ? patch.contactNote
          : (Object.prototype.hasOwnProperty.call(patch, "note") ? patch.note : source.note);
        const nicknameSource = Object.prototype.hasOwnProperty.call(patch, "remarkName")
          ? patch.remarkName
          : (Object.prototype.hasOwnProperty.call(patch, "nickname") ? patch.nickname : source.nickname);
        const nameSource = Object.prototype.hasOwnProperty.call(patch, "realName")
          ? patch.realName
          : (Object.prototype.hasOwnProperty.call(patch, "name") ? patch.name : source.name);
        const remark = contactDisplayToken(remarkSource);
        const nickname = contactDisplayToken(nicknameSource);
        const name = contactDisplayToken(nameSource);
        return remark || nickname || name || String(fallback || "").trim();
      }

      function normalizeContactInput(input = {}) {
        const nickname = normalizeText(input.nickname);
        const name = normalizeText(input.name);
        const note = normalizeText(input.note);
        const group = GROUPS.includes(input.group) ? input.group : DEFAULT_GROUP;
        const settingContent = normalizeText(input.settingContent);
        return {
          nickname,
          name,
          group,
          settingContent,
          selfLove: Boolean(input.selfLove),
          bio: normalizeText(input.bio),
          note,
          contactType: input.contactType === "group" ? "group" : "friend",
          memberContactIds: Array.from(new Set((Array.isArray(input.memberContactIds) ? input.memberContactIds : [])
            .map((id) => normalizeOptionalId(id)).filter(Boolean))),
          status: input.status === "inactive" ? "inactive" : "active"
        };
      }

      async function getCurrentAccountId() {
        return QWQIdentityContext.getActiveAccountId();
      }

      async function countContactAvatarReferences(assetId) {
        if (!assetId) return 0;
        const [contactRefs, characterRefs] = await Promise.all([
          db.contacts.where("avatarAssetId").equals(assetId).count(),
          db.characters.where("avatarAssetId").equals(assetId).count()
        ]);
        return contactRefs + characterRefs;
      }

      async function deleteOwnedContactAvatarIfOrphaned(assetId, contactId) {
        const id = String(assetId || "").trim();
        if(!id) return false;
        const asset = await db.mediaAssets.get(id);
        if(!asset || asset.ownerType !== "contact" || String(asset.ownerId || "") !== String(contactId || "")) return false;
        if((await countContactAvatarReferences(id)) !== 0) return false;
        await db.mediaAssets.delete(id);
        return true;
      }

      async function validateRelationTargets(worldBookIds) {
        if (!worldBookIds.length) return;
        const worldBooks = await db.worldBooks.bulkGet(worldBookIds);
        if (worldBooks.some((worldBook) => !worldBook)) throw new Error("选择的世界书不存在");
        if (worldBooks.some((worldBook) => worldBook.scope === "global")) {
          throw new Error("全局世界书会自动挂载，好友只能手动选择局部世界书");
        }
      }

      async function syncWholeWorldBookBindings(contactId, worldBookIds, timestamp) {
        const selected = new Set(worldBookIds);
        const bindings = await db.worldBookBindings.where("conversationId").equals(contactId).toArray();
        const wholeBookBindings = bindings.filter((binding) => binding.entryId === null);
        const retained = new Set();

        for (const binding of wholeBookBindings) {
          if (!selected.has(binding.worldBookId) || retained.has(binding.worldBookId)) {
            await db.worldBookBindings.delete(binding.bindingId);
            continue;
          }
          retained.add(binding.worldBookId);
          if (!binding.enabled) {
            await db.worldBookBindings.update(binding.bindingId, { enabled: true, updatedAt: timestamp });
          }
        }

        for (const worldBookId of worldBookIds) {
          if (retained.has(worldBookId)) continue;
          await db.worldBookBindings.add({
            bindingId: uid("worldbook-binding"),
            conversationId: contactId,
            worldBookId,
            entryId: null,
            enabled: true,
            createdAt: timestamp,
            updatedAt: timestamp
          });
        }
      }

      async function ensureCanonicalCharacter(contact, { avatarAssetId, worldBookIds, now }) {
        const related = await db.characters.where("contactId").equals(contact.contactId).toArray();
        let character = contact.characterId ? await db.characters.get(contact.characterId) : null;
        if (!character || character.contactId !== contact.contactId) character = related[0] || null;

        const primaryWorldBookId = character?.worldBookId && worldBookIds.includes(character.worldBookId)
          ? character.worldBookId
          : (worldBookIds[0] || null);
        if (!character) {
          character = {
            characterId: uid("character"),
            contactId: contact.contactId,
            name: resolveContactName(contact, null, "未命名角色"),
            persona: contact.settingContent,
            worldBookId: primaryWorldBookId,
            avatarAssetId: avatarAssetId || null,
            createdAt: now,
            updatedAt: now
          };
          await db.characters.add(character);
        } else {
          await db.characters.update(character.characterId, {
            contactId: contact.contactId,
            name: resolveContactName(contact, null, "未命名角色"),
            persona: contact.settingContent,
            worldBookId: primaryWorldBookId,
            avatarAssetId: avatarAssetId || null,
            updatedAt: now
          });
        }

        if (contact.characterId !== character.characterId) {
          await db.contacts.update(contact.contactId, { characterId: character.characterId, updatedAt: now });
        }
        for (const duplicate of related) {
          if (duplicate.characterId !== character.characterId) await db.characters.delete(duplicate.characterId);
        }
        return character;
      }

      async function createContact(input, avatarBlob = null) {
        await ThemeCustomization.ready;
        const next = normalizeContactInput(input);
        const worldBookIds = normalizeWorldBookIds(input.worldBookIds);
        const accountId = await getCurrentAccountId();
        if (!accountId) throw new Error("请先创建或切换一个 QQ 账号");
        if (!resolveContactName(next)) throw new Error("请至少填写备注、昵称或姓名");
        if (avatarBlob && (!(avatarBlob instanceof Blob) || !String(avatarBlob.type || "").startsWith("image/"))) {
          throw new Error("头像必须是可用的图片文件");
        }
        const persistentAvatarBlob = avatarBlob instanceof Blob
          ? (typeof File !== "undefined" && avatarBlob instanceof File
              ? await ThemeCustomization.prepareImageBlob(avatarBlob, { maxSide: 720, quality: .9 })
              : avatarBlob)
          : null;
        const now = Date.now();
        const timestamp = new Date(now).toISOString();
        const contactId = uid("contact");
        let avatarAssetId = null;
        const characterId = uid("character");
        await db.transaction(
          "rw",
          db.contacts,
          db.mediaAssets,
          db.characters,
          db.worldBooks,
          db.worldBookBindings,
          async () => {
            await validateRelationTargets(worldBookIds);
            if (persistentAvatarBlob) {
              avatarAssetId = uid("asset");
              await db.mediaAssets.add({
                assetId: avatarAssetId,
                kind: "contact-avatar",
                ownerType: "contact",
                ownerId: contactId,
                mime: persistentAvatarBlob.type || "application/octet-stream",
                size: persistentAvatarBlob.size,
                blob: persistentAvatarBlob,
                createdAt: now,
                updatedAt: now
              });
            }
            await db.contacts.add({
              contactId,
              accountId,
              ...next,
              avatarAssetId,
              characterId,
              createdAt: now,
              updatedAt: now
            });
            await db.characters.add({
              characterId,
              contactId,
              name: resolveContactName(next),
              persona: next.settingContent,
              worldBookId: worldBookIds[0] || null,
              avatarAssetId,
              createdAt: now,
              updatedAt: now
            });
            await syncWholeWorldBookBindings(contactId, worldBookIds, timestamp);
          }
        );
        window.QWQChatStore?.invalidateConversationCache?.();
        const created = await getContact(contactId);
        document.dispatchEvent(new CustomEvent("qwq:contact-change", {
          detail: { type: "create", contactId, accountId, contact: created ? { ...created } : null }
        }));
        return created;
      }

      async function getContact(contactId) {
        await ThemeCustomization.databaseReady;
        const accountId = await getCurrentAccountId();
        if (!accountId) return null;
        const contact = await db.contacts.get(String(contactId || ""));
        return contact?.accountId === accountId ? {...contact} : null;
      }

      async function getContactRelations(contactId) {
        await ThemeCustomization.ready;
        const id = String(contactId || "");
        const contact = await getContact(id);
        if (!contact) return null;
        const [bindings, character] = await Promise.all([
          db.worldBookBindings.where("conversationId").equals(id).toArray(),
          contact.characterId ? db.characters.get(contact.characterId) : db.characters.where("contactId").equals(id).first()
        ]);
        const worldBookIds = Array.from(new Set(bindings
          .filter((binding) => binding.enabled && binding.entryId === null)
          .map((binding) => binding.worldBookId)));
        const worldBooks = (await db.worldBooks.bulkGet(worldBookIds)).filter(Boolean);
        return { contact, character: character || null, worldBookIds, worldBooks };
      }

      async function listContacts() {
        await ThemeCustomization.databaseReady;
        const accountId = await getCurrentAccountId();
        if (!accountId) return [];
        const rows = await db.contacts.where("accountId").equals(accountId).toArray();
        return rows.sort((a, b) => resolveContactName(a).localeCompare(resolveContactName(b), "zh-CN"));
      }

      async function updateContact(contactId, patch = {}, avatarBlob) {
        await ThemeCustomization.ready;
        const id = String(contactId || "");
        const current = await db.contacts.get(id);
        if (!current) throw new Error("联系人不存在");
        const accountId = await getCurrentAccountId();
        if (!accountId || current.accountId !== accountId) throw new Error("该好友不属于当前 QQ 账号");
        const currentBindings = await db.worldBookBindings.where("conversationId").equals(id).toArray();
        const currentWorldBookIds = Array.from(new Set(currentBindings
          .filter((binding) => binding.enabled && binding.entryId === null)
          .map((binding) => binding.worldBookId)));
        const worldBookIds = Object.prototype.hasOwnProperty.call(patch, "worldBookIds")
          ? normalizeWorldBookIds(patch.worldBookIds)
          : currentWorldBookIds;
        const relationSet = new Set(currentWorldBookIds);
        const relationsChanged = worldBookIds.length !== currentWorldBookIds.length
          || worldBookIds.some((worldBookId) => !relationSet.has(worldBookId));
        const merged = normalizeContactInput({ ...current, ...patch });
        if (!resolveContactName(merged)) throw new Error("请至少填写备注、昵称或姓名");
        if (avatarBlob !== undefined && avatarBlob !== null && (!(avatarBlob instanceof Blob) || !String(avatarBlob.type || "").startsWith("image/"))) {
          throw new Error("头像必须是可用的图片文件");
        }
        const persistentAvatarBlob = avatarBlob instanceof Blob
          ? (typeof File !== "undefined" && avatarBlob instanceof File
              ? await ThemeCustomization.prepareImageBlob(avatarBlob, { maxSide: 720, quality: .9 })
              : avatarBlob)
          : null;
        const now = Date.now();
        const timestamp = new Date(now).toISOString();
        let nextAvatarAssetId = current.avatarAssetId || null;
        let canonicalCharacterId = current.characterId || null;
        const previousAvatarAssetId = current.avatarAssetId || null;
        const updateTransaction = async () => {
            if (relationsChanged) await validateRelationTargets(worldBookIds);
            if (persistentAvatarBlob) {
              nextAvatarAssetId = uid("asset");
              await db.mediaAssets.add({
                assetId: nextAvatarAssetId,
                kind: "contact-avatar",
                ownerType: "contact",
                ownerId: id,
                mime: persistentAvatarBlob.type || "application/octet-stream",
                size: persistentAvatarBlob.size,
                blob: persistentAvatarBlob,
                createdAt: now,
                updatedAt: now
              });
            }
            await db.contacts.update(id, { ...merged, avatarAssetId: nextAvatarAssetId, updatedAt: now });
            const synchronizedContact = { ...current, ...merged, avatarAssetId: nextAvatarAssetId, contactId: id };
            const character = await ensureCanonicalCharacter(synchronizedContact, { avatarAssetId: nextAvatarAssetId, worldBookIds, now });
            canonicalCharacterId = character?.characterId || canonicalCharacterId;
            if (relationsChanged) await syncWholeWorldBookBindings(id, worldBookIds, timestamp);
            if (previousAvatarAssetId && previousAvatarAssetId !== nextAvatarAssetId) {
              await deleteOwnedContactAvatarIfOrphaned(previousAvatarAssetId, id);
            }
          };
        if (relationsChanged) {
          await db.transaction("rw", db.contacts, db.mediaAssets, db.characters, db.worldBooks, db.worldBookBindings, updateTransaction);
        } else {
          await db.transaction("rw", db.contacts, db.mediaAssets, db.characters, updateTransaction);
        }
        window.QWQChatStore?.invalidateConversationCache?.();
        const updated = {
          ...current,
          ...merged,
          contactId:id,
          accountId,
          avatarAssetId:nextAvatarAssetId,
          characterId:canonicalCharacterId,
          updatedAt:now
        };
        document.dispatchEvent(new CustomEvent("qwq:contact-change", {
          detail: { type: "update", contactId:id, accountId, contact: { ...updated } }
        }));
        return updated;
      }

      async function deleteContact(contactId) {
        await ThemeCustomization.ready;
        const id = String(contactId || "");
        const current = await db.contacts.get(id);
        if (!current) return false;
        const accountId = await getCurrentAccountId();
        if (!accountId || current.accountId !== accountId) throw new Error("该好友不属于当前 QQ 账号");
        const avatarAssetId = current.avatarAssetId || null;
        const memoryCascade = await prepareMemoryContactCascade();
        await memoryCascade.repository.runContactCascadeTransaction({
          accountId,
          conversationId: id,
          characterId: current.characterId || null,
          tables: [
            db.contacts,
            db.mediaAssets,
            db.characters,
            db.worldBookBindings,
            db.chatMessages,
            db.chatSettings
          ]
        }, async () => {
          // 好友域与记忆域必须同事务删除。任一侧失败都整体回滚，禁止产生“好友已删、记忆仍可召回”的孤儿状态。
          memoryCascade.guard.authorize(memoryCascadeCapability, {
            operation: "purge",
            purpose: "contact-delete",
            surface: "data-cascade"
          });
          await db.chatMessages.where("[accountId+conversationId]").equals([accountId, id]).delete();
          await db.chatSettings.delete(id);
          await db.worldBookBindings.where("conversationId").equals(id).delete();
          await db.characters.where("contactId").equals(id).delete();
          await db.contacts.delete(id);
          if (avatarAssetId) {
            await deleteOwnedContactAvatarIfOrphaned(avatarAssetId, id);
          }
        });
        document.dispatchEvent(new CustomEvent("qwq:memory-change", { detail: { accountId, conversationId: id, purged: true } }));
        window.QWQChatStore?.invalidateConversationCache?.();
        document.dispatchEvent(new CustomEvent("qwq:chat-store-change", {
          detail:{ type:"remove-conversation", conversationId:id, messageIds:[] }
        }));
        document.dispatchEvent(new CustomEvent("qwq:contact-change", {
          detail: { type: "delete", contactId:id, accountId, contact: null }
        }));
        return true;
      }

      async function getAvatarBlob(avatarAssetId) {
        if (!avatarAssetId) return null;
        await ThemeCustomization.databaseReady;
        return (await db.mediaAssets.get(avatarAssetId))?.blob || null;
      }

      async function getAvatarBlobs(avatarAssetIds) {
        await ThemeCustomization.databaseReady;
        const ids = Array.from(new Set((Array.isArray(avatarAssetIds) ? avatarAssetIds : [])
          .map((value)=>String(value || "").trim())
          .filter(Boolean)));
        if(!ids.length) return new Map();
        const rows = await db.mediaAssets.bulkGet(ids);
        const result = new Map();
        ids.forEach((id,index)=>{
          const blob = rows[index]?.blob;
          if(blob instanceof Blob && blob.size) result.set(id, blob);
        });
        return result;
      }

      function contactAvatarMediaSlot(key) { return `qq:contacts:avatar:${String(key || "")}`; }
      function releaseAvatarUrl(key) {
        window.QWQMediaSurface?.release?.(contactAvatarMediaSlot(key));
        avatarObjectUrls.delete(key);
      }

      async function fillAvatar(slot, contact, instanceKey = contact.contactId, blobCache = null) {
        if (!contact.avatarAssetId) return false;
        const assetId = String(contact.avatarAssetId);
        let blobPromise = blobCache?.get(assetId);
        if (!blobPromise) {
          blobPromise = getAvatarBlob(assetId);
          blobCache?.set(assetId, blobPromise);
        }
        const blob = await blobPromise;
        if (!(blob instanceof Blob) || !blob.size) return false;
        const mediaSlot = contactAvatarMediaSlot(instanceKey);
        const image = document.createElement("img");
        image.alt = "";
        const applied = await window.QWQMediaSurface?.setImage?.(image, mediaSlot, blob, {identity:`asset:${assetId}`,alt:""});
        if(!applied) return false;
        avatarObjectUrls.set(instanceKey, { assetId, url:window.QWQMediaSurface?.get?.(mediaSlot) || image.currentSrc || image.src });
        slot.replaceChildren(image);
        return true;
      }

      function contactFirstChar(contact) {
        const value = resolveContactName(contact);
        if (!value) return "#";
        if (globalThis.Intl?.Segmenter) {
          const segment = new Intl.Segmenter("zh-CN", { granularity: "grapheme" }).segment(value)[Symbol.iterator]().next().value;
          if (segment?.segment) return segment.segment;
        }
        return Array.from(value)[0] || "#";
      }

      function createContactRow(contact, scope, avatarJobs, blobCache) {
        const row = document.createElement("button");
        row.type = "button";
        row.className = "qq-contact-item";
        row.dataset.contactId = contact.contactId;
        const avatar = document.createElement("span");
        avatar.className = "qq-contact-item-avatar";
        avatar.textContent = contactFirstChar(contact);
        const copy = document.createElement("span");
        copy.className = "qq-contact-item-copy";
        const display = document.createElement("span");
        display.className = "qq-contact-item-name";
        display.textContent = resolveContactName(contact, null, "好友");
        const meta = document.createElement("span");
        meta.className = "qq-contact-item-meta";
        const statusDot = document.createElement("span");
        statusDot.className = `qq-contact-status-dot${contact.status === "inactive" ? " is-offline" : ""}`;
        statusDot.setAttribute("aria-hidden", "true");
        const statusText = document.createElement("span");
        statusText.textContent = contact.status === "inactive" ? "离线" : "WiFi在线";
        meta.append(statusDot, statusText);
        copy.append(display, meta);
        row.append(avatar, copy);
        row.addEventListener("click", () => {
          document.dispatchEvent(new CustomEvent("qwq:contact-open", { detail: { contactId: contact.contactId } }));
        });
        if(contact.avatarAssetId){
          avatarJobs.push(fillAvatar(avatar, contact, `${scope}:${contact.contactId}`, blobCache)
            .catch((error) => console.error("contact avatar render failed", error)));
        }
        return row;
      }

      async function renderContacts() {
        if (!friendsPane) return false;
        const revision = ++contactRenderRevision;
        const contacts = await listContacts();
        if(revision !== contactRenderRevision) return false;
        const query = normalizeText(document.querySelector('[data-qq-search="contacts"]')?.value || "", 100).toLowerCase();
        const visible = contacts.filter((item) => {
          if (!query) return true;
          return [item.note, item.nickname, item.name, resolveContactName(item), item.group].some((value) => String(value || "").toLowerCase().includes(query));
        });
        const avatarJobs = [];
        const blobCache = new Map();
        const groupCommits = [];

        document.querySelectorAll("[data-contact-group]").forEach((row) => {
          const groupName = row.dataset.contactGroup;
          const allInGroup = contacts.filter((item) => item.group === groupName);
          const activeCount = allInGroup.filter((item) => item.status !== "inactive").length;
          const list = Array.from(document.querySelectorAll("[data-contact-group-list]")).find((item) => item.dataset.contactGroupList === groupName);
          if (!list) return;
          const fragment = document.createDocumentFragment();
          visible.filter((item) => item.group === groupName).forEach((contact) => {
            fragment.appendChild(createContactRow(contact, `group:${groupName}`, avatarJobs, blobCache));
          });
          groupCommits.push({ row, list, fragment, count:`${activeCount}/${allInGroup.length}` });
        });

        const friendsFragment = document.createDocumentFragment();
        if (!visible.length) {
          const empty = document.createElement("div");
          empty.className = "qq-contact-placeholder";
          empty.textContent = query ? "无匹配好友" : "暂无好友";
          friendsFragment.appendChild(empty);
        } else {
          const buckets = new Map();
          visible.forEach((contact) => {
            const firstChar = contactFirstChar(contact);
            if (!buckets.has(firstChar)) buckets.set(firstChar, []);
            buckets.get(firstChar).push(contact);
          });
          const firstChars = Array.from(buckets.keys()).sort((a, b) => {
            if (a === "#") return 1;
            if (b === "#") return -1;
            return a.localeCompare(b, "zh-CN", { numeric: true, sensitivity: "variant" });
          });
          firstChars.forEach((firstChar) => {
            const heading = document.createElement("div");
            heading.className = "qq-friend-headchar";
            heading.textContent = firstChar;
            friendsFragment.appendChild(heading);
            buckets.get(firstChar).forEach((contact) => {
              friendsFragment.appendChild(createContactRow(contact, `friends:${firstChar}`, avatarJobs, blobCache));
            });
          });
          const total = document.createElement("div");
          total.className = "qq-contact-total";
          total.textContent = `${visible.length}位联系人`;
          friendsFragment.appendChild(total);
        }

        await Promise.allSettled(avatarJobs);
        if(revision !== contactRenderRevision) return false;
        groupCommits.forEach(({row,list,fragment,count})=>{
          const output = row.querySelector(".qq-group-count");
          if(output) output.textContent = count;
          list.replaceChildren(fragment);
        });
        friendsPane.replaceChildren(friendsFragment);
        return true;
      }

      function contactsSurfaceActive() {
        const qqPage = document.getElementById("page-qq-app");
        return Boolean(qqPage?.classList.contains("is-active") && contactsPanel?.classList.contains("is-active"));
      }

      function refreshContacts() {
        if(contactRenderPromise) return contactRenderPromise;
        const requestedRevision = contactDirtyRevision;
        contactRenderPromise = renderContacts()
          .then((rendered)=>{
            if(rendered && requestedRevision === contactDirtyRevision) contactRenderedRevision = requestedRevision;
            return rendered;
          })
          .finally(()=>{
            contactRenderPromise = null;
            // 渲染期间如果又收到变更，只合并补做最后一次；不丢事件，也不并发重建 DOM。
            if(contactRenderedRevision !== contactDirtyRevision && contactsSurfaceActive()){
              queueMicrotask(()=>{
                if(!contactRenderPromise && contactRenderedRevision !== contactDirtyRevision && contactsSurfaceActive()){
                  refreshContacts().catch((error)=>console.error("contact render failed", error));
                }
              });
            }
          });
        return contactRenderPromise;
      }

      function subscribeContacts() {
        if (contactSubscription || !globalThis.Dexie?.liveQuery) return;
        contactSubscription = Dexie.liveQuery(async () => {
          const accountId = await QWQIdentityContext.getActiveAccountId();
          return accountId ? db.contacts.where("accountId").equals(accountId).primaryKeys() : [];
        }).subscribe({
          next: () => {
            contactDirtyRevision += 1;
            if(contactsSurfaceActive()) refreshContacts().catch((error) => console.error("contact render failed", error));
          },
          error: (error) => console.error("contact live query failed", error)
        });
      }

      function createField(labelText, { type = "text", placeholder = "" } = {}) {
        const row = document.createElement("label");
        row.className = "ui-form-row";
        const label = document.createElement("span");
        label.className = "ui-field-label";
        label.textContent = labelText;
        const input = document.createElement("input");
        input.className = "ui-field-input";
        input.type = type;
        input.placeholder = placeholder;
        input.autocomplete = "off";
        row.append(label, input);
        return { row, input };
      }

      function createGroupField() {
        const row = document.createElement("label");
        row.className = "ui-form-row";
        const label = document.createElement("span");
        label.className = "ui-field-label";
        label.textContent = "分组";
        const select = document.createElement("select");
        select.className = "ui-field-select";
        GROUPS.forEach((groupName) => {
          const option = document.createElement("option");
          option.value = groupName;
          option.textContent = groupName;
          select.appendChild(option);
        });
        select.value = DEFAULT_GROUP;
        row.append(label, select);
        return { row, select };
      }

      function createContactSettingField(initialText = "", initialSelfLove = false) {
        const row = document.createElement("div");
        row.className = "contact-setting-row";
        const heading = document.createElement("div");
        heading.className = "contact-setting-heading";
        const label = document.createElement("label");
        label.className = "ui-field-label";
        label.textContent = "设定内容";
        const control = document.createElement("span");
        control.className = "contact-self-love-control";
        const controlLabel = document.createElement("span");
        controlLabel.className = "contact-self-love-label";
        controlLabel.textContent = "本体恋";
        const toggle = document.createElement("button");
        toggle.type = "button";
        toggle.className = `ui-switch${initialSelfLove ? " is-on" : ""}`;
        toggle.setAttribute("role", "switch");
        toggle.setAttribute("aria-checked", initialSelfLove ? "true" : "false");
        toggle.setAttribute("aria-label", "本体恋");
        const textarea = document.createElement("textarea");
        textarea.id = uid("contact-setting");
        textarea.className = "ui-field-textarea";
        textarea.placeholder = "输入角色设定，或从 DOCX / TXT 导入";
        textarea.value = normalizeText(initialText);
        label.htmlFor = textarea.id;
        let selfLove = Boolean(initialSelfLove);
        toggle.addEventListener("click", () => {
          selfLove = !selfLove;
          toggle.classList.toggle("is-on", selfLove);
          toggle.setAttribute("aria-checked", selfLove ? "true" : "false");
        });
        control.append(controlLabel, toggle);
        const headingActions = document.createElement("span");
        headingActions.className = "contact-setting-heading-actions";
        headingActions.append(ThemeCustomization.TextEntryUI.createFullscreenButton(textarea, "设定内容"), control);
        heading.append(label, headingActions);
        row.append(heading, textarea);
        return { row, textarea, isSelfLove: () => selfLove };
      }

      function createFileInput(accept) {
        const input = document.createElement("input");
        input.type = "file";
        input.accept = accept;
        input.className = "theme-hidden-input";
        document.body.appendChild(input);
        return input;
      }

      function appendImportedText(textarea, text) {
        const incoming = normalizeText(text);
        if (!incoming) return false;
        const current = textarea.value.trim();
        textarea.value = current ? `${current}\n\n${incoming}` : incoming;
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
        return true;
      }

      async function loadRelationOptions(contact = null) {
        const [allWorldBooks, bindings] = await Promise.all([
          db.worldBooks.orderBy("updatedAt").reverse().toArray(),
          contact?.contactId ? db.worldBookBindings.where("conversationId").equals(contact.contactId).toArray() : []
        ]);
        const worldBooks = allWorldBooks.filter((worldBook) => worldBook.scope !== "global");
        const selectedWorldBookIds = new Set(bindings
          .filter((binding) => binding.enabled && binding.entryId === null && worldBooks.some((worldBook) => worldBook.worldBookId === binding.worldBookId))
          .map((binding) => binding.worldBookId));
        return { worldBooks, selectedWorldBookIds };
      }

      function createWorldBookSelector(worldBooks, selectedIds = new Set()) {
        const selected = new Set(Array.from(selectedIds).map(String));
        const list = document.createElement("div");
        list.className = "ui-control-list";
        if (!worldBooks.length) {
          const empty = document.createElement("div");
          empty.className = "ui-row-note";
          empty.textContent = "暂无世界书，可先在世界书 APP 中创建。";
          list.appendChild(empty);
        }
        worldBooks.forEach((worldBook) => {
          const row = document.createElement("div");
          row.className = "ui-list-row";
          const copy = document.createElement("span");
          copy.className = "ui-row-copy";
          const label = document.createElement("span");
          label.className = "ui-row-label";
          label.textContent = worldBook.name;
          const note = document.createElement("span");
          note.className = "ui-row-note";
          note.textContent = "整本作为该好友的上下文";
          copy.append(label, note);
          const toggle = document.createElement("button");
          toggle.type = "button";
          toggle.className = `ui-switch${selected.has(worldBook.worldBookId) ? " is-on" : ""}`;
          toggle.setAttribute("role", "switch");
          toggle.setAttribute("aria-checked", selected.has(worldBook.worldBookId) ? "true" : "false");
          toggle.setAttribute("aria-label", `关联世界书 ${worldBook.name}`);
          toggle.addEventListener("click", () => {
            if (selected.has(worldBook.worldBookId)) selected.delete(worldBook.worldBookId);
            else selected.add(worldBook.worldBookId);
            const enabled = selected.has(worldBook.worldBookId);
            toggle.classList.toggle("is-on", enabled);
            toggle.setAttribute("aria-checked", enabled ? "true" : "false");
          });
          row.append(copy, toggle);
          list.appendChild(row);
        });
        return {
          element: list,
          getSelectedIds: () => worldBooks.map((worldBook) => worldBook.worldBookId).filter((id) => selected.has(id))
        };
      }

      async function openEditDrawer(contactId) {
        await ThemeCustomization.ready;
        const current = await getContact(contactId);
        if (!current) return false;
        const relationOptions = await loadRelationOptions(current);
        return ThemeCustomization.GlobalDrawer.open({
          type: "contact:edit",
          title: "好友设置",
          async render() {
            const host = document.getElementById("theme-drawer-body");
            const avatarInput = createFileInput(ThemeCustomization.imageAccept);
            const documentInput = createFileInput(".docx,.txt,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain");
            let avatarBlob;
            const previewSlot = `qq:contact-edit-preview:${String(current.contactId || "")}`;
            const cleanupInputs = () => {
              [avatarInput, documentInput].forEach((input) => input.remove());
              window.QWQMediaSurface?.release?.(previewSlot);
            };

            const avatarEditor = document.createElement("div");
            avatarEditor.className = "contact-avatar-editor";
            const avatarPicker = document.createElement("button");
            avatarPicker.type = "button";
            avatarPicker.className = "contact-avatar-picker";
            avatarPicker.setAttribute("aria-label", "更换头像");
            const avatarPreview = document.createElement("span");
            avatarPreview.className = "contact-avatar-preview";
            const avatarAdd = document.createElement("span");
            avatarAdd.className = "contact-avatar-add";
            const plusIcon = document.querySelector('#page-qq-app svg[data-icon-provider="lucide"][data-lucide="plus"]')?.cloneNode(true);
            if (plusIcon) {
              plusIcon.classList.remove("qq-lucide-svg");
              plusIcon.classList.add("contact-avatar-add-icon");
              avatarAdd.appendChild(plusIcon);
            }
            avatarPicker.append(avatarPreview, avatarAdd);
            avatarEditor.appendChild(avatarPicker);

            const existingAvatar = await getAvatarBlob(current.avatarAssetId);
            if (existingAvatar instanceof Blob) {
              const image = document.createElement("img");
              await window.QWQMediaSurface?.setImage?.(image, previewSlot, existingAvatar, {
                identity:current.avatarAssetId ? `asset:${current.avatarAssetId}` : existingAvatar, alt:"头像预览"
              });
              avatarPreview.replaceChildren(image);
            }

            const identitySection = createSection("个人信息");
            const identityList = document.createElement("div");
            identityList.className = "ui-control-list";
            const nickname = createField("昵称", { placeholder: "输入昵称" });
            const name = createField("姓名", { placeholder: "输入姓名" });
            const group = createGroupField();
            nickname.input.value = current.nickname || "";
            name.input.value = current.name || "";
            group.select.value = GROUPS.includes(current.group) ? current.group : DEFAULT_GROUP;
            identityList.append(nickname.row, name.row, group.row);
            identitySection.appendChild(identityList);

            const settingSection = createSection("设定内容");
            const settingField = createContactSettingField(current.settingContent || "", current.selfLove === true);
            const setting = settingField.textarea;
            settingSection.appendChild(settingField.row);

            const relationSection = createSection("世界书");
            const relationList = document.createElement("div");
            relationList.className = "ui-control-list";
            const worldBookSelector = createWorldBookSelector(
              relationOptions.worldBooks,
              relationOptions.selectedWorldBookIds
            );
            relationList.appendChild(worldBookSelector.element);
            relationSection.appendChild(relationList);

            const actionSection = createSection("好友操作");
            const actionRow = document.createElement("div");
            actionRow.className = "ui-action-row";
            const importDocument = createActionButton("导入文档", "file-import");
            const save = createActionButton("保存修改", "pen", "is-primary");
            const deleteFriend = createActionButton("删除好友", "trash-can", "is-danger is-wide");
            actionRow.append(importDocument, save);
            appendSectionContent(actionSection, actionRow, deleteFriend);
            host.append(avatarEditor, identitySection, settingSection, relationSection, actionSection);

            avatarPicker.addEventListener("click", () => avatarInput.click());
            avatarInput.addEventListener("change", async () => {
              const file = avatarInput.files?.[0];
              avatarInput.value = "";
              if (!file) return;
              try {
                avatarBlob = await ThemeCustomization.prepareImageBlob(file, { maxSide: 720, quality: .9 });
                const image = document.createElement("img");
                const committed = await window.QWQMediaSurface?.setImage?.(image, previewSlot, avatarBlob, { identity:avatarBlob, alt:"头像预览" });
                if (committed !== false) avatarPreview.replaceChildren(image);
              } catch (error) {
                console.error("contact avatar processing failed", error);
                avatarBlob = undefined;
                ThemeCustomization.GlobalModal.alert({ title: "头像无法使用", message: error?.message || "图片处理失败，请换一张图片重试。", confirmLabel: "知道了", action: "dismiss" });
              }
            });

            importDocument.addEventListener("click", () => documentInput.click());
            documentInput.addEventListener("change", async () => {
              const file = documentInput.files?.[0];
              documentInput.value = "";
              if (!file) return;
              importDocument.disabled = true;
              try {
                const imported = await QWQDocumentText.extract(file);
                if (!appendImportedText(setting, imported)) throw new Error("文档中没有可导入的文本");
              } catch (error) {
                console.error("contact document import failed", error);
                ThemeCustomization.GlobalModal.alert({ title: "文档导入失败", message: error?.message || "文档无法读取。", confirmLabel: "知道了", action: "dismiss" });
              } finally {
                importDocument.disabled = false;
              }
            });

            deleteFriend.addEventListener("click", () => {
              ThemeCustomization.GlobalModal.confirm({
                title: "删除好友",
                message: `确认删除“${resolveContactName(current, null, "该好友")}”？删除后无法恢复。`,
                confirmLabel: "删除",
                cancelLabel: "取消",
                danger: true,
                action: async () => {
                  await deleteContact(current.contactId);
                  cleanupInputs();
                  ThemeCustomization.GlobalDrawer.close();
                  await renderContacts();
                  if (window.QQApp?.state?.().currentView === "profile") window.QQApp.open("contacts");
                  return true;
                }
              });
            });

            save.addEventListener("click", async () => {
              save.disabled = true;
              try {
                const updated = await updateContact(current.contactId, {
                  nickname: nickname.input.value,
                  name: name.input.value,
                  group: group.select.value,
                  settingContent: setting.value,
                  selfLove: settingField.isSelfLove(),
                  worldBookIds: worldBookSelector.getSelectedIds()
                }, avatarBlob);
                // DB 事务成功就是保存完成。先立即关闭抽屉反馈成功，再异步刷新联系人列表/资料页；
                // 不把整页头像读取和 profile 重绘继续算进“保存 C”的按钮等待时间。
                cleanupInputs();
                ThemeCustomization.GlobalDrawer.close();
                void renderContacts().catch((error) => console.error("contact list refresh after save failed", error));
                if (window.QQApp?.state?.().currentView === "profile") {
                  void window.QQApp.openContact(updated.contactId).catch((error) => console.error("contact profile refresh after save failed", error));
                }
              } catch (error) {
                console.error("contact save failed", error);
                ThemeCustomization.GlobalModal.alert({ title: "无法保存好友", message: error?.message || "联系人数据保存失败。", confirmLabel: "知道了", action: "dismiss" });
                save.disabled = false;
              }
            });

            const observer = new MutationObserver(() => {
              if (!host.contains(avatarEditor)) {
                observer.disconnect();
                cleanupInputs();
              }
            });
            observer.observe(host, { childList: true });
            const drawerElement = document.getElementById("theme-global-drawer");
            const drawerOverlay = document.getElementById("theme-drawer-overlay");
            const handleDrawerClosed = (event) => {
              if (event.target !== drawerElement || event.propertyName !== "transform" || drawerOverlay.classList.contains("is-open")) return;
              drawerElement.removeEventListener("transitionend", handleDrawerClosed);
              observer.disconnect();
              cleanupInputs();
            };
            drawerElement.addEventListener("transitionend", handleDrawerClosed);
          }
        });
      }

      async function openCreateDrawer() {
        await ThemeCustomization.ready;
        const relationOptions = await loadRelationOptions();
        return ThemeCustomization.GlobalDrawer.open({
          type: "contact:create",
          title: "添加好友",
          async render() {
            const host = document.getElementById("theme-drawer-body");
            const avatarInput = createFileInput(ThemeCustomization.imageAccept);
            const documentInput = createFileInput(".docx,.txt,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain");
            let avatarBlob = null;
            const previewSlot = `qq:contact-create-preview:${Date.now()}:${Math.random().toString(36).slice(2)}`;
            const cleanupInputs = () => {
              [avatarInput, documentInput].forEach((input) => input.remove());
              window.QWQMediaSurface?.release?.(previewSlot);
            };

            const avatarEditor = document.createElement("div");
            avatarEditor.className = "contact-avatar-editor";
            const avatarPicker = document.createElement("button");
            avatarPicker.type = "button";
            avatarPicker.className = "contact-avatar-picker";
            avatarPicker.setAttribute("aria-label", "选择头像");
            const avatarPreview = document.createElement("span");
            avatarPreview.className = "contact-avatar-preview";
            const avatarAdd = document.createElement("span");
            avatarAdd.className = "contact-avatar-add";
            const plusIcon = document.querySelector('#page-qq-app svg[data-icon-provider="lucide"][data-lucide="plus"]')?.cloneNode(true);
            if (plusIcon) {
              plusIcon.classList.remove("qq-lucide-svg");
              plusIcon.classList.add("contact-avatar-add-icon");
              avatarAdd.appendChild(plusIcon);
            }
            avatarPicker.append(avatarPreview, avatarAdd);
            avatarEditor.appendChild(avatarPicker);
            const identitySection = createSection("个人信息");
            const identityList = document.createElement("div");
            identityList.className = "ui-control-list";
            const nickname = createField("昵称", { placeholder: "输入昵称" });
            const name = createField("姓名", { placeholder: "输入姓名" });
            const group = createGroupField();
            identityList.append(nickname.row, name.row, group.row);
            identitySection.appendChild(identityList);

            const settingSection = createSection("设定内容");
            const settingField = createContactSettingField();
            const setting = settingField.textarea;
            settingSection.appendChild(settingField.row);

            const relationSection = createSection("世界书");
            const relationList = document.createElement("div");
            relationList.className = "ui-control-list";
            const worldBookSelector = createWorldBookSelector(
              relationOptions.worldBooks,
              new Set()
            );
            relationList.appendChild(worldBookSelector.element);
            relationSection.appendChild(relationList);

            const actionSection = createSection("好友操作");
            const actionRow = document.createElement("div");
            actionRow.className = "ui-action-row";
            const importDocument = createActionButton("导入文档", "file-import");
            const addFriend = createActionButton("添加好友", "user-plus", "is-primary");
            actionRow.append(importDocument, addFriend);
            appendSectionContent(actionSection, actionRow);
            host.append(avatarEditor, identitySection, settingSection, relationSection, actionSection);

            avatarPicker.addEventListener("click", () => avatarInput.click());
            avatarInput.addEventListener("change", async () => {
              const file = avatarInput.files?.[0];
              avatarInput.value = "";
              if (!file) return;
              try {
                avatarBlob = await ThemeCustomization.prepareImageBlob(file, { maxSide: 720, quality: .9 });
                const image = document.createElement("img");
                const committed = await window.QWQMediaSurface?.setImage?.(image, previewSlot, avatarBlob, { identity:avatarBlob, alt:"头像预览" });
                if (committed !== false) avatarPreview.replaceChildren(image);
              } catch (error) {
                console.error("avatar processing failed", error);
                avatarBlob = null;
                ThemeCustomization.GlobalModal.alert({ title: "头像无法使用", message: error?.message || "图片处理失败，请换一张图片重试。", confirmLabel: "知道了", action: "dismiss" });
              }
            });
            importDocument.addEventListener("click", () => documentInput.click());
            documentInput.addEventListener("change", async () => {
              const file = documentInput.files?.[0];
              documentInput.value = "";
              if (!file) return;
              importDocument.disabled = true;
              try {
                const imported = await QWQDocumentText.extract(file);
                if (!appendImportedText(setting, imported)) throw new Error("文档中没有可导入的文本");
              } catch (error) {
                console.error("contact document import failed", error);
                ThemeCustomization.GlobalModal.alert({ title: "文档导入失败", message: error?.message || "文档无法读取。", confirmLabel: "知道了", action: "dismiss" });
              } finally {
                importDocument.disabled = false;
              }
            });

            addFriend.addEventListener("click", async () => {
              addFriend.disabled = true;
              try {
                const created = await createContact({
                  nickname: nickname.input.value,
                  name: name.input.value,
                  group: group.select.value,
                  settingContent: setting.value,
                  selfLove: settingField.isSelfLove(),
                  worldBookIds: worldBookSelector.getSelectedIds()
                }, avatarBlob);
                cleanupInputs();
                ThemeCustomization.GlobalDrawer.close();
                document.dispatchEvent(new CustomEvent("qwq:contact-created", { detail: { contactId: created.contactId } }));
                // 添加完成后保持联系人页为唯一返回面，避免新增抽屉关闭后仍滞留在旧 profile/side 状态。
                void renderContacts().catch((error) => console.error("contact list refresh after create failed", error));
              } catch (error) {
                console.error("contact create failed", error);
                ThemeCustomization.GlobalModal.alert({ title: "无法添加好友", message: error?.message || "联系人数据保存失败。", confirmLabel: "知道了", action: "dismiss" });
                addFriend.disabled = false;
              }
            });

            const observer = new MutationObserver(() => {
              if (!host.contains(avatarEditor)) {
                observer.disconnect();
                cleanupInputs();
              }
            });
            observer.observe(host, { childList: true });
            const drawerElement = document.getElementById("theme-global-drawer");
            const drawerOverlay = document.getElementById("theme-drawer-overlay");
            const handleDrawerClosed = (event) => {
              if (event.target !== drawerElement || event.propertyName !== "transform" || drawerOverlay.classList.contains("is-open")) return;
              drawerElement.removeEventListener("transitionend", handleDrawerClosed);
              observer.disconnect();
              cleanupInputs();
            };
            drawerElement.addEventListener("transitionend", handleDrawerClosed);
          }
        });
      }

      document.querySelector('[data-qq-search="contacts"]')?.addEventListener("input", () => {
        renderContacts().catch((error) => console.error("contact search render failed", error));
      });

      document.querySelectorAll("[data-contact-group]").forEach((row) => {
        row.addEventListener("click", () => {
          const block = row.closest("[data-contact-group-block]");
          if (!block) return;
          const expanded = !block.classList.contains("is-expanded");
          block.classList.toggle("is-expanded", expanded);
          row.setAttribute("aria-expanded", expanded ? "true" : "false");
        });
      });

      document.addEventListener("qwq:contact-settings", (event) => {
        const contactId = event.detail?.contactId;
        if (!contactId) return;
        openEditDrawer(contactId).catch((error) => console.error("contact settings open failed", error));
      });

      async function activate(){
        if(!contactActivation){
          contactActivation = ThemeCustomization.ready.then(()=>{
            subscribeContacts();
            return true;
          }).catch((error)=>{
            contactActivation = null;
            console.error("contact initialization failed", error);
            return false;
          });
        }
        const ready = await contactActivation;
        if(!ready) return false;
        if(contactRenderedRevision !== contactDirtyRevision || !friendsPane?.childElementCount){
          return refreshContacts();
        }
        return true;
      }

      return Object.freeze({
        openCreateDrawer,
        openEditDrawer,
        create: createContact,
        get: getContact,
        getRelations: getContactRelations,
        list: listContacts,
        update: updateContact,
        delete: deleteContact,
        getAvatarBlob,
        getAvatarBlobs,
        resolveName: resolveContactName,
        render: renderContacts,
        activate
      });
    })();
    window.ContactApp = ContactApp;

    const QWQChatSettings = (() => {
      const db = ThemeCustomization.db;
      const view = document.getElementById("qq-chat-settings-view");
      const scrollHost = document.getElementById("qq-chat-settings-scroll");
      const tabsHost = document.getElementById("qq-chat-settings-tabs");
      const contentHost = document.getElementById("qq-chat-settings-content");
      const avatarHost = document.getElementById("qq-chat-settings-avatar");
      const selfAvatarHost = document.getElementById("qq-chat-settings-self-avatar");
      const previewHost = document.getElementById("qq-chat-settings-preview");
      const peerFrameInput = document.getElementById("qq-chat-settings-peer-frame-input");
      const selfFrameInput = document.getElementById("qq-chat-settings-self-frame-input");
      const wallpaperInput = document.getElementById("qq-chat-settings-wallpaper-input");
      const importInput = document.getElementById("qq-chat-settings-import-input");
      const nameHost = document.getElementById("qq-chat-settings-name");
      const chatView = document.getElementById("qq-chat-view");
      const chatTitleName = document.getElementById("qq-chat-title-name");
      const chatPresenceText = document.getElementById("qq-chat-presence-text");
      const automationTimers = new Map();
      let currentContactId = null;
      let currentContact = null;
      let currentTab = "identity";
      let draft = null;
      let importMode = "history";
      let autoSaveTimer = 0;
      let autoSaveChain = Promise.resolve();
      let currentConversationIdentity = null;

      const TABS = Object.freeze([
        ["identity", "身份"], ["conversation", "会话"], ["beauty", "美化"]
      ]);
      const TIMEZONES = ["Asia/Shanghai", "Asia/Singapore", "Asia/Tokyo", "Asia/Seoul", "Asia/Hong_Kong", "Asia/Taipei", "Asia/Bangkok", "Asia/Dubai", "Europe/London", "Europe/Paris", "Europe/Berlin", "Europe/Moscow", "America/New_York", "America/Chicago", "America/Los_Angeles", "America/Toronto", "America/Vancouver", "Australia/Sydney", "Pacific/Auckland", "UTC"];
      const LANGUAGES = [
        ["auto", "跟随人设"],
        ["zh-CN", "简体中文"], ["zh-TW", "繁体中文"], ["zh-HK", "粤语"],
        ["en", "English"], ["ja", "日语"], ["ko", "韩语"],
        ["fr", "法语"], ["de", "德语"], ["es", "西班牙语"], ["pt", "葡萄牙语"], ["it", "意大利语"],
        ["ru", "俄语"], ["uk", "乌克兰语"], ["pl", "波兰语"], ["nl", "荷兰语"], ["sv", "瑞典语"], ["no", "挪威语"], ["da", "丹麦语"], ["fi", "芬兰语"],
        ["tr", "土耳其语"], ["el", "希腊语"], ["cs", "捷克语"], ["hu", "匈牙利语"], ["ro", "罗马尼亚语"],
        ["ar", "阿拉伯语"], ["he", "希伯来语"], ["fa", "波斯语"], ["hi", "印地语"], ["bn", "孟加拉语"], ["ur", "乌尔都语"],
        ["th", "泰语"], ["vi", "越南语"], ["id", "印度尼西亚语"], ["ms", "马来语"], ["tl", "菲律宾语"]
      ];
      const DEFAULTS = Object.freeze({
        realName:"", remarkName:"", contactNote:"", birthday:"", dynamicAge:false, timezone:"Asia/Shanghai", location:"",
        characterPersona:"", userName:"", userPersona:"", worldBookIds:[],
        contextRounds:20, enterTriggersOutput:false,
        autoSummary:true, summaryInterval:100, coreMemoryLimit:30,
        replyCustom:false, replyMin:3, replyMax:7,
        bilingual:false, bilingualMode:"all", sourceLanguage:"auto", targetLanguage:"en",
        offlineMinLength:500, offlineMaxLength:900,
        offlineStylePreset:"default", offlineWritingStyle:"", offlineNarrativePerspective:"third", offlineTimeAwareness:true,
        offlineBeautyPreset:"default", offlineFontSize:100, offlineWallpaperMode:"none", offlineWallpaperPresetId:"", offlineWallpaper:null, offlineWallpaperAssetKey:"", offlineCustomCss:"",
        timeAwareness:true, customTime:"", weatherAwareness:true, thinkingEnabled:true, cotEnabled:false, cotPrompt:"",
        customSystemPrompt:"",
        activeReply:false, activeInterval:60, activeRandom:true,
        busyAutoReply:false, busyState:"none", quickCommands:[],
        ttsEnabled:false, voiceLanguage:"auto", voiceSpeed:1, statusText:"",
        avatarVisibility:"show",
        avatarRadius:50, avatarScale:1, avatarOffsetX:0, avatarOffsetY:0,
        frameRadius:50, frameScale:1, frameOffsetX:0, frameOffsetY:0,
        peerAvatarFrame:null, peerAvatarFrameAssetKey:"", selfAvatarFrame:null, selfAvatarFrameAssetKey:"",
        timestampPosition:"center",
        chatFontSize:100, chatWallpaperMode:"none", chatWallpaperPresetId:"", chatWallpaper:null, chatWallpaperAssetKey:"",
        peerBubbleColor:"#ffffff", selfBubbleColor:"#0099ff",
        avatarCss:"", bubbleCss:"", timestampCss:"", customCss:"",
        isBlocked:false
      });
      const DEFAULT_REPLY_RANGE = Object.freeze({ min:DEFAULTS.replyMin, max:DEFAULTS.replyMax });
      const PREVIOUS_DEFAULT_SELF_BUBBLE_COLOR = "#6f8fa8";
      const SETTING_KEYS = new Set(Object.keys(DEFAULTS));

      const option = (value, label=value) => [value, label];
      const CSS_TEMPLATES = Object.freeze({
        avatar: `#page-qq-app .qq-chat-message .qq-chat-avatar {
  /* 真实头像节点：.qq-chat-avatar */
}
#page-qq-app .qq-chat-message.is-incoming .qq-chat-avatar {
  /* 对方头像 */
}
#page-qq-app .qq-chat-message.is-outgoing .qq-chat-avatar {
  /* 我方头像 */
}`,
        bubble: `#page-qq-app .qq-chat-message.is-incoming .qq-chat-bubble {
  background: #ffffff;
  color: #17181b;
  border-radius: 14px;
}
#page-qq-app .qq-chat-message.is-outgoing .qq-chat-bubble {
  background: #0099ff;
  color: #ffffff;
  border-radius: 14px;
}
#page-qq-app .qq-chat-message.is-incoming .qq-chat-bubble::before {
  /* 对方气泡尾巴 */
}
#page-qq-app .qq-chat-message.is-outgoing .qq-chat-bubble::after {
  /* 我方气泡尾巴 */
}`,
        timestamp: `#page-qq-app .qq-chat-time .qq-chat-system-notice {
  /* 居中时间戳 */
}
#page-qq-app .qq-chat-message-timestamp {
  /* 头像下方 / 气泡外部 / 气泡内部时间戳 */
}`,
        custom: `#page-qq-app #qq-chat-view .qq-chat-stream {
  /* 聊天记录滚动区 */
}
#page-qq-app #qq-chat-view .qq-chat-message {
  /* 单条消息行 */
}
#page-qq-app #qq-chat-view .qq-chat-avatar {
  /* 聊天头像 */
}
#page-qq-app #qq-chat-view .qq-chat-bubble {
  /* 文本气泡 */
}
#page-qq-app #qq-chat-view .qq-chat-message-timestamp,
#page-qq-app #qq-chat-view .qq-chat-time .qq-chat-system-notice {
  /* 时间戳 */
}`
      });
      const FIELDS = Object.freeze([
        {tab:"identity",section:"对方身份",items:[
          {key:"realName",label:"姓名",type:"text",placeholder:"联系人姓名"},
          {key:"remarkName",label:"昵称",type:"text",placeholder:"留空使用姓名"},
          {key:"contactNote",label:"备注",type:"text",placeholder:"联系人备注"},
          {key:"birthday",label:"角色生日",type:"date"},
          {key:"dynamicAge",label:"年龄感知",type:"switch",desc:"按当前时间或虚拟时间计算并注入年龄",enabledWhen:["timeAwareness",true]},
          {key:"timezone",label:"角色时区",type:"select",options:TIMEZONES.map(x=>option(x))},
          {key:"location",label:"所在地",type:"text",placeholder:"国家·省份·城市"}
        ]},
        {tab:"identity",section:"人设",items:[
          {key:"characterPersona",label:"对方人设",type:"textarea",placeholder:"性格、说话方式、经历与关系边界"},
          {action:"worldbooks",label:"局部世界书",type:"action",button:"管理",desc:"仅管理当前会话额外挂载的世界书"}
        ]},
        {tab:"identity",section:"我的身份",items:[
          {key:"userName",label:"我的昵称",type:"text",placeholder:"留空跟随本会话挂载身份"},
          {key:"userPersona",label:"我的会话人设",type:"textarea",placeholder:"留空跟随当前QQ账号唯一面具"}
        ]},

        {tab:"conversation",section:"回复",items:[
          {key:"contextRounds",label:"请求上下文轮数",type:"number",min:1,max:200,desc:"我方一次完整发言 + 对方一次完整发言计为一轮；同一方连续多条消息仍属于同一次发言"},
          {key:"enterTriggersOutput",label:"回车触发输出",type:"switch",desc:"开启后，输入栏为空时按回车或点击发送按钮会直接触发输出请求"},
          {key:"replyCustom",label:"自定义回复条数",type:"switch"},
          {key:"replyMin",label:"最少回复条数",type:"number",min:1,step:1,desc:"不设固定上限；实际可生成数量仍受所用模型的上下文与输出能力限制。",enabledWhen:["replyCustom",true]},
          {key:"replyMax",label:"最多回复条数",type:"number",min:1,step:1,desc:"不设固定上限；实际可生成数量仍受所用模型的上下文与输出能力限制。",enabledWhen:["replyCustom",true]}
        ]},
        {tab:"conversation",section:"语言",items:[
          {key:"bilingual",label:"双语回复",type:"switch"},
          {key:"bilingualMode",label:"双语模式",type:"select",options:[["all","全部为双语"],["occasional","偶尔输出双语"]],enabledWhen:["bilingual",true]},
          {key:"sourceLanguage",label:"原文语言",type:"select",options:LANGUAGES,enabledWhen:["bilingual",true]},
          {key:"targetLanguage",label:"翻译语言",type:"select",options:LANGUAGES,enabledWhen:["bilingual",true]}
        ]},
        {tab:"conversation",section:"时间与指令",items:[
          {key:"timeAwareness",label:"时间感知",type:"switch",desc:"开启后感知准确时间、日期、星期与节日；按相关性和稳定概率决定是否显性提及"},
          {key:"customTime",label:"虚拟时间",type:"datetime-local",enabledWhen:["timeAwareness",true]},
          {key:"weatherAwareness",label:"天气感知",type:"switch",desc:"按相关性和概率感知我的天气与当前好友天气；不会每轮强行提及"},
          {key:"thinkingEnabled",label:"显示 Thinking",type:"switch"},
          {key:"cotEnabled",label:"会话补充",type:"switch"},
          {key:"cotPrompt",label:"补充内容",type:"textarea",enabledWhen:["cotEnabled",true]},
          {key:"customSystemPrompt",label:"角色专属系统提示词",type:"textarea",placeholder:"留空跟随全局设置"}
        ]},
        {tab:"conversation",section:"主动消息与状态",items:[
          {key:"activeReply",label:"后台主动发送消息",type:"switch"},
          {key:"activeInterval",label:"主动消息间隔（分钟）",type:"number",min:1,max:10080,enabledWhen:["activeReply",true]},
          {key:"activeRandom",label:"随机化主动间隔",type:"switch",enabledWhen:["activeReply",true]},
          {key:"busyAutoReply",label:"忙时自动回复",type:"switch"},
          {key:"busyState",label:"当前忙碌状态",type:"select",options:[["none","正常"],["busy","忙碌 / 通勤"],["focus","专注 / 学习"],["sleep","休息 / 睡眠"]],enabledWhen:["busyAutoReply",true]},
          {action:"quick-commands",label:"快捷指令",type:"action",button:"管理"}
        ]},
        {tab:"conversation",section:"朗读与显示",items:[
          {key:"ttsEnabled",label:"朗读角色回复",type:"switch"},
          {key:"voiceLanguage",label:"朗读语言",type:"select",options:LANGUAGES,enabledWhen:["ttsEnabled",true]},
          {key:"voiceSpeed",label:"朗读速度",type:"range",min:.5,max:2,step:.05,enabledWhen:["ttsEnabled",true]},
          {key:"statusText",label:"自定义在线状态",type:"text",placeholder:"留空显示联系人状态"}
        ]},
        {tab:"beauty",section:"头像",items:[
          {key:"avatarVisibility",label:"头像显示",type:"select",options:[["show","显示双方"],["hide-peer","隐藏对方"],["hide-self","隐藏我方"],["hide-both","隐藏双方"]]},
          {key:"peerAvatarFrame",label:"对方头像框",type:"frame",side:"peer"},
          {key:"selfAvatarFrame",label:"我方头像框",type:"frame",side:"self"},
          {key:"avatarRadius",label:"头像圆角",type:"range",min:0,max:50,step:1,suffix:"%"},
          {key:"avatarScale",label:"头像缩放",type:"range",min:.5,max:2,step:.01,suffix:"×"},
          {key:"avatarOffsetX",label:"头像水平偏移",type:"range",min:-24,max:24,step:1,suffix:"px"},
          {key:"avatarOffsetY",label:"头像垂直偏移",type:"range",min:-24,max:24,step:1,suffix:"px"},
          {key:"frameRadius",label:"头像框圆角",type:"range",min:0,max:50,step:1,suffix:"%"},
          {key:"frameScale",label:"头像框缩放",type:"range",min:.5,max:2,step:.01,suffix:"×"},
          {key:"frameOffsetX",label:"头像框水平偏移",type:"range",min:-24,max:24,step:1,suffix:"px"},
          {key:"frameOffsetY",label:"头像框垂直偏移",type:"range",min:-24,max:24,step:1,suffix:"px"},
          {key:"avatarCss",label:"头像 CSS",type:"textarea",placeholder:"使用真实 .qq-chat-avatar 选择器",template:"avatar"}
        ]},
        {tab:"beauty",section:"显示",items:[
          {key:"chatFontSize",label:"字体大小",type:"range",min:80,max:160,step:5,suffix:"%"},
          {key:"chatWallpaperMode",label:"聊天壁纸",type:"wallpaper",desc:"可上传独立聊天壁纸，或直接选择主屏幕中已保存的壁纸预设"}
        ]},
        {tab:"beauty",section:"气泡",items:[
          {key:"peerBubbleColor",label:"对方气泡颜色",type:"bubble-color"},
          {key:"selfBubbleColor",label:"我方气泡颜色",type:"bubble-color"},
          {key:"bubbleCss",label:"气泡 CSS",type:"textarea",placeholder:"使用真实 .qq-chat-bubble 选择器",template:"bubble"}
        ]},
        {tab:"beauty",section:"时间戳",items:[
          {key:"timestampPosition",label:"渲染位置",type:"select",options:[["center","居中（当前）"],["avatar-under","头像下方"],["bubble-outside","气泡外部"],["bubble-inside","气泡内部"],["hidden","隐藏"]]},
          {key:"timestampCss",label:"时间戳 CSS",type:"textarea",placeholder:"使用真实 .qq-chat-time / .qq-chat-message-timestamp 选择器",template:"timestamp"}
        ]},
        {tab:"beauty",section:"聊天页面 CSS",items:[
          {key:"customCss",label:"自定义 CSS",type:"textarea",placeholder:"仅写聊天页面 CSS；复制模板可获得当前真实选择器",template:"custom"}
        ]}
      ]);

      function clone(value){
        if(typeof structuredClone === "function") return structuredClone(value);
        return JSON.parse(JSON.stringify(value));
      }
      const CUSTOM_CSS_KEYS = Object.freeze(["avatarCss","bubbleCss","timestampCss","customCss","offlineCustomCss"]);
      function isolateQqCss(value){
        const raw=String(value||"").replace(/\r\n?/g,"\n");
        return window.QWQCssIsolation?.sanitizeScoped?.(raw,"#page-qq-app") ?? raw;
      }
      function normalizeRecord(record, contact=null){
        const source = record?.settings && typeof record.settings === "object" ? record.settings : {};
        const next = clone(DEFAULTS);
        if(source.contextRounds == null && Number.isFinite(Number(source.contextLimit))){
          next.contextRounds = Math.max(1, Math.min(200, Math.ceil(Number(source.contextLimit) / 2)));
        }
        for(const [key,value] of Object.entries(source)){
          if(SETTING_KEYS.has(key)) next[key] = value;
        }
        if(String(source.selfBubbleColor || "").toLowerCase() === PREVIOUS_DEFAULT_SELF_BUBBLE_COLOR){
          next.selfBubbleColor = DEFAULTS.selfBubbleColor;
        }
        CUSTOM_CSS_KEYS.forEach((key)=>{ next[key]=isolateQqCss(next[key]); });
        if(!TIMEZONES.includes(String(next.timezone||""))) next.timezone=DEFAULTS.timezone;
        if(next.customTime && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(String(next.customTime))) next.customTime="";
        next.worldBookIds = Array.isArray(source.worldBookIds) ? [...new Set(source.worldBookIds.map(String))] : [];
        next.quickCommands = Array.isArray(source.quickCommands) ? source.quickCommands.slice(0,50) : [];
        if(next.replyCustom !== true){
          next.replyCustom = false;
          next.replyMin = DEFAULT_REPLY_RANGE.min;
          next.replyMax = DEFAULT_REPLY_RANGE.max;
        }
        if(contact){
          next.realName = contact.name ?? source.realName ?? "";
          next.remarkName = contact.nickname ?? source.remarkName ?? "";
          next.contactNote = contact.note ?? source.contactNote ?? "";
          // 联系人 settingContent 是人设唯一权威源，避免聊天设置旧副本覆盖好友资料中的新设定。
          next.characterPersona = contact.settingContent ?? source.characterPersona ?? "";
        }
        return next;
      }
      async function readBoundWorldBookIds(contactId){
        const id=String(contactId||"").trim();
        if(!id)return [];
        const bindings=await db.worldBookBindings.where("conversationId").equals(id).toArray();
        const ids=Array.from(new Set(bindings
          .filter((binding)=>binding?.enabled && binding.entryId===null && String(binding.worldBookId||"").trim())
          .map((binding)=>String(binding.worldBookId).trim())));
        if(!ids.length)return [];
        const books=await db.worldBooks.bulkGet(ids);
        return ids.filter((worldBookId,index)=>books[index] && books[index].scope!=="global");
      }
      async function get(contactId){
        await ThemeCustomization.ready;
        if(window.QWQMemoryRepository?.ready) await window.QWQMemoryRepository.ready();
        const id = String(contactId || "").trim();
        if(!id) return clone(DEFAULTS);
        const [record, contact, boundWorldBookIds] = await Promise.all([
          db.chatSettings.get(id),
          window.ContactApp?.get?.(id),
          readBoundWorldBookIds(id)
        ]);
        const normalized = normalizeRecord(record, contact);
        // worldBookBindings 才是好友局部世界书关系的唯一权威源。chatSettings 中的
        // worldBookIds 只是历史 UI 镜像，禁止它覆盖好友资料页后来保存的新绑定。
        normalized.worldBookIds = boundWorldBookIds;
        const needsShapeRepair = record?.settings && Object.keys(record.settings).some(key=>key !== "coreMemory" && !SETTING_KEYS.has(key));
        const needsAccountRepair = Boolean(record && contact && record.accountId !== contact.accountId);
        const needsBubbleDefaultRepair = String(record?.settings?.selfBubbleColor || "").toLowerCase() === PREVIOUS_DEFAULT_SELF_BUBBLE_COLOR;
        const needsCssIsolationRepair = Boolean(record?.settings && CUSTOM_CSS_KEYS.some((key)=>String(record.settings[key]||"") !== String(normalized[key]||"")));
        if(record && (needsShapeRepair || needsAccountRepair || needsBubbleDefaultRepair || needsCssIsolationRepair)){
          const legacyCoreMemory = Array.isArray(record?.settings?.coreMemory) ? clone(record.settings.coreMemory) : null;
          await db.chatSettings.put({
            ...record,
            accountId:contact?.accountId || record.accountId || null,
            settings:legacyCoreMemory ? {...normalized, coreMemory:legacyCoreMemory} : normalized,
            updatedAt:Date.now()
          });
        }
        return normalized;
      }
      async function put(contactId, settings){
        if(window.QWQMemoryRepository?.ready) await window.QWQMemoryRepository.ready();
        const contact = await window.ContactApp?.get?.(contactId);
        if(!contact) throw new Error("当前好友不存在");
        const [existing, boundWorldBookIds] = await Promise.all([
          db.chatSettings.get(contact.contactId),
          readBoundWorldBookIds(contact.contactId)
        ]);
        const normalized = normalizeRecord({settings}, contact);
        // 持久化聊天设置时也只镜像当前真实 binding；任何旧设置、导入设置或无关
        // 自动保存都不得凭一份 worldBookIds 副本新增/删除好友的世界书关系。
        normalized.worldBookIds = boundWorldBookIds;
        // sharedMemory.v1 之后 coreMemory 只允许作为迁移审计冻结副本存在。
        // 常规聊天设置保存不得新增、编辑或清空该字段，避免形成双写事实源。
        const legacyCoreMemory = Array.isArray(existing?.settings?.coreMemory) ? clone(existing.settings.coreMemory) : null;
        const persistedSettings = legacyCoreMemory ? {...normalized, coreMemory:legacyCoreMemory} : normalized;
        await db.chatSettings.put({ conversationId:contact.contactId, accountId:contact.accountId, settings:persistedSettings, updatedAt:Date.now() });
        document.dispatchEvent(new CustomEvent("qwq:chat-settings-change", {detail:{contactId:contact.contactId, settings:clone(normalized)}}));
        return normalized;
      }
      function mediaSlot(key){ return `qq:chat-settings:${String(key||"")}`; }
      function releaseUrl(key){ window.QWQMediaSurface?.release?.(mediaSlot(key)); }
      async function preloadMediaSlots(keys){
        const urls=Array.from(new Set((keys||[]).map((key)=>window.QWQMediaSurface?.get?.(mediaSlot(key))).filter(Boolean)));
        if(!urls.length)return true;
        await Promise.all(urls.map((url)=>window.QWQMediaSurface?.preload?.(url) || Promise.resolve(true)));
        return true;
      }
      function cssUrl(url){ return url ? `url(${JSON.stringify(url)})` : "none"; }
      function styleNode(id){
        let node=document.getElementById(id);
        if(!node){node=document.createElement("style");node.id=id;document.head.appendChild(node);}
        return node;
      }
      function setStyleText(id,text){ styleNode(id).textContent=String(text||""); }
      const BUBBLE_COLOR_PRESETS = Object.freeze([
        "#ffffff", "#f3f4f6", "#e8eef5", "#e9f1ec", "#f4eee3", "#f2e8ec",
        "#0099ff", "#6f8fa8", "#73977f", "#b08e62", "#b27e89", "#8175a0", "#555b63"
      ]);
      function normalizeHexColor(value, fallback){
        const text=String(value||"").trim();
        if(/^#[0-9a-f]{6}$/i.test(text))return text.toLowerCase();
        if(/^#[0-9a-f]{3}$/i.test(text))return `#${text.slice(1).split("").map(ch=>ch+ch).join("")}`.toLowerCase();
        return fallback;
      }
      function contrastTextColor(value, fallback="#17181b"){
        const hex=normalizeHexColor(value,"");
        if(!hex)return fallback;
        const channels=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255).map(channel=>channel<=.03928?channel/12.92:Math.pow((channel+.055)/1.055,2.4));
        const luminance=.2126*channels[0]+.7152*channels[1]+.0722*channels[2];
        return luminance>.48?"#17181b":"#ffffff";
      }
      function resolveChatWallpaperPreset(settings){
        if(String(settings?.chatWallpaperMode||"none")!=="preset")return null;
        return ThemeCustomization.getWallpaperPreset?.(settings?.chatWallpaperPresetId) || null;
      }
      function resolveChatWallpaperBlob(settings){
        const mode=String(settings?.chatWallpaperMode||"none");
        if(mode==="custom")return settings?.chatWallpaper instanceof Blob && settings.chatWallpaper.size ? settings.chatWallpaper : null;
        if(mode==="preset")return resolveChatWallpaperPreset(settings)?.blob || null;
        return null;
      }
      function settingsMediaIdentity(kind, settings, blob, scope=""){
        if(!(blob instanceof Blob)||!blob.size)return "";
        const id=String(scope || currentContactId || "global");
        if(kind==="chat-wallpaper" && String(settings?.chatWallpaperMode||"none")==="preset"){
          return `chat-wallpaper:preset:${String(settings?.chatWallpaperPresetId||"")}`;
        }
        const field = kind==="peer-frame" ? "peerAvatarFrameAssetKey"
          : kind==="self-frame" ? "selfAvatarFrameAssetKey"
          : kind==="offline-wallpaper" ? "offlineWallpaperAssetKey"
          : "chatWallpaperAssetKey";
        const explicit=String(settings?.[field]||"").trim();
        if(explicit)return `${kind}:asset:${explicit}`;
        // 旧数据没有资源键：同一会话 + 类型 + Blob 描述作为只读迁移身份。
        // 任何新上传都会立刻获得唯一 asset key，因此不会把真正替换误认成旧图。
        return `${kind}:legacy:${id}:${blob.size}:${blob.type||"application/octet-stream"}`;
      }
      function chatWallpaperUrl(key, settings, scope=""){
        const blob=resolveChatWallpaperBlob(settings);
        if(!(blob instanceof Blob)||!blob.size){releaseUrl(key);return "";}
        return blobUrl(key,blob,settingsMediaIdentity("chat-wallpaper",settings,blob,scope));
      }

      function applyVisualVariables(target, settings, peerFrameUrl="", selfFrameUrl="", wallpaperImageUrl=""){
        if(!target||!settings)return;
        target.dataset.qwqAvatarVisibility=String(settings.avatarVisibility||"show");
        target.dataset.qwqTimestampPosition=String(settings.timestampPosition||"center");
        const peerBubbleColor=normalizeHexColor(settings.peerBubbleColor,DEFAULTS.peerBubbleColor);
        const selfBubbleColor=normalizeHexColor(settings.selfBubbleColor,DEFAULTS.selfBubbleColor);
        target.style.setProperty("--qwq-chat-peer-bubble-bg",peerBubbleColor);
        target.style.setProperty("--qwq-chat-self-bubble-bg",selfBubbleColor);
        target.style.setProperty("--qwq-chat-peer-bubble-text",contrastTextColor(peerBubbleColor,"#17181b"));
        target.style.setProperty("--qwq-chat-self-bubble-text",contrastTextColor(selfBubbleColor,"#ffffff"));
        target.style.setProperty("--qwq-chat-avatar-radius",`${Number(settings.avatarRadius ?? 50)}%`);
        target.style.setProperty("--qwq-chat-avatar-scale",String(Number(settings.avatarScale ?? 1)));
        target.style.setProperty("--qwq-chat-avatar-offset-x",`${Number(settings.avatarOffsetX ?? 0)}px`);
        target.style.setProperty("--qwq-chat-avatar-offset-y",`${Number(settings.avatarOffsetY ?? 0)}px`);
        target.style.setProperty("--qwq-chat-frame-radius",`${Number(settings.frameRadius ?? 50)}%`);
        target.style.setProperty("--qwq-chat-frame-scale",String(Number(settings.frameScale ?? 1)));
        target.style.setProperty("--qwq-chat-frame-offset-x",`${Number(settings.frameOffsetX ?? 0)}px`);
        target.style.setProperty("--qwq-chat-frame-offset-y",`${Number(settings.frameOffsetY ?? 0)}px`);
        target.style.setProperty("--qwq-chat-peer-frame-image",cssUrl(peerFrameUrl));
        target.style.setProperty("--qwq-chat-self-frame-image",cssUrl(selfFrameUrl));
        target.style.setProperty("--qwq-chat-font-scale",String(Math.max(.8,Math.min(1.6,Number(settings.chatFontSize ?? 100)/100))));
        const wallpaperCss=cssUrl(wallpaperImageUrl);
        if(target.style.getPropertyValue("--qwq-chat-wallpaper-image")!==wallpaperCss){
          target.style.setProperty("--qwq-chat-wallpaper-image",wallpaperCss);
        }
      }
      function previewCss(css){
        return String(css||"").replaceAll("#qq-chat-view","#qq-chat-settings-preview");
      }
      function applyCssFields(settings){
        const avatarCss=isolateQqCss(settings.avatarCss);
        const bubbleCss=isolateQqCss(settings.bubbleCss);
        const timestampCss=isolateQqCss(settings.timestampCss);
        const customCss=isolateQqCss(settings.customCss);
        setStyleText("qwq-chat-avatar-css",avatarCss);
        setStyleText("qwq-chat-bubble-css",bubbleCss);
        setStyleText("qwq-chat-timestamp-css",timestampCss);
        setStyleText("qwq-chat-custom-css",customCss);
        setStyleText("qwq-chat-custom-preview-css",previewCss(customCss));
      }
      function frameUrl(key, blob, identity=blob){
        if(!(blob instanceof Blob)||!blob.size){releaseUrl(key);return "";}
        return blobUrl(key,blob,identity);
      }
      function refreshBeautyPreview(){
        if(!draft)return;
        const scope=String(currentContactId||"preview");
        const peerUrl=frameUrl("preview-peer-frame",draft.peerAvatarFrame,settingsMediaIdentity("peer-frame",draft,draft.peerAvatarFrame,scope));
        const selfUrl=frameUrl("preview-self-frame",draft.selfAvatarFrame,settingsMediaIdentity("self-frame",draft,draft.selfAvatarFrame,scope));
        const wallpaperImageUrl=chatWallpaperUrl("preview-chat-wallpaper",draft,scope);
        applyVisualVariables(previewHost,draft,peerUrl,selfUrl,wallpaperImageUrl);
        applyCssFields(draft);
        const peerTime=document.getElementById("qq-chat-settings-preview-peer-time");
        const selfTime=document.getElementById("qq-chat-settings-preview-self-time");
        const position=String(draft.timestampPosition||"center");
        [["qq-chat-settings-preview-peer",peerTime],["qq-chat-settings-preview-self",selfTime]].forEach(([rowId,node])=>{
          const row=document.getElementById(rowId); if(!row||!node)return;
          if(position==="bubble-inside"){
            const bubble=row.querySelector(".qq-chat-bubble"); if(bubble&&!bubble.contains(node))bubble.appendChild(node);
          }else if(position==="avatar-under"){
            const avatar=row.querySelector(".qq-chat-avatar"); if(avatar&&node.parentElement!==avatar)avatar.appendChild(node);
          }else if(!row.contains(node))row.appendChild(node);
          else if(node.parentElement!==row)row.appendChild(node);
        });
      }
      async function persistDraft(){
        if(!currentContactId||!draft)return false;
        const snapshot=normalizeForSave(draft);
        const contactId=currentContactId;
        autoSaveChain=autoSaveChain.then(async()=>{
          // 世界书关系不参与普通聊天设置自动保存。它由 worldBookBindings 独立管理，
          // 否则改字号/状态等无关设置也可能拿旧 worldBookIds 镜像反写并清空真实绑定。
          const identityChanged=!currentContact
            || String(currentContact.name||"")!==String(snapshot.realName||"")
            || String(currentContact.nickname||"")!==String(snapshot.remarkName||"")
            || String(currentContact.note||"")!==String(snapshot.contactNote||"")
            || String(currentContact.settingContent||"")!==String(snapshot.characterPersona||"");
          const updated=identityChanged
            ? await window.ContactApp.update(contactId,{name:snapshot.realName,nickname:snapshot.remarkName,note:snapshot.contactNote,settingContent:snapshot.characterPersona})
            : currentContact;
          const persisted=await put(contactId,snapshot);
          if(currentContactId===contactId&&draft){
            draft=persisted;
            currentContact=updated||currentContact;
            await apply(contactId,draft);
            // 普通设置自动保存不得重新读取双方头像。IndexedDB 每次读取 Blob 都可能得到
            // 新对象引用，旧链路会因此撤销并重建 Object URL，造成头像解码空白帧。
            updateIdentityCopy(currentContact,currentConversationIdentity);
            refreshBeautyPreview();
            renderTabs();
            scheduleAutomation(contactId,draft);
          }
          return true;
        }).catch((error)=>{console.error("chat settings auto save failed",error);alert("自动保存失败",error?.message||"设置保存失败");return false;});
        return autoSaveChain;
      }
      function queueAutoSave(delay=220){
        if(autoSaveTimer)clearTimeout(autoSaveTimer);
        refreshBeautyPreview();
        autoSaveTimer=setTimeout(()=>{autoSaveTimer=0;void persistDraft();},Math.max(0,Number(delay)||0));
      }
      async function flushAutoSave(){
        if(autoSaveTimer){clearTimeout(autoSaveTimer);autoSaveTimer=0;await persistDraft();}
        else await autoSaveChain;
        return true;
      }
      function blobUrl(key, blob, sourceIdentity=blob){
        if(!(blob instanceof Blob)||!blob.size){releaseUrl(key);return "";}
        return window.QWQMediaSurface?.stableBlobUrl?.(mediaSlot(key),blob,sourceIdentity) || "";
      }
      function alert(title, message){ ThemeCustomization.GlobalModal.alert({title,message,confirmLabel:"知道了",action:"dismiss"}); }
      function confirmAction(config){ ThemeCustomization.GlobalModal.confirm({...config,cancelLabel:"取消"}); }
      async function copyText(text){
        const value=String(text||"");
        if(navigator.clipboard?.writeText){
          try{await navigator.clipboard.writeText(value);return true;}catch(error){console.warn("clipboard api unavailable, falling back",error);}
        }
        const textarea=document.createElement("textarea");
        textarea.value=value;textarea.setAttribute("readonly","");textarea.style.position="fixed";textarea.style.opacity="0";textarea.style.pointerEvents="none";document.body.appendChild(textarea);textarea.select();
        const copied=document.execCommand("copy");textarea.remove();return copied;
      }

      function appendChatSettingsIcon(host, name){
        if(!host)return null;
        const icon=QWQSystemUI.createIcon({provider:"fontawesome",family:"classic",style:"solid",name,format:"inline-svg"});
        if(icon)host.appendChild(icon);
        return icon;
      }

      function selectOptionLabel(field, value){
        const match=(field.options||[]).find(([optionValue])=>String(optionValue)===String(value));
        return match?.[1] ?? String(value ?? "");
      }

      function updatePickerTrigger(button, field){
        if(!button)return;
        const raw=draft?.[field.key] ?? "";
        const label=field.type==="select" ? selectOptionLabel(field,raw) : String(raw||"").replace("T"," ");
        button.replaceChildren();
        const text=document.createElement("span");
        text.className="qq-chat-settings-picker-value";
        text.textContent=label || field.placeholder || "选择";
        button.classList.toggle("is-empty",!label);
        button.appendChild(text);
        appendChatSettingsIcon(button,"chevron-down");
      }

      function openOptionPicker(field, trigger){
        const current=String(draft?.[field.key] ?? "");
        const list=document.createElement("div");
        list.className=`global-modal-list qq-chat-settings-modal-options${field.key==="voiceLanguage"?" is-voice-language-scroll global-scroll":""}`;
        (field.options||[]).forEach(([value,label])=>{
          const row=document.createElement("button");
          row.type="button";
          row.className=`global-modal-row${String(value)===current?" is-selected":""}`;
          const copy=document.createElement("span");copy.className="global-modal-row-copy";
          const name=document.createElement("span");name.className="global-modal-row-label";name.textContent=label;
          copy.appendChild(name);
          const mark=document.createElement("span");mark.className="global-modal-row-mark";mark.textContent=String(value)===current?"●":"";
          row.append(copy,mark);
          row.addEventListener("click",()=>{
            draft[field.key]=value;
            queueAutoSave(0);
            updatePickerTrigger(trigger,field);
            ThemeCustomization.GlobalModal.close();
          });
          list.appendChild(row);
        });
        ThemeCustomization.GlobalModal.open({
          title:field.label,
          message:field.desc||"",
          content:list,
          confirmLabel:"关闭",
          showCancel:false,
          size:(field.options||[]).length>9?"large":"default",
          action:"dismiss"
        });
      }

      function temporalMeta(type){
        if(type==="date")return {placeholder:"YYYY-MM-DD",max:10,pattern:/^\d{4}-\d{2}-\d{2}$/,message:"请输入 YYYY-MM-DD，例如 2000-01-01"};
        if(type==="time")return {placeholder:"HH:MM",max:5,pattern:/^(?:[01]\d|2[0-3]):[0-5]\d$/,message:"请输入 24 小时制 HH:MM，例如 23:30"};
        return {placeholder:"YYYY-MM-DD HH:MM",max:16,pattern:/^\d{4}-\d{2}-\d{2}[ T](?:[01]\d|2[0-3]):[0-5]\d$/,message:"请输入 YYYY-MM-DD HH:MM，例如 2026-08-26 13:38"};
      }

      function openTemporalPicker(field, trigger){
        const meta=temporalMeta(field.type);
        const current=String(draft?.[field.key]||"").replace("T"," ");
        ThemeCustomization.GlobalModal.prompt({
          title:field.label,
          message:meta.message,
          inputValue:current,
          inputPlaceholder:meta.placeholder,
          confirmLabel:"应用",
          cancelLabel:"取消",
          action:({input})=>{
            const value=String(input.value||"").trim();
            input.setCustomValidity("");
            if(value && !meta.pattern.test(value)){
              input.setCustomValidity(meta.message);
              input.reportValidity();
              return false;
            }
            draft[field.key]=field.type==="datetime-local"?value.replace(" ","T"):value;
            queueAutoSave(0);
            updatePickerTrigger(trigger,field);
            return true;
          }
        });
      }

      function isFieldEnabled(field){
        const rule=field?.enabledWhen;
        if(!rule)return true;
        const [key,expected]=rule;
        const value=draft?.[key];
        return typeof expected==="function" ? !!expected(value) : value===expected;
      }

      function openChatWallpaperPresetPicker(){
        const presets=ThemeCustomization.getWallpaperPresets?.() || [];
        if(!presets.length){alert("暂无壁纸预设","请先在主题 → 主屏幕壁纸中保存壁纸预设。");return false;}
        const list=document.createElement("div");
        list.className="global-modal-list qq-chat-settings-wallpaper-preset-list";
        const presetMediaSlots=[];
        const cleanup=()=>{while(presetMediaSlots.length)window.QWQMediaSurface?.release?.(presetMediaSlots.pop());};
        presets.forEach((preset)=>{
          const row=document.createElement("button");row.type="button";row.className=`global-modal-row${draft.chatWallpaperMode==="preset"&&String(draft.chatWallpaperPresetId)===String(preset.id)?" is-selected":""}`;
          const thumb=document.createElement("span");thumb.className="qq-chat-settings-wallpaper-preset-thumb";
          const mediaSlot=`qq:chat-settings:preset-thumb:${String(preset.id||"")}`;presetMediaSlots.push(mediaSlot);
          void window.QWQMediaSurface?.setBackground?.(thumb,mediaSlot,preset.blob,{identity:`preset:${String(preset.id||"")}`,className:"has-image",emptyValue:"none"});
          const copy=document.createElement("span");copy.className="global-modal-row-copy";
          const name=document.createElement("span");name.className="global-modal-row-label";name.textContent=preset.name||"壁纸预设";copy.appendChild(name);
          row.append(thumb,copy);
          row.addEventListener("click",()=>{
            draft.chatWallpaperMode="preset";draft.chatWallpaperPresetId=String(preset.id);draft.chatWallpaper=null;draft.chatWallpaperAssetKey="";
            queueAutoSave(0);renderTab();cleanup();ThemeCustomization.GlobalModal.close();
          });
          list.appendChild(row);
        });
        ThemeCustomization.GlobalModal.open({title:"壁纸预设",message:"选择主屏幕中已经保存的壁纸预设。",content:list,confirmLabel:"关闭",showCancel:false,action:()=>{cleanup();return true;}});
        const observer=new MutationObserver(()=>{if(!list.isConnected){cleanup();observer.disconnect();}});
        observer.observe(document.body,{childList:true,subtree:true});
        return true;
      }

      function createControl(field){
        const enabled=isFieldEnabled(field);
        const wrap=document.createElement("div"); wrap.className="qq-chat-settings-control";
        if(field.type === "switch"){
          const button=document.createElement("button");
          button.type="button"; button.className=`ui-switch${draft[field.key]?" is-on":""}`;
          button.disabled=!enabled;
          button.setAttribute("role","switch"); button.setAttribute("aria-checked",draft[field.key]?"true":"false");
          button.setAttribute("aria-label",field.label||"切换设置");
          button.addEventListener("click",()=>{
            draft[field.key]=!draft[field.key];
            if(field.key === "replyCustom" && draft.replyCustom !== true){
              draft.replyMin = DEFAULT_REPLY_RANGE.min;
              draft.replyMax = DEFAULT_REPLY_RANGE.max;
            }
            queueAutoSave(0);
            renderTab();
          });
          wrap.appendChild(button); return wrap;
        }
        if(field.type === "action"){
          const button=document.createElement("button"); button.type="button"; button.disabled=!enabled; button.className=`ui-action-button qq-chat-settings-action-control${field.danger?" is-danger":""}`; button.textContent=field.button||"打开"; button.dataset.qwqChatSettingsAction=field.action; wrap.appendChild(button); return wrap;
        }
        if(field.type === "frame"){
          wrap.classList.add("qq-chat-settings-frame-control");
          const upload=document.createElement("button"); upload.type="button"; upload.className="ui-action-button"; upload.textContent=draft[field.key] instanceof Blob?"替换":"上传";
          const reset=document.createElement("button"); reset.type="button"; reset.className="ui-action-button qq-chat-settings-frame-reset"; reset.textContent="重置"; reset.disabled=!(draft[field.key] instanceof Blob);
          upload.addEventListener("click",()=>{(field.side==="self"?selfFrameInput:peerFrameInput)?.click();});
          reset.addEventListener("click",()=>{draft[field.key]=null;draft[field.key==="peerAvatarFrame"?"peerAvatarFrameAssetKey":"selfAvatarFrameAssetKey"]="";queueAutoSave(0);renderTab();});
          wrap.append(upload,reset);return wrap;
        }
        if(field.type === "wallpaper"){
          wrap.classList.add("qq-chat-settings-wallpaper-control");
          const currentBlob=resolveChatWallpaperBlob(draft);
          const preview=document.createElement("span");preview.className="qq-chat-settings-wallpaper-thumb";
          if(currentBlob instanceof Blob&&currentBlob.size){void window.QWQMediaSurface?.setBackground?.(preview,mediaSlot("settings-chat-wallpaper-thumb"),currentBlob,{identity:settingsMediaIdentity("chat-wallpaper",draft,currentBlob,String(currentContactId||"preview")),className:"has-image",emptyValue:"none"});}
          const actions=document.createElement("div");actions.className="qq-chat-settings-wallpaper-actions";
          const preset=document.createElement("button");preset.type="button";preset.className="ui-action-button";preset.textContent="壁纸预设";preset.addEventListener("click",openChatWallpaperPresetPicker);
          const upload=document.createElement("button");upload.type="button";upload.className="ui-action-button";upload.textContent=draft.chatWallpaperMode==="custom"?"替换":"上传";upload.addEventListener("click",()=>wallpaperInput?.click());
          const clear=document.createElement("button");clear.type="button";clear.className="ui-action-button qq-chat-settings-wallpaper-clear";clear.textContent="清除";clear.disabled=!(currentBlob instanceof Blob&&currentBlob.size);clear.addEventListener("click",()=>{draft.chatWallpaperMode="none";draft.chatWallpaperPresetId="";draft.chatWallpaper=null;draft.chatWallpaperAssetKey="";releaseUrl("settings-chat-wallpaper-thumb");queueAutoSave(0);renderTab();});
          actions.append(preset,upload,clear);wrap.append(preview,actions);return wrap;
        }
        if(field.type === "bubble-color"){
          wrap.classList.add("qq-chat-settings-color-control");
          const presets=document.createElement("div"); presets.className="qq-chat-settings-color-presets";
          const current=normalizeHexColor(draft[field.key],field.key==="peerBubbleColor"?DEFAULTS.peerBubbleColor:DEFAULTS.selfBubbleColor);
          BUBBLE_COLOR_PRESETS.forEach((color)=>{
            const button=document.createElement("button"); button.type="button"; button.className=`qq-chat-settings-color-swatch${current===color?" is-active":""}`; button.style.setProperty("--swatch-color",color); button.setAttribute("aria-label",`使用颜色 ${color}`);
            button.addEventListener("click",()=>{draft[field.key]=color;queueAutoSave(0);renderTab();}); presets.appendChild(button);
          });
          const custom=document.createElement("label"); custom.className="qq-chat-settings-custom-color";
          const colorInput=document.createElement("input"); colorInput.type="color"; colorInput.value=current; colorInput.setAttribute("aria-label",`${field.label}自定义颜色`);
          const customCopy=document.createElement("span"); customCopy.textContent="自定义";
          colorInput.addEventListener("input",()=>{draft[field.key]=normalizeHexColor(colorInput.value,current);queueAutoSave(90);});
          colorInput.addEventListener("change",()=>{draft[field.key]=normalizeHexColor(colorInput.value,current);queueAutoSave(0);renderTab();});
          custom.append(colorInput,customCopy); wrap.append(presets,custom); return wrap;
        }
        if(field.type === "range"){
          wrap.classList.add("qq-chat-settings-range-wrap");
          const input=document.createElement("input"); input.type="range"; input.disabled=!enabled; input.className="global-range qq-chat-settings-range"; input.min=field.min; input.max=field.max; input.step=field.step||1; input.value=Number(draft[field.key] ?? field.min);
          const syncRangeProgress=()=>{
            const min=Number(input.min), max=Number(input.max), current=Number(input.value);
            const percent=max>min ? ((current-min)/(max-min))*100 : 0;
            input.style.setProperty("--range-progress",`${Math.max(0,Math.min(100,percent))}%`);
          };
          syncRangeProgress();
          const value=document.createElement("span"); value.className="qq-chat-settings-range-value"; value.textContent=`${input.value}${field.suffix||""}`;
          input.addEventListener("input",()=>{syncRangeProgress();draft[field.key]=Number(input.value);value.textContent=`${input.value}${field.suffix||""}`;queueAutoSave(90);}); wrap.append(input,value); return wrap;
        }
        if(field.type === "select" || ["date","time","datetime-local"].includes(field.type)){
          const button=document.createElement("button");
          button.type="button";
          button.disabled=!enabled;
          button.className="qq-chat-settings-picker-trigger";
          button.setAttribute("aria-haspopup","dialog");
          button.setAttribute("aria-label",field.label||"选择");
          updatePickerTrigger(button,field);
          button.addEventListener("click",()=>{
            if(field.type==="select")return openOptionPicker(field,button);
            return openTemporalPicker(field,button);
          });
          wrap.appendChild(button);
          return wrap;
        }
        let input;
        if(field.type === "textarea"){ input=document.createElement("textarea"); input.className="ui-field-textarea qq-chat-settings-textarea"; }
        else{ input=document.createElement("input"); input.type=field.type||"text"; input.className="ui-field-input qq-chat-settings-input"; if(field.min!==undefined)input.min=field.min;if(field.max!==undefined)input.max=field.max;if(field.step!==undefined)input.step=field.step; }
        input.disabled=!enabled;
        input.value=draft[field.key] ?? ""; if(field.placeholder)input.placeholder=field.placeholder;
        const update=()=>{ draft[field.key]=["number"].includes(field.type) ? (input.value===""?0:Number(input.value)) : input.value; queueAutoSave(field.type==="textarea"?260:180); };
        input.addEventListener(field.type==="textarea"?"input":"change",update); if(field.type!=="textarea")input.addEventListener("input",update);
        wrap.appendChild(input); return wrap;
      }

      function syncChatSettingsTabLayout(){
        if(view)view.dataset.qwqChatSettingsTab=currentTab;
        if(scrollHost)scrollHost.classList.toggle("is-beauty-mode",currentTab==="beauty");
        if(contentHost)contentHost.classList.toggle("is-beauty-scroll",currentTab==="beauty");
      }

      function renderTab(){
        if(!contentHost || !draft) return;
        syncChatSettingsTabLayout();
        contentHost.replaceChildren();
        const sections=FIELDS.filter(section=>section.tab===currentTab);
        sections.forEach(section=>{
          const group=document.createElement("section"); group.className="qq-chat-settings-section";
          const title=document.createElement("h3"); title.className="ui-section-title"; title.textContent=section.section; group.appendChild(title);
          const list=document.createElement("div"); list.className="ui-control-list qq-chat-settings-control-list";
          section.items.forEach(field=>{
            const isStack=field.type==="textarea" || field.type==="bubble-color" || field.type==="wallpaper";
            const isWide=field.type==="range" || field.type==="bubble-color" || field.type==="wallpaper";
            const enabled=isFieldEnabled(field);
            const row=document.createElement("div");
            row.className=`${isStack?"ui-form-row":"ui-list-row"} qq-chat-settings-field${isStack?" is-stack":""}${isWide?" has-wide-control":""}${field.danger?" is-danger":""}${enabled?"":" is-disabled"}`;
            if(field.template)row.dataset.cssField="true";
            const control=createControl(field);
            const copyHost=document.createElement("div"); copyHost.className="ui-row-copy";
            const label=document.createElement(isStack?"label":"div"); label.className=isStack?"ui-field-label":"ui-row-label"; label.textContent=field.label;
            if(field.type==="textarea"){
              const labelLine=document.createElement("div"); labelLine.className="qq-chat-settings-label-line";
              labelLine.append(label, ThemeCustomization.TextEntryUI.createFullscreenButton(control.querySelector("textarea"), field.label));
              copyHost.appendChild(labelLine);
            }else copyHost.appendChild(label);
            if(field.desc){const small=document.createElement("small");small.className="ui-row-note";small.textContent=field.desc;copyHost.appendChild(small);}
            if(field.template){
              const bar=document.createElement("div");bar.className="qq-chat-settings-template-bar";
              const copy=document.createElement("button");copy.type="button";copy.className="qq-chat-settings-copy-template";copy.textContent="复制真实 CSS 模板";
              copy.addEventListener("click",async()=>{const text=CSS_TEMPLATES[field.template]||"";try{const copied=await copyText(text);if(!copied)throw new Error("copy command rejected");copy.textContent="已复制";setTimeout(()=>{if(copy.isConnected)copy.textContent="复制真实 CSS 模板";},1200);}catch(error){console.error("copy css template failed",error);alert("复制失败","当前浏览器未允许访问剪贴板。");}});
              bar.appendChild(copy);copyHost.appendChild(bar);
            }
            row.append(copyHost,control);
            list.appendChild(row);
          });
          group.appendChild(list); contentHost.appendChild(group);
        });
        if(!sections.length){const empty=document.createElement("div");empty.className="qq-chat-settings-empty";empty.textContent="暂无设置";contentHost.appendChild(empty);}
      }

      function renderTabs(){
        if(!tabsHost) return;
        tabsHost.replaceChildren();
        tabsHost.style.setProperty("--qq-chat-settings-tab-count",String(TABS.length));
        TABS.forEach(([id,label])=>{
          const button=document.createElement("button");
          button.type="button";
          button.className=`qq-chat-settings-tab${id===currentTab?" is-active":""}`;
          button.textContent=label;
          button.dataset.tab=id;
          button.setAttribute("aria-pressed",id===currentTab?"true":"false");
          button.addEventListener("click",()=>{
            if(currentTab===id)return;
            currentTab=id;
            renderTabs();
            renderTab();
          });
          tabsHost.appendChild(button);
        });
      }

      function updateIdentityCopy(contact, conversationIdentity=currentConversationIdentity){
        if(!contact)return;
        const peerName=window.ContactApp.resolveName(contact,draft,"好友");
        const selfName=String(draft?.userName||conversationIdentity?.name||"我").trim()||"我";
        if(nameHost)nameHost.textContent=`${peerName} ＆ ${selfName}`;
      }

      function applyIdentityAvatar(host,key,blob,sourceIdentity){
        if(!host)return;
        const url=blob instanceof Blob?blobUrl(key,blob,sourceIdentity):"";
        const nextBackground=url?`url(${JSON.stringify(url)})`:"none";
        // URL 未变化时不重复写 background-image，避免无意义的样式失效与重新合成。
        if(host.style.backgroundImage!==nextBackground)host.style.backgroundImage=nextBackground;
        host.classList.toggle("has-image",Boolean(url));
      }

      async function fillIdentity(contact,{reloadAvatars=true}={}){
        if(!contact)return;
        if(reloadAvatars||!currentConversationIdentity){
          currentConversationIdentity=await window.QWQIdentityContext?.getConversationIdentity?.(contact).catch?.((error)=>{console.error("conversation identity load failed",error);return null;}) || null;
        }
        const conversationIdentity=currentConversationIdentity;
        updateIdentityCopy(contact,conversationIdentity);

        if(reloadAvatars){
          if(avatarHost){
            const peerAssetId=String(contact.avatarAssetId||"");
            const peerBlob=peerAssetId?await window.ContactApp?.getAvatarBlob?.(peerAssetId):null;
            applyIdentityAvatar(avatarHost,"settings-avatar",peerBlob,peerAssetId?`asset:${peerAssetId}`:peerBlob);
          }

          if(selfAvatarHost){
            const selfAssetId=String(conversationIdentity?.avatarAssetId||"");
            const selfBlob=conversationIdentity?.avatarBlob instanceof Blob
              ? conversationIdentity.avatarBlob
              : selfAssetId ? (await db.mediaAssets.get(selfAssetId))?.blob : null;
            applyIdentityAvatar(selfAvatarHost,"settings-self-avatar",selfBlob,selfAssetId?`asset:${selfAssetId}`:selfBlob);
          }
        }
        refreshBeautyPreview();
      }

      async function open(contactId){
        if(!view) return false;
        view.setAttribute("aria-busy","true");
        try{
          const contact=await window.ContactApp?.get?.(contactId);
          if(!contact) return false;
          currentContactId=contact.contactId; currentContact=contact; currentTab="identity"; draft=await get(contact.contactId);
          await fillIdentity(contact);
          renderTabs();
          renderTab();
          refreshBeautyPreview();
          // 只等待设置页真正拥有的六个媒体槽，禁止扫描整棵 DOM 后为每个 blob/data 再创建探针 Image。
          await preloadMediaSlots(["settings-avatar","settings-self-avatar","preview-peer-frame","preview-self-frame","preview-chat-wallpaper","settings-chat-wallpaper-thumb"]);
          if(currentContactId !== contact.contactId) return false;
          if(scrollHost) scrollHost.scrollTop=0;
          view.classList.add("is-open");
          view.setAttribute("aria-hidden","false");
          return true;
        }catch(error){
          currentContactId=null; currentContact=null; currentConversationIdentity=null; draft=null;
          releaseUrl("settings-avatar"); releaseUrl("settings-self-avatar");releaseUrl("preview-peer-frame");releaseUrl("preview-self-frame");releaseUrl("preview-chat-wallpaper");releaseUrl("settings-chat-wallpaper-thumb");
          throw error;
        }finally{
          view.removeAttribute("aria-busy");
        }
      }
      async function close(force=false){
        if(!view?.classList.contains("is-open"))return true;
        if(!force)await flushAutoSave();
        else if(autoSaveTimer){clearTimeout(autoSaveTimer);autoSaveTimer=0;}
        view.classList.remove("is-open");view.setAttribute("aria-hidden","true");currentContactId=null;currentContact=null;currentConversationIdentity=null;draft=null;
        // 关闭面板只隐藏 DOM，不销毁已经解码的媒体槽；下次打开同一资源直接命中稳定 URL。
        // 真正替换/清除资源时由 slot identity 原子换帧并回收旧 URL。
        return true;
      }

      function normalizeForSave(settings){
        const source=settings||{};
        const next=clone(source);
        // structuredClone 会产生新的 Blob 对象引用。视觉媒体本身未变化时保留原引用，
        // 使预览/真实聊天页可以稳定复用已经解码的 Object URL。
        ["peerAvatarFrame","selfAvatarFrame","chatWallpaper","offlineWallpaper"].forEach((key)=>{
          if(source[key] instanceof Blob)next[key]=source[key];
        });
        const number=(key,min,max,fallback)=>{
          const raw=Number(next[key]);
          const safe=Number.isFinite(raw)?raw:fallback;
          next[key]=Math.min(max,Math.max(min,safe));
        };
        const positiveInteger=(key,fallback)=>{
          const raw=Number(next[key]);
          next[key]=Number.isFinite(raw)&&raw>=1?Math.floor(raw):fallback;
        };
        positiveInteger("replyMin",DEFAULTS.replyMin); positiveInteger("replyMax",DEFAULTS.replyMax);
        if(next.replyMax<next.replyMin)next.replyMax=next.replyMin;
        if(next.replyCustom !== true){
          next.replyCustom = false;
          next.replyMin = DEFAULT_REPLY_RANGE.min;
          next.replyMax = DEFAULT_REPLY_RANGE.max;
        }
        number("offlineMinLength",20,5000,DEFAULTS.offlineMinLength); number("offlineMaxLength",20,10000,DEFAULTS.offlineMaxLength);
        if(next.offlineMaxLength<next.offlineMinLength)next.offlineMaxLength=next.offlineMinLength;
        next.offlineStylePreset=["default","delicate","cinematic","restrained","custom"].includes(next.offlineStylePreset)?next.offlineStylePreset:"default";
        next.offlineWritingStyle=String(next.offlineWritingStyle||"").replace(/\r\n?/g,"\n").trim();
        next.offlineNarrativePerspective=["third","second","first"].includes(next.offlineNarrativePerspective)?next.offlineNarrativePerspective:"third";
        next.offlineTimeAwareness=next.offlineTimeAwareness!==false;
        next.offlineBeautyPreset=["default","reading","immersive","compact","custom"].includes(next.offlineBeautyPreset)?next.offlineBeautyPreset:"default";
        number("offlineFontSize",80,160,DEFAULTS.offlineFontSize);
        next.offlineWallpaperMode=["none","custom","preset"].includes(next.offlineWallpaperMode)?next.offlineWallpaperMode:"none";
        next.offlineWallpaperPresetId=String(next.offlineWallpaperPresetId||"");
        next.offlineWallpaper=next.offlineWallpaper instanceof Blob&&next.offlineWallpaper.size?next.offlineWallpaper:null;
        next.offlineWallpaperAssetKey=String(next.offlineWallpaperAssetKey||"");
        if(next.offlineWallpaperMode==="custom"){next.offlineWallpaperPresetId="";if(!next.offlineWallpaper)next.offlineWallpaperMode="none";}
        else if(next.offlineWallpaperMode==="preset"){next.offlineWallpaper=null;if(!next.offlineWallpaperPresetId)next.offlineWallpaperMode="none";}
        else{next.offlineWallpaperPresetId="";next.offlineWallpaper=null;}
        next.offlineCustomCss=String(next.offlineCustomCss||"").replace(/\r\n?/g,"\n");
        number("contextRounds",1,200,DEFAULTS.contextRounds); number("summaryInterval",5,300,DEFAULTS.summaryInterval);
        number("coreMemoryLimit",0,200,DEFAULTS.coreMemoryLimit);
        next.bilingualMode = next.bilingualMode === "occasional" ? "occasional" : "all";
        number("activeInterval",1,10080,DEFAULTS.activeInterval);
        number("voiceSpeed",.5,2,DEFAULTS.voiceSpeed);
        number("avatarRadius",0,50,DEFAULTS.avatarRadius); number("avatarScale",.5,2,DEFAULTS.avatarScale);
        number("avatarOffsetX",-24,24,DEFAULTS.avatarOffsetX); number("avatarOffsetY",-24,24,DEFAULTS.avatarOffsetY);
        number("frameRadius",0,50,DEFAULTS.frameRadius); number("frameScale",.5,2,DEFAULTS.frameScale);
        number("frameOffsetX",-24,24,DEFAULTS.frameOffsetX); number("frameOffsetY",-24,24,DEFAULTS.frameOffsetY);
        number("chatFontSize",80,160,DEFAULTS.chatFontSize);
        next.enterTriggersOutput=next.enterTriggersOutput===true;
        next.chatWallpaperMode=["none","custom","preset"].includes(next.chatWallpaperMode)?next.chatWallpaperMode:"none";
        next.chatWallpaperPresetId=String(next.chatWallpaperPresetId||"");
        next.chatWallpaper=next.chatWallpaper instanceof Blob&&next.chatWallpaper.size?next.chatWallpaper:null;
        next.chatWallpaperAssetKey=String(next.chatWallpaperAssetKey||"");
        next.peerAvatarFrameAssetKey=String(next.peerAvatarFrameAssetKey||"");
        next.selfAvatarFrameAssetKey=String(next.selfAvatarFrameAssetKey||"");
        if(next.chatWallpaperMode==="custom"){next.chatWallpaperPresetId="";if(!next.chatWallpaper)next.chatWallpaperMode="none";}
        else if(next.chatWallpaperMode==="preset"){next.chatWallpaper=null;if(!next.chatWallpaperPresetId)next.chatWallpaperMode="none";}
        else{next.chatWallpaperPresetId="";next.chatWallpaper=null;}
        if(!["show","hide-peer","hide-self","hide-both"].includes(next.avatarVisibility))next.avatarVisibility="show";
        if(!["center","avatar-under","bubble-outside","bubble-inside","hidden"].includes(next.timestampPosition))next.timestampPosition="center";
        next.peerBubbleColor=normalizeHexColor(next.peerBubbleColor,DEFAULTS.peerBubbleColor);
        next.selfBubbleColor=normalizeHexColor(next.selfBubbleColor,DEFAULTS.selfBubbleColor);
        return next;
      }
      async function openChecklist(title, items, selected, onApply){
        const chosen=new Set(selected||[]);
        const content=document.createElement("div");
        const list=document.createElement("div");
        list.className="global-modal-list qq-chat-settings-modal-checklist";
        items.forEach(item=>{
          const row=document.createElement("div"); row.className="global-modal-row";
          const copy=document.createElement("span"); copy.className="global-modal-row-copy";
          const strong=document.createElement("span"); strong.className="global-modal-row-label"; strong.textContent=item.label;
          copy.appendChild(strong);
          if(item.note){const small=document.createElement("span");small.className="global-modal-row-note";small.textContent=item.note;copy.appendChild(small);}
          const toggle=document.createElement("button");toggle.type="button";toggle.className=`ui-switch${chosen.has(item.id)?" is-on":""}`;toggle.setAttribute("role","switch");toggle.setAttribute("aria-checked",chosen.has(item.id)?"true":"false");toggle.setAttribute("aria-label",`${chosen.has(item.id)?"取消选择":"选择"}${item.label}`);
          const change=()=>{const on=!chosen.has(item.id);if(on)chosen.add(item.id);else chosen.delete(item.id);toggle.classList.toggle("is-on",on);toggle.setAttribute("aria-checked",on?"true":"false");toggle.setAttribute("aria-label",`${on?"取消选择":"选择"}${item.label}`);};
          toggle.addEventListener("click",change);
          row.addEventListener("click",event=>{if(event.target.closest("button"))return;change();});
          row.append(copy,toggle);list.appendChild(row);
        });
        if(!items.length){
          const empty=document.createElement("div");empty.className="qq-chat-settings-empty";empty.textContent="暂无可选项目";content.appendChild(empty);
        }else content.appendChild(list);
        ThemeCustomization.GlobalModal.open({
          title,
          content,
          confirmLabel:"完成",
          cancelLabel:"取消",
          size:"large",
          action:async()=>{await onApply([...chosen]);return true;}
        });
      }

      async function worldbookAction(){
        const books=(await db.worldBooks.toArray()).filter(book=>book.scope!=="global");
        await openChecklist(
          "关联世界书",
          books.map(book=>({id:book.worldBookId,label:book.name,note:`${book.entryCount||""}局部世界书`})),
          draft.worldBookIds,
          async(ids)=>{
            const selected=Array.from(new Set((Array.isArray(ids)?ids:[]).map(String)));
            // 关联操作直接写唯一权威源，不再借普通设置 autosave 间接反写。
            const updated=await window.ContactApp.update(currentContactId,{worldBookIds:selected});
            currentContact=updated||currentContact;
            draft.worldBookIds=selected;
            draft=await put(currentContactId,draft);
            renderTab();
          }
        );
      }
      async function quickCommands(){
        const content=document.createElement("div");
        const list=document.createElement("div");list.className="global-modal-list";
        if(draft.quickCommands.length){
          draft.quickCommands.forEach((item,index)=>{
            const row=document.createElement("div");row.className="global-modal-row";
            const copy=document.createElement("span");copy.className="global-modal-row-copy";
            const label=document.createElement("span");label.className="global-modal-row-label";label.textContent=`${index+1}. ${item.title}`;
            const note=document.createElement("span");note.className="global-modal-row-note";note.textContent=item.content;
            copy.append(label,note);
            const remove=document.createElement("button");remove.type="button";remove.className="ui-action-button";remove.textContent="删除";remove.addEventListener("click",()=>{draft.quickCommands.splice(index,1);queueAutoSave(0);quickCommands();});
            row.append(copy,remove);list.appendChild(row);
          });
        }else{
          const row=document.createElement("div");row.className="global-modal-row";
          const copy=document.createElement("span");copy.className="global-modal-row-copy";
          const label=document.createElement("span");label.className="global-modal-row-label";label.textContent="还没有快捷指令";
          const note=document.createElement("span");note.className="global-modal-row-note";note.textContent="在下方填写标题和要插入的内容。";
          copy.append(label,note);row.appendChild(copy);list.appendChild(row);
        }
        const form=document.createElement("div");form.className="global-modal-field-stack";
        const titleInput=document.createElement("input");titleInput.className="global-modal-input";titleInput.type="text";titleInput.placeholder="指令名，例如：晚安";
        const contentInput=document.createElement("textarea");contentInput.className="ui-field-textarea";contentInput.rows=4;contentInput.placeholder="展开内容";
        form.append(titleInput,contentInput);content.append(list,form);
        ThemeCustomization.GlobalModal.open({
          title:"快捷指令",
          message:"输入 /指令名 可快速展开；可在这里新增或删除。",
          content,
          confirmLabel:"添加",
          cancelLabel:"关闭",
          size:"large",
          action:()=>{
            const title=titleInput.value.trim(),text=contentInput.value.trim();
            if(!title||!text){
              if(!title)titleInput.placeholder="请输入指令名";
              if(!text)contentInput.placeholder="请输入展开内容";
              (!title?titleInput:contentInput).focus();
              return false;
            }
            draft.quickCommands.push({id:`command-${Date.now()}`,title,content:text});
            queueAutoSave(0);
            return true;
          }
        });
      }
      function activeHistoryMode(){
        return window.QQApp?.state?.().currentView === "offline-longform" ? "offline-longform" : "online-chat";
      }
      async function messagesForExport({allModes=false}={}){
        const rows=await window.QWQChatStore.list(currentContactId, allModes ? {} : {conversationMode:activeHistoryMode()});
        return Promise.all(rows.map(async row=>({...row,mediaBlob:undefined,mediaDataUrl:row.mediaBlob instanceof Blob?await blobToDataUrl(row.mediaBlob):""})));
      }
      function blobToDataUrl(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result||""));reader.onerror=()=>reject(reader.error);reader.readAsDataURL(blob);});}
      function dataUrlToBlob(value){const match=String(value||"").match(/^data:([^;,]+)?;base64,(.*)$/s);if(!match)return null;const binary=atob(match[2]);const bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);return new Blob([bytes],{type:match[1]||"application/octet-stream"});}
      function downloadJson(name,data){window.QWQFileDownload.saveBlob(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),name);}
      function downloadText(name,text,mime="text/plain;charset=utf-8"){window.QWQFileDownload.saveBlob(new Blob([text],{type:mime}),name);}
      async function encodeQWQCardValue(value){
        if(value instanceof Blob)return {$qwqType:"blob",mime:value.type||"application/octet-stream",data:await blobToDataUrl(value)};
        if(value instanceof Date)return {$qwqType:"date",value:value.toISOString()};
        if(Array.isArray(value))return Promise.all(value.map(item=>encodeQWQCardValue(item)));
        if(value&&typeof value==="object"){
          const output={};
          for(const [key,item] of Object.entries(value))output[key]=await encodeQWQCardValue(item);
          return output;
        }
        return value;
      }
      async function exportQWQCharacterCard(){
        const exportedAt=new Date().toISOString();
        const safeName=String(nameHost?.textContent||resolveContactName(currentContact||{},null,"角色")).trim().replace(/[\\/:*?"<>|]+/g,"_").slice(0,80)||"角色";
        const card={
          $schema:"qwq://character-card/spec/1",
          qwq:{magic:"QWQCC",kind:"character-card",spec:"QWQ-CARD/1",appVersion:myPhoneConfig.version,exportedAt},
          character:{
            contact:await encodeQWQCardValue(currentContact),
            settings:await encodeQWQCardValue(draft)
          }
        };
        const body=`QWQ_CHARACTER_CARD\nSPEC:QWQ-CARD/1\nENCODING:UTF-8\n---\n${JSON.stringify(card,null,2)}\n`;
        downloadText(`QWQ_角色卡_${safeName}.qwqcard`,body,"application/x-qwq-character-card;charset=utf-8");
      }
      async function exportHistory(full=false){
        const messages=await messagesForExport({allModes:full}); const data=full?{format:"QWQConversationBackup",version:1,exportedAt:new Date().toISOString(),contact:currentContact,settings:draft,messages}:{format:"QWQChatHistory",version:1,exportedAt:new Date().toISOString(),contactId:currentContactId,conversationMode:activeHistoryMode(),messages};
        downloadJson(`QWQ_${full?"会话备份":"聊天记录"}_${nameHost.textContent}_${new Date().toISOString().slice(0,10)}.json`,data);
      }
      async function importHistoryFile(file){
        const payload=JSON.parse(await file.text()); const rows=Array.isArray(payload?.messages)?payload.messages:[]; if(!rows.length)throw new Error("文件中没有可导入的聊天记录");
        const merge=importMode==="merge";const fullBackup=payload?.format==="QWQConversationBackup";const targetMode=activeHistoryMode();const scopedRows=fullBackup?rows:rows.filter(row=>{const mode=row?.conversationMode||row?.payload?.conversationMode||payload?.conversationMode||"online-chat";return (mode==="offline-longform"?"offline-longform":"online-chat")===targetMode;});if(!scopedRows.length)throw new Error("文件中没有属于当前聊天模式的记录");confirmAction({title:merge?"合并聊天记录":"导入聊天记录",message:merge?`将保留当前记录，只合并文件中未存在的消息。文件共 ${scopedRows.length} 条。`:`将覆盖当前${targetMode==="offline-longform"?"线下":"线上"}记录并导入 ${scopedRows.length} 条消息。`,confirmLabel:merge?"合并":"导入",danger:!merge,action:async()=>{const existing=new Set(merge?(await window.QWQChatStore.list(currentContactId,fullBackup?{}:{conversationMode:targetMode})).map(row=>row.messageId):[]);if(!merge)await window.QWQChatStore.removeConversation(currentContactId,fullBackup?{}:{conversationMode:targetMode});for(const row of scopedRows){if(existing.has(row.messageId))continue;const mediaBlob=dataUrlToBlob(row.mediaDataUrl);const rowMode=fullBackup?(row.conversationMode||row.payload?.conversationMode||"online-chat"):targetMode;await window.QWQChatStore.append(currentContactId,row.role,row.text,{messageId:row.messageId,createdAt:row.createdAt,kind:row.kind,mediaBlob,payload:row.payload,conversationMode:rowMode,quote:row.quote,thinking:row.thinking,replyGroupId:row.replyGroupId,timeLabel:row.timeLabel});}if(payload.settings&&!merge){draft=normalizeRecord({settings:payload.settings},currentContact);await put(currentContactId,draft);}await window.QQApp?.openChat?.(currentContactId);close(true);return true;}});
      }
      async function handleAction(action){
        if(!draft||!currentContactId)return;
        try{
          if(action==="worldbooks")return worldbookAction(); if(action==="quick-commands")return quickCommands();
          if(action==="export-history")return exportHistory(false); if(action==="export-backup")return exportHistory(true); if(action==="import-history"){importMode="history";importInput.click();return;} if(action==="import-merge"){importMode="merge";importInput.click();return;}
          if(action==="export-character")return await exportQWQCharacterCard();
          if(action==="clear-images"){const mode=activeHistoryMode();const rows=await window.QWQChatStore.list(currentContactId,{conversationMode:mode});const ids=rows.filter(row=>["image","image_message","polaroid"].includes(row.kind)).map(row=>row.messageId);return confirmAction({title:"清空图片记录",message:`将删除当前${mode==="offline-longform"?"线下":"线上"}聊天中的 ${ids.length} 条图片消息，无法撤销。`,confirmLabel:"清空",danger:true,action:async()=>{if(ids.length)await window.QWQChatStore.removeMessages(currentContactId,ids);await window.QQApp.openChat(currentContactId);close(true);return true;}});}
          if(action==="clear-chat"){const mode=activeHistoryMode();return confirmAction({title:"清空聊天记录",message:`将永久删除当前${mode==="offline-longform"?"线下":"线上"}聊天记录，另一模式记录与共享记忆保留。`,confirmLabel:"清空",danger:true,action:async()=>{await window.QWQChatStore.removeConversation(currentContactId,{conversationMode:mode});await window.QQApp.openChat(currentContactId);close(true);return true;}});}
          if(action==="toggle-block"){draft.isBlocked=!draft.isBlocked;queueAutoSave(0);return alert(draft.isBlocked?"已拉黑":"已解除拉黑",draft.isBlocked?"将禁止双方发言，并停止后台主动消息。":"已恢复聊天。");}
          if(action==="delete-contact")return confirmAction({title:"删除好友",message:"将删除好友、人设、世界书绑定、聊天记录与本会话设置。",confirmLabel:"删除",danger:true,action:async()=>{const id=currentContactId;await window.ContactApp.delete(id);await db.chatSettings.delete(id);close(true);window.QQApp.closeChat();return true;}});
        }catch(error){console.error("chat settings action failed", error);alert("操作失败",error?.message||String(error));}
      }

      function scheduleAutomation(contactId, settings){
        const old=automationTimers.get(contactId);if(old)clearTimeout(old);automationTimers.delete(contactId);
        if(!settings.activeReply||settings.isBlocked)return;const base=Math.max(1,Number(settings.activeInterval)||60)*60000;const delay=settings.activeRandom?base*(.72+Math.random()*.56):base;
        const timer=setTimeout(async()=>{try{const latest=await get(contactId);if(latest.activeReply&&!latest.isBlocked)await window.QQApp?.triggerAiReplyFor?.(contactId,{background:true});}finally{scheduleAutomation(contactId,await get(contactId));}},delay);automationTimers.set(contactId,timer);
      }

      async function apply(contactId, supplied=null, options={}){
        if(!chatView||String(contactId)!==String(window.QQApp?.state?.().currentChatContactId||contactId))return false;
        const settings=supplied||await get(contactId);
        if(chatPresenceText)chatPresenceText.textContent=settings.statusText||(settings.isBlocked?"已拉黑":"在线");
        if(chatTitleName&&currentContact)chatTitleName.textContent=window.ContactApp.resolveName(currentContact, settings, "好友");
        const mediaScope=String(contactId||currentContactId||"active");
        const peerFrameUrl=frameUrl("active-peer-frame",settings.peerAvatarFrame,settingsMediaIdentity("peer-frame",settings,settings.peerAvatarFrame,mediaScope));
        const selfFrameUrl=frameUrl("active-self-frame",settings.selfAvatarFrame,settingsMediaIdentity("self-frame",settings,settings.selfAvatarFrame,mediaScope));
        const wallpaperImageUrl=chatWallpaperUrl("active-chat-wallpaper",settings,mediaScope);
        applyVisualVariables(chatView,settings,peerFrameUrl,selfFrameUrl,wallpaperImageUrl);
        applyCssFields(settings);
        if(options.waitForMedia===true){
          await preloadMediaSlots(["active-peer-frame","active-self-frame","active-chat-wallpaper"]);
        }
        if(options.refreshTimeline!==false){
          const stream=document.getElementById("qq-chat-stream");
          if(stream&&typeof window.QQApp?.rebuildChatTimeline==="function")window.QQApp.rebuildChatTimeline(stream);
          else document.dispatchEvent(new CustomEvent("qwq:chat-timeline-refresh",{detail:{contactId}}));
        }
        if(options.scheduleAutomation!==false)scheduleAutomation(contactId,settings);
        return true;
      }

      function ageFromBirthday(value,settings,timeAware=settings?.timeAwareness!==false){const date=new Date(value);if(Number.isNaN(date.getTime()))return "";const fixed=timeAware&&settings?.customTime?new Date(settings.customTime):null;const now=fixed&&!Number.isNaN(fixed.getTime())?fixed:new Date();let age=now.getFullYear()-date.getFullYear();if(now.getMonth()<date.getMonth()||(now.getMonth()===date.getMonth()&&now.getDate()<date.getDate()))age--;return age>=0?String(age):"";}
      function buildPromptAddon(settings, options={}){
        const conversationMode=options?.conversationMode==="offline-longform"?"offline-longform":"online-chat";
        const effectiveTimeAwareness=conversationMode==="offline-longform"?settings.offlineTimeAwareness!==false:settings.timeAwareness!==false;
        const lines=[];const push=(label,value)=>{if(value!==""&&value!==false&&value!=null)lines.push(`${label}：${value===true?"开启":value}`);};
        push("角色生日",settings.birthday);if(settings.dynamicAge&&effectiveTimeAwareness)push("角色当前年龄",ageFromBirthday(settings.birthday,settings,effectiveTimeAwareness));push("角色时区",settings.timezone);push("角色所在地",settings.location);
        if(settings.cotEnabled&&settings.cotPrompt)push("会话补充",settings.cotPrompt);
        if(settings.customSystemPrompt)push("角色专属系统指令",settings.customSystemPrompt);
        if(settings.replyCustom&&conversationMode!=="offline-longform"){
          const range=replyRange(settings);
          push("输出数量",range.min===range.max?`${range.min}条（聊天设置）`:`${range.min}-${range.max}条（聊天设置）`);
        }
        return lines.length?`<conversation_specific_settings>\n${lines.join("\n")}\n</conversation_specific_settings>`:"";
      }
      function replyRange(settings){
        if(settings?.replyCustom!==true)return {...DEFAULT_REPLY_RANGE};
        const rawMin=Number(settings.replyMin), rawMax=Number(settings.replyMax);
        const min=Number.isFinite(rawMin)&&rawMin>=1?Math.floor(rawMin):DEFAULT_REPLY_RANGE.min;
        const maxCandidate=Number.isFinite(rawMax)&&rawMax>=1?Math.floor(rawMax):DEFAULT_REPLY_RANGE.max;
        return {min,max:Math.max(min,maxCandidate)};
      }
      function defaultReplyRange(){return {...DEFAULT_REPLY_RANGE};}
      async function beforeAiRequest(contactId, options={}){const settings=await get(contactId);if(settings.isBlocked)throw new Error("当前会话已拉黑，请先在聊天设置中解除。");const conversationMode=options?.conversationMode==="offline-longform"?"offline-longform":"online-chat";if(conversationMode!=="offline-longform"&&settings.busyAutoReply&&settings.busyState!=="none"&&options.ignoreBusy!==true){const replies={busy:"[自动回复] 我现在有点忙，晚点回你。",focus:"[自动回复] 我正在专注，结束后找你。",sleep:"[自动回复] 我休息了，醒来看到会回你。"};return {skip:true,localReply:replies[settings.busyState],settings,conversationMode};}return {skip:false,settings,conversationMode};}
      async function expandQuickCommand(contactId, value){
        const text=String(value||"").trim();if(!text.startsWith("/"))return text;const settings=await get(contactId);const query=text.slice(1).trim().toLowerCase();
        const exact=(settings.quickCommands||[]).find(item=>String(item.title||"").trim().toLowerCase()===query);return exact?.content || text;
      }
      async function afterReply(contactId, options={}){
        const loader = window.QWQModuleLoader;
        if(!loader?.ensureMemoryServiceRuntime) throw new Error("记忆服务运行时加载器不可用");
        await loader.ensureMemoryServiceRuntime();
        const service = window.QWQMemoryService;
        if(!service?.afterReply) throw new Error("记忆服务运行时未完成初始化");
        return service.afterReply(contactId,options);
      }
      async function handleIncomingMessage(contactId,text){
        try{
          const settings=await get(contactId);
          if(!settings.ttsEnabled)return false;
          const loader=window.QWQModuleLoader;
          if(!loader?.ensureSettingsRuntime)return false;
          await loader.ensureSettingsRuntime();
          const settingsApp=window.SettingsApp;
          if(!settingsApp?.hasChatVoiceConfiguration||!settingsApp?.speakChatVoice)return false;
          if(!await settingsApp.hasChatVoiceConfiguration())return false;
          await settingsApp.speakChatVoice(String(text||""));
          return true;
        }catch(error){
          console.error("incoming message TTS failed", error);
          return false;
        }
      }

      view?.addEventListener("click",event=>{const action=event.target.closest?.("[data-qwq-chat-settings-action]")?.dataset.qwqChatSettingsAction;if(action)void handleAction(action);});
      view?.querySelectorAll("[data-qwq-chat-settings-close]").forEach(button=>button.addEventListener("click",()=>void close()));
      async function handleFrameFile(input,key){
        const file=input?.files?.[0]; if(input)input.value=""; if(!file||!draft)return;
        if(file.type!=="image/png"&&!/\.png$/i.test(file.name||"")){alert("头像框格式错误","头像框仅接受 PNG，透明区域会原样保留。");return;}
        try{
          const bytes=await file.arrayBuffer();
          draft[key]=new Blob([bytes],{type:"image/png"});
          const assetKeyField=key==="peerAvatarFrame"?"peerAvatarFrameAssetKey":"selfAvatarFrameAssetKey";
          draft[assetKeyField]=globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
          renderTab();queueAutoSave(0);
        }catch(error){console.error("chat frame load failed",error);alert("头像框读取失败",error?.message||"PNG 无法读取");}
      }
      peerFrameInput?.addEventListener("change",()=>void handleFrameFile(peerFrameInput,"peerAvatarFrame"));
      selfFrameInput?.addEventListener("change",()=>void handleFrameFile(selfFrameInput,"selfAvatarFrame"));
      wallpaperInput?.addEventListener("change",async()=>{
        const file=wallpaperInput.files?.[0];wallpaperInput.value="";if(!file||!draft)return;
        try{
          const blob=await ThemeCustomization.prepareImageBlob(file,{maxSide:2160,quality:.9});
          draft.chatWallpaperMode="custom";draft.chatWallpaperPresetId="";draft.chatWallpaper=blob;
          draft.chatWallpaperAssetKey=globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
          renderTab();queueAutoSave(0);
        }catch(error){console.error("chat wallpaper load failed",error);alert("聊天壁纸读取失败",error?.message||"图片无法读取");}
      });
      importInput?.addEventListener("change",async()=>{const file=importInput.files?.[0];importInput.value="";if(!file)return;try{if(importMode==="history")await importHistoryFile(file);}catch(error){console.error("chat settings import failed", error);alert("导入失败",error?.message||"文件无法读取");}});
      document.addEventListener("qwq:chat-menu-intent",event=>{const id=event.detail?.contactId;if(id)open(id).catch(error=>{console.error("chat settings open failed", error);alert("无法打开聊天设置",error?.message||String(error));});});
      document.addEventListener("qwq:chat-open",event=>{
        const id=event.detail?.contactId;
        if(!id)return;
        const supplied=event.detail?.settings;
        (supplied ? apply(id,supplied) : get(id).then(settings=>apply(id,settings))).catch(console.error);
      });
      let automationBootstrapStarted = false;
      function activateAutomations(){
        if(automationBootstrapStarted) return true;
        automationBootstrapStarted = true;
        const bootstrapAutomations = ()=>ThemeCustomization.ready.then(async()=>{
          const contacts = await window.ContactApp.list();
          for(const contact of contacts){
            const settings = await get(contact.contactId);
            scheduleAutomation(contact.contactId,settings);
          }
        }).catch((error)=>{
          automationBootstrapStarted = false;
          console.error("chat settings automation initialization failed",error);
        });
        if(window.QWQLifecycle?.idle) window.QWQLifecycle.idle(bootstrapAutomations,{timeout:1800});
        else window.setTimeout(bootstrapAutomations,80);
        return true;
      }

      return Object.freeze({open,close,get,put,apply,activateAutomations,buildPromptAddon,replyRange,defaultReplyRange,beforeAiRequest,expandQuickCommand,afterReply,handleIncomingMessage,isBlocked:async id=>(await get(id)).isBlocked,state:()=>({contactId:currentContactId,tab:currentTab,autoSaving:Boolean(autoSaveTimer)})});
    })();
    window.QWQChatSettings = QWQChatSettings;



    const QQAccountIdentityController = (() => {
      const { createSection, appendSectionContent, createActionButton } = ThemeCustomization.DrawerUI;
      let activeAccountId = null;
      let activeIdentity = null;
      let activeAvatarUrl = null;
      let activeAvatarRevision = 0;

      function normalizeText(value, maxLength = Number.POSITIVE_INFINITY) {
        const text = String(value ?? "").replace(/\r\n?/g, "\n").trim();
        return Number.isFinite(maxLength) ? text.slice(0, maxLength) : text;
      }

      function resolveName(account = activeIdentity) {
        return normalizeText(account?.nickname || account?.name) || "^ω^";
      }

      function applyAvatarNode(node, url) {
        if (!node) return;
        node.style.backgroundImage = url ? `url(${JSON.stringify(url)})` : "none";
      }

      async function applyActiveProfile(account, accountId = account?.accountId || null) {
        const revision = ++activeAvatarRevision;
        activeAccountId = accountId || null;
        activeIdentity = account || null;
        const nickname = resolveName(account);
        document.querySelectorAll("#page-qq-app .qq-side-name").forEach((node) => { node.textContent = nickname; });
        const qqState = window.QQApp?.state?.();
        const headerTitle = document.getElementById("qq-header-title");
        if (headerTitle && (!qqState || qqState.currentTab === "messages")) headerTitle.textContent = nickname;

        const blob = account?.avatarBlob instanceof Blob
          ? account.avatarBlob
          : await QQAccountStore.mediaBlob(account?.avatarAssetId || null);
        if (revision !== activeAvatarRevision || activeAccountId !== (accountId || null)) return false;
        const avatarIdentity = account?.avatarAssetId ? `asset:${account.avatarAssetId}` : blob;
        activeAvatarUrl = blob instanceof Blob && blob.size
          ? (await window.QWQMediaSurface?.prepareBlobSlot?.("qq:account:active-avatar", blob, avatarIdentity) || "")
          : null;
        if (!activeAvatarUrl) window.QWQMediaSurface?.release?.("qq:account:active-avatar");
        applyAvatarNode(document.querySelector("#page-qq-app .qq-header-avatar"), activeAvatarUrl);
        applyAvatarNode(document.querySelector("#page-qq-app .qq-side-avatar"), activeAvatarUrl);
        document.dispatchEvent(new CustomEvent("qwq:qq-account-identity-refresh", {
          detail: {
            accountId: activeAccountId,
            identity: account ? {
              nickname: account.nickname || "",
              name: resolveName(account),
              settingContent: account.persona || "",
              avatarAssetId: account.avatarAssetId || null
            } : null
          }
        }));
        return true;
      }

      async function refreshActive() {
        await QQAccountStore.ensureInitialized();
        const accountId = await QQAccountStore.getActiveAccountId();
        if (!accountId) {
          activeAccountId = null;
          activeIdentity = null;
          return applyActiveProfile(null, null);
        }
        // QQ launch/header only needs the account avatar. The potentially much larger
        // profile cover is fetched later by the side/profile surface that owns it.
        const account = await QQAccountStore.get(accountId, { withMedia:"avatar" });
        if (!account) throw new Error("当前QQ账号不存在");
        await applyActiveProfile(account, accountId);
        return account;
      }

      async function openEditor(accountId = null) {
        await QQAccountStore.ensureInitialized();
        const id = String(accountId || await QQAccountStore.getActiveAccountId() || "").trim();
        if (!id) throw new Error("QQ账号不存在");
        const current = await QQAccountStore.get(id, { withMedia:false });
        if (!current) throw new Error("QQ账号不存在");

        return ThemeCustomization.GlobalDrawer.open({
          type: "qq-account-persona:edit",
          title: "编辑资料",
          async render() {
            const host = document.getElementById("theme-drawer-body");
            const documentInput = document.createElement("input");
            documentInput.type = "file";
            documentInput.accept = ".docx,.txt,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain";
            documentInput.className = "theme-hidden-input";
            document.body.appendChild(documentInput);
            const cleanup = () => { documentInput.remove(); };

            const profileSection = createSection("基础资料");
            const createProfileField=(labelText,value,placeholder)=>{
              const row=document.createElement("label"); row.className="ui-form-row";
              const label=document.createElement("span"); label.className="ui-field-label"; label.textContent=labelText;
              const input=document.createElement("input"); input.type="text"; input.className="ui-field-input"; input.value=String(value||""); input.placeholder=placeholder;
              row.append(label,input); return {row,input};
            };
            const realName=createProfileField("姓名",current.name,"输入姓名");
            const nickname=createProfileField("昵称",current.nickname,"输入昵称");
            profileSection.append(realName.row,nickname.row);

            const settingSection = createSection("面具设定");
            const settingRow = document.createElement("div");
            settingRow.className = "contact-setting-row";
            const settingHeading = document.createElement("div");
            settingHeading.className = "contact-setting-heading";
            const settingLabel = document.createElement("label");
            settingLabel.className = "ui-field-label";
            settingLabel.textContent = "设定内容";
            const setting = document.createElement("textarea");
            setting.id = uid("qq-account-persona-setting");
            setting.className = "ui-field-textarea";
            setting.placeholder = "输入当前QQ账号的面具设定，或从 DOCX / TXT 导入";
            setting.value = current.persona || "";
            settingLabel.htmlFor = setting.id;
            settingHeading.append(settingLabel, ThemeCustomization.TextEntryUI.createFullscreenButton(setting, "设定内容"));
            settingRow.append(settingHeading, setting);
            settingSection.appendChild(settingRow);

            const actionSection = createSection("面具操作");
            const actionRow = document.createElement("div");
            actionRow.className = "ui-action-row";
            const importDocument = createActionButton("导入文档", "file-import");
            const saveProfile = createActionButton("保存面具", "pen", "is-primary");
            actionRow.append(importDocument, saveProfile);
            appendSectionContent(actionSection, actionRow);
            host.append(profileSection, settingSection, actionSection);

            importDocument.addEventListener("click", () => documentInput.click());
            documentInput.addEventListener("change", async () => {
              const file = documentInput.files?.[0];
              documentInput.value = "";
              if (!file) return;
              importDocument.disabled = true;
              try {
                const imported = await QWQDocumentText.extract(file);
                const incoming = normalizeText(imported);
                if (!incoming) throw new Error("文档中没有可导入的文本");
                const existing = setting.value.trim();
                setting.value = existing ? `${existing}\n\n${incoming}` : incoming;
                setting.dispatchEvent(new Event("input", { bubbles:true }));
              } catch (error) {
                ThemeCustomization.GlobalModal.alert({ title:"文档导入失败", message:error?.message || "文档无法读取。", confirmLabel:"知道了", action:"dismiss" });
              } finally {
                importDocument.disabled = false;
              }
            });

            saveProfile.addEventListener("click", async () => {
              saveProfile.disabled = true;
              try {
                const saved = await QQAccountStore.save(id, { name:realName.input.value, nickname:nickname.input.value, persona:setting.value });
                if (id === activeAccountId) await applyActiveProfile(saved, id);
                cleanup();
                ThemeCustomization.GlobalDrawer.close();
              } catch (error) {
                saveProfile.disabled = false;
                ThemeCustomization.GlobalModal.alert({ title:"面具保存失败", message:error?.message || "数据无法保存。", confirmLabel:"知道了", action:"dismiss" });
              }
            });

            const observer = new MutationObserver(() => {
              if (!host.contains(profileSection)) {
                observer.disconnect();
                cleanup();
              }
            });
            observer.observe(host, { childList:true });
          }
        });
      }

      async function ensureInitialized() {
        await QQAccountStore.ensureInitialized();
        await refreshActive();
        return true;
      }

      return Object.freeze({
        openEditor,
        refreshActive,
        ensureInitialized,
        getActive: async () => {
          await ensureInitialized();
          return activeAccountId ? QQAccountStore.get(activeAccountId, { withMedia:false }) : null;
        },
        getCachedActive: () => activeAccountId && activeIdentity
          ? { accountId: activeAccountId, identity: activeIdentity }
          : null,
        activeName: () => resolveName(activeIdentity),
        activeSettingContent: () => String(activeIdentity?.persona || "")
      });
    })();
    window.QQAccountIdentityController = QQAccountIdentityController;