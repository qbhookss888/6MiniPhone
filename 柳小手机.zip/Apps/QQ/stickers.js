const StickerLibraryApp = (() => {
  const db = ThemeCustomization.db;
  const { createActionButton } = ThemeCustomization.DrawerUI;
  const page = document.getElementById("page-sticker-library");
  const groupPage = document.getElementById("page-sticker-group");
  const titleButton = document.getElementById("sticker-page-title");
  const groupTitleButton = document.getElementById("sticker-group-title");
  const actionButton = document.getElementById("sticker-page-action");
  const groupActionButton = document.getElementById("sticker-group-action");
  const menu = document.getElementById("sticker-page-menu");
  const groupMenu = document.getElementById("sticker-group-menu");
  const list = document.getElementById("sticker-page-list");
  const groupList = document.getElementById("sticker-group-list");
  const importInput = document.getElementById("sticker-import-file-input");

  let currentGroupId = null;
  let libraryManageMode = false;
  let groupManageMode = false;
  let importRunning = false;
  let importContextGroupId = null;
  const selectedGroupIds = new Set();
  const selectedStickerIds = new Set();

  function uid(prefix) {
    const raw = globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
    return `${prefix}-${raw}`;
  }
  function cleanText(value, max = Number.POSITIVE_INFINITY) {
    const text = String(value ?? "").replace(/\r\n?/g, "\n").trim();
    const finiteLimit = Number(max);
    return Number.isFinite(finiteLimit) && finiteLimit > 0 ? text.slice(0, finiteLimit) : text;
  }
  function cleanName(value) { return cleanText(value).replace(/\s+/g, " "); }
  function normalizeName(value) { return cleanName(value).toLocaleLowerCase("zh-CN"); }
  function cleanUrl(value) {
    let raw = cleanText(value)
      .replace(/&amp;/gi, "&")
      .replace(/^[\s<'"([{]+/g, "")
      .replace(/[\s>'"\])}，,；;。！!？?]+$/g, "");
    if (!raw) return "";
    if (raw.startsWith("//")) raw = `https:${raw}`;
    try {
      const url = new URL(raw);
      return ["http:", "https:"].includes(url.protocol) ? url.href : "";
    } catch (error) { console.error("sticker URL normalization failed", error); return ""; }
  }
  function extractStickerUrl(value) {
    const text = cleanText(value);
    if (!text) return "";
    const patterns = [
      /<img\b[^>]*?\bsrc\s*=\s*["'](https?:\/\/[^"']+)["'][^>]*>/i,
      /!\[[^\]]*\]\(\s*(https?:\/\/[^\s)]+)(?:\s+["'][^"']*["'])?\s*\)/i,
      /\[img\]\s*(https?:\/\/[^\s[]+)\s*\[\/img\]/i,
      /(https?:\/\/[^\s<>"']+)/i
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      const url = cleanUrl(match?.[1] || match?.[0] || "");
      if (url) return url;
    }
    return "";
  }
  function stickerDescriptionHint(value) {
    const text = cleanText(value);
    const markdown = text.match(/!\[([^\]]*)\]\(/);
    if (markdown?.[1]) return cleanText(markdown[1]);
    const htmlAlt = text.match(/<img\b[^>]*?\balt\s*=\s*["']([^"']+)["']/i);
    if (htmlAlt?.[1]) return cleanText(htmlAlt[1]);
    return "";
  }
  function descriptionFromUrl(url, fallbackIndex = 1) {
    try {
      const path = decodeURIComponent(new URL(url).pathname || "");
      const file = path.split("/").filter(Boolean).pop() || "";
      const base = file.replace(/\.[a-z0-9]{1,8}$/i, "").replace(/[_-]+/g, " ").trim();
      if (base) return base;
    } catch (error) { console.error("sticker URL description parse failed", error); }
    return `表情 ${fallbackIndex}`;
  }

  function stickerSourceUrl(value) {
    const raw = typeof value === "string" ? value : value?.url;
    return cleanUrl(raw);
  }

  function normalizeStickerRecord(value) {
    const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const url = stickerSourceUrl(source);
    const description = cleanText(source.description || (url ? descriptionFromUrl(url, 1) : "表情")) || "表情";
    return { ...source, url, description };
  }

  // 唯一表情资源链：数据库 stickerId -> canonical sticker record -> canonical URL -> <img>。
  // 不切换 Referer 策略、不重试第二来源、不从消息 payload 恢复 URL。
  const stickerMedia = Object.freeze({
    normalizeUrl: stickerSourceUrl,
    normalizeRecord: normalizeStickerRecord,
    createImage(sticker, { alt = "", eager = true } = {}) {
      const normalized = normalizeStickerRecord(typeof sticker === "string" ? { url: sticker } : sticker);
      if (!normalized.url) throw new Error("表情资源 URL 无效");
      const image = document.createElement("img");
      image.alt = alt || normalized.description || "表情";
      image.loading = eager ? "eager" : "lazy";
      image.decoding = "async";
      image.draggable = false;
      image.referrerPolicy = "no-referrer";
      // 延后一个 microtask 再赋 src，仅用于保证调用方先完成 load/error 监听器注册；不是重试链。
      queueMicrotask(() => { void window.QWQMediaSurface?.setImage?.(image, `qq:sticker:${normalized.stickerId || normalized.url}`, normalized.url, {identity:normalized.url,alt:normalized.description || "表情包"}); });
      return image;
    }
  });

  const repository = Object.freeze({
    async listGroups() {
      await ThemeCustomization.databaseReady;
      const groups = await db.stickerGroups.toArray();
      return groups.sort((a, b) => Number(a.createdAt || 0) - Number(b.createdAt || 0));
    },
    async getGroup(groupId) {
      await ThemeCustomization.databaseReady;
      return db.stickerGroups.get(String(groupId || ""));
    },
    async createGroup(name) {
      await ThemeCustomization.databaseReady;
      const clean = cleanName(name);
      if (!clean) throw new Error("请输入分组名称");
      const duplicate = await db.stickerGroups.filter((group) => normalizeName(group.name) === normalizeName(clean)).first();
      if (duplicate) throw new Error("分组名称已存在");
      const now = Date.now();
      const group = { groupId: uid("sticker-group"), name: clean, createdAt: now, updatedAt: now };
      await db.stickerGroups.add(group);
      return group;
    },
    async ensureGroup(name) {
      const clean = cleanName(name) || "默认分组";
      const existing = await db.stickerGroups.filter((group) => normalizeName(group.name) === normalizeName(clean)).first();
      return existing || this.createGroup(clean);
    },
    async renameGroup(groupId, name) {
      const clean = cleanName(name);
      if (!clean) throw new Error("请输入分组名称");
      const duplicate = await db.stickerGroups.filter((group) => normalizeName(group.name) === normalizeName(clean)).first();
      if (duplicate && duplicate.groupId !== groupId) throw new Error("分组名称已存在");
      const changed = await db.stickerGroups.update(groupId, { name: clean, updatedAt: Date.now() });
      if (!changed) throw new Error("分组不存在");
      return db.stickerGroups.get(groupId);
    },
    async deleteGroups(groupIds) {
      const ids = Array.from(new Set((Array.isArray(groupIds) ? groupIds : [groupIds]).map(String).filter(Boolean)));
      if (!ids.length) return 0;
      await db.transaction("rw", db.stickerGroups, db.stickers, async () => {
        for (const id of ids) await db.stickers.where("groupId").equals(id).delete();
        await db.stickerGroups.bulkDelete(ids);
      });
      return ids.length;
    },
    async listStickers(groupId) {
      await ThemeCustomization.databaseReady;
      const rows = await db.stickers.where("groupId").equals(String(groupId || "")).sortBy("createdAt");
      return rows.map(normalizeStickerRecord);
    },
    async getSticker(stickerId) {
      await ThemeCustomization.databaseReady;
      const sticker = await db.stickers.get(String(stickerId || ""));
      return sticker ? normalizeStickerRecord(sticker) : null;
    },
    async listStickerCatalog(limit = 80) {
      await ThemeCustomization.databaseReady;
      const max = Math.max(1, Math.min(200, Number.parseInt(limit, 10) || 80));
      const groups = await this.listGroups();
      const groupNames = new Map(groups.map((group) => [group.groupId, group.name]));
      const rows = await db.stickers.orderBy("createdAt").reverse().limit(max).toArray();
      return rows.reverse()
        .map(normalizeStickerRecord)
        .filter((sticker) => Boolean(sticker.url))
        .map((sticker) => ({ ...sticker, groupName: groupNames.get(sticker.groupId) || "未分组" }));
    },
    async countStickers(groupId) {
      await ThemeCustomization.databaseReady;
      return db.stickers.where("groupId").equals(String(groupId || "")).count();
    },
    async previewStickers(groupId, limit = 4) {
      const rows = await this.listStickers(groupId);
      return rows.slice(0, Math.max(1, limit));
    },
    async addStickers(groupId, items) {
      await ThemeCustomization.databaseReady;
      const group = await db.stickerGroups.get(String(groupId || ""));
      if (!group) throw new Error("目标分组不存在");
      const normalized = [];
      const localUrls = new Set();
      for (const item of items || []) {
        const url = cleanUrl(item?.url);
        if (!url || localUrls.has(url)) continue;
        localUrls.add(url);
        normalized.push({ url, description: cleanText(item?.description || descriptionFromUrl(url, normalized.length + 1)) });
      }
      if (!normalized.length) throw new Error("没有解析到有效表情 URL");
      const existing = await db.stickers.where("groupId").equals(group.groupId).toArray();
      const existingUrls = new Set(existing.map((item) => cleanUrl(item.url)).filter(Boolean));
      const now = Date.now();
      const records = normalized.filter((item) => !existingUrls.has(item.url)).map((item, index) => ({
        stickerId: uid("sticker"),
        groupId: group.groupId,
        url: item.url,
        description: item.description || descriptionFromUrl(item.url, index + 1),
        createdAt: now + index,
        updatedAt: now + index
      }));
      if (records.length) await db.stickers.bulkAdd(records);
      await db.stickerGroups.update(group.groupId, { updatedAt: Date.now() });
      return { added: records.length, skipped: normalized.length - records.length, records };
    },
    async deleteStickers(stickerIds) {
      const ids = Array.from(new Set((Array.isArray(stickerIds) ? stickerIds : [stickerIds]).map(String).filter(Boolean)));
      if (!ids.length) return 0;
      const records = (await db.stickers.bulkGet(ids)).filter(Boolean);
      await db.stickers.bulkDelete(ids);
      const groupIds = new Set(records.map((item) => item.groupId));
      for (const groupId of groupIds) await db.stickerGroups.update(groupId, { updatedAt: Date.now() });
      return ids.length;
    },
    async moveStickers(stickerIds, groupId) {
      const ids = Array.from(new Set((stickerIds || []).map(String).filter(Boolean)));
      const target = await db.stickerGroups.get(String(groupId || ""));
      if (!target) throw new Error("目标分组不存在");
      if (!ids.length) return 0;
      await db.stickers.where("stickerId").anyOf(ids).modify({ groupId: target.groupId, updatedAt: Date.now() });
      return ids.length;
    },
    async exportAll() {
      const groups = await this.listGroups();
      const stickers = await db.stickers.toArray();
      return {
        format: "QWQStickerLibrary",
        version: 1,
        exportedAt: new Date().toISOString(),
        groups: groups.map((group) => ({
          name: group.name,
          stickers: stickers.filter((item) => item.groupId === group.groupId).map((item) => ({ url: item.url, description: item.description }))
        }))
      };
    }
  });

  function parseStickerLine(line, fallbackIndex = 1) {
    const value = cleanText(line);
    if (!value) return null;
    const url = extractStickerUrl(value);
    if (!url) return null;
    const hinted = stickerDescriptionHint(value);
    const plain = value
      .replace(/<img\b[^>]*>/ig, " ")
      .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
      .replace(/\[img\][\s\S]*?\[\/img\]/ig, " ")
      .replace(/https?:\/\/[^\s<>"']+/ig, " ")
      .replace(/[：:\-—|]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    const description = hinted || cleanText(plain) || descriptionFromUrl(url, fallbackIndex);
    return { url, description };
  }

  function parseStickerText(text) {
    const lines = String(text || "").replace(/\r\n?/g, "\n").split("\n");
    const items = [];
    const seen = new Set();
    lines.forEach((line, index) => {
      const parsed = parseStickerLine(line, index + 1);
      if (!parsed || seen.has(parsed.url)) return;
      seen.add(parsed.url);
      items.push(parsed);
    });
    return items;
  }

  function jsonItemToSticker(item, index) {
    if (typeof item === "string") return parseStickerLine(item, index + 1);
    if (!item || typeof item !== "object" || Array.isArray(item)) return null;
    const url = extractStickerUrl(item.url || item.src || item.image || item.imageUrl || item.link);
    if (!url) return null;
    return {
      url,
      description: cleanText(item.description || item.desc || item.name || item.title || item.label || descriptionFromUrl(url, index + 1))
    };
  }

  function parseJsonPayload(payload) {
    const grouped = [];
    const loose = [];
    const addLoose = (items) => {
      (Array.isArray(items) ? items : []).forEach((item, index) => {
        const sticker = jsonItemToSticker(item, index);
        if (sticker) loose.push(sticker);
      });
    };
    const addGroup = (name, items) => {
      const stickers = [];
      (Array.isArray(items) ? items : []).forEach((item, index) => {
        const sticker = jsonItemToSticker(item, index);
        if (sticker) stickers.push(sticker);
      });
      if (stickers.length) grouped.push({ name: cleanName(name) || "导入分组", stickers });
    };

    if (Array.isArray(payload)) addLoose(payload);
    else if (payload && typeof payload === "object") {
      if (Array.isArray(payload.groups)) {
        payload.groups.forEach((group, index) => addGroup(group?.name || group?.title || `分组 ${index + 1}`, group?.stickers || group?.items || group?.emojis || []));
      }
      if (Array.isArray(payload.stickers)) addLoose(payload.stickers);
      if (Array.isArray(payload.items)) addLoose(payload.items);
      if (!grouped.length && !loose.length) {
        Object.entries(payload).forEach(([name, value]) => { if (Array.isArray(value)) addGroup(name, value); });
      }
    }
    const dedupe = (items) => Array.from(new Map(items.map((item) => [item.url, item])).values());
    grouped.forEach((group) => { group.stickers = dedupe(group.stickers); });
    return { groups: grouped, stickers: dedupe(loose) };
  }

  async function parseImportFile(file) {
    const name = String(file?.name || "").toLowerCase();
    if (name.endsWith(".json") || file?.type === "application/json") {
      const text = QWQDocumentText.decodeBytes(new Uint8Array(await file.arrayBuffer()));
      return { type: "json", ...parseJsonPayload(JSON.parse(text)) };
    }
    if (QWQDocumentText.fileKind(file)) return { type: "text", text: await QWQDocumentText.extract(file, { allowLegacyDoc: true }) };
    throw new Error("仅支持 DOCX、DOC、TXT、JSON 文件");
  }

  function icon(name) {
    const node = document.createElement("i");
    node.dataset.lucide = name;
    node.setAttribute("aria-hidden", "true");
    return node;
  }
  function makeMenuItem(label, iconName, action) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "sticker-library-menu-item";
    button.append(icon(iconName), document.createTextNode(label));
    button.addEventListener("click", action);
    return button;
  }
  function closeMenus() {
    [menu, groupMenu].forEach((node) => { if (node) node.hidden = true; });
    actionButton?.setAttribute("aria-expanded", "false");
    groupActionButton?.setAttribute("aria-expanded", "false");
  }
  function toggleMenu(node, button) {
    const nextHidden = !node.hidden;
    closeMenus();
    node.hidden = nextHidden;
    button.setAttribute("aria-expanded", nextHidden ? "false" : "true");
  }
  function clearToolbars() {
    page?.querySelector(".sticker-manage-toolbar")?.remove();
    groupPage?.querySelector(".sticker-manage-toolbar")?.remove();
    list?.classList.remove("has-management-toolbar");
    groupList?.classList.remove("has-management-toolbar");
  }
  function createSelectionCheck(selected, className) {
    const check = document.createElement("span");
    check.className = `${className} qwq-selection-check`;
    check.setAttribute("aria-hidden", "true");
    check.classList.toggle("is-selected", selected === true);
    return check;
  }
  function syncSelectionCheck(check, selected) {
    check?.classList.toggle("is-selected", selected === true);
  }
  function syncLibrarySelectionUi(groups) {
    list?.querySelectorAll(".sticker-pack-card[data-sticker-group-id]").forEach((card) => {
      const selected = selectedGroupIds.has(card.dataset.stickerGroupId);
      card.classList.toggle("is-selected", selected);
      card.setAttribute("aria-pressed", selected ? "true" : "false");
      syncSelectionCheck(card.querySelector(".sticker-pack-select"), selected);
    });
    if (!libraryManageMode) return;
    const current = page?.querySelector(".sticker-manage-toolbar");
    const next = createLibraryToolbar(groups);
    if (current) current.replaceWith(next); else page?.appendChild(next);
    window.QWQIcons?.hydrate(next);
  }
  function syncGroupSelectionUi(stickers) {
    groupList?.querySelectorAll(".sticker-item-card[data-sticker-id]").forEach((card) => {
      const selected = selectedStickerIds.has(card.dataset.stickerId);
      card.classList.toggle("is-selected", selected);
      card.setAttribute("aria-pressed", selected ? "true" : "false");
      syncSelectionCheck(card.querySelector(".sticker-item-select"), selected);
    });
    if (!groupManageMode) return;
    const current = groupPage?.querySelector(".sticker-manage-toolbar");
    const next = createGroupToolbar(stickers);
    if (current) current.replaceWith(next); else groupPage?.appendChild(next);
    window.QWQIcons?.hydrate(next);
  }
  function showEmpty(host, message) {
    const empty = document.createElement("p");
    empty.className = "sticker-empty";
    empty.textContent = message;
    host.replaceChildren(empty);
  }
  function showError(title, error) {
    console.error(`sticker module error: ${title}`, error);
    ThemeCustomization.GlobalModal.alert({
      title,
      message: error?.message || "操作未完成。",
      confirmLabel: "知道了",
      action: "dismiss"
    });
  }

  function createStickerImage(sticker, options = {}) {
    return stickerMedia.createImage(sticker, options);
  }

  function createPackPreview(previews) {
    const preview = document.createElement("div");
    preview.className = "sticker-pack-preview";
    const sticker = Array.isArray(previews) ? previews[0] : null;
    if (sticker?.url) {
      const image = createStickerImage(sticker, { alt:"", eager:true });
      image.addEventListener("error", () => {
        preview.classList.add("is-empty");
        image.remove();
        const placeholder = document.createElement("i");
        placeholder.dataset.lucide = "image";
        placeholder.setAttribute("aria-hidden", "true");
        preview.appendChild(placeholder);
        window.QWQIcons?.hydrate(preview);
      }, { once: true });
      preview.appendChild(image);
    } else {
      preview.classList.add("is-empty");
      const placeholder = document.createElement("i");
      placeholder.dataset.lucide = "image";
      placeholder.setAttribute("aria-hidden", "true");
      preview.appendChild(placeholder);
    }
    return preview;
  }

  async function renderLibrary() {
    closeMenus();
    clearToolbars();
    currentGroupId = null;
    titleButton.textContent = "Stickers.";
    const groups = await repository.listGroups();
    const active = new Set(groups.map((group) => group.groupId));
    Array.from(selectedGroupIds).forEach((id) => { if (!active.has(id)) selectedGroupIds.delete(id); });
    if (!groups.length && !libraryManageMode) {
      showEmpty(list, "暂无表情包分组。点击右上角添加分组，或导入 DOCX / DOC / TXT / JSON。");
      return true;
    }
    const grid = document.createElement("section");
    grid.className = "sticker-pack-grid";
    grid.setAttribute("aria-label", "表情包分组");
    const groupStats = await Promise.all(groups.map((group)=>Promise.all([
      repository.countStickers(group.groupId),
      repository.previewStickers(group.groupId, 1)
    ])));
    for (let groupIndex = 0; groupIndex < groups.length; groupIndex += 1) {
      const group = groups[groupIndex];
      const [count, previews] = groupStats[groupIndex];
      const card = document.createElement("button");
      card.type = "button";
      card.className = "sticker-pack-card";
      card.dataset.stickerGroupId = group.groupId;
      card.classList.toggle("is-selected", selectedGroupIds.has(group.groupId));
      card.setAttribute("aria-pressed", selectedGroupIds.has(group.groupId) ? "true" : "false");
      card.setAttribute("aria-label", `${group.name}，${count} 个表情`);
      card.appendChild(createPackPreview(previews));
      const info = document.createElement("span");
      info.className = "sticker-pack-info";
      const name = document.createElement("span");
      name.className = "sticker-pack-name";
      name.textContent = group.name;
      const meta = document.createElement("span");
      meta.className = "sticker-pack-count";
      meta.textContent = `${count} 个表情`;
      info.append(name, meta);
      card.appendChild(info);
      if (libraryManageMode) {
        card.appendChild(createSelectionCheck(selectedGroupIds.has(group.groupId), "sticker-pack-select"));
      }
      card.addEventListener("click", () => {
        if (libraryManageMode) {
          if (selectedGroupIds.has(group.groupId)) selectedGroupIds.delete(group.groupId); else selectedGroupIds.add(group.groupId);
          syncLibrarySelectionUi(groups);
          return;
        }
        openGroup(group.groupId).catch((error) => showError("分组无法打开", error));
      });
      grid.appendChild(card);
    }
    list.replaceChildren(grid);
    void window.QWQLifecycle?.waitForLocalImages?.(list);
    if (libraryManageMode) {
      page.appendChild(createLibraryToolbar(groups));
      list.classList.add("has-management-toolbar");
    }
    list.scrollTop = 0;
    window.QWQIcons?.hydrate(page);
    return true;
  }

  function createLibraryToolbar(groups) {
    const toolbar = document.createElement("section");
    toolbar.className = "sticker-manage-toolbar";
    toolbar.setAttribute("aria-label", "管理表情包分组");
    const allSelected = groups.length > 0 && groups.every((group) => selectedGroupIds.has(group.groupId));
    const selectAll = createActionButton(allSelected ? "取消" : "全选", "check-check");
    const rename = createActionButton("改名", "pen");
    const remove = createActionButton("删除", "trash-2", "is-danger");
    const finish = createActionButton("完成", "x");
    rename.disabled = selectedGroupIds.size !== 1;
    remove.disabled = selectedGroupIds.size === 0;
    selectAll.addEventListener("click", () => {
      selectedGroupIds.clear();
      if (!allSelected) groups.forEach((group) => selectedGroupIds.add(group.groupId));
      syncLibrarySelectionUi(groups);
    });
    rename.addEventListener("click", async () => {
      const group = await repository.getGroup(Array.from(selectedGroupIds)[0]);
      if (group) openRenameGroupPrompt(group);
    });
    remove.addEventListener("click", () => {
      const ids = Array.from(selectedGroupIds);
      ThemeCustomization.GlobalModal.confirm({
        title: "删除表情包分组",
        message: `确认删除已选择的 ${ids.length} 个分组？其中的表情也会一并删除。`,
        confirmLabel: "删除",
        cancelLabel: "取消",
        danger: true,
        action: async () => {
          await repository.deleteGroups(ids);
          selectedGroupIds.clear();
          libraryManageMode = false;
          await renderLibrary();
          return true;
        }
      });
    });
    finish.addEventListener("click", () => {
      selectedGroupIds.clear();
      libraryManageMode = false;
      renderLibrary().catch((error) => showError("目录刷新失败", error));
    });
    toolbar.append(selectAll, rename, remove, finish);
    return toolbar;
  }

  async function openGroup(groupId) {
    currentGroupId = String(groupId || "");
    groupManageMode = false;
    selectedStickerIds.clear();
    Router.push("page-sticker-group");
    await window.QWQLifecycle?.afterNextPaint?.();
    await renderGroup();
    if(!currentGroupId) return false;
    return true;
  }

  async function renderGroup() {
    closeMenus();
    clearToolbars();
    const group = await repository.getGroup(currentGroupId);
    if (!group) {
      currentGroupId = null;
      Router.back("page-sticker-library");
      return renderLibrary();
    }
    groupTitleButton.textContent = group.name;
    const stickers = await repository.listStickers(group.groupId);
    const active = new Set(stickers.map((item) => item.stickerId));
    Array.from(selectedStickerIds).forEach((id) => { if (!active.has(id)) selectedStickerIds.delete(id); });
    if (!stickers.length && !groupManageMode) {
      showEmpty(groupList, "该分组暂无表情。点击右上角添加，或导入 DOCX / DOC / TXT / JSON。");
      return true;
    }
    const directory = document.createElement("section");
    directory.className = "sticker-group-directory";
    directory.setAttribute("aria-label", `${group.name} 表情`);
    stickers.forEach((sticker) => {
      const card = document.createElement("button");
      card.type = "button";
      card.className = "sticker-item-card";
      card.dataset.stickerId = sticker.stickerId;
      card.classList.toggle("is-selected", selectedStickerIds.has(sticker.stickerId));
      card.setAttribute("aria-pressed", selectedStickerIds.has(sticker.stickerId) ? "true" : "false");
      card.setAttribute("aria-label", sticker.description || "表情");
      const preview = document.createElement("span");
      preview.className = "sticker-item-preview";
      const image = createStickerImage(sticker, { alt:sticker.description || "表情", eager:true });
      image.addEventListener("error",()=>{
        image.remove(); preview.classList.add("is-empty");
        const placeholder=document.createElement("i"); placeholder.className="fa-solid fa-image"; placeholder.setAttribute("aria-hidden","true"); preview.appendChild(placeholder);
      },{once:true});
      preview.appendChild(image);
      const label = document.createElement("span");
      label.className = "sticker-item-name";
      label.textContent = sticker.description || "表情";
      card.append(preview, label);
      if (groupManageMode) {
        card.appendChild(createSelectionCheck(selectedStickerIds.has(sticker.stickerId), "sticker-item-select"));
      }
      card.addEventListener("click", () => {
        if (groupManageMode) {
          if (selectedStickerIds.has(sticker.stickerId)) selectedStickerIds.delete(sticker.stickerId); else selectedStickerIds.add(sticker.stickerId);
          syncGroupSelectionUi(stickers);
          return;
        }
        openStickerInfo(sticker);
      });
      directory.appendChild(card);
    });
    groupList.replaceChildren(directory);
    void window.QWQLifecycle?.waitForLocalImages?.(groupList);
    if (groupManageMode) {
      groupPage.appendChild(createGroupToolbar(stickers));
      groupList.classList.add("has-management-toolbar");
    }
    groupList.scrollTop = 0;
    window.QWQIcons?.hydrate(groupPage);
    return true;
  }

  function createGroupToolbar(stickers) {
    const toolbar = document.createElement("section");
    toolbar.className = "sticker-manage-toolbar";
    toolbar.setAttribute("aria-label", "管理表情");
    const allSelected = stickers.length > 0 && stickers.every((item) => selectedStickerIds.has(item.stickerId));
    const selectAll = createActionButton(allSelected ? "取消" : "全选", "check-check");
    const move = createActionButton("移动", "folder-input");
    const remove = createActionButton("删除", "trash-2", "is-danger");
    const finish = createActionButton("完成", "x");
    move.disabled = selectedStickerIds.size === 0;
    remove.disabled = selectedStickerIds.size === 0;
    selectAll.addEventListener("click", () => {
      selectedStickerIds.clear();
      if (!allSelected) stickers.forEach((item) => selectedStickerIds.add(item.stickerId));
      syncGroupSelectionUi(stickers);
    });
    move.addEventListener("click", () => openMovePrompt(Array.from(selectedStickerIds)));
    remove.addEventListener("click", () => {
      const ids = Array.from(selectedStickerIds);
      ThemeCustomization.GlobalModal.confirm({
        title: "删除表情",
        message: `确认删除已选择的 ${ids.length} 个表情？`,
        confirmLabel: "删除",
        cancelLabel: "取消",
        danger: true,
        action: async () => {
          await repository.deleteStickers(ids);
          selectedStickerIds.clear();
          groupManageMode = false;
          await renderGroup();
          return true;
        }
      });
    });
    finish.addEventListener("click", () => {
      selectedStickerIds.clear();
      groupManageMode = false;
      renderGroup().catch((error) => showError("分组刷新失败", error));
    });
    toolbar.append(selectAll, move, remove, finish);
    return toolbar;
  }

  function openCreateGroupPrompt() {
    closeMenus();
    ThemeCustomization.GlobalModal.prompt({
      title: "添加表情包分组",
      inputPlaceholder: "分组名称",
      confirmLabel: "保存",
      action: async ({ input }) => {
        try {
          await repository.createGroup(input.value);
          libraryManageMode = false;
          selectedGroupIds.clear();
          await renderLibrary();
          return true;
        } catch (error) {
          console.error("sticker group create failed", error);
          input.setCustomValidity(error?.message || "分组无法创建");
          input.reportValidity();
          input.addEventListener("input", () => input.setCustomValidity(""), { once: true });
          return false;
        }
      }
    });
  }
  function openRenameGroupPrompt(group) {
    ThemeCustomization.GlobalModal.prompt({
      title: "修改分组名称",
      inputValue: group.name,
      inputPlaceholder: "分组名称",
      confirmLabel: "保存",
      action: async ({ input }) => {
        try {
          await repository.renameGroup(group.groupId, input.value);
          selectedGroupIds.clear();
          libraryManageMode = false;
          await renderLibrary();
          return true;
        } catch (error) {
          console.error("sticker group rename failed", error);
          input.setCustomValidity(error?.message || "名称无法修改");
          input.reportValidity();
          input.addEventListener("input", () => input.setCustomValidity(""), { once: true });
          return false;
        }
      }
    });
  }

  function openBulkAdd(groupId = currentGroupId) {
    closeMenus();
    let textarea = null;
    let errorNode = null;
    ThemeCustomization.GlobalModal.open({
      title: "添加表情",
      message: "每行一个表情，支持 4 种描述格式。",
      confirmLabel: "添加",
      cancelLabel: "取消",
      size: "large",
      content(host) {
        const help = document.createElement("p");
        help.className = "sticker-import-help";
        help.textContent = "支持直链、图床 Markdown、<img src>、[img]URL[/img]，每行一个表情。";
        textarea = document.createElement("textarea");
        textarea.className = "sticker-bulk-input";
        textarea.placeholder = "https://example.com/a.png\n![开心](https://example.com/b.gif)\n<img src=\"https://example.com/c.webp\" alt=\"无语\">";
        textarea.spellcheck = false;
        const preview = document.createElement("div");
        preview.className = "sticker-image-host-preview";
        const renderPreview = () => {
          preview.replaceChildren();
          const items = parseStickerText(textarea.value).slice(0, 8);
          if (!items.length) { preview.hidden = true; return; }
          preview.hidden = false;
          items.forEach((item) => {
            const cell = document.createElement("span"); cell.className = "sticker-image-host-preview-cell";
            cell.appendChild(createStickerImage(item, { alt:item.description || "表情预览", eager:true }));
            preview.appendChild(cell);
          });
        };
        errorNode = document.createElement("p");
        errorNode.className = "sticker-import-error";
        textarea.addEventListener("input", () => { if (errorNode) errorNode.textContent = ""; renderPreview(); });
        host.append(help, textarea, preview, errorNode);
      },
      action: async () => {
        const items = parseStickerText(textarea?.value || "");
        if (!items.length) {
          if (errorNode) errorNode.textContent = "没有识别到有效 URL，请按上方任一种格式每行填写一个表情。";
          textarea?.focus();
          return false;
        }
        try {
          const result = await repository.addStickers(groupId, items);
          if (!result.added && result.skipped) {
            if (errorNode) errorNode.textContent = "这些 URL 已全部存在于当前分组。";
            return false;
          }
          groupManageMode = false;
          selectedStickerIds.clear();
          if (currentGroupId === groupId) await renderGroup(); else await renderLibrary();
          return true;
        } catch (error) {
          console.error("sticker add failed", error);
          if (errorNode) errorNode.textContent = error?.message || "添加失败";
          return false;
        }
      }
    });
    window.setTimeout(() => textarea?.focus(), 80);
  }

  function openStickerInfo(sticker) {
    ThemeCustomization.GlobalModal.open({
      title: sticker.description || "表情",
      message: sticker.url,
      confirmLabel: "关闭",
      showCancel: false,
      size: "small",
      content(host) {
        const image = createStickerImage(sticker, { alt:sticker.description || "表情", eager:true });
        image.className = "sticker-modal-preview";
        host.appendChild(image);
      },
      action: "dismiss"
    });
  }

  async function openMovePrompt(stickerIds) {
    const groups = (await repository.listGroups()).filter((group) => group.groupId !== currentGroupId);
    if (!groups.length) {
      ThemeCustomization.GlobalModal.alert({ title: "没有其他分组", message: "请先创建另一个表情包分组。", confirmLabel: "知道了", action: "dismiss" });
      return;
    }
    let select = null;
    ThemeCustomization.GlobalModal.open({
      title: "移动表情",
      message: `移动已选择的 ${stickerIds.length} 个表情。`,
      confirmLabel: "移动",
      cancelLabel: "取消",
      content(host) {
        const row = document.createElement("label");
        row.className = "ui-form-row";
        const label = document.createElement("span");
        label.className = "ui-field-label";
        label.textContent = "目标分组";
        select = document.createElement("select");
        select.className = "ui-field-select";
        groups.forEach((group) => {
          const option = document.createElement("option");
          option.value = group.groupId;
          option.textContent = group.name;
          select.appendChild(option);
        });
        row.append(label, select);
        host.appendChild(row);
      },
      action: async () => {
        await repository.moveStickers(stickerIds, select?.value);
        selectedStickerIds.clear();
        groupManageMode = false;
        await renderGroup();
        return true;
      }
    });
  }

  function waitModalAnimation() {
    const raw = Number.parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--global-modal-transition-duration"));
    return new Promise((resolve) => window.setTimeout(resolve, (Number.isFinite(raw) ? raw : .2) * 1000 + 36));
  }
  async function requestTargetGroup(filename) {
    const groups = await repository.listGroups();
    if (!groups.length) return repository.createGroup(cleanName(filename.replace(/\.(docx?|txt|json)$/i, "")) || "导入分组");
    if (groups.length === 1) return groups[0];
    return new Promise((resolve) => {
      let select = null;
      ThemeCustomization.GlobalModal.open({
        title: "选择导入分组",
        message: cleanName(filename),
        confirmLabel: "继续",
        cancelLabel: "取消",
        content(host) {
          const row = document.createElement("label");
          row.className = "ui-form-row";
          const label = document.createElement("span");
          label.className = "ui-field-label";
          label.textContent = "目标分组";
          select = document.createElement("select");
          select.className = "ui-field-select";
          groups.forEach((group) => {
            const option = document.createElement("option");
            option.value = group.groupId;
            option.textContent = group.name;
            select.appendChild(option);
          });
          row.append(label, select);
          host.appendChild(row);
        },
        action: () => {
          const group = groups.find((item) => item.groupId === select?.value) || groups[0];
          resolve(group);
          return true;
        },
        cancelAction: () => resolve(null)
      });
    });
  }

  async function importParsedIntoTarget(parsed, file, forcedGroupId = null) {
    let added = 0;
    let skipped = 0;
    if (!forcedGroupId && parsed.groups?.length) {
      for (const parsedGroup of parsed.groups) {
        const group = await repository.ensureGroup(parsedGroup.name);
        const result = await repository.addStickers(group.groupId, parsedGroup.stickers);
        added += result.added;
        skipped += result.skipped;
      }
      if (parsed.stickers?.length) {
        const target = await requestTargetGroup(file.name);
        if (!target) return { added, skipped, cancelled: true };
        await waitModalAnimation();
        const result = await repository.addStickers(target.groupId, parsed.stickers);
        added += result.added;
        skipped += result.skipped;
      }
      return { added, skipped };
    }
    const items = parsed.type === "text" ? parseStickerText(parsed.text) : [...(parsed.stickers || []), ...(parsed.groups || []).flatMap((group) => group.stickers || [])];
    if (!items.length) throw new Error("文件中没有解析到有效表情 URL");
    const target = forcedGroupId ? await repository.getGroup(forcedGroupId) : await requestTargetGroup(file.name);
    if (!target) return { added: 0, skipped: 0, cancelled: true };
    if (!forcedGroupId) await waitModalAnimation();
    const result = await repository.addStickers(target.groupId, items);
    return { added: result.added, skipped: result.skipped };
  }

  async function handleImport(files, forcedGroupId = importContextGroupId) {
    if (importRunning || !files.length) return false;
    importRunning = true;
    let added = 0;
    let skipped = 0;
    const failures = [];
    let cancelled = false;
    try {
      for (const file of files) {
        try {
          const parsed = await parseImportFile(file);
          const result = await importParsedIntoTarget(parsed, file, forcedGroupId);
          added += result.added || 0;
          skipped += result.skipped || 0;
          if (result.cancelled) { cancelled = true; break; }
        } catch (error) {
          console.error("sticker import file failed", file?.name, error);
          failures.push(`${file.name}: ${error?.message || "无法导入"}`);
        }
      }
      if (currentGroupId) await renderGroup(); else await renderLibrary();
      if (!cancelled || added || failures.length) {
        const summary = [`新增 ${added} 个表情`];
        if (skipped) summary.push(`跳过 ${skipped} 个重复项`);
        if (failures.length) summary.push(`失败 ${failures.length} 个文件：${failures.join("；")}`);
        ThemeCustomization.GlobalModal.alert({
          title: failures.length ? "导入完成（部分失败）" : "导入完成",
          message: summary.join("；"),
          confirmLabel: "知道了",
          action: "dismiss"
        });
      }
      return true;
    } finally {
      importRunning = false;
      importContextGroupId = null;
    }
  }

  function triggerImport(groupId = null) {
    closeMenus();
    importContextGroupId = groupId;
    importInput?.click();
  }

  function initializeMenus() {
    [actionButton, groupActionButton].forEach((button) => {
      const plus = document.createElement("i");
      plus.className = "fa-solid fa-plus";
      plus.setAttribute("aria-hidden", "true");
      button.replaceChildren(plus);
      button.setAttribute("aria-haspopup", "menu");
      button.setAttribute("aria-expanded", "false");
    });
    menu.replaceChildren(
      makeMenuItem("添加分组", "plus", openCreateGroupPrompt),
      makeMenuItem("导入表情", "file-input", () => triggerImport(null)),
      makeMenuItem("管理分组", "folder-cog", () => {
        closeMenus();
        libraryManageMode = true;
        selectedGroupIds.clear();
        renderLibrary().catch((error) => showError("管理模式无法打开", error));
      })
    );
    groupMenu.replaceChildren(
      makeMenuItem("添加表情", "plus", () => openBulkAdd(currentGroupId)),
      makeMenuItem("导入表情", "file-input", () => triggerImport(currentGroupId)),
      makeMenuItem("管理表情", "list-checks", () => {
        closeMenus();
        groupManageMode = true;
        selectedStickerIds.clear();
        renderGroup().catch((error) => showError("管理模式无法打开", error));
      })
    );
  }

  async function open() {
    window.QQApp?.closeSide?.();
    currentGroupId = null;
    libraryManageMode = false;
    groupManageMode = false;
    selectedGroupIds.clear();
    selectedStickerIds.clear();
    await ThemeCustomization.databaseReady;
    Router.push("page-sticker-library");
    await window.QWQLifecycle?.afterNextPaint?.();
    return renderLibrary();
  }
  function close() {
    currentGroupId = null;
    libraryManageMode = false;
    groupManageMode = false;
    selectedGroupIds.clear();
    selectedStickerIds.clear();
    clearToolbars();
    closeMenus();
    return true;
  }

  function closePicker() {
    ThemeCustomization.GlobalDrawer.close();
    return true;
  }

  async function openPicker({ onSelect } = {}) {
    await ThemeCustomization.databaseReady;
    const groups = await repository.listGroups();
    if (!groups.length) {
      ThemeCustomization.GlobalModal.confirm({
        title: "暂无表情包",
        message: "先到表情包页创建分组并添加表情。",
        confirmLabel: "去添加",
        cancelLabel: "取消",
        action: () => {
          ThemeCustomization.GlobalDrawer.close();
          open().catch((error) => showError("表情包页无法打开", error));
          return true;
        }
      });
      return false;
    }
    let activeGroupId = groups[0].groupId;
    return ThemeCustomization.GlobalDrawer.open({
      type: "sticker-picker",
      title: "表情包",
      async render() {
        const host = document.getElementById("theme-drawer-body");
        const tabs = document.createElement("div");
        tabs.className = "sticker-picker-tabs";
        const grid = document.createElement("div");
        grid.className = "sticker-picker-grid";
        const renderItems = async () => {
          tabs.querySelectorAll(".sticker-picker-tab").forEach((button) => button.classList.toggle("is-active", button.dataset.groupId === activeGroupId));
          grid.replaceChildren();
          const stickers = await repository.listStickers(activeGroupId);
          if (!stickers.length) {
            const empty = document.createElement("p");
            empty.className = "sticker-empty";
            empty.textContent = "该分组暂无表情";
            grid.appendChild(empty);
            return;
          }
          stickers.forEach((sticker) => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "sticker-picker-item";
            button.setAttribute("aria-label", sticker.description || "表情");
            const image = createStickerImage(sticker, { alt:sticker.description || "表情", eager:true });
            const label = document.createElement("span");
            label.textContent = sticker.description || "表情";
            button.append(image, label);
            button.addEventListener("click", async () => {
              button.disabled = true;
              try {
                const result = await onSelect?.(sticker);
                if (result !== false) ThemeCustomization.GlobalDrawer.close();
              } finally { button.disabled = false; }
            });
            grid.appendChild(button);
          });
        };
        groups.forEach((group) => {
          const button = document.createElement("button");
          button.type = "button";
          button.className = "sticker-picker-tab";
          button.dataset.groupId = group.groupId;
          button.textContent = group.name;
          button.addEventListener("click", () => { activeGroupId = group.groupId; renderItems().catch((error) => showError("表情加载失败", error)); });
          tabs.appendChild(button);
        });
        host.append(tabs, grid);
        await renderItems();
      }
    });
  }

  initializeMenus();
  actionButton?.addEventListener("click", (event) => { event.stopPropagation(); toggleMenu(menu, actionButton); });
  groupActionButton?.addEventListener("click", (event) => { event.stopPropagation(); toggleMenu(groupMenu, groupActionButton); });
  titleButton?.addEventListener("click", () => {
    Router.back("page-qq-app");
    void (window.QWQLifecycle?.afterNextPaint?.() || Promise.resolve()).then(() => close());
  });
  groupTitleButton?.addEventListener("click", () => {
    Router.back("page-sticker-library");
    void (window.QWQLifecycle?.afterNextPaint?.() || Promise.resolve()).then(() => {
      currentGroupId = null;
      groupManageMode = false;
      selectedStickerIds.clear();
      return renderLibrary();
    }).catch((error) => showError("目录刷新失败", error));
  });
  importInput?.addEventListener("change", () => {
    const files = Array.from(importInput.files || []);
    importInput.value = "";
    handleImport(files, importContextGroupId).catch((error) => showError("导入失败", error));
  });
  document.addEventListener("click", (event) => {
    if (!menu?.hidden && !menu.contains(event.target) && !actionButton.contains(event.target)) closeMenus();
    if (!groupMenu?.hidden && !groupMenu.contains(event.target) && !groupActionButton.contains(event.target)) closeMenus();
  });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeMenus(); });
  document.addEventListener("qwq:qq-side-action", (event) => {
    if (event.detail?.action !== "表情包") return;
    open().catch((error) => showError("表情包页无法打开", error));
  });

  window.StickerRepository = repository;
  return Object.freeze({ open, close, openPicker, closePicker, render: renderLibrary, repository, media:stickerMedia, parseStickerLine, parseStickerText, parseImportFile });
})();
window.StickerLibraryApp = StickerLibraryApp;